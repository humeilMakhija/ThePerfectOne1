df = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/humeil/max_comp_edges_overlapping_with_external_group_assigned")

G2 = df.filter(df.src_external_group == 'G2').filter(df.dst_external_group == 'G2')
G2.write.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/edges/")


pyspark --conf spark.sql.shuffle.partitions=5000 --packages graphframes:graphframes:0.8.0-spark2.4-s_2.12

pyspark --conf spark.sql.shuffle.partitions=5000 --packages graphframes:graphframes:0.8.0-spark2.4-s_2.11

from pyspark.sql.functions import *
from graphframes import *


G2 = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/edges/") 
edges = G2.select(col("src_long_id").alias("src"),col("dst_long_id").alias("dst"))
vertices = edges.select(col("src").alias("id")).union(edges.select(col("dst").alias("id")).distinct())

edges.distinct().write.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/edges_filtered/")
vertices.distinct().write.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/vertices_filtered/")


edges = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/edges_filtered/")
vertices = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/vertices_filtered/")


G = GraphFrame(vertices , edges)
G_new = G.dropIsolatedVertices()

sc.setCheckpointDir("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/checkpoint/")

G_CC = G_new.connectedComponents(algorithm = "graphframes", checkpointInterval = 2, broadcastThreshold = 100000)
G_CC.write.mode("overwrite").parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/component/")

G_CC = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/component/")

vertices_types = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/data/long_int_vertex")

G_CC_type = G_CC.join(vertices_types, G_CC.id == vertices_types.long_id).select(G_CC["id"],"types", "component")
G_CC_type.write.mode("overwrite").parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/component_with_type")


G_CC_type = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/component_with_type")

#check skewness
G_CC_type_skewness = G_CC_type.groupby("component").agg(collect_list("types").alias("type"))
G_CC_type_distribution = G_CC_type_skewness.rdd.map(lambda x: (x["component"], size(col("type")))).toDF(["comp", "len"])

G_CC_type_distribution = G_CC_type_skewness.withColumn('length_col2', size(col("type")))



#read vertex type data


G_CC_type.groupby("component").count().orderBy("count", ascending = False).show()


#filter vertex with cid = 4 
#decission 1
#cleaning require for all cc > 25k 

G_CC_big = G_CC_type.filter(G_CC_type["component"] ==4)
#418336653

edges = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/edges_filtered/")

edge_src_join = edges.join(G_CC_big, G_CC_big.id == edges.src).select(col("component").alias("src_comp"),"src", "dst")

edge_src_dst_join = edge_src_join.join(G_CC_big, G_CC_big.id == edge_src_join.dst).select("src_comp","src","dst",col("component").alias("dst_comp"))

edge_src_dst_join.filter(col("src_comp") == col("dst_comp")).write.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/G2_big_edges")

edge_src_dst_join = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/G2_big_edges")
#983247613

similarities = edge_src_dst_join.rdd.map(lambda x: tuple((x["src"] , x["dst"] , float(1.0))))
similarities = similarities.repartition(2000)

from pyspark.mllib.clustering import PowerIterationClustering, PowerIterationClusteringModel

# heat and trial to  know number of iterration and cluster k 
# DECISSION k = 19 to 20 iteration : 30 to 40 on 300m data set 
model = PowerIterationClustering.train(similarities , 20 , 10)


data_res = model.assignments().toDF(["id" , "cluster"])   

data_res.write.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/G2_big_cc_vertex_with_pic")



res = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/G2_big_cc_vertex_with_pic")

edge_src_dst_join = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/G2_big_edges")

edges = edge_src_dst_join.select("src","dst")



edge_src_clust = edges.join(res, res.id == edges.src).select(col("cluster").alias("src_clust"),"src", "dst")

edge_src_dst_clust = edge_src_clust.join(res, res.id == edges.dst).select("src_clust","src", "dst",col("cluster").alias("dst_clust"))


edge_src_dst_clust.filter(col("src_clust") == col("dst_clust")).count()





community_edges = edge_src_dst_clust.filter(col("src_clust") == col("dst_clust"))
non_community_edges = edge_src_dst_clust.filter(col("src_clust") != col("dst_clust"))

community_edges.write.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/community_edges") 
#g1 > all vertice s from communiy edge 

non_community_edges.write.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/non_community_edges") 
#g2  > all vertices froin non community edges 


#community edges 
community_edges = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/community_edges") 


vertices = community_edges.select("src").union(community_edges.select("dst")).distinct()
vertices = vertices.select(col("src").alias("id"))
edge = community_edges.select("src","dst")
G = GraphFrame(vertices , edge)
G_new = G.dropIsolatedVertices()

sc.setCheckpointDir("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/checkpoint_new/")

G_CC = G_new.connectedComponents(algorithm = "graphframes", checkpointInterval = 2, broadcastThreshold = 100000)

G_CC.show()
G_CC.write.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/community/")

G_CC = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/community/")

# make sure to remove edges that are from  from g1 to g2  if src vertex is a part of community edge and dst is not 
#g1 edges in community group 
#g2 all edges in non communioty group  

#community edges 
non_community_edges = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/non_community_edges") 


vertices = non_community_edges.select("src").union(non_community_edges.select("dst")).distinct()
vertices = vertices.select(col("src").alias("id"))
edge = non_community_edges.select("src","dst")
G = GraphFrame(vertices , edge)
G_new = G.dropIsolatedVertices()

sc.setCheckpointDir("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/checkpoint_new_nc/")

G_CC = G_new.connectedComponents(algorithm = "graphframes", checkpointInterval = 2, broadcastThreshold = 100000)

G_CC.show()
G_CC.write.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/non_community/")

#analyse 
community = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/community/")

non_community = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/non_community/")


# non commiunity component id 4 has some issue 
# remove community to non community edge

community = community.rdd.map(lambda x : (x["id"], str("com"))).toDF(["id","com"])
non_community = non_community.rdd.map(lambda x : (x["id"], str("non_com"))).toDF(["id","com"])

#point 1 remove edge from com to non_com

big_cc_vertex = community.union(non_community)
#456994105
big_cc_vertex.distinct().count()
#456994105


#load second level cc


non_community_edges = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/non_community_edges") 

edges = non_community_edges.select("src","dst")

non_community = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/non_community/")                                                         
vertices = non_community.filter(col("component") == 4)


edges_filtered = edges.join(vertices, vertices.id == edges.src).select("src","dst").join(vertices, vertices.id == edges.src).select("src","dst")

edges_filtered.write.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/edge_filter_second_phase/")

edges_filtered = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/edge_filter_second_phase/")

#719036740


df = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/humeil/max_comp_edges_overlapping_with_external_group_assigned")

G2 = df.filter(df.src_external_group == 'G2').filter(df.dst_external_group == 'G2')






G2_edge = G2.select("src_long_id","dst_long_id","src_component", "dst_component")

G2_edge.filter(col("src_component") == col("dst_component") ).count()

community = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/community/")

non_community = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/non_community/")


# non commiunity component id 4 has some issue 
# remove community to non community edge

community = community.rdd.map(lambda x : (x["id"], str("com"))).toDF(["id","com"])
non_community = non_community.rdd.map(lambda x : (x["id"], str("non_com"))).toDF(["id","com"])

#point 1 remove edge from com to non_com

big_cc_vertex = community.union(non_community)


first_clean = G2_edge.join(big_cc_vertex, big_cc_vertex.id == G2_edge.src_long_id).select([col("com").alias("src_com"),"src_long_id","dst_long_id","src_component", "dst_component"]).join(big_cc_vertex, big_cc_vertex.id == G2_edge.dst_long_id).select(["src_com","src_long_id","dst_long_id","src_component", "dst_component", col("com").alias("dst_com")])


first_clean.write.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/first_clean/")


first_clean = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/first_clean/")



first_clean.filter(first_clean.src_com == first_clean.dst_com)

#read whole edge 
G2 = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/edges/") 


G2= G2.select(col("src_long_id").alias("src"), col("dst_long_id").alias("dst"))

edges_filtered = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/edge_filter_second_phase/")


second_phase_edge = first_clean.join(edges_filtered, [edges_filtered.src == first_clean.src_long_id , edges_filtered.dst == first_clean.dst_long_id]).select(["src","dst","src_component", "dst_component"])

second_phase_edge.write.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/second_phase_edges/")

second_phase_edge = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/second_phase_edges/")

new_edges = second_phase_edge.filter(col("src_component") == col("dst_component"))

vertices = new_edges.select("src").union(new_edges.select("dst")).select(col("src").alias("id")).distinct()
edges = new_edges.select(["src","dst"])


from graphframes import *

G = GraphFrame(vertices , edges)

sc.setCheckpointDir("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/checkpoint_scnd_phase/")

G_second_CC = G.connectedComponents(algorithm = "graphframes", checkpointInterval = 2, broadcastThreshold = 100000)

G_second_CC.write.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/second_phase_cc/")



G_second_CC = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/second_phase_cc/")


#take vertices that are part of more than 10 k 
cc_ids = G_second_CC.groupby("component").count().filter(col("count")> 10000)


vertices = G_second_CC.join(cc_ids, cc_ids.component == G_second_CC.component ).select("id")
#third level edge cleaning 
edge = edges.join(vertices, [vertices.id == edges.src, vertices.id ==edges.src])


#third level edge and vertex 
vertices.write.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/third_level_vertex")
edge.write.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/third_level_edge")




vertices = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/third_level_vertex")

edges = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/third_level_edge")


G = GraphFrame(vertices , edge)

sc.setCheckpointDir("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/checkpoint_third_phase/")

G_third_CC = G.connectedComponents(algorithm = "graphframes", checkpointInterval = 2, broadcastThreshold = 100000)

G_third_CC.groupby("component").count().orderBy("count", ascending = False).show()

similarities = edges.rdd.map(lambda x: tuple((x["src"] , x["dst"] , float(1.0))))

from pyspark.mllib.clustering import PowerIterationClustering, PowerIterationClusteringModel

model = PowerIterationClustering.train(similarities , 100 , 20)
res = model.assignments().toDF(["id" , "cluster"])   


res.join(edges, [res.id == edges.src, edges.dst == res.id]).count()

final = edges.join(res, res.id == edges.src).select(col("cluster").alias("src_clu"),"src", "dst").join(res, res.id == edges.dst).select("src_clu","src","dst", col("cluster").alias("dst_clu"))


final.write.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/final_res/")


final = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/final_res/")

final.filter(final.src_clu == final.dst_clu).count()

filter3 = final.filter(final.src_clu != final.dst_clu).select("src", "dst").distinct()
filter2 = second_phase_edge.filter(col("src_component") != col("dst_component")).select("src","dst").distinct()
filter1 = first_clean.filter(first_clean.src_com != first_clean.dst_com).select(col("src_long_id").alias("src"), col("dst_long_id").alias("dst")).distinct()

total_filter = filter1.union(filter2).union(filter3).distinct()
total_filter.write.mode("overwrite").parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/blacklist_edges/")

total_filter = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/blacklist_edges/")
#442845878

edge_total = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/edges/") 
#1836009545

#edge_total = edge_total.select(col("src_long_id").alias("src"), col("src_long_id").alias("dst"))

edge_total = edge_total.select(["src_long_id", "dst_long_id"])
final_edge = edge_total.join(total_filter, [edge_total.src_long_id == total_filter.src, edge_total.dst_long_id == total_filter.dst], "outer").select(["src","dst", "src_long_id", "dst_long_id"])

final_edge.write.mode("overwrite").parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/final_edge/")

#####
final_edge = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/final_edge/")




#After removal
edges = final_edge.where(col("src").isNull() & col("dst").isNull()).select(col("src_long_id").alias("src"), col("dst_long_id").alias("dst")).distinct()
#1558605957

vertices = edges.select("src").union(edges.select("dst")).select(col("src").alias("id")).distinct()
#416417208


vertices.write.mode("overwrite").parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/delivery_vertices/")
edges.write.mode("overwrite").parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/delivery_edges/")


###############
vertices = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/delivery_vertices/")
edges = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/delivery_edges/")

G = GraphFrame(vertices.repartition(2000) , edges.repartition(2000))
G_new = G.dropIsolatedVertices()

sc.setCheckpointDir("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/checkpoint_delivery3/")

G_CC = G.connectedComponents(algorithm = "graphframes", checkpointInterval = 2, broadcastThreshold = 100000)

G_CC.groupby("component").count().orderBy("count", ascending = False).show(100)
G_CC.write.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/delivery_components/")


G_CC = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/nila/G2/delivery_components/")
