
## 1.  require edges set and vertex set with all the meta data 
## vertex contains id-> Integer , metadata
## edges contain vertex1Long -> Integer , vertex2Long -> Integer , metadata
from graphframes import *
from pyspark.sql.functions import *
from pyspark.mllib.clustering import PowerIterationClustering, PowerIterationClusteringModel
from itertools import chain, combinations
import math
import networkx as nx

# input set of paths
edge_set_path = "gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/ishan/graphQuality/mappedEdges/validated/yr=2019/mon=10"
vertex_set_path = "gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/ishan/graphQuality/mappedVertices/yr=2019/mon=10"




## intermediate paths
base_path = "gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/graph_test_oct_snapshot/"
checkpoint_dir_path = base_path + "checkpoints/"
save_component_path = base_path + "components/"
intermediate_edges_path_for_biggest_comp = base_path + "intermediate_edges_path_for_biggest_comp/"
final_edges_path_for_biggest_comp = base_path + "final_edges_path_for_biggest_comp/"
PIC_output_path = base_path + "PIC_output/"
vertex_with_types_path = base_path + "vertex_with_types/"
vertex_with_types_after_PIC_path = base_path + "vertex_with_types_after_PIC/"
intermediate_edges_set_after_PIC_path = base_path + "intermediate_edges_set_after_PIC/"
final_edges_set_after_PIC_path = base_path + "final_edges_set_after_PIC/"
intra_cluster_edges_path = base_path + "intra_cluster_edges/"
inter_cluster_edges_path = base_path + "inter_cluster_edges/"
intra_cluster_edges_groupby_path = base_path + "intra_cluster_edges_groupby/"
vertex_groupby_path = base_path + "vertex_groupby/"
component_for_vertex_stamp_path = base_path + "component_for_vertex_stamp/"
Match_rate_3_max_hops_path = base_path + "Match_rate_3_max_hops/"
Match_rate_5_max_hops_path = base_path + "Match_rate_5_max_hops/"
hops_data_path = base_path + "hops_data/"
max_len_cliques_intermediate_path = base_path + "max_len_cliques_intermediate/"
max_len_cliques_path = base_path + "max_len_cliques_path/"
vertex_scored_path = base_path + "scoring/vertex"
edges_score_path = base_path + "scoring/edges"



#### functions defined
def getData(x , match_rate=[ 3, 5] , offline_count , online_count ):
    data = x["edges"]
    count=0
    score_dictionary1 = {} # need to return 
    score_dictionary2 = {} # need to return 
    graph = nx.Graph()
    for i in data:
            graph.add_edge(list(i.keys())[0] , list(i.values())[0])
    offline_count_ = offline_count
    onnline_count_ = online_count
    total = offline_count_ + onnline_count_
    offline_percentage = offline_count_ / total
    online_percentage = offline_count_ / total
    prob = 0
    if any("id" in s[0:2] for s in x["vtypes"]):
        hops1=0
        hops2=0
        flag = ""
        for node in x["id"]:
            count+=1
            if node in list(graph.nodes()):
                online_id_grabbed_in_1_moove = online_percentage * graph.degree(node)
                hops1 = math.ceil(match_rate[0] / online_id_grabbed_in_1_moove)
                hops2 = math.ceil(match_rate[1] / online_id_grabbed_in_1_moove)
                flag = "scored_with_no_anomaly"
                score_dictionary1[node] = hops1
                score_dictionary2[node] = hops2
            else:
                flag = "no_edges_found_for_this_id"
                score_dictionary1[node] = 1
                score_dictionary2[node] = 1
    else:
        flag = "ids_with_skewed_distribution"
        score_dictionary1 = dict(zip(list(x["id"]) , [0]*len(list(x["id"]))))
        score_dictionary2 = dict(zip(list(x["id"]) , [0]*len(list(x["id"]))))
    return x['cluster'], x['id'], score_dictionary1 , score_dictionary2  , flag 


def offline(x):
    offline=0
    for i in x["vtypes"][0:2]:
        if i != "id":
            offline+=1
        else:
            break
    if offline == len(x["vtypes"]):
    	return "value" , offline
    else:
    	return "value" , 0
   
def online(x):
    online=0
    for i in x["vtypes"][0:2]:
        if i == "id":
            online+=1
        else:
            break
    if online == len(x["vtypes"]):
    	return "value" , online
    else:
    	return "value" , 0




def getCliques(x):
     data = x["edges"]
     graph = nx.Graph() 
     for i in data:
         graph.add_edge(list(i.keys())[0] , list(i.values())[0])
     dictionary = nx.node_clique_number(graph)
     if len(list(graph.nodes())) != x["id"]:
     	extra_id = list(set(x["id"]) - set(list(graph.nodes())))
     	for item in extra_id:
     		dictionary[item] = 2
     else:
     	pass
     return x["cluster"] , dictionary 


def run_pipeline(edge_set_path , vertex_set_path):

	## read vertex and edges
	edges = spark.read.parquet(edge_set_path).withColumnRenamed("vertex1Long" , "src").withColumnRenamed("vertex2Long" , "dst").withColumnRenamed("vertex1Type" , "srcType").withColumnRenamed("vertex2Type" , "dstType")
	vertex = spark.read.parquet(vertex_set_path)

	vertex_new = vertex.withColumnRenamed("int_id" , "id").select("id")
	edges_new = edges.select("src" , "dst")



	############# --------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	## 2. create graph and connected comp
	graph = GraphFrame(vertex_new , edges_new)
	graph = graph.dropIsolatedVertices()
	sc.setCheckpointDir(checkpoint_dir_path)

	## create connected components
	conn_comp = graph1.connectedComponents(algorithm = "graphframes", checkpointInterval = 2, broadcastThreshold = 1000000)
	conn_comp.write.mode("overwrite").parquet(save_component_path)
	conn_comp = spark.read.parquet(save_component_path)
	sorted_comp = conn_comp.groupby("component").count().sort(col("count").desc())
	sorted_comp.show()
	largest_comp = sorted_comp.collect()[0][0]
	## get the component with biggest count of nodes i.e. anomalous component






	############# --------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	## 3. create vertex and edge set for largest component

	vertex_largest_comp = conn_comp.filter("component" == largest_comp).select("id") ## vertex_set created
	vertex_largest_comp.join(edges_new , [vertex_largest_comp.id == edges.src]).drop("id").write.mode("overwrite").parquet(intermediate_edges_path_for_biggest_comp)
	intermediate_edges_biggest_comp = spark.read.parquet(intermediate_edges_path_for_biggest_comp)
	vertex_largest_comp.join(intermediate_edges_biggest_comp , [vertex_largest_comp.id == intermediate_edges_biggest_comp.dst]).drop("id").write.mode("overwrite").parquet(final_edges_path_for_biggest_comp) ## edges set created 
	edges_biggest_comp = spark.read.parquet(final_edges_path_for_biggest_comp)




	############# --------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	## 4. run PIC algorithm on edges created 

	edges_biggest_comp = edges_biggest_comp.repartition(5000)
	edges_biggest_comp.cache()
	## edges_biggest_comp.count()

	similarities = df.rdd.map(lambda x: tuple((x["src"] , x["dst"] , float(1.0))))
	model = PowerIterationClustering.train(similarities, 100000 ,5) ## PIC running
	model.assignments().toDF(["id" , "cluster"]).write.mode("overwrite").parquet(PIC_output_path) ## PIC output written





	############# --------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	## 5. create vertex and edges set after PIC , remove inter cluster edges 

	vertex_after_PIC_without_types = spark.read.parquet(PIC_output_path) ## cluster , id for each vertex
	edges_src_type = edges.select("src" , "srcType").withColumnRenamed("srcType" , "vTypes").withColumnRenamed("src" , "id")  
	edges_dst_type = edges.select("dst" , "dstType").withColumnRenamed("dstType" , "vTypes").withColumnRenamed("dst" , "id")  

	edges_src_type.union(edges_dst_type).distinct().write.mode("overwrite").parquet(vertex_with_types_path) ## write vertex with Types
	vertex_with_types = spark.read.parquet(vertex_with_types_path).withColumnRenamed("id" , "id1")  ## id1 , vTypes

	## create vertex_set_after_PIC_with_types
	vertex_with_types.join(vertex_after_PIC_without_types , [vertex_after_PIC_without_types.id == vertex_with_types.id]).drop("id1").write.mode("overwrite").parquet(vertex_with_types_after_PIC_path)
	vertex_with_types_after_PIC = spark.read.parquet(vertex_with_types_after_PIC_path) ## cluster , id , vTypes

	## intra_cluster_edges_set_creation
	vertex_with_types_after_PIC.join(edges_biggest_comp , [vertex_with_types_after_PIC.id == edges_biggest_comp.src]).drop("vTypes","id").withColumnRenamed("cluster" , "srcCluster").write.mode("overwrite").parquet(intermediate_edges_set_after_PIC_path)
	intermediate_edges_set_after_PIC = spark.read.parquet(intermediate_edges_set_after_PIC_path)
	vertex_with_types_after_PIC.join(intermediate_edges_set_after_PIC , [vertex_with_types_after_PIC.id == intermediate_edges_set_after_PIC.dst]).drop("vTypes","id").withColumnRenamed("cluster" , "dstCluster").write.mode("overwrite").parquet(final_edges_set_after_PIC_path)
	final_edges_set_after_PIC = spark.read.parquet(final_edges_set_after_PIC_path) ## edges_set_created_after_PIC

	## remove intercluster edges
	final_edges_set_after_PIC.filter(col("srcCluster") == col("dstCluster")).withColumn("scoring" , lit(1)).drop("srcCluster" , "dstCluster").write.mode("overwrite").parquet(intra_cluster_edges_path)
	intra_cluster_edges = spark.read.parquet(intra_cluster_edges_path) 
	final_edges_set_after_PIC.filter(col("srcCluster") != col("dstCluster")).withColumn("scoring" , lit(0)).drop("srcCluster" , "dstCluster").write.mode("overwrite").parquet(inter_cluster_edges_path)
	## score inter and intra cluster edges
	inter_cluster_edges_ = spark.read.parquet(inter_cluster_edges_path)
	intra_cluster_edges_ = spark.read.parquet(intra_cluster_edges_path)
	inter_cluster_edges_.select("src","dst","scoring").union(intra_cluster_edges_.select("src","dst","scoring")).write.mode("overwrite").parquet(edges_score_path)


# srcCluster : Int
# dstCluster : Int
# src : BigInt
# dst : BigInt



	############# --------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	## 6. Vertex Stamping Algorithm

	intra_cluster_edges.groupby("srcCluster").agg(collect_list(create_map("src" , "dst")).alias("edges")).write.mode("overwrite").parquet(intra_cluster_edges_groupby_path)
	intra_cluster_edges_groupby = spark.read.parquet(intra_cluster_edges_groupby_path)
	vertex_with_types_after_PIC.groupby("cluster").agg(collect_list("id").alias("id") , collect_list("vTypes").alias("vTypes")).write.mode("overwrite").parquet(vertex_groupby_path)
	vertex_groupby = spark.read.parquet(vertex_groupby_path)

	vertex_groupby.join(intra_cluster_edges_groupby , [vertex_groupby.cluster == intra_cluster_edges_groupby.srcCluster]).drop("srcCluster").write.mode("overwrite").parquet(component_for_vertex_stamp_path)
	component_for_vertex_stamp = spark.read.parquet(component_for_vertex_stamp_path) 

	online_count = vertex_with_types_after_PIC.filter(col("vTypes")[0:2] == "id").count().collect()[0][0]
	offline_count = vertex_with_types_after_PIC.filter(col("vTypes")[0:2] != "id").count().collect()[0][0]

	dframe = component_for_vertex_stamp.rdd.map(lambda x : getData(x)).toDF(["component" , "id" , "max_hops_for_MR_3" , "max_hops_for_MR_5" , "flag"])
	dframe.select(explode("max_hops_for_MR_3").alias("id","hops"), "flag").write.mode("overwrite").parquet(Match_rate_3_max_hops_path)
	dframe.select(explode("max_hops_for_MR_5").alias("id","hops"), "flag").write.mode("overwrite").parquet(Match_rate_5_max_hops_path)

	MR3 = spark.read.parquet(Match_rate_3_max_hops_path)
	MR5 = spark.read.parquet(Match_rate_5_max_hops_path)

	MR3 = MR3.withColumnRenamed("id","id_MR_3").withColumnRenamed("hops","hops_MR_3").withColumnRenamed("flag","flag_MR_3")
	MR5 = MR5.withColumnRenamed("id","id_MR_5").withColumnRenamed("hops","hops_MR_5").withColumnRenamed("flag","flag_MR_5")

	MR5.join(MR3 , [MR3.id_MR_3 == MR5.id_MR_5]).drop("id_MR_5" , "flag_MR_5").withColumnRenamed("id_MR_3" , "id").withColumnRenamed("flag_MR_3" , "flag").write.mode("overwrite").parquet(hops_data_path)

	dframe = final.rdd.map(lambda x: getCliques(x)).toDF(["cluster" ,"max_clique_per_id"])
	dframe.write.mode("overwrite").parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/max_len_cliques_intermediate")
	cliques = spark.read.parquet(max_len_cliques_intermediate_path)
	cliques.select(explode("max_clique_per_id").alias("id","max_len_clique")).write.mode("overwrite").parquet(max_len_cliques_path)

	cliques = spark.read.parquet(max_len_cliques_path)
	hops = spark.read.parquet(hops_data_path)

	hops = hops.withColumnRenamed("id","id_1")
	cliques.join(hops , [hops.id_1 == cliques.id]).drop("id_1").distinct().withColumnRenamed("max_len_clique" , "cliques").write.mode("overwrite").parquet(vertex_scored_path)

	print("edges scoring path " +  edges_score_path)
	print("vertex scoring path "  + vertex_scored_path)


	return edges_score_path , vertex_scored_path


######## result --------------------------------------------------------------------------------------------------------------------------------------------------------------------------

edges_score_path , vertex_scored_path = run_pipeline(edge_set_path , vertex_set_path)



















