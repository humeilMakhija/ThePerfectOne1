pyspark --conf spark.sql.shuffle.partitions=5000 --packages graphframes:graphframes:0.8.0-spark2.4-s_2.11

from pyspark.sql.functions import *
from graphframes import *

df = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/humeil/groups_created_for_analysis/all_comp/final_components_with_hashed_types")

def get_clique_based_measure(component,id_, types_, edges_):
	import networkx as nx
    id_mapping=dict()
    for i,j in zip(id_, types_):
        id_mapping[i]=j
    G = nx.Graph()
    for e in edges :
        G.add_edge(e[0], e[1])
    unmerged_count = 0
    merged_count = 0 
    for cliques_ in find_cliques(G):
        email_count = 0
        id_mid_1_count =0 
        for clique_vertices in cliques_:
            if "email" in str(id_mapping[clique_vertices]):
                email_count += 1
            if str(id_mapping[clique_vertices]).strip()=="id_mid_1":
                id_mid_1_count +=1
        unmerged_count += unmerged_count+ (email_count*id_mid_1_count)
        if email_count >0 and id_mid_1_count >0:
            merged_count += 1
    return component,unmerged_count, merged_count

new_df = df.repartition(5000)
new_df.cache()
new_df.count()

res_df = new_df.rdd.map(lambda x : get_clique_based_measure(x["component"],x["id"], x["types"], x["edges"])).toDF(["component","unmerged_count", "merged_count"])



def get_clique_based_measure(component,id_, types_, edges_):
    import networkx as nx
    id_mapping=dict()
    for i,j in zip(id_, types_):
        id_mapping[i]=j
    G_offline = nx.Graph()
    G_online = nx.Graph()
    for e in edges_ :
        src = list(e.keys())[0]
        dst = list(e.values())[0]
#         print (src, id_mapping[src], dst, id_mapping[dst])
        if "email" in str(id_mapping[src]) and "email" in str(id_mapping[dst]):
            G_offline.add_edge(src, dst)
        if "email" in str(id_mapping[src]):
            G_offline.add_node(src)
        if "email" in str(id_mapping[dst]):
            G_offline.add_node(dst)
        if str(id_mapping[src]).strip()=="id_mid_1" and str(id_mapping[dst]).strip()=="id_mid_1":
            G_online.add_edge(src, dst)
        if str(id_mapping[src]).strip()=="id_mid_1":
            G_online.add_node(src)
        if str(id_mapping[dst]).strip()=="id_mid_1":
            G_online.add_node(dst)
    cc_offline = nx.connected_components(G_offline)
    cc_online = nx.connected_components(G_online)
    on = list(cc_online)
    off = list(cc_offline)
    return component, str(on)+ str(off), len(on)*len(off)

res_df_1 = new_df.rdd.map(lambda x : get_clique_based_measure(x["component"],x["id"], x["types"], x["edges"])).toDF(["component","unmerged_count", "merged_count"])
res_df_1.show()
res_df_1.agg(sum("merged_count")).show()



def get_clique_based_measure(component,id_, types_, edges_):
    import networkx as nx
    id_mapping=dict()
    for i,j in zip(id_, types_):
        id_mapping[i]=j
    email=[]
    maid=[]
    for e in edges_ :
        src = list(e.keys())[0]
        dst = list(e.values())[0]
        if "email" in str(id_mapping[src]) or "cellphone" in str(id_mapping[src]) :
            email.append(src)
        if "email" in str(id_mapping[dst]) or "cellphone" in str(id_mapping[dst]):
            email.append(dst)
        if str(id_mapping[src]).strip()=="id_mid_1":
            maid.append(src)
        if str(id_mapping[dst]).strip()=="id_mid_1":
            maid.append(dst)
    return component, int(bool(len(list(set(email))))), str(set(email)), str(set(maid))

res_df = new_df.rdd.map(lambda x : get_clique_based_measure(x["component"],x["id"], x["types"], x["edges"])).toDF(["component","ct","s1","s2"])
res_df.show()
res_df.agg(sum("ct")).show()

res_df = df_cleaned.rdd.map(lambda x : get_clique_based_measure(x["component"],x["id"], x["types"], x["edges"])).toDF(["component","ct","s1","s2"])
res_df.show()
res_df.agg(sum("ct")).show()






# for any mid ids 

def get_clique_based_measure(component,id_, types_, edges_):
    import networkx as nx
    id_mapping=dict()
    for i,j in zip(id_, types_):
        id_mapping[i]=j
    G_offline = nx.Graph()
    G_online = nx.Graph()
    for e in edges_ :
        src = list(e.keys())[0]
        dst = list(e.values())[0]
#         print (src, id_mapping[src], dst, id_mapping[dst])
        if "email" in str(id_mapping[src]) and "email" in str(id_mapping[dst]):
            G_offline.add_edge(src, dst)
        if "email" in str(id_mapping[src]):
            G_offline.add_node(src)
        if "email" in str(id_mapping[dst]):
            G_offline.add_node(dst)
        if "mid" in str(id_mapping[src]).strip() and "mid" in str(id_mapping[dst]).strip():
            G_online.add_edge(src, dst)
        if "mid" in str(id_mapping[src]).strip():
            G_online.add_node(src)
        if "mid" in str(id_mapping[dst]).strip():
            G_online.add_node(dst)
    cc_offline = nx.connected_components(G_offline)
    cc_online = nx.connected_components(G_online)
    on = list(cc_online)
    off = list(cc_offline)
    return component, str(on)+ str(off), len(on)*len(off)

res_df_1 = new_df.rdd.map(lambda x : get_clique_based_measure(x["component"],x["id"], x["types"], x["edges"])).toDF(["component","unmerged_count", "merged_count"])
res_df_1.show()
res_df_1.agg(sum("merged_count")).show()



def get_clique_based_measure(component,id_, types_, edges_):
    import networkx as nx
    id_mapping=dict()
    for i,j in zip(id_, types_):
        id_mapping[i]=j
    email=[]
    maid=[]
    for e in edges_ :
        src = list(e.keys())[0]
        dst = list(e.values())[0]
        if "email" in str(id_mapping[src]):
            email.append(src)
        if "email" in str(id_mapping[dst]):
            email.append(dst)
        if str(id_mapping[src]).strip()=="id_mid_1":
            maid.append(src)
        if str(id_mapping[dst]).strip()=="id_mid_1":
            maid.append(dst)
    return component, int(bool(len(list(set(email)))*len(list(set(maid))))), str(set(email)), str(set(maid))

res_df = new_df.rdd.map(lambda x : get_clique_based_measure(x["component"],x["id"], x["types"], x["edges"])).toDF(["component","ct","s1","s2"])
res_df.show()
res_df.agg(sum("ct")).show()






email_md5_uppercase',
,'email_sha256_uppercase',
 'email_sha256_uppercase',
 email_md5_uppercase

   '', 'email_sha1_lowercase', 'email_md5_lowercase', 'id_mid_4', 'id_
mid_5', 'id_mid_1', 'id_mid_1', 'email_sha1_lowercase', 'id_mid_4', 'email_sha256_lowercase', 'email_sha1_uppercase', 'email_sha1_uppercase', 'email_md5_lowercase', 'id_mid_4', 'id_mid_1', 'email_sha256_lowercase', 'email_md5_lowercase', 'id_mid_1', 'id_mid_1', 'email_sha1_uppercase', 'email_sha256_lowercase', 'email_sha1_uppercase', 'id_mid_4', 'email_md5_uppercase', 'email_md5_uppercase', 'email_sha1_lowercase', 'id_mid_1', 'id_mid_1', 'email_md5_uppercase', 'email_sha256_lowercase', 'email_sha1_lowercase', 'email_sha256_uppercase', 'email_sha256_uppercase'

  'id_mid_1',




Row(component=3075196646350, unmerged_count='[{6253473245781}, {38354058773350}, {26740466533901}, {6442451093452}, {3487514350511}, {8529805181735}, {14697378504449}, {35914516938997}][{23862838603604}, {32366874341747}, {20272246700934}, {5695126957874}, {41558104161823}, {20323785444489}, {29197188479521}, {11295764041746}, {32487132754224}, {35399121364141}, {26534308283586}, {3100967464914}, {24962350325018}, {18391050018944}, {3075196646350}, {15899969983521}, {17978733341358}, {24687472723079}, {13812615623660}, {30760555972978}, {31997507201623}, {32933810114883}, 
{27865748665966}, {16595754519326}]', merged_count=192)]




df = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/connect/adhoc_graph_cleaning/humeil/groups_created_for_analysis/all_comp/hashed_type_with_flag1")




stats previous delivery oracle dump:

Number of users (cleaned cc): 584,881,502 
Number of CC cointaining atleast 1 HEM and 1 MAID: 205,543,952 (35.14%)
Number of CC containing atleast 1 HEM: 405,497,041 (70%) 
Number of CC containing atleast 1 offline (hem or cellphone): 405497041 (70%)




Stats on cleaned cc created from 1 anamolous component:

Total cc created: 266,860,779 
Number of CC cointaining atleast 1 HEM and 1 MAID: 205,543,952 (42.82%)
Number of CC containg atleats 1 offline(HEM or phone number) and 1 online vertex (any type online id):  266,802,940 (99.9%)



