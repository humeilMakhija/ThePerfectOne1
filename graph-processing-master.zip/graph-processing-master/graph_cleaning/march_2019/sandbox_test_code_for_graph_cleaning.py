from graphframes import *
from pyspark.sql.functions import *
from pyspark.mllib.clustering import PowerIterationClustering, PowerIterationClusteringModel
from itertools import chain, combinations
import math
import networkx as nx

## read the edges into pic
edges = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/distinct_edges_for_largest_comp")
edges.cache()
similarities = edges.rdd.map(lambda x: tuple((x["src"] , x["dst"] , float(1.0))))
# model = PowerIterationClustering.train(similarities , 19 , 	40)

## intra cluster analysis
cluster_number = "19"
iterations1 = "30"
model = PowerIterationClustering.train(similarities , int(cluster_number) , str(iterations1))

sav2 = model.assignments().toDF(["id" , "cluster"])   
sav2.groupby("cluster").count().sort(col("count").desc()).show()
join1 = edges.join(sav2 , [edges.src == sav2.id]).withColumnRenamed("cluster" , "src_cluster").drop("id")
join2 = join1.join(sav2 , [join1.dst == sav2.id]).withColumnRenamed("cluster" , "dst_cluster").drop("id")
inter = join2.filter(col("src_cluster") != col("dst_cluster"))
intra = join2.filter(col("src_cluster") == col("dst_cluster"))
inter.select("src").union(inter.select("dst")).distinct().count()
intra.select("src").union(intra.select("dst")).distinct().count()
join2.filter(col("src_cluster") == col("dst_cluster")).write.mode("overwrite").parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/intra_cluster_edges/")
join2.filter(col("src_cluster") != col("dst_cluster")).write.mode("overwrite").parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/inter_cluster_edges/")




## total offline ids: 663811
## total online ids: 175763
##------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


## analysis on intra cluster edges // part 1
vertices = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/long_id_with_types_for_single_comp")
intra_cluster_edges = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/intra_cluster_edges/")
intra_cluster_edges_1 = intra_cluster_edges.select("src","dst")
vertices_from_edges_intra = intra_cluster_edges.select("src").union(intra_cluster_edges.select("dst")).distinct().withColumnRenamed("src","id")
## total ids in intra clusters 772825 = 93 % saved , 7% loss (yet to be decided)
## online ids 161430
## offline ids 611395
												------------------------------------------------------------------------------
## analysis on inter cluster edges // part 2
inter_cluster_edges = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/inter_cluster_edges/")
inter_cluster_edges_1 = inter_cluster_edges.select("src","dst")
vertices_from_edges_inter = inter_cluster_edges.select("src").union(inter_cluster_edges.select("dst")).distinct().withColumnRenamed("src","id")
dataframe1 =vertices_from_edges_inter.subtract(vertices_from_edges_intra)
dataframe2 = dataframe1.join(edges , [dataframe1.id == edges.src]).drop("id")
dataframe2.join(dataframe1 , [dataframe1.id == dataframe2.dst]).drop("id").write.mode("overwrite").parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/inter_cluster_edges_with_vertices_remooved/")
inter_cluster_edges_1_new = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/inter_cluster_edges_with_vertices_remooved/")
vertices_from_edges_inter1_new = inter_cluster_edges_1_new.select("src").union(inter_cluster_edges_1_new.select("dst")).distinct().withColumnRenamed("src","id")
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
dataframe1.subtract(vertices_from_edges_inter1_new).write.mode("overwrite").parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/inter_cluster_vertices_of_1_deg_to_be_scored")
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
inter_cluster_edges_1.subtract(inter_cluster_edges_1_new).write.mode("overwrite").parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/inter_cluster_edges_lost_to_be_scored")
##gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/inter_cluster_vertices_of_1_deg_to_be_scored
##------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

## graph of intra cluster edges
graph_intra = GraphFrame(vertices_from_edges_intra , intra_cluster_edges_1)
graph_intra =  graph_intra.dropIsolatedVertices()
graph_intra.vertices.write.mode("overwrite").parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/analysis_on_intra_clusters/dropped_isloated_vertices")
sc.setCheckpointDir("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/analysis_on_intra_clusters/checkPointDir")
conn_comp_intra = graph_intra.connectedComponents(algorithm = "graphframes", checkpointInterval = 2, broadcastThreshold = 100000)
conn_comp_intra.write.mode("overwrite").parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/analysis_on_intra_clusters/intra_cluster_comp")
conn_comp_intra = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/analysis_on_intra_clusters/intra_cluster_comp")
## cc count 18121

##  level 2 loss (i) : skewed offline ids  2805 (0.4 %)
## level 2 loss (i) : skewed online ids 0 (0 %)

## conn_comp.select("component").distinct().count()
conn_comp_intra.groupby("component").count().sort(col("count").desc()).show()
conn_comp_intra = conn_comp_intra.withColumnRenamed("id","id1")
# conn_comp.join(vertices , [vertices.id == conn_comp.id1]).drop("id1").groupby("component").agg(collect_list(col("id")) , collect_list(col("vtypes"))).show()
												------------------------------------------------------------------------------

## graph of intra cluster edges
graph_inter = GraphFrame(vertices_from_edges_inter1_new , inter_cluster_edges_1_new)
graph_inter =  graph_inter.dropIsolatedVertices()
graph_inter.vertices.write.mode("overwrite").parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/analysis_on_inter_clusters/dropped_isloated_vertices")
sc.setCheckpointDir("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/analysis_on_inter_clusters/checkPointDir")
conn_comp_inter = graph_inter.connectedComponents(algorithm = "graphframes", checkpointInterval = 2, broadcastThreshold = 10000000)
conn_comp_inter.write.mode("overwrite").parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/analysis_on_inter_clusters/inter_cluster_comp")
conn_comp_inter = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/analysis_on_inter_clusters/inter_cluster_comp")
## cc count 18121
##  level 2 loss (i) : skewed offline ids  2805 (0.4 %)
## level 2 loss (i) : skewed online ids 0 (0 %)

## conn_comp.select("component").distinct().count()
conn_comp_inter.groupby("component").count().sort(col("count").desc()).show()
conn_comp_inter = conn_comp_inter.withColumnRenamed("id","id1")

##------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

edges_src_dst = edges.withColumnRenamed("src","id1").withColumnRenamed("dst","id2")
edges_dst_src = edges.withColumnRenamed("dst","id1").withColumnRenamed("src","id2")

edges_new = edges_src_dst.select("id1","id2").union(edges_dst_src.select("id1","id2")).withColumnRenamed("id1","src").withColumnRenamed("id2","dst").distinct()


## finding loss by skewness
def find_offline_and_online(x):
	offline_count = 0
	online_count = 0
	for i in x["vtypes"]:
		if i == "offline":
			offline_count += 1
		else:
			online_count += 1
	return x["component"]  ,offline_count ,  online_count




from collections import Counter
import numpy as np
def list_duplicates_of(seq,item):
    start_at = -1
    locs = []
    while True:
        try:
            loc = seq.index(item,start_at+1)
        except ValueError:
            break
        else:
            locs.append(loc)
            start_at = loc
    return locs

# def relinking(x):
# 	# c = Counter(x["dst_component"])
# 	# m =sorted(list(c.values()))[-1]
# 	# r = [k for k in c if c[k] == m]
# 	# list_of_favourable_comp_online_ids = []
# 	# for comp in r:
# 	# 	list_of_favourable_comp_online_ids.append((x["count_online"][x["dst_component"].index(comp)] , x["dst_component"].index(comp)))
# 	# store = sorted(list_of_favourable_comp_online_ids , key = itemgetter(0))[-1]
# 	most_common , num_most_common = Counter(x["dst_component"]).most_common(1)[0]
# 	give_index = np.random.choice(list_duplicates_of(x["dst_component"] , most_common))
# 	dst = x["dst"][give_index]
# 	return  most_common , x["src"] , dst  

# def relinking_v2(x):
# 	index_of_id_to_be_linked = np.random.choice(list_duplicates_of(x["count_online"] , sorted(x["count_online"])[-1]))
# 	id_to_be_linked ,  comp_to_be_linked = x["dst"][index_of_id_to_be_linked] , x["dst_component"][index_of_id_to_be_linked]
# 	return x["src_comp"] , x["src"] , id_to_be_linked , comp_to_be_linked

def relinking_v3(x):
	comp_with_online_count_list = []
	try:
		for i in x["edges_for_old_comp"]:
			if x["component"] == list(i.values())[0][2]:
				pass
			else:
				comp_with_online_count_list.append([list(i.keys())[0] , list(i.values())[0][0] , list(i.values())[0][1] , list(i.values())[0][2] ])
		comp_with_online_count_list_sorted_on = sorted(comp_with_online_count_list , key = itemgetter(2) , reverse = True) ## sort the list with respect to count of online ids
		max_count_of_online = comp_with_online_count_list_sorted_on[0][2]
		final_list_with_max_online_count_for_comp = [x for i,x in enumerate(comp_with_online_count_list_sorted_on) if x[2] == max_count_of_online]
		counter_list = []
		for i in final_list_with_max_online_count_for_comp:
			counter_list.append(i[-1])
		final_component_to_assign = Counter(counter_list).most_common(1)[0][0]
		src_id_per_comp  ,dst_id_per_comp = final_list_with_max_online_count_for_comp[0][0] , final_list_with_max_online_count_for_comp[0][1]
	except:
		src_id_per_comp , dst_id_per_comp , final_component_to_assign = 0 , 0 , 0
	return  x["component"] , src_id_per_comp  , dst_id_per_comp  , final_component_to_assign


def relinking_for_excludes(x):
	max1 = np.max(x["online_count"])
	return x["src"] , x["component"][x["online_count"].index(max1)]









relinking3.join(comp_all , [relinking3.dst == comp_all.id]).drop("id").withColumnRenamed("component" , "dst_component").withColumnRenamed("vtypes","dst_vtypes").groupby("src_comp" , "src").withColumnRenamed("vtypes","dst_vtypes").groupby("src_comp" , "src").agg(collect_list(col("dst")).alias("dst") , collect_list(col("dst_component")).alias("dst_component") ,collect_list(col("dst_vtypes")).alias("dst_vtypes") , collect_list(col("new")).alias("count_online"))
relinking3_1 = relinking3.join(comp_all , [relinking3.dst == comp_all.id]).drop("id").withColumnRenamed("component" , "dst_component").withColumnRenamed("vtypes","dst_vtypes").groupby("src").agg(collect_list(col("dst")).alias("dst") , collect_list(col("dst_component")).alias("dst_component") ,collect_list(col("dst_vtypes")).alias("dst_vtypes") , collect_list(col("new")).alias("count_online")) 
relinking3_1.rdd.map(lambda x: relinking(x)).toDF(["component" , "src" , "dst"]).write.mode("overwrite").parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/relinked_corner_vertices")
single_id_edges = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/relinked_corner_vertices")




## for intra cluster
comp_with_vertices_intra = conn_comp_intra.join(vertices , [vertices.id == conn_comp_intra.id1]).drop("id1")
comp_with_vertices_groupby_intra = comp_with_vertices_intra.groupby("component").agg(collect_list(col("id")).alias("id") , collect_list(col("vtypes")).alias("vtypes"))
comp_with_vertices_groupby_intra.rdd.map(lambda x : find_offline_and_online(x)).toDF(["component" , "id" , "offline" , "online"]).filter(col("online")==0).groupby().sum("offline").show()
comp_with_vertices_groupby_intra.rdd.map(lambda x : find_offline_and_online(x)).toDF(["component" , "id" , "offline" , "online"]).filter(col("offline")==0).groupby().sum("online").show()
offline_skewed_intra = comp_with_vertices_groupby_intra.rdd.map(lambda x : find_offline_and_online(x)).toDF(["component" , "id" , "offline" , "online"]).filter(col("online")==0).select("component",explode("id").alias("id")) 
relink_intra_1 = offline_skewed_intra.join(edges_new , [offline_skewed_intra.id == edges_new.src]).drop("id").withColumnRenamed("component","src_comp").distinct()
relink_intra_2 = relink_intra_1.join(comp_all , [relink_intra_1.dst == comp_all.id]).drop("id").withColumnRenamed("component" , "dst_component").withColumnRenamed("vtypes","dst_vtypes").groupby("src_comp" , "src").agg(collect_list(col("dst")).alias("dst") , collect_list(col("dst_component")).alias("dst_component") ,collect_list(col("dst_vtypes")).alias("dst_vtypes") , collect_list(col("new")).alias("count_online"))
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
relink_intra_2.rdd.map(lambda x: relinking(x)).toDF(["component" , "src" , "dst"]).write.mode("overwrite").parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/relinked_intra_cluster_skewed_vertices")
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
relinked_intra_cluster_skewed_vertices = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/relinked_intra_cluster_skewed_vertices")


## for inter cluster 
comp_with_vertices_inter = conn_comp_inter.join(vertices , [vertices.id == conn_comp_inter.id1]).drop("id1")
comp_with_vertices_groupby_inter = comp_with_vertices_inter.groupby("component").agg(collect_list(col("id")).alias("id") , collect_list(col("vtypes")).alias("vtypes"))
comp_with_vertices_groupby_inter.rdd.map(lambda x : find_offline_and_online(x)).toDF(["component" , "id" , "offline" , "online"]).filter(col("online")==0).groupby().sum("offline").show()
comp_with_vertices_groupby_inter.rdd.map(lambda x : find_offline_and_online(x)).toDF(["component" , "id" , "offline" , "online"]).filter(col("offline")==0).groupby().sum("online").show()
offline_skewed_inter = comp_with_vertices_groupby_inter.rdd.map(lambda x : find_offline_and_online(x)).toDF(["component" , "id" , "offline" , "online"]).filter(col("online")==0).select("component",explode("id").alias("id")) 

comp_all = comp_with_vertices_intra.union(comp_with_vertices_inter)
comp_all_ = comp_all.groupby("component").agg(collect_list(col("vtypes")).alias("vtypes")).withColumn("new" , find_on1(col("vtypes"))).select("component","new").withColumnRenamed("component" , "component1")

comp_all_new = comp_all.join(comp_all_ , [comp_all_.component1 == comp_all.component]).drop("component1")
comp_all_new.write.mode("overwrite").parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/components_after_PIC/with_types_and_count_online")
comp_all = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/components_after_PIC/with_types_and_count_online")

relink_inter_1 = offline_skewed_inter.join(edges_new , [offline_skewed_inter.id == edges_new.src]).drop("id").withColumnRenamed("component","src_comp")


relink_inter_2 = relink_inter_1.join(comp_all , [relink_inter_1.dst == comp_all.id]).drop("id").withColumnRenamed("component" , "dst_component").withColumnRenamed("vtypes","dst_vtypes").groupby("src_comp" , "src").agg(collect_list(col("dst")).alias("dst") , collect_list(col("dst_component")).alias("dst_component") ,collect_list(col("dst_vtypes")).alias("dst_vtypes") , collect_list(col("new")).alias("count_online"))
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
relink_inter_2.rdd.map(lambda x: relinking(x)).toDF(["component" , "src" , "dst"]).write.mode("overwrite").parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/relinked_inter_cluster_skewed_vertices")
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
relinked_inter_cluster_skewed_vertices = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/relinked_inter_cluster_skewed_vertices")








##------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------








## intra cluster analysis
comp_with_vertices_groupby_intra.write.mode("overwrite").parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/analysis_on_intra_clusters/comp_with_vertices_and_types_groupby/")

join1 = comp_with_vertices_intra.join(intra_cluster_edges_1 , [comp_with_vertices_intra.id == intra_cluster_edges_1.src ]).drop("id","vtypes").withColumnRenamed("component" , "src_component")
join2 = comp_with_vertices_intra.join(join1 , [comp_with_vertices_intra.id == join1.dst ]).drop("id","vtypes").withColumnRenamed("component" , "dst_component")
join2.select("src_component","src","dst").withColumnRenamed("src_component" , "component").groupby("component").agg(collect_list(create_map(col("src"),col("dst"))).alias("edges")).write.mode("overwrite").parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/analysis_on_intra_clusters/comp_with_edges_groupby/")


comp_with_vert_groupby_intra= spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/analysis_on_intra_clusters/comp_with_vertices_and_types_groupby/")
comp_with_vert_groupby_intra1 = comp_with_vert_groupby_intra.withColumnRenamed("component" , "component1")
comp_with_edges_groupby_intra = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/analysis_on_intra_clusters/comp_with_edges_groupby/")

comp_with_vert_groupby_intra1.join(comp_with_edges_groupby_intra , [comp_with_vert_groupby_intra1.component1 == comp_with_edges_groupby_intra.component]).drop("component1").write.mode("overwrite").parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/analysis_on_intra_clusters/comp_with_all_data/")

data = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/analysis_on_intra_clusters/comp_with_all_data/")
data.rdd.map(lambda x: func_input_match_rate(x)).toDF(["cluster","list_new","vtypes"]).write.mode("overwrite").parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/analysis_on_intra_clusters/list_with_offline_ids_within_2_hops_or_not")
data1 = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/analysis_on_intra_clusters/list_with_offline_ids_within_4_hops_or_not")

data1.rdd.flatMap(lambda x: [(y[0] , y[1]) for y in x["list_new"]]).toDF(["a","b"]).distinct()





## inter cluster analysis

comp_with_vertices_groupby_inter.write.mode("overwrite").parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/analysis_on_inter_clusters/comp_with_vertices_and_types_groupby/")

join1 = comp_with_vertices_inter.join(inter_cluster_edges_1_new , [comp_with_vertices_inter.id == inter_cluster_edges_1_new.src ]).drop("id","vtypes").withColumnRenamed("component" , "src_component")
join2 = comp_with_vertices_inter.join(join1 , [comp_with_vertices_inter.id == join1.dst ]).drop("id","vtypes").withColumnRenamed("component" , "dst_component")
join2.select("src_component","src","dst").withColumnRenamed("src_component" , "component").groupby("component").agg(collect_list(create_map(col("src"),col("dst"))).alias("edges")).write.mode("overwrite").parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/analysis_on_inter_clusters/comp_with_edges_groupby/")

comp_with_vert_groupby_inter= spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/analysis_on_inter_clusters/comp_with_vertices_and_types_groupby/")
comp_with_vert_groupby_inter1 = comp_with_vert_groupby_inter.withColumnRenamed("component" , "component1")
comp_with_edges_groupby_inter = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/analysis_on_inter_clusters/comp_with_edges_groupby/")

comp_with_vert_groupby_inter1.join(comp_with_edges_groupby_inter , [comp_with_vert_groupby_inter1.component1 == comp_with_edges_groupby_inter.component]).drop("component1").write.mode("overwrite").parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/analysis_on_inter_clusters/comp_with_all_data/")


data = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/analysis_on_inter_clusters/comp_with_all_data/")
data.rdd.map(lambda x: func_input_match_rate(x)).toDF(["cluster","list_new","vtypes"]).write.mode("overwrite").parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/analysis_on_inter_clusters/list_with_offline_ids_within_4_hops_or_not")
data1 = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/analysis_on_inter_clusters/list_with_offline_ids_within_4_hops_or_not")

data1.rdd.flatMap(lambda x: [(y[0] , y[1]) for y in x["list_new"]]).toDF(["a","b"]).distinct()















##------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------








53k clusters
intra cluster vertices : 563886
inter cluster vertices : 432943
top cluster size after PIC :
 component|count|
+-----------+-----+
|     279053| 7965|
|     117949| 5382|
|     952265| 2645|
|    2132678|  905|
|    5533739|  848|
|    2493267|  644|
|    1332902|  615|
|    1252284|  570|
|     124789|  513|

skewed offline ids : 40838 (6.1%)
skewed online ids : 0

offline ids reachable to online ids in less than 4 hops : 100%







comp_with_edges_groupby_inter_exploded = comp_with_edges_groupby_inter.select("component" , explode("edges").alias("edges")).select("component" , explode("edges").alias("src" , "dst"))
comp_with_edges_groupby_intra_exploded = comp_with_edges_groupby_intra.select("component" , explode("edges").alias("edges")).select("component" , explode("edges").alias("src" , "dst"))

single_id_edges.union(relinked_intra_cluster_skewed_vertices).union(relinked_intra_cluster_skewed_vertices).union(comp_with_edges_groupby_inter_exploded).union(comp_with_edges_groupby_intra_exploded)
 
all_edges = single_id_edges.union(relinked_intra_cluster_skewed_vertices).union(relinked_intra_cluster_skewed_vertices).union(comp_with_edges_groupby_inter_exploded).union(comp_with_edges_groupby_intra_exploded).distinct()
all_edges.groupby("component").agg(collect_list(create_map(col("src") , col("dst"))).alias("edges"))

relinked_inter_cluster_skewed_vertices = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/relinked_inter_cluster_skewed_vertices").select("component" , "src").withColumnRenamed("src" , "id")
relinked_intra_cluster_skewed_vertices = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/relinked_intra_cluster_skewed_vertices").select("component" , "src").withColumnRenamed("src" , "id")
single_id_edges = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/relinked_corner_vertices").select("component" , "src").withColumnRenamed("src" , "id")

comp_with_vert_groupby_inter_vertices = comp_with_vert_groupby_inter.select("component" , explode("id").alias("id")).distinct()
comp_with_vert_groupby_intra_vertices = comp_with_vert_groupby_intra.select("component" , explode("id").alias("id")).distinct()

comp_with_vert_groupby_inter_vertices.subtract(relinked_inter_cluster_skewed_vertices).subtract()

vertices_test = relinked_inter_cluster_skewed_vertices.union(relinked_intra_cluster_skewed_vertices).union(single_id_edges)

relinked_inter_cluster_skewed_vertices = relinked_inter_cluster_skewed_vertices.withColumnRenamed("component" , "new_comp")
relinked_intra_cluster_skewed_vertices = relinked_intra_cluster_skewed_vertices.withColumnRenamed("component" , "new_comp")

comp_with_vert_groupby_intra_vertices.subtract(comp_with_vert_groupby_intra_vertices.join(relinked_intra_cluster_skewed_vertices , ["id"]).select("component" , "id")).write.mode("overwrite").parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/purely_intra_cluster_ids")
comp_with_vert_groupby_inter_vertices.subtract(comp_with_vert_groupby_inter_vertices.join(relinked_inter_cluster_skewed_vertices , ["id"]).select("component" , "id")).write.mode("overwrite").parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/purely_inter_cluster_ids")

relinked_inter_cluster_skewed_vertices = relinked_inter_cluster_skewed_vertices.withColumnRenamed("new_comp" , "component")
relinked_intra_cluster_skewed_vertices = relinked_intra_cluster_skewed_vertices.withColumnRenamed("new_comp" , "component")


single_id_edges.union(comp_with_vert_groupby_intra_vertices).union(comp_with_vert_groupby_inter_vertices)

unioned_all = single_id_edges.union(comp_with_vert_groupby_intra_vertices).union(comp_with_vert_groupby_inter_vertices)
vertices1 = vertices.withColumnRenamed("id" , "id1")
vertices1.join(unioned_all  , [unioned_all.id == vertices1.id1]).drop("id1").write.mode("overwrite").parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/all_ids_with_relinked_comps")






comp_with_edges_groupby_intra_exploded = comp_with_edges_groupby_intra.select("component",explode("edges").alias("edges")).select("component",explode("edges").alias("src" , "dst"))
comp_with_edges_groupby_inter_exploded = comp_with_edges_groupby_inter.select("component",explode("edges").alias("edges")).select("component",explode("edges").alias("src" , "dst"))
comp_with_edges_groupby_intra_exploded.union(comp_with_edges_groupby_inter_exploded).union(relinked_intra_cluster_skewed_vertices).union(relinked_inter_cluster_skewed_vertices).union(single_id_edges).write.mode("overwrite").parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/all_edges_after_relinkation")



verti_grouped = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/all_ids_with_relinked_comps_groupby")
edge_grouped = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/all_edges_after_relinkation_groupby")

verti_grouped = verti_grouped.withColumnRenamed("component" , "component1")
verti_grouped.join(edge_grouped , [verti_grouped.component1 == edge_grouped.component]).drop("component1").write.mode("overwrite").parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/comp_with_all_data_after_relinkation/")


final = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/comp_with_all_data_after_relinkation/")


def getData(x , match_rate=[ 3, 5 , 8 , 12]):
    data = x["edges"]
    count=0
    score_dictionary1 = {} # need to return 
    score_dictionary2 = {} # need to return 
    score_dictionary3 = {} # need to return 
    score_dictionary4 = {} # need to return 
    graph = nx.Graph()
    for i in data:
            graph.add_edge(list(i.keys())[0] , list(i.values())[0])
    offline_count = 663811
    online_count = 175763
    total = 839574
    offline_percentage = 0.790652164073685
    online_percentage = 0.209347835926315
    prob = 0
    if any("online" in s for s in x["vtypes"]):
        hops1=0
        hops2=0
        hops3=0
        hops4=0
        flag = ""
        for node in x["id"]:
            count+=1
            if node in list(graph.nodes()):
                online_id_grabbed_in_1_moove = online_percentage * graph.degree(node)
                hops1 = math.ceil(match_rate[0] / online_id_grabbed_in_1_moove)
                hops2 = math.ceil(match_rate[1] / online_id_grabbed_in_1_moove)
                hops3 = math.ceil(match_rate[2] / online_id_grabbed_in_1_moove)
                hops4 = math.ceil(match_rate[3] / online_id_grabbed_in_1_moove)
                flag = "scored_with_no_anomaly"
                score_dictionary1[node] = hops1
                score_dictionary2[node] = hops2
                score_dictionary3[node] = hops3
                score_dictionary4[node] = hops4
            else:
                flag = "no_edges_found_for_this_id"
                score_dictionary1[node] = 1
                score_dictionary2[node] = 1
                score_dictionary3[node] = 1
                score_dictionary4[node] = 1
    else:
        flag = "ids_with_skewed_distribution"
        score_dictionary1 = dict(zip(list(x["id"]) , [0]*len(list(x["id"]))))
        score_dictionary2 = dict(zip(list(x["id"]) , [0]*len(list(x["id"]))))
        score_dictionary3 = dict(zip(list(x["id"]) , [0]*len(list(x["id"]))))
        score_dictionary4 = dict(zip(list(x["id"]) , [0]*len(list(x["id"]))))
    return x['component'], x['id'], score_dictionary1 , score_dictionary2  , score_dictionary3 , score_dictionary4 , flag 




final = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/comp_data_ready")
dframe = final.rdd.map(lambda x : getData(x)).toDF(["component" , "id" , "max_hops_for_MR_3" , "max_hops_for_MR_5" , "max_hops_for_MR_8" , "max_hops_for_MR_12" , "flag"])

dframe.select(explode("max_hops_for_MR_3").alias("id","hops"), "flag").write.mode("overwrite").parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/results/max_hops/MR3")
dframe.select(explode("max_hops_for_MR_5").alias("id","hops"), "flag").write.mode("overwrite").parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/results/max_hops/MR5")
dframe.select(explode("max_hops_for_MR_8").alias("id","hops"), "flag").write.mode("overwrite").parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/results/max_hops/MR8")
dframe.select(explode("max_hops_for_MR_12").alias("id","hops"), "flag").write.mode("overwrite").parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/results/max_hops/MR12")

MR3 = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/results/max_hops/MR3")
MR5 = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/results/max_hops/MR5")
MR8 = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/results/max_hops/MR8")
MR12 = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/results/max_hops/MR12")

MR3 = MR3.withColumnRenamed("id","id_MR_3").withColumnRenamed("hops","hops_MR_3").withColumnRenamed("flag","flag_MR_3")
MR5 = MR5.withColumnRenamed("id","id_MR_5").withColumnRenamed("hops","hops_MR_5").withColumnRenamed("flag","flag_MR_5")
MR8 = MR8.withColumnRenamed("id","id_MR_8").withColumnRenamed("hops","hops_MR_8").withColumnRenamed("flag","flag_MR_8")
MR12 = MR12.withColumnRenamed("id","id_MR_12").withColumnRenamed("hops","hops_MR_12").withColumnRenamed("flag","flag_MR_12")
sa1 = MR5.join(MR3 , [MR3.id_MR_3 == MR5.id_MR_5]).drop("id_MR_5" , "flag_MR_5").withColumnRenamed("id_MR_3" , "id").withColumnRenamed("flag_MR_3" , "flag")
sa2 = MR8.join(MR12 , [MR8.id_MR_8 == MR12.id_MR_12]).drop("id_MR_8" , "flag_MR_8").withColumnRenamed("id_MR_12" , "id").withColumnRenamed("flag_MR_12" , "flag")
sa1 = sa1.withColumnRenamed("flag" , "flag1").withColumnRenamed("id","id1")
sa1.join(sa2 , [sa1.id1 == sa2.id]).drop("id1" , "flag1").write.mode("overwrite").parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/results/hops_data_v2/")


def offline(x):
    offline=0
    for i in x["vtypes"]:
        if i == "offline":
            offline+=1
        else:
            break
    if offline == len(x["vtypes"]):
        return "value" , offline
    else:
        return "value" , 0
   
def online(x):
    online=0
    for i in x["vtypes"]:
        if i == "online":
            online+=1
        else:
            break
    if online == len(x["vtypes"]):
        return "value" , online
    else:
        return "value" , 0


def getCliques(x):
	data = x["edges"]
	graph = nx.Graph() 
	for i in data:
		graph.add_edge(list(i.keys())[0] , list(i.values())[0])
	dictionary = nx.node_clique_number(graph)
	if len(list(graph.nodes())) != x["id"]:
		extra_id = list(set(x["id"]) - set(list(graph.nodes())))
		for item in extra_id:
			dictionary[item] = 2
	else:
		pass
	return x["component"] , dictionary

def greater_clique(x):
	selection = sorted(x["max_clique_per_id"])[-1]
	return x["id"] , selection


dframe = final.rdd.map(lambda x: getCliques(x)).toDF(["cluster" ,"max_clique_per_id"])
dframe.write.mode("overwrite").parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/results/max_len_cliques_intermediate_v2/")
cliques = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/results/max_len_cliques_intermediate_v2")
cliques.select(explode("max_clique_per_id").alias("id","max_len_clique")).write.mode("overwrite").parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/results/max_len_cliques_v2")
cliques_test = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/results/max_len_cliques_v2")
cliques_test = cliques_test.groupby("id").agg(collect_list(col("max_len_clique")).alias("max_clique_per_id")).rdd.map(lambda x: greater_clique(x)).toDF(["id" , "max_clique_per_id"])


cliques_test = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/results/max_len_cliques_v2")
hops = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/results/hops_data_v2/")


hops = hops.withColumnRenamed("id","id_1")
cliques_test.join(hops , [hops.id_1 == cliques_test.id]).drop("id_1").distinct().withColumnRenamed("max_clique_per_id" , "cliques").write.mode("overwrite").parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/results/clique_hops_stats_v2")



##------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------




## relinking find all the skewed ids
conn_comp_intra = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/analysis_on_intra_clusters/intra_cluster_comp")




def IMR(x):
	data = x['edges']
	types = x["vtypes"]
	omr=[]
	graph = nx.Graph()
	for i in data:
		graph.add_edge(int(list(i.keys())[0]), int(list(i.values())[0]))
	vertices = x["id"]
	list_new = []
	count1=0
	for node in x["sample_id"]:
		try:
			paths = dict(nx.single_source_shortest_path_length(graph, node))
			have_online = False
			tup = [[vert , hoop] for vert , hoop in paths.items()]
			for tu in tup:
				if x["vtypes"][x["id"].index(tu[0])] == "online" and tu[1] <=5:
					omr.append(tu[0])
					have_online = True
					list_new.append((node , "reached"))
					# break
				else:
					pass
			if have_online == True :
				pass
			else : 
				list_new.append((node , "not_reached"))	
		except:
			list_new.append((node , "not_reached"))	
	# len(list_new) , len(graph.nodes()) , len(x["id"]),x["vtypes"] , x["id"] , paths
	return x["comp_new"] ,  list_new , x["vtypes"]  , omr


sample_comp = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/test_sample/CC/0.25")
sample_comp = sample_comp.drop("id" , "type")
comp_all = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/final_comp_with_vertices_types_version_2")
sample_comp1 = sample_comp.join(comp_all , [sample_comp.flag == comp_all.id]).drop("vtypes").drop("id")
# sample_comp1 = final.join(sample_comp , [final.id == sample_comp.flag]).drop("flag")
sample_comp2 = sample_comp1.groupby("component").agg(collect_list(col("flag")).alias("sample_id")).withColumnRenamed("component" , "comp_new")
sample_comp2.join(final , [sample_comp2.comp_new == final.component]).drop("component").rdd.map(lambda x: IMR(x)).toDF(["component" , "list_new" , "vtypes" , "omr"]).rdd.flatMap(lambda x: [(y[0] , y[1]) for y in x["list_new"]]).toDF(["a","b"]).distinct().filter(col("b") == "reached").count()

sample_comp2.join(final , [sample_comp2.comp_new == final.component]).drop("component").rdd.map(lambda x: IMR(x)).toDF(["component" , "list_new" , "vtypes" , "omr"]).select("omr").select(explode("omr").alias("omr")).select("omr").distinct().count()





data1 = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/inter_cluster_vertices_of_1_deg_to_be_scored")
data2 = data1.join(edges_new , [data1.id == edges_new.src]).drop("id") # 110746
comp_all_with_types_group = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/all_old_comps_with_vtypes")
data3 = data2.join(comp_all , [comp_all.id == data2.dst]).drop("id").select("src" , "component").distinct()
comp_all_with_types_group1 = comp_all_with_types_group.rdd.map(lambda x: find_offline_and_online(x)).toDF(["component1" , "online_count"])
data3.join(comp_all_with_types_group1 , [comp_all_with_types_group1.component1 == data3.component]).drop("component1").count() # 76043
data3.count() # 76043
data4 = data3.join(comp_all_with_types_group1 , [comp_all_with_types_group1.component1 == data3.component]).drop("component1").groupby("src").agg(collect_list("component").alias("component") , collect_list("online_count").alias("online_count"))
data3.join(comp_all_with_types_group1 , [comp_all_with_types_group1.component1 == data3.component]).drop("component1").groupby("src").agg(collect_list("component").alias("component") , collect_list("online_count").alias("online_count")).rdd.map(lambda x: relinking_for_excludes(x)).toDF(["src" , "component"]).count()
data3.join(comp_all_with_types_group1 , [comp_all_with_types_group1.component1 == data3.component]).drop("component1").groupby("src").agg(collect_list("component").alias("component") , collect_list("online_count").alias("online_count")).rdd.map(lambda x: relinking_for_excludes(x)).toDF(["src" , "component"]).write.mode("overwrite").parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/idswith_deg_to_be_relinked")
single_deg_vertices = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/idswith_deg_to_be_relinked").withColumnRenamed("src" , "id1")
comp_all = comp_all.union(single_deg_vertices).distinct()
comp_all = comp_all.withColumnRenamed("id" , "id1")
comp_all_with_types = comp_all.join(vertices , [comp_all.id1 == vertices.id]) 
comp_all_with_types = comp_all.join(vertices , [comp_all.id1 == vertices.id]).drop("id1")


conn_comp_intra = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/analysis_on_intra_clusters/intra_cluster_comp")
conn_comp_inter = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/analysis_on_inter_clusters/inter_cluster_comp")
conn_comp_intra.groupby("component").count().sort(col("count").desc()).show()
conn_comp_intra = conn_comp_intra.withColumnRenamed("id","id1")
conn_comp_inter.groupby("component").count().sort(col("count").desc()).show()
conn_comp_inter = conn_comp_inter.withColumnRenamed("id","id1")

comp_with_vertices_intra = conn_comp_intra.join(vertices , [vertices.id == conn_comp_intra.id1]).drop("id1")
comp_with_vertices_groupby_intra = comp_with_vertices_intra.groupby("component").agg(collect_list(col("id")).alias("id") , collect_list(col("vtypes")).alias("vtypes"))
comp_with_vertices_groupby_intra.rdd.map(lambda x : find_offline_and_online(x)).toDF(["component" , "id" , "offline" , "online"]).filter(col("online")==0).groupby().sum("offline").show()
comp_with_vertices_groupby_intra.rdd.map(lambda x : find_offline_and_online(x)).toDF(["component" , "id" , "offline" , "online"]).filter(col("offline")==0).groupby().sum("online").show()
offline_skewed_intra = comp_with_vertices_groupby_intra.rdd.map(lambda x : find_offline_and_online(x)).toDF(["component" , "id" , "offline" , "online"]).filter(col("online")==0).select("component",explode("id").alias("id")) 

comp_with_vertices_inter = conn_comp_inter.join(vertices , [vertices.id == conn_comp_inter.id1]).drop("id1")
comp_with_vertices_groupby_inter = comp_with_vertices_inter.groupby("component").agg(collect_list(col("id")).alias("id") , collect_list(col("vtypes")).alias("vtypes"))
comp_with_vertices_groupby_inter.rdd.map(lambda x : find_offline_and_online(x)).toDF(["component" , "id" , "offline" , "online"]).filter(col("online")==0).groupby().sum("offline").show()
comp_with_vertices_groupby_inter.rdd.map(lambda x : find_offline_and_online(x)).toDF(["component" , "id" , "offline" , "online"]).filter(col("offline")==0).groupby().sum("online").show()
offline_skewed_inter = comp_with_vertices_groupby_inter.rdd.map(lambda x : find_offline_and_online(x)).toDF(["component" , "id" , "offline" , "online"]).filter(col("online")==0).select("component",explode("id").alias("id")) 

stored_skewed_ids_with_comp = offline_skewed_inter.union(offline_skewed_intra)
stored_skewed_ids_with_comp
stored_skewed_ids_with_comp.count()

stored_skewed_ids_with_comp_with_dst_edges = stored_skewed_ids_with_comp.join(edges_new , [stored_skewed_ids_with_comp.id == edges_new.src]).drop("src")
comp_all1 = comp_all.withColumnRenamed("id" , "id1").withColumnRenamed("component" , "c1")
comp_all2 = comp_all.join(vertices , [vertices.id == comp_all.id1]).drop("id1")  
comp_all3 = comp_all2.groupby("component").agg(collect_list(col("vtypes")).alias("vtypes")).rdd.map(lambda x: find_offline_and_online(x)).toDF(["component" , "online_count"]).withColumnRenamed("component" , "c3")


skewed_ids_with_comp_dst_edges_and_dst_comp = comp_all1.join(stored_skewed_ids_with_comp_with_dst_edges , [comp_all1.id1 == stored_skewed_ids_with_comp_with_dst_edges.dst]).drop("id1").withColumnRenamed("c1" ,  "dst_component")
skewed_ids_all_data_v2 = skewed_ids_with_comp_dst_edges_and_dst_comp.join(comp_all3 , [comp_all3.c3 == skewed_ids_with_comp_dst_edges_and_dst_comp.dst_component]).drop("c3")

columns1 = [col("dst") , col("online_count") , col("dst_component")]
skewed_all_data_grouped_new = skewed_ids_all_data_v2.withColumn("new" , array(columns1)).select("id" , "component" , "new") 
skewed_all_data_grouped_new_v2 = skewed_all_data_grouped_new.groupby("component").agg(collect_list(create_map(col("id") , col("new"))).alias("edges_for_old_comp"))
skewed_all_data_grouped_new_v2.rdd.map(lambda x: relinking_v3(x)).toDF(["component" , "src_id_per_comp" , "dst_id_per_comp" , "final_component_to_assign"])

test7_all_with_types = test7.join(vertices , [comp_all.id1 == vertices.id]) 




## final vertices with component
## gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/final_comp_with_vertices_types_version_2
##gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/final_data_v2/vertices_groupby_with_comp/

## final edges with component
##gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/final_edges_version_2/traversible_edges/
##gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/final_edges_version_2/non_traversible_edges/
##gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/final_edges_version_2/groupby_traversible/

spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/final_data_v2/final_data_groupby")
##vertices_with_edges_grouped


join1 = all_vertices_of_comp.join(edges_stamp , [all_vertices_of_comp.long_int_idx == edges_stamp.src]).drop("long_int_idx").withColumnRenamed("vertex1" , "src_string")
join2 = all_vertices_of_comp.join(join1 , [all_vertices_of_comp.long_int_idx == join1.dst]).drop("long_int_idx").withColumnRenamed("vertex1" , "dst_string")




## vertes path and edges_path to send 1st and 3rd
gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/all_march_vertices_stamped_with_scoring/
gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/all_march_edges_stamped_with_flags
gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/all_march_edges_stamped_with_string_ids_and_flags
## final comps saved = 
gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/final_comp_after_the_process


stats:
1. median of hops for 3 and 5 MR (we took <= 4 hops and how better we are from 3 or 5 MR hops)
2. maximum cc size after PIC and after whole process compare :
3. skewness before and after : before is -> [offline : 5.23 % (45mill/860mill) , online : ] , after is -> [offline : 5.23% + 0.01% , online :  + 0]
4. drop in edges : 10.1% ~203k(for largest component) , 
5. number of inter cluster edges and intra cluster edges 
6. inter and intra cluster vertices
7. total edges_in full march 2019 snapshot ->
8. total vertices in full march 2019 snapshot -> 
9. vertices part of anommalous component -> 
10. number of comp before and after the process : before -> 130127808 , after -> 130177722 
11. total offline ids count in march 2019 snapshot 860107894
12. total online ids count in large component


final_vertex_set = spark.read.paruqet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/all_march_vertices_stamped_with_scoring/")
final_edge_set = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/all_march_edges_stamped_with_string_ids_and_flags")
