input schema : df["component(Array(BigInt))" , "id(Array(Integer))" , "types(Array(String))" , "edges(Array(Map(Long->Long)))"]
output schema : df["component(BigInt)" , "OMR_list_for_all_offline_ids_in_cc(Array(BigInt))"]

def OMR(x):
	data = x['edges']
	types = x["types"]
	hops_online_reached=[]
	graph = nx.Graph()
	for i in data:
		graph.add_edge(int(list(i.keys())[0]), int(list(i.values())[0]))
	vertices = x["id"]
	list_new = []
	count1=0
	omr_list = []
	for node in x["id"]:
		try:
			if x["types"][x["id"].index(node)] == "offline":
				paths = dict(nx.single_source_shortest_path_length(graph, node))
				have_online = False
				tup = [[vert , hoop] for vert , hoop in paths.items()]
				tupe_sorted = sorted(tup, key=itemgetter(1))
				for tu in tupe_sorted:
					if x["types"][x["id"].index(tu[0])] == "online" and tu[1] <= 5: 
						if t[0] in omr_list:
							pass
						else: 
							omr_list.append(tu[0])
						have_online = True
					else:
						pass
			else:
				pass	
		except:
			pass	
	return x["component"] ,  omr_list
