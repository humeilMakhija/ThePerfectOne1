input schema : df["component(Array(BigInt))" , "id(Array(Integer))" , "types(Array(String))" , "edges(Array(Map(Long->Long)))"]
output schema : df["component(BigInt)" , "offline_id_IMR_list(Array((BigInt , String)))"]

def IMR(x):
	data = x['edges']
	types = x["types"]
	hops_online_reached=[]
	graph = nx.Graph()
	for i in data:
		graph.add_edge(int(list(i.keys())[0]), int(list(i.values())[0]))
	vertices = x["id"]
	list_new = []
	count1=0
	for node in x["id"]:
		try:
			if x["types"][x["id"].index(node)] == "offline":
				paths = dict(nx.single_source_shortest_path_length(graph, node))
				have_online = False
				tup = [[vert , hoop] for vert , hoop in paths.items()]
				tupe_sorted = sorted(tup, key=itemgetter(1))
				for tu in tupe_sorted:
					if x["types"][x["id"].index(tu[0])] == "online" and tu[1] <= 5 : 
						# hops_online_reached.append((node , tu[1]))
						have_online = True
						list_new.append((node , "reached"))
						break
					else:
						pass
				if have_online == True :
					pass
				else : 
					list_new.append((node , "not_reached"))	
		except:
			list_new.append((node , "not_reached"))	
	# len(list_new) , len(graph.nodes()) , len(x["id"]),x["vtypes"] , x["id"] , paths
	return x["component"] ,  list_new

## create sample segment of offline vertices
sample_comp = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/test_sample/CC/0.25")
sample_comp = sample_comp.drop("id" , "type")
## component data witb component for vertices , types and edges 
comp_all = spark.read.parquet("gs://gcs-virginia-all-us-datascience-adhoc-internal-zeotap-com/humeil/data_till_march2019/clusters_PIC/number="+cluster_number+"/iteration="+iterations1+"/final_comp_with_vertices_types_version_2")
sample_comp1 = sample_comp.join(comp_all , [sample_comp.flag == comp_all.id]).drop("vtypes").drop("id")
# sample_comp1 = final.join(sample_comp , [final.id == sample_comp.flag]).drop("flag")
sample_comp2 = sample_comp1.groupby("component").agg(collect_list(col("flag")).alias("sample_id")).withColumnRenamed("component" , "comp_new")
sample_comp2.join(final , [sample_comp2.comp_new == final.component]).drop("component").rdd.map(lambda x: IMR(x)).toDF(["component" , "list_new" , "vtypes" , "omr"]).rdd.flatMap(lambda x: [(y[0] , y[1]) for y in x["list_new"]]).toDF(["a","b"]).distinct().filter(F.col("b") == "reached").count()

## end of code

# sample_comp2.join(final , [sample_comp2.comp_new == final.component]).drop("component").rdd.map(lambda x: IMR(x)).toDF(["component" , "list_new" , "vtypes" , "omr"]).select("omr").select(explode("omr").alias("omr")).select("omr").distinct().count()

