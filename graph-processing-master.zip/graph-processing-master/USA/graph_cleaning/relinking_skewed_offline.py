## relinking skewed offline ids 
input schema : df["src_component(BigInt)" , "src_vertex(BigInt)" , "dst_vertex(BigInt)" , "dst_component(BigInt)" , "new(Array(Integer))"]
## new is list of (online ids corresponding to each destination component to which dst ids are linked to) 
output schema :  df["src_component(BigInt)" , "new_destination_component(BigInt)"] 
## assign all the verticces of previous component to new component based on majority voting and atleast 1 online id in destination component , 
##approach can be changed if the size get exploded , then we can assign each vertex to different component based on different relinking approach 

def relinking_skewed_offline(x):
	list_of_online_comps = []
	list_of_comps = []
	final_component_to_assign = -2
	try:
		for i in range(0 , len(x["new"])):
			if x["new"][i] > 0 : 
				list_of_online_comps.append(x["new"][i])
		data = sorted(list_of_online_comps)[0]
		ind = x["new"].index(data)
		final_component_to_assign = x["dst_component"][ind] ##Counter(list_of_comps).most_common(1)[0][0]
	except:
		final_component_to_assign = x["src_comp"]
	return  x["src_comp"]   , final_component_to_assign 
