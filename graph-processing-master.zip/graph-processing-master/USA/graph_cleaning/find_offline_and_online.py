input schema : df["component(BigInt)" , "list_of_vertex_types(Array(String))" , "list_of_ids(Array(Integer))"]
output schema : df["component(BigInt)" , "offline_id_count(BigInt)" , "online_id_count(BigInt)"] 
def find_offline_and_online(x):
	offline_count = 0
	online_count = 0
	for i in x["types"]:
		if i == "offline":
			offline_count += 1
		else:
			online_count += 1
	return x["component"]  ,offline_count ,  online_count
