import pyspark.sql.functions as F
from pyspark.sql.types import *
import networkx as nx
from graphframes import *
import numpy as np
from operator import itemgetter


### find offline and online count
def find_offline_and_online(x):
	offline_count = 0
	online_count = 0
	for i in x["types"]:
		if i == "offline":
			offline_count += 1
		else:
			online_count += 1
	return x["component"]  ,offline_count ,  online_count
  
## relinking skewed offline ids 
def relinking_offline(x):
	list_of_online_comps = []
	list_of_comps = []
	final_component_to_assign = -2
	try:
		for i in range(0 , len(x["new"])):
			if x["new"][i] > 0 : 
				list_of_online_comps.append(x["new"][i])
		data = sorted(list_of_online_comps)[0]
		ind = x["new"].index(data)
		final_component_to_assign = x["dst_component"][ind] ##Counter(list_of_comps).most_common(1)[0][0]
	except:
		final_component_to_assign = x["src_comp"]
	return  x["src_comp"]   , final_component_to_assign 
  
## relinking skewed online ids 
def relinking_online(x):
	list_of_offline_comps = []
	list_of_comps = []
	final_component_to_assign = -1
	try:
		for i in range(0 , len(x["new"])):
			if x["new"][i] > 0 : 
				list_of_offline_comps.append(x["new"][i])
		data = sorted(list_of_offline_comps)[0]
		ind = x["new"].index(data)
		final_component_to_assign = x["dst_component"][ind] ##Counter(list_of_comps).most_common(1)[0][0]
	except:
		final_component_to_assign = x["src_comp"]
	return  x["src_comp"]   , final_component_to_assign 

def IMR(x):
	data = x['edges']
	types = x["types"]
	hops_online_reached=[]
	graph = nx.Graph()
	for i in data:
		graph.add_edge(int(list(i.keys())[0]), int(list(i.values())[0]))
	vertices = x["id"]
	list_new = []
	count1=0
	for node in x["id"]:
		try:
			if x["types"][x["id"].index(node)] == "offline":
				paths = dict(nx.single_source_shortest_path_length(graph, node))
				have_online = False
				tup = [[vert , hoop] for vert , hoop in paths.items()]
				tupe_sorted = sorted(tup, key=itemgetter(1))
				for tu in tupe_sorted:
					if x["types"][x["id"].index(tu[0])] == "online" and tu[1] <= 5 : 
						# hops_online_reached.append((node , tu[1]))
						have_online = True
						list_new.append((node , "reached" , tu[1] , x["types"][x["id"].index(node)]))
						break
					else:
						pass
				if have_online == True :
					pass
				else : 
					list_new.append((node , "not_reached"))	
		except:
			list_new.append((node , "not_reached"))	
	# len(list_new) , len(graph.nodes()) , len(x["id"]),x["vtypes"] , x["id"] , paths
	return x["component"] ,  list_new , x["types"] 

## getOnlineGreaterThan50
def getOnlineGreaterThan50(x):
	if "online" in x["dst_type"]:
		return x["id_type"] , x["id"] , dict(collections.Counter(x["dst_type"]))["online"]
	else:
		return x["id_type"] , x["id"] , 0
