import networkx as nx
from networkx.utils import not_implemented_for
from networkx.algorithms.approximation import ramsey

__all__ = ["clique_removal", "max_clique", "large_clique_size"]


def max_clique(G):
    if G is None:
        raise ValueError("Expected NetworkX graph!")
    cgraph = nx.complement(G)
    iset, _ = clique_removal(cgraph)
    return iset



def clique_removal(G):
    graph = G.copy()
    c_i, i_i = ramsey.ramsey_R2(graph)
    cliques = [c_i]
    isets = [i_i]
    while graph:
        graph.remove_nodes_from(c_i)
        c_i, i_i = ramsey.ramsey_R2(graph)
        if c_i:
            cliques.append(c_i)
        if i_i:
            isets.append(i_i)
    # Determine the largest independent set as measured by cardinality.
    maxiset = max(isets, key=len)
    return maxiset, cliques

@not_implemented_for("directed")
@not_implemented_for("multigraph")
def large_clique_size(G):
    degrees = G.degree
    def _clique_heuristic(G, U, size, best_size):
        if not U:
            return max(best_size, size)
        u = max(U, key=degrees)
        U.remove(u)
        N_prime = {v for v in G[u] if degrees[v] >= best_size}
        return _clique_heuristic(G, U & N_prime, size + 1, best_size)
    best_size = 0
    nodes = (u for u in G if degrees[u] >= best_size)
    for u in nodes:
        neighbors = {v for v in G[u] if degrees[v] >= best_size}
        best_size = _clique_heuristic(G, neighbors, 1, best_size)
    return best_size