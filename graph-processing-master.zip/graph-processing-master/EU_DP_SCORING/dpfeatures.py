Take a dp and get its graph-G1
now find the features of G1-->

Structure features-

Triangle count - 
network average clustering coefficient-
(the overall level of clustering in a network is as the average of the local clustering coefficients of all the vertices.)


length of cut set -
Let 'G'= (V, E) be a connected graph. A subset E' of E is called a cut set of G if deletion of all the edges of E' from G makes G disconnect.
minimum_node_cut(networkx)


modularity - A global graph G1 feature- 

 It was designed to measure the strength of division of a network into modules. Networks with high modularity have dense connections between the nodes within modules but sparse connections between nodes in different modules.


Betweeness Centrality -
This metric defines and measures the importance of a node in a network based upon how many times it occurs in the shortest path between all pairs of nodes in a graph.
In a similar way, betweeness centrality for an edge can be defined.
Application wise, A node with high BC when removed causes a huge disruption in network. For an edge, a node with high BC can be thought as a bridge.



randomwalk of length L and store all the id types in the path


maxclique(A clique in an undirected graph G = (V, E) is a subset of the vertex set C subseteq V such that for every two vertices in C there exists an edge connecting the two. This is equivalent to saying that the subgraph induced by C is complete)
Radius(The radius of a graph is the minimum graph eccentricity of any graph vertex in a graph.
eccentricity-The maximum distance between a vertex to all other vertices is considered as the eccentricity of the vertex. It is denoted by e(V).)
Breadth

diameter(max eccentricity)

length of periphery(nodes with eccentricity==diameter)


GED-(in networkx, its the graph edit distance between two input graphs)
the returned values for a graph with all other graphs, can be normalized to 0-1

Functional features-
vertex degree distribution ( approxQuantile)

(all these are calculated for a connected component, so , feature of graph can be a weighted average of all comps,(weight can be size of that cc))


Functional features-

percent of no.of times seen on each day of the week (heirarchial)
which hour of the day( the mean hour of the component)
offline count
online count
meansize of ccs in G1
no.of cc / total c.c in graph
no.of skewed cc (online and offline) - an indepenedent feature
(these are global graph features)
 #May be percent of eachid type (no.of idmid1's in G1/total idmid1's in whole Graph)
make three grps based on density of ccs


The all pair similarity score can be cosine distance, now to assign scores based on these distance values, a algo similar to pagerank can be followed
to incrementally update the score of each graph (initially a graph is attached to all other graphs with weight 1/n and these weights keep changing, finally, the score for each graph will be weighted sum of those cosine distance*weight)



Features should be disjoint
individual features of dps-


dp alonness
dp cover 
dp ingestion 
dp off online
dp betweenness_centrality
dp usefullness in final graph 
dp degree_distribution 

find how much data only this dp is seeing

find how may offlineonline  links a dp giving
so -> less score for skewed ones , so on ideally, offline count=8

an set 
cover problem


SO, set cover can help 

from the paper, set cover with threshold can also be done (which is approximate anyways)

the newness metrix can also be with respect to old data(we get diff data and compare that with existig data)

dps which give around same sized ccs are good(majority are of similar size)

ingestion percent


PAGE RANK 

BetweenessCENTRALITY OF NODES-
within a cc, if there are many nodes with high BC (means many nodes which are almost bridges), then its may be bad dp 
so, now what is the value of high?
may be depending on how many nodes are close to highest BC value of cc 
like majority of nodes will have less or avg BC, so ones with mean+sigma BCs are bridged ones 


once we get dp scores initially, 
then using pagerank similar algo, dps score can be iteratively updated,
a dp which connected to bad dp is also bad 
so what is connection of dps?
the All pair similarity we found, 
for a dp, the other dps which are very much correlated to this dp are the connections to it 
so , y aboive approaches we have a base dp score and then using this pagerank iterative algo with a dampingfacto also, the dp score can be further refined 






