
sub=df.select('component').subtract(interm.select('component')).distinct()
+---------+                                                                     
|component|
+---------+
|      515|
|      623|
|     1151|
|     1388|
|     1436|
|     2296|
|     2820|
|     3234|
|     5171|
|     5571|
|     6083|
|     6359|
|     6820|
|     7500|
|     7590|
|     7658|
|     7762|
|     9318|
|    10721|
|    11390|
+---------+
sub.write.mode('overwrite').parquet(path+'/subtracted_ccs')
# 59380583
 482398185 
 729418766 
 1153060386.39
 {'738', '87'} 

cc_with_edges=spark.read.parquet(path+"cc_merged_with_edges")
trav_edges_cc=cc_with_edges.filter(F.col('src_component')==F.col('dst_component')).drop('dst_component').withColumnRenamed('src_component','component')
# 1895575051
df=trav_edges_cc.groupby('component').agg( F.collect_list( F.struct(F.col('src'),F.col('dst'))).alias('edges'))

cc_counts=spark.read.parquet(path+'/final_ccs_counts')
sub=spark.read.parquet(path+'/subtracted_ccs')
sub=sub.filter(F.col('component')!=515)  #this is the only compoentn with size>10000
sub=sub.withColumnRenamed('component','component_')
df_=sub.join(df,df.component==sub.component_).drop('component_')



df_.write.mode('overwrite').parquet(path+'/intermedia')
df_=spark.read.parquet(path+'/intermedia')
try:
	def bc_edge(x):
		edges=list(map(lambda x:tuple(x),x['edges']))
		graph_nx=nx.from_edgelist(edges)
		edge_bcs=nx.edge_betweenness_centrality(graph_nx)
		return x['component'],edge_bcs
	df_.rdd.map(lambda x: bc_edge(x)).toDF(['component','edges_with_bcs']).write.mode('overwrite').parquet(path+'sub_edges_bcs_interm_')
except:
	print('NO')


sub2=spark.read.parquet(path+'sub_edges_bcs_interm_')
# 58506775 coz only these were written in path 
df2=df_.join(sub2, on=['component'],how='left_anti')
df2.rdd.map(lambda x: bc_edge(x)).toDF(['component','edges_with_bcs']).write.mode('overwrite').parquet(path+'sub_edges_bcs_interm__')


sub3=spark.read.parquet(path+'sub_edges_bcs_interm__')
# 654586   
df3=df2.join(sub3, on=['component'],how='left_anti')
219221  
df3.rdd.map(lambda x: bc_edge(x)).toDF(['component','edges_with_bcs']).write.mode('overwrite').parquet(path+'sub_edges_bcs_interm___')
#nothing happening (count =0 )

df3.write.mode('overwrite').parquet(path+'/df3')
def custom_bc_edge(x,k):
	edges=list(map(lambda x:tuple(x),x['edges']))
	graph_nx=nx.from_edgelist(edges)
	edgebcs=edge_betweenness_centrality(graph_nx,k) 
	return x['component'],edgebcs 
ret=df3.rdd.map(lambda x:custom_bc_edge(x,50)).toDF(['component','edges_with_bcs']) # 50 coz the mean comp size is 9 and max is 68k
# 219221 
ret.write.mode('overwrite').parquet(path+'subb_edges_bcs_interm___')


def fun(x):
	return 1,len(x['edges'])
f=df.rdd.map(lambda z:fun(z)).toDF(['dum','lent'])
#now do it for the remaining last componont 515 
cc_with_edges=spark.read.parquet(path+"cc_merged_with_edges")
trav_edges_cc=cc_with_edges.filter(F.col('src_component')==F.col('dst_component')).drop('dst_component').withColumnRenamed('src_component','component')
# 1895575051
df=trav_edges_cc.groupby('component').agg( F.collect_list( F.struct(F.col('src'),F.col('dst'))).alias('edges'))
df=df.filter(F.col('component')==515)
df.write.mode('overwrite').parquet(path+'/remaining_one_df')
df=spark.read.parquet(path+'/remaining_one_df')
ret=df.rdd.map(lambda x :custom_bc_edge(x,100000)).toDF(['component','edges_with_bcs'])




total comps-131,008,530 
interm=spark.read.parquet(path+'edgesbcs_interm')
# 71627947
sub2=spark.read.parquet(path+'sub_edges_bcs_interm_')
# 58506775 
sub3=spark.read.parquet(path+'sub_edges_bcs_interm__')
# 654586 
sub4=spark.read.parquet(path+'subb_edges_bcs_interm___')
# 219221

total made- 131008529
one comp- 515 is missing  

comp515=trav_edges_cc.filter(F.col('component')==515).distinct()
# 1770455 
def InfoMap(x):
	import infomap
	from collections import defaultdict
	d = defaultdict(list)
	community_dict = dict()
	data = x['edges']
	im = infomap.Infomap()
	for i in data:
		im.add_link(int(list(i.keys())[0]), int(list(i.values())[0]))
	im.run()
	for node_id, module_id in im.modules:d[module_id].append(node_id)
	return 1 , {min(j):j for i,j in dict(d).items()}


def gettraversibleedges(comps_final,final_edges_to_apply_cc,data=""):
	max_comp_intermediate_edges=comps_final.join(final_edges_to_apply_cc, [comps_final.id == final_edges_to_apply_cc.src]).drop("id")
	max_comp_intermediate_edges=max_comp_intermediate_edges.withColumnRenamed("component","src_component")
	max_comp_edges=max_comp_intermediate_edges.join(comps_final , [comps_final.id == max_comp_intermediate_edges.dst]).drop("id").withColumnRenamed("component","dst_component")
	return max_comp_edges.filter(F.col("src_component") == F.col("dst_component")).drop("dst_component").withColumnRenamed("src_component" , "component")


def breakittolessthanlakh(comp_edges): #component,src,dst
	comp_edges=comp_edges.distinct()
	ind=0
	flag=True
	schema = StructType([
		  StructField('component', LongType(), False),
		  StructField('src', LongType(), False),
		  StructField('dst', LongType(), False),
		  ])
	finaldf=spark.sparkContext.parallelize([]).toDF(schema)
	while(flag):
		comp_count=comp_edges.groupby('component').count()
		maxcount= comp_count.agg({"count": "max"}).collect()[0]['max(count)']
		ideals=comp_count.filter(F.col('count')<100000).select('component').distinct().withColumnRenamed('component','component_')
		final_df=final_df.union(comp_edges.join(ideals,ideals.component_==comp_edges.component).drop('component_'))
		ideals=ideals.withColumnRenamed('component_','component')
		tobecleaned=comp_edges.join(ideals,on=['component'],how='left_anti')
		if(maxcount>=100000):
			max_comp_edges_as_dict=tobecleaned.groupby('component').agg(F.collect_list(F.create_map(F.col("src") , F.col("dst"))).alias("edges"))
			max_comp_edges_as_dict.rdd.map(lambda x: InfoMap(x)).toDF([ "dummy","community_dict"]).write.mode("overwrite").parquet(path+"/comp_communities_detected/"+ind)
			y=spark.read.parquet(path+"/comp_communities_detected/"+ind).drop('dummy')
			df=y.select(F.explode("community_dict").alias("component" , "id"))
			df2=df.select("component" , F.explode("id").alias("id"))
			df2.write.mode("overwrite").parquet(path+"/communitie_with_ids/"+ind)
			df2=spark.read.parquet(path+"/communitie_with_ids/"+ind)
			comp_edges=gettraversibleedges(df2,tobecleaned.select('src','dst'))
			comp_edges.write.mode('overwrite').parquet(path+'/comp_edges_at_itr/'+ind)
			ind+=1
			comp_edges=spark.read.parquet(path+'/comp_edges_at_itr/'+ind)
		else:
			flag=False 
	return final_df 






max_comp_edges_as_dict=comp515.select('src','dst').groupby().agg(F.collect_list(F.create_map(F.col("src") , F.col("dst"))).alias("edges"))
max_comp_edges_as_dict.rdd.map(lambda x: InfoMap(x)).toDF([ "dummy","community_dict"]).write.mode("overwrite").parquet(path+"/515comp_communities_detected")
y=spark.read.parquet(path+"/515comp_communities_detected")
df=y.select(F.explode("community_dict").alias("component" , "id"))
df2=df.select("component" , F.explode("id").alias("id"))
df2.write.mode("overwrite").parquet(path+"/comp515_communitie_with_ids")
df2=spark.read.parquet(path+"/comp515_communitie_with_ids")
# 904814
df2.groupby('component').count().sort(F.col("count").desc()).show()
+---------+------+                                                              
|component| count|
+---------+------+
|      515|377128|
|     1310|225283|
|     1029|194238|
|      926|108165|
# +---------+------



df2_edges=gettraversibleedges(df2,comp515.select('src','dst'))
# 1770446 

df2_edges.write.mode('overwrite').parquet(path+'comp515_communities_travedges')
df2_edges=spark.read.parquet(path+'comp515_communities_travedges')

max_comp_edges_as_dict=df2_edges.groupby('component').agg(F.collect_list(F.create_map(F.col("src") , F.col("dst"))).alias("edges"))
max_comp_edges_as_dict.rdd.map(lambda x: InfoMap(x)).toDF([ "dummy","community_dict"]).write.mode("overwrite").parquet(path+"/515comp_second_communities_detected")
one=spark.read.parquet(path+"/515comp_second_communities_detected").drop('dummy')
dum=one.select(F.explode("community_dict").alias("component" , "id"))
final=dum.select("component" , F.explode("id").alias("id"))
final.write.mode("overwrite").parquet(path+"/comp515_second_communitie_with_ids")
final=spark.read.parquet(path+"/comp515_second_communitie_with_ids")
904814
final.groupby('component').count().sort(F.col("count").desc()).show()
+---------+------+                                                              
|component| count|
+---------+------+
|      515|259266|
|     6164|132626|
|     1310| 92657|
|      926| 71091|
|    12804| 53641|
|     1605| 44993|
|     1181| 42975|
|    14622| 37074|
|     2171| 23379|
|     5591| 21380|
|    55294| 19865|
|    87309| 13606|
|    16792| 12170|
|     1029| 12069|
|    77286| 11473|
|    16569| 10814|
|    13828|  9657|
|     4325|  8589|
|    76452|  7778|
|    39874|  7369|
+---------+------+ 


#break more than 1lakh ones 
onelakcomps=final.filter(F.col('component')==515).union( final.filter(F.col('component')==6164) )


df3_edges=gettraversibleedges(onelakcomps,comp515.select('src','dst'))
max_comp_edges_as_dict=df3_edges.groupby('component').agg(F.collect_list(F.create_map(F.col("src") , F.col("dst"))).alias("edges"))
max_comp_edges_as_dict.rdd.map(lambda x: InfoMap(x)).toDF([ "dummy","community_dict"]).write.mode("overwrite").parquet(path+"/515comp_third_communities_detected")
one=spark.read.parquet(path+"/515comp_third_communities_detected").drop('dummy')
dum=one.select(F.explode("community_dict").alias("component" , "id"))
final2=dum.select("component" , F.explode("id").alias("id"))
final2.write.mode("overwrite").parquet(path+"/comp515_third_communitie_with_ids")
final2=spark.read.parquet(path+"/comp515_third_communitie_with_ids")
# 391892
final2.groupby('component').count().sort(F.col("count").desc()).show()
+---------+------+                                                              
|component| count|
+---------+------+
|      515|223166|
|    39495| 32979|
|    24160| 32404|
|     6164| 22497|
|    57528| 20090|
|    87726| 12255|
|   116793| 11598|
|   541437| 11287|
|    10966|  9172|
|    48813|  7165|
|  1807169|  6158|
|    66714|  3121|
+---------+------+

#break more than 1lakh ones 
onelakcomps=final2.filter(F.col('component')==515)
df4_edges=gettraversibleedges(onelakcomps,comp515.select('src','dst'))
max_comp_edges_as_dict=df4_edges.groupby('component').agg(F.collect_list(F.create_map(F.col("src") , F.col("dst"))).alias("edges"))
max_comp_edges_as_dict.rdd.map(lambda x: InfoMap(x)).toDF([ "dummy","community_dict"]).write.mode("overwrite").parquet(path+"/515comp_4th_communities_detected")
one=spark.read.parquet(path+"/515comp_4th_communities_detected").drop('dummy')
dum=one.select(F.explode("community_dict").alias("component" , "id"))
final3=dum.select("component" , F.explode("id").alias("id"))
final3.write.mode("overwrite").parquet(path+"/comp515_4th_communitie_with_ids")
final3=spark.read.parquet(path+"/comp515_4th_communitie_with_ids")
# 223166
final3.groupby('component').count().sort(F.col("count").desc()).show()
+---------+-----+
|component|count|
+---------+-----+
|      925|28017|
|      515|27254|
|    10593|20914|
|     1500|15518|
|    36329|14908|
|    20786|13811|
|    10298|11864|
|    71838|10838|
|    21965| 9211|
|     4384| 8260|
|    26859| 6347|
|   568818| 5313|
|    57432| 4757|
|   408611| 4434|
|  2930150| 3820|
|  1681913| 3774|
|   408271| 3171|
|    80409| 2703|
|   281179| 2186|
|  4942865| 2000|
# +---------+-----+

#DONE NOW UNION ALL 

final=spark.read.parquet(path+"/comp515_second_communitie_with_ids")
final_df=final3.union(final2.filter(F.col('component')!=515).union( final.filter( (F.col('component')!=515) & (F.col('component')!=6164))))
# 904814 
+---------+-----+                                                               
|component|count|
+---------+-----+
|     1310|92657|
|      926|71091|
|    12804|53641|
|     1605|44993|
|     1181|42975|
|    14622|37074|
|    39495|32979|
|    24160|32404|
|      925|28017|
|      515|27254|
|     2171|23379|
|     6164|22497|
|     5591|21380|
|    10593|20914|
|    57528|20090|
|    55294|19865|
|     1500|15518|
|    36329|14908|
|    20786|13811|
|    87309|13606|
+---------+-----+
final_df.groupby('component').count().sort(F.col("count").desc()).show()
final_df.write.mode('overwrite').parquet(path+'comp515_final_communites')
final_df=spark.read.parquet(path+'comp515_final_communites')
# 76 components 
final_df_edges=gettraversibleedges(final_df,comp515.select('src','dst'))
final_df_edges.write.mode('overwrite').parquet(path+'comp515_final_communites_with_edges')
final_df_edges=spark.read.parquet(path+'comp515_final_communites_with_edges')
# 1770144 -traversible edges (total edges were-1770455)
df=final_df_edges.groupby('component').agg( F.collect_list( F.struct(F.col('src'),F.col('dst'))).alias('edges'))
def bc_edge(x):
		edges=list(map(lambda x:tuple(x),x['edges']))
		graph_nx=nx.from_edgelist(edges)
		edge_bcs=nx.edge_betweenness_centrality(graph_nx)
		return x['component'],edge_bcs


df.rdd.map(lambda x: bc_edge(x)).toDF([ "component","edges_with_bcs"]).write.mode('overwrite').parquet(path+'comp515_edgesbcs_')
edgebcs515=spark.read.parquet(path+'comp515_edgesbcs_')
#only 64 comps written 
#see what are these 64
edgebcs515=edgebcs515.withColumnRenamed('component','component_')
includedcomps=edgebcs515.join(final_df_edges,edgebcs515.component_==final_df_edges.component).drop('component_')
includedcomps.select('component','src','dst').distinct().groupby('component').count().sort(F.col('count').desc()).show()

#see the subtracted comps
sub_comps=final_df_edges.join(edgebcs515.select('component').distinct(),on=['component'],how='left_anti')
# 12 comps - expected 
edges count-
+---------+------+                                                              
|component| count|
+---------+------+
|     1310|185430|
|      926|141529|
|    12804| 97472|
|     1181| 83241|
|     1605| 81158|
|    14622| 75899|
|    24160| 65513|
|    39495| 63099|
|      925| 53927|
|      515| 51657|
|   972545|  4125|
|  4942865|  3940|
+---------+------+

sub_comps.groupby('component').count().sort(F.col("count").desc()).show()
df=sub_comps.groupby('component').agg( F.collect_list( F.struct(F.col('src'),F.col('dst'))).alias('edges'))
def custom_bc_edge(x,k):
		edges=list(map(lambda x:tuple(x),x['edges']))
		graph_nx=nx.from_edgelist(edges)
		edge_bcs=edge_betweenness_centrality(graph_nx,k)
		return x['component'],edge_bcs
#written 

df.rdd.map(lambda x: custom_bc_edge(x,3000)).toDF([ "component","edges_with_bcs"]).write.mode('overwrite').parquet(path+'comp515_subedgesbcs')
edgebcs515=spark.read.parquet(path+'comp515_subedgesbcs')

 
allcompsbcs=edgebcs515.union(spark.read.parquet(path+'comp515_edgesbcs_'))
interm=spark.read.parquet(path+'edgesbcs_interm')
# 71627947
sub2=spark.read.parquet(path+'sub_edges_bcs_interm_')
# 58506775 
sub3=spark.read.parquet(path+'sub_edges_bcs_interm__')
# 654586 
sub4=spark.read.parquet(path+'subb_edges_bcs_interm___')
# 219221

total made- 131008529
one comp- 515 is missing  allcompsbcs

allcompsbcs=allcompsbcs.union(sub2.union(sub3.union(sub4.union(interm))))
131008605 (76 were comp515 broken down)
interm_=allcompsbcs.select("component",F.explode("edges_with_bcs"))
interm_.select('component','key.*','value').withColumnRenamed('_1','src').withColumnRenamed('_2','dst').withColumnRenamed('value','edge_bc').write.mode('overwrite').parquet(path+'all_edges_with_their_edgebcs')