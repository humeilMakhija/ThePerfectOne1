

"""
Ingestion percent

Count of offline-online links / total links

How much of new datalinks ONLY this dp has seen (/ total data it has seen)
"""

import pyspark.sql.functions as F
from pyspark.sql.types import *
import networkx as nx
from graphframes import *
from pyspark.mllib.clustering import PowerIterationClustering, PowerIterationClusteringModel
from itertools import chain, combinations
import math
from operator import itemgetter
from collections import Counter
from collections import defaultdict
from os import sys, path
import community as community_louvain
from pyspark.sql.functions import lit

# path="gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/graph/cleanup/country=BEL/Prudhvi/BEL_Graph_cleaning_new"
# edges_path_tube="gs://gcs-ireland-all-eu-daap-idu-bootstrap-internal-zeotap-com/run__20201123/tubeGraphEdges_idu_524/country=BEL"
# edges_path_nontube_req=path+"edges_nontube_with_askedtypes"
# all_vertices_path=path+"/final_vertices_to_apply_cc"
# all_edges_path=path+"/final_edges_to_apply_cc"
# long_mapped_ids_path = path+"data/all_ids_with_long_mapping"
# paths
path="gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/graph/cleanup/country=NLD/Prudhvi/NLD_Graph_cleaning_new"
edges_path_nontube="gs://gcs-ireland-all-eu-daap-idu-bootstrap-internal-zeotap-com/run__20201123/zeoGraphEdges_idu_524/country=NLD"
edges_path_tube="gs://gcs-ireland-all-eu-daap-idu-bootstrap-internal-zeotap-com/run__20201123/tubeGraphEdges_idu_524/country=NLD"
edges_path_nontube_req=path+"edges_nontube_with_askedtypes"
all_vertices_path=path+"/final_vertices_to_apply_cc"
all_edges_path=path+"/final_edges_to_apply_cc"
long_mapped_ids_path = path+"data/all_ids_with_long_mapping"
# created ones

#ingestion percent-
APPROACH-
TAKE ALL FINAL EDGES (TRAVERSIBLE ONES) , SO WE CHECK OUT OF THE TRAVERSIBLE EDGES EVERY DP HAS SEEN, HOW MUCH OF INGESTED ONES IT IS GIVING
#here also, we are bothered with distinct edges only, so parallel edges by same dp isnt considered

try:
	edges_tube=spark.read.parquet(edges_path_tube)
	edges_nontube =spark.read.parquet(edges_path_nontube_req)
	# DataFrame[vertex1: string, vertex1type: string, vertex2: string, vertex2type: string, dpid: int, timestamp: bigint, recordType: string]
	dp_tube=edges_tube.select('dpid','vertex1','vertex1type','vertex2','vertex2type','timestamp').distinct()
	dp_nontube=edges_nontube.select('dpid','vertex1','vertex1type','vertex2','vertex2type','timestamp').distinct()
	dp_tube.union(dp_nontube).distinct().write.mode('overwrite').parquet(path+"dpids_with_its_edges")
	dp_edges=spark.read.parquet(path+'dpids_with_its_edges')
	# 16847482
	#map to long
	long_mapped_ids=spark.read.parquet(long_mapped_ids_path)
	intermediate_edges = long_mapped_ids.join(dp_edges , [long_mapped_ids.id == dp_edges.vertex1 , long_mapped_ids.type == dp_edges.vertex1type]).drop("id","type").withColumnRenamed("long_id" , "src_long_id")
	long_mapped_ids.join(intermediate_edges , [long_mapped_ids.id == intermediate_edges.vertex2 , long_mapped_ids.type == intermediate_edges.vertex2type]).drop("id","type").withColumnRenamed("long_id" , "dst_long_id").write.mode("overwrite").parquet(path+"dp_edges_mapped_to_long")
	dp_longedges= spark.read.parquet(path+"dp_edges_mapped_to_long")
	c=dp_longedges.count()
	#  16847482
	all_dps_count=(dp_longedges.select('dpid').distinct().count())
	# 59
	#all required edges
	all_edges=spark.read.parquet(all_edges_path)	
	dp_longedges.join(all_edges,[all_edges.src==dp_longedges.src_long_id,all_edges.dst==dp_longedges.dst_long_id]).drop('src_long_id','dst_long_id').write.mode('overwrite').parquet(path+'dp_req_edges_with_longs')
	#IT NEEDS TO BE DONE FOR SRC=DST AND DST=SRC ALSO 
	dp_req_edges=spark.read.parquet(path+'dp_req_edges_with_longs')		
	dp_req_edges=dp_req_edges.withColumn("datetime",F.from_unixtime(F.col("timestamp")))
	total=all_edges.count()
	print("total_edges",total)
	# 422394
	dp_req_count=dp_req_edges.count()
	# 2544362 - since an edge is seen by multiple dps and also timestamps
	total_fromdps=dp_req_edges.select('src','dst').distinct().count()
	print(total_fromdps==total)
	# 422394 - as expected
	dps=dp_req_edges.select('dpid').distinct().collect()
	dps=list(map(lambda x:x[0],dps))
	required_dps_count=len(dps)
	#26
	# THE REMAINING 59-26 ARE ANYWAYS NEGATIVE SCORED IN DPCOVER CODE 
	#now give score 
	# score based on ingestion percent-
	dp_score_inges=defaultdict(int)
	for dp in dps:
		dp_score_inges[dp]="{:.8f}".format(float( -(dp_req_edges.filter(F.col('dpid')==dp).where(F.col('datetime').like("%00:00:00")).distinct().count()/dp_req_edges.filter(F.col('dpid')==dp).distinct().count()) ))
	# now the actual score based on ingestion percent shouldnt be very high so scale it down by alpha 
	# dp_score_inges={'1396': '-0.99948959', '335': '-0.00000000', '598': '-0.01685393', '1222': '-1.00000000', '667': '-1.00000000', '1110': '-0.74468085', '648': '-0.00000000', '1258': '-0.00000000', '738': '-0.99849085', '637': '-0.00000000', '1141': '-1.00000000', '525': '-1.00000000', '395': '-0.00000000', '979': '-0.00000000', '678': '-1.00000000', '1332': '-1.00000000', '120': '-0.00000000', '871': '-0.00000000', '314': '-0.00000000', '87': '-0.00000000', '404': '-0.51515152', '634': '-1.00000000', '876': '-0.00000000', '529': '-0.00000000', '1292': '-0.00000000', '59': '-0.00000000', '1361': '-0.00000000', '229': '-1.00000000'}
	alpha=0.05
	for i in dp_score_inges.keys():
		if(float(dp_score_inges[i])!=0):
			dp_score_inges[i]=alpha*float(dp_score_inges[i])
	# {'876': '-0.00000000', '678': -0.05, '314': '-0.00000000', '1258': '-0.00000000', '598': -0.032142857000000004, '1222': -0.05, '820': -0.05, '1361': '-0.00000000', '979': '-0.00000000', '1141': -0.05, '667': -0.05, '1396': -0.0499941755, '1332': -0.05, '105': '-0.00000000', '529': '-0.00000000', '87': '-0.00000000', '404': -0.0135135135, '738': -0.04998032250000001, '871': '-0.00000000', '634': -0.05, '1110': -0.05, '1292': '-0.00000000', '59': '-0.00000000', '229': -0.05, '648': '-0.00000000', '395': '-0.00000000'}
	#score based on no.of off-on links given
	#again it is seen only on all_edges becoz thats what is finnaly useful to us-
	dp_score_off_on=defaultdict(int)
	for dp in dps:
		dp_score_off_on[dp]="{:.8f}".format(float( (  (dp_req_edges.filter(F.col('dpid')==dp).filter(F.col("vertex1type")[0:2] == "id").filter(F.col("vertex2type")[0:2] != "id").count()+dp_req_edges.filter(F.col('dpid')==dp).filter(F.col("vertex2type")[0:2] == "id").filter(F.col("vertex1type")[0:2] != "id").count()) / dp_req_edges.filter(F.col('dpid')==dp).distinct().count() )))
	# {'876': '0.00000000', '678': '0.00000000', '314': '0.00000000', '1258': '0.00000000', '598': '0.53571429', '1222': '0.71316306', '820': '1.00000000', '1361': '0.00000000', '979': '0.00000000', '1141': '0.75762954', '667': '0.85921626', '1396': '0.63420170', '1332': '0.00000000', '105': '0.00000000', '529': '0.00000000', '87': '0.00000000', '404': '0.99324324', '738': '0.00000000', '871': '0.00000000', '634': '0.00000000', '1110': '0.31313131', '1292': '0.00000000', '59': '0.00000000', '229': '1.00000000', '648': '0.00000000', '395': '0.00000000'})
	# may be this score is also good and can be scaled up by alpha 
	alpha=1.1 
	print("off-on done")
	#now score based on how much of links only this dp has seen (onlyme edges/all edges I saw)
	# to get only me edges 
	# grp by wrt edges 
	dp_req_edges=dp_req_edges.select('dpid','src','dst','timestamp')
	only_mes=dp_req_edges.select('dpid','src','dst').distinct().groupby('src','dst').count().filter(F.col('count')==1)
	only_mescount=only_mes.count()
	print(only_mescount>=total)
	#411348 (out of 422394)
	only_mes=only_mes.withColumnRenamed('src','src_').withColumnRenamed('dst','dst_')
	df=only_mes.join(dp_req_edges,[dp_req_edges.src==only_mes.src_, dp_req_edges.dst==only_mes.dst_]).drop('src_','dst_').write.mode('overwrite').parquet(path+'only_me_edges_dpids')
	dp_only=spark.read.parquet(path+'only_me_edges_dpids')
	dp_edgeonly=dp_only.select('src','dst','dpid').distinct()
	e=dp_edgeonly.count()
	print(e==only_mescount)
	# 411348
	dp_edgeonly.select('dpid').distinct().count()
	# 24  
	dp_alones=dp_edgeonly.select('dpid').distinct().collect()
	dp_alones=list(map(lambda x:x[0],dp_alones))
	dp_score_aloness=defaultdict(int)
	total_edges=dp_req_edges.select('src','dst').distinct().count()
	print(total==total_edges)
	#422394
	for dp in dp_alones:
		alone_count=dp_edgeonly.filter(F.col('dpid')==dp).distinct().count()
		print(dp,alone_count)
		dp_score_aloness[dp]="{:.8f}".format(float( ( alone_count/total_edges)))
# {'876': '0.00000237', '678': '0.00128790', '1258': '0.00012784', '598': '0.00003788', '1222': '0.00185845', '820': '0.00018940', '1361': '0.00018466', '979': '0.00010180', '1141': '0.01506650', '667': '0.00077179', '1396': '0.91043670', '1332': '0.00000237', '529': '0.00001184', '87': '0.00278887', '404': '0.00000947', '738': '0.04028466', '871': '0.00000237', '634': '0.00000237', '1110': '0.00009233', '1292': '0.00000237', '59': '0.00012074', '229': '0.00008760', '648': '0.00035749', '395': '0.00002131'}
except Exception as e:
	print("No",e)
#now this score is to be scale accordingly
# if a dp produces 2 edges and both are new,score will be 1 which is very high for 2 edges
# so the scale factor can be percent of edges seen 
#THIS SCALING IS NOW DONE DIRECTLY IN THE ABOVE LOOP ONLY
# for dps in dp_score_aloness.keys():
# 	seencount=dp_req_edges.filter(F.col('dpid')==dps).select('src','dst').distinct().count()
# 	#this scaling can be added in the above for loop only 
# 	print(dps,seencount)
# 	dp_score_aloness[dps]="{:.8f}".format(float( (seencount/total_edges*float(dp_score_aloness[dps]))))
# {'1396': '0.92344411', '335': '0.00007288', '598': '0.00034616', '1222': '0.00098382', '667': '0.00051013', '1110': '0.00009109', '648': '0.00088362', '1258': '0.00056479', '738': '0.02948732', '1141': '0.00936452', '395': '0.00004555', '979': '0.00036438', '678': '0.00112046', '1332': '0.00376221', '120': '0.00002733', '871': '0.00001822', '87': '0.00888172', '634': '0.00000911', '876': '0.00003644', '529': '0.00005466', '1292': '0.00005466', '59': '0.00059211', '1361': '0.00067410', '229': '0.00007288'}
#so, if dp has seen x amount of only me edges , then those x may be good or bad
#so dp need to be scored in accordance with anomal value of those x edges
#so to score edges, betweeness centrality can be used
# more the bc, means it is near to bridge and so it can be anomaly
# now may be the score we use can be 1/bc (since more bc , more it is a bride, so more anomaly, less score)
#BC Implementation-
try:
	all_edges=spark.read.parquet(all_edges_path)
	cc_path_tube_nontube=path+"/connected_component_tube_nontube"
	cc_final=spark.read.parquet(cc_path_tube_nontube)
	final_edges_to_apply_cc=spark.read.parquet(path+"/final_edges_to_apply_cc")
	max_comp_intermediate_edges=cc_final.join(final_edges_to_apply_cc, [cc_final.id == final_edges_to_apply_cc.src]).drop("id")
	max_comp_intermediate_edges=max_comp_intermediate_edges.withColumnRenamed("component","src_component")
	max_comp_intermediate_edges.join(cc_final , [cc_final.id == max_comp_intermediate_edges.dst]).drop("id").withColumnRenamed("component","dst_component").write.mode("overwrite").parquet(path+"cc_merged_with_edges")
	cc_with_edges=spark.read.parquet(path+"cc_merged_with_edges")
	edge_count=cc_with_edges.count()
	print(edge_count==total)
	# 422394
	trav_edges_cc=cc_with_edges.filter(F.col('src_component')==F.col('dst_component')).drop('dst_component').withColumnRenamed('src_component','component')
	df=trav_edges_cc.groupby('component').agg( F.collect_list( F.struct(F.col('src'),F.col('dst'))).alias('edges'))
	#DF WITH COMPONENT-EDGE_LIST
	# def getcount(x):
	# 	return x['component'],len(x['edges'])
	# cdf=df.rdd.map(lambda x:getcount(x)).toDF(['comp','count'])
	# cdf.select('count').groupBy().sum().collect()
	# # 109776 - sum of counts
	# cdf=cdf.withColumnRenamed('count','countcdf')
	# test=cdf.join(interm,interm.component==cdf.comp).drop('comp')
	# #2657 
	# test.filter(F.col('countcdf')!=F.col('count')).count()
	def bc_edge(x):
		edges=list(map(lambda x:tuple(x),x['edges']))
		graph_nx=nx.from_edgelist(edges)
		edge_bcs=nx.edge_betweenness_centrality(graph_nx)
		return x['component'],edge_bcs
	print("bcedge start")
	interm=df.rdd.map(lambda x: bc_edge(x)).toDF([ "component","edges_with_bcs"])
	interm_=interm.select("component",F.explode("edges_with_bcs"))
	interm_.select('component','key.*','value').withColumnRenamed('_1','src').withColumnRenamed('_2','dst').withColumnRenamed('value','edge_bc').write.mode('overwrite').parquet(path+'edges_with_edgebcs')
	x=spark.read.parquet(path+'edges_with_edgebcs')
	edge_bcs_count=x.count()
	print(edge_bcs_count,total)
	#  coz it counted all undirected edges only and in the dataset there are b0th a-b and b-a edges
	# now use the dp_edgeonly df here 
	x=x.withColumnRenamed('src','src_').withColumnRenamed('dst','dst_')
	curr=dp_edgeonly.join(x,[x.src_==dp_edgeonly.src,x.dst_==dp_edgeonly.dst]).drop('src_','dst_')
	#  remaining are revrse direction edges
	curr=curr.union(dp_edgeonly.join(x,[x.dst_==dp_edgeonly.src,x.src_==dp_edgeonly.dst]).drop('src_','dst_'))
	curr.write.mode('overwrite').parquet(path+'aone_edges_with_edgebc')
	aloneedges=spark.read.parquet(path+'aone_edges_with_edgebc')
	alone_dp_count=aloneedges.count()
	print(alone_dp_count==e)
	aloneedges=aloneedges.withColumn('edge_score',1/F.col('edge_bc'))
	#scale the score between 0 -1
	def scalecolumn(df,col):
		from pyspark.ml.feature import MinMaxScaler
		from pyspark.ml.feature import VectorAssembler
		from pyspark.ml import Pipeline
		from pyspark.sql.functions import udf
		from pyspark.sql.types import DoubleType
		# UDF for converting column type from vector to double type
		unlist = udf(lambda x: round(float(list(x)[0]),3), DoubleType())
		assembler = VectorAssembler(inputCols=[col],outputCol=col+"_Vect")
		# MinMaxScaler Transformation
		scaler = MinMaxScaler(inputCol=col+"_Vect", outputCol=col+"_Scaled")
		# Pipeline of VectorAssembler and MinMaxScaler
		pipeline = Pipeline(stages=[assembler, scaler])
		# Fitting pipeline on dataframe
		returndf= pipeline.fit(df).transform(df).withColumn(col+"_Scaled", unlist(col+"_Scaled")).drop(col+"_Vect")
		return returndf
	dpid_with_edgescore=aloneedges.groupby('dpid').agg(F.avg(F.col('edge_score')).alias('avg_edgescore'))
	#now get avg edge_score for a dpid 
	dumm=scalecolumn(dpid_with_edgescore,'avg_edgescore')
	dumm.write.mode('overwrite').parquet(path+'dpid_with_avg_edgescore_scaled')
	dpids_edgescore=spark.read.parquet(path+'dpid_with_avg_edgescore_scaled')
	dpids_edgescore=dpids_edgescore.collect()
	for dp,_,score in dpids_edgescore:
		dp_score_aloness[dp]=score*float(dp_score_aloness[str(dp)])
except Exception as e:
	print("No",e)
# {'876': 1.8723000000000002e-07, '678': 0.0012879, '1258': 6.647679999999999e-06, '598': 1.2879200000000001e-06, '1222': 0.00010221475, '820': 5.3032e-06, '1361': 1.126426e-05, '979': 4.1738e-06, '1141': 0.00060266, '667': 1.620759e-05, '1396': 0.2713101366, '1332': 9.480000000000001e-09, '529': 1.3852800000000002e-06, '87': 4.462192e-05, '404': 0.0, '738': 0.02932723248, '871': 1.8960000000000002e-08, '634': 9.480000000000001e-09, '1110': 3.7855300000000004e-06, '1292': 7.821000000000001e-08, '59': 3.98442e-06, '229': 6.132e-07, '648': 8.937250000000002e-06, '395': 5.1144e-07}






#do the same for ids
# how many of new ids only this dp has seen 
try:
	dp_tube=edges_tube.select('dpid','vertex1','vertex1type').distinct().union(edges_tube.select('dpid','vertex2','vertex2type').distinct())
	dp_nontube=edges_nontube.select('dpid','vertex1','vertex1type').distinct().union(edges_nontube.select('dpid','vertex2','vertex2type').distinct())
	dp_tube.union(dp_nontube).distinct().write.mode('overwrite').parquet(path+"dpids_with_its_vertices")
	dp_vertices=spark.read.parquet(path+'dpids_with_its_vertices')
	#now join with long mapped ids 
	long_mapped_ids=spark.read.parquet(long_mapped_ids_path)
	all_dps=dp_vertices.select('dpid').distinct().count()
	# 59 no.of dps
	multiple_count=dp_vertices.count()
	# 17142650 the count of all vertices seen by dps( more than actual count coz one vertex can be seen by more than one dp) 
	dp_vertices.join(long_mapped_ids,[long_mapped_ids.id==dp_vertices.vertex1,long_mapped_ids.type==dp_vertices.vertex1type]).drop('vertex1','vertex1type').write.mode('overwrite').parquet(path+'dpids_with_its_vertices_long_mapped')
	dp_ids=spark.read.parquet(path+'dpids_with_its_vertices_long_mapped')
	# 17142650
	dp_longs=dp_ids.select('dpid','long_id')
	all_vertices=spark.read.parquet(all_vertices_path)
	allvs=all_vertices.count()
	# 311671
	# DataFrame[id: bigint]
	dp_longs.join(all_vertices,all_vertices.id==dp_longs.long_id).drop('id').write.mode('overwrite').parquet(path+'dpids_with_its_final_vertices')
	dp_reqids=spark.read.parquet(path+'dpids_with_its_final_vertices')
	dpidvs=dp_reqids.count()
	distinctids=dp_reqids.select('long_id').distinct().count()
	# 329466(ids with dps) and  311671(distinct ids)
	print(allvs==distinctids)
	#now grp by wrto id 
	alone_ids=dp_reqids.groupby('long_id').count().distinct().filter(F.col('count')==1)
	alone_ids=alone_ids.withColumnRenamed('long_id','long_id_').drop('count')
	alones=alone_ids.count()
	print(alones<=allvs)
	# 296671 (out of 311671)
	alone_ids.join(dp_reqids,dp_reqids.long_id==alone_ids.long_id_).drop('long_id_').write.mode('overwrite').parquet(path+'only_me_ids_dpids')
	aloneid_dps=spark.read.parquet(path+'only_me_ids_dpids')
	print(aloneid_dps.count()==alones)
	# 296671 
	alone_dps=aloneid_dps.select('dpid').distinct().collect()
	alone_dps=list(map(lambda x:x[0],alone_dps))
	print(len(alone_dps))
	# 23 (it was 24 for edges)
	dpidscore_aloness=defaultdict(int)
	total_ids=dp_reqids.select('long_id').distinct().count()
	#311671
	#coz based on above scaling logic, 
	for dp in alone_dps:
		alone_count=aloneid_dps.filter(F.col('dpid')==dp).distinct().count()
		print(alone_count,total_ids)
		dpidscore_aloness[dp]="{:.8f}".format(float( ( alone_count/total_ids )))
except Exception as e:
	print("No",e)

{'1396': '0.91746791', '335': '0.00001279', '598': '0.00029407', '1222': '0.00130415', '667': '0.00058815', '1110': '0.00010229', '648': '0.00062650', '1258': '0.00054979', '738': '0.00489695', '1141': '0.00866875', '395': '0.00006393', '979': '0.00034522', '678': '0.00007671', '1332': '0.01033090', '871': '0.00002557', '87': '0.01245333', '634': '0.00001279', '529': '0.00001279', '59': '0.00060093', '1361': '0.00033243', '229': '0.00014064'}
# now same as before, the ids have to scored based on anaomaly



# so node bc can be used in a similar way 
try:
	cc_with_edges=spark.read.parquet(path+"cc_merged_with_edges")
	trav_edges_cc=cc_with_edges.filter(F.col('src_component')==F.col('dst_component')).drop('dst_component').withColumnRenamed('src_component','component')
	df=trav_edges_cc.groupby('component').agg( F.collect_list( F.struct(F.col('src'),F.col('dst'))).alias('edges'))
	def bc_node(x):
		edges=list(map(lambda x:tuple(x),x['edges']))
		graph_nx=nx.from_edgelist(edges)
		node_bcs=nx.betweenness_centrality(graph_nx)
		return x['component'],node_bcs
	print("node_bc start")
	interm=df.rdd.map(lambda x: bc_node(x)).toDF([ "component","nodes_with_bcs"])
	interm_=interm.select("component",F.explode("nodes_with_bcs"))
	interm_.withColumnRenamed('key','id').withColumnRenamed('value','node_bc').write.mode('overwrite').parquet(path+'nodes_with_nodebcs')
	nodebcs=spark.read.parquet(path+'nodes_with_nodebcs')
	print(nodebcs.count()==distinctids)
	# 311671 as expected 
	aloneid_dps=spark.read.parquet(path+'only_me_ids_dpids')
	curr=aloneid_dps.join(nodebcs,nodebcs.id==aloneid_dps.long_id).drop('long_id')
	# 74998  
	curr.write.mode('overwrite').parquet(path+'alone_ids_with_nodebc')
	curr=spark.read.parquet(path+'alone_ids_with_nodebc')
	node_scores=curr.withColumn('node_score',1/F.col('node_bc'))
	# dpid_with_nodescore.select('avg_nodescore').withColumn('isNull_node_bc',F.col('avg_nodescore').isNull()).where('isNull_node_bc = True').count()
	#scale the score between 0 -1
	def scalecolumn(df,col):
		from pyspark.ml.feature import MinMaxScaler
		from pyspark.ml.feature import VectorAssembler
		from pyspark.ml import Pipeline
		from pyspark.sql.functions import udf
		from pyspark.sql.types import DoubleType
		# UDF for converting column type from vector to double type
		unlist = udf(lambda x: round(float(list(x)[0]),3), DoubleType())
		assembler = VectorAssembler(inputCols=[col],outputCol=col+"_Vect")
		# MinMaxScaler Transformation
		scaler = MinMaxScaler(inputCol=col+"_Vect", outputCol=col+"_Scaled")
		# Pipeline of VectorAssembler and MinMaxScaler
		pipeline = Pipeline(stages=[assembler, scaler])
		# Fitting pipeline on dataframe
		returndf= pipeline.fit(df).transform(df).withColumn(col+"_Scaled", unlist(col+"_Scaled")).drop(col+"_Vect")
		return returndf
	dpid_with_nodescore=node_scores.groupby('dpid').agg(F.avg(F.col('node_score')).alias('avg_nodescore'))
	#now get avg node_score for a dpid 
	dpid_with_nodescore=dpid_with_nodescore.fillna({'avg_nodescore':1})
	dum=scalecolumn(dpid_with_nodescore,'avg_nodescore')
	dum.write.mode('overwrite').parquet(path+'dpid_with_avg_nodescore_scaled')
	dum=spark.read.parquet(path+'dpid_with_avg_nodescore_scaled')
	dpids_nodescore=dum.collect()
	for dp,_,score in dpids_nodescore:
		dpidscore_aloness[dp]=score*float(dpidscore_aloness[str(dp)])
# {'678': 9.49083e-06, '1258': 0.0, '598': 2.581849e-05, '1222': 0.0007117499999999999, '820': 0.0, '1361': 0.0, '979': 0.0, '1141': 0.0013530290000000002, '667': 0.0, '1396': 0.92483099, '1332': 0.0, '529': 0.0, '87': 0.0, '404': 0.0, '738': 0.00022442251999999998, '871': 0.0, '634': 0.0, '1110': 0.0, '1292': 0.0, '59': 0.0, '229': 0.0, '648': 0.0, '395': 0.0}
except Exception as e:
	print("No",e)

#ROUGH WORK

#get degree distribution 
max(list(map(lambda x:x[1],(graph_nx.degree(list(graph_nx.nodes()))))))
# 708
x=list(map(list,list(graph_nx.degree(list(graph_nx.nodes())))))
dum=spark.createDataFrame(x,['id','degree'])
dum.write.mode('overwrite').parquet(path+'ids_with_degrees')
dum=spark.read.parquet(path+'ids_with_degrees')
array_of_percent=[0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,0.95,0.98,0.99,1.0]
array_of_percent_mapped=list(map(lambda x : str(x*100) + "%" , array_of_percent))
comp_data_array=dum.approxQuantile("degree" , array_of_percent  ,0.001)
data=list(zip(array_of_percent_mapped , comp_data_array))
field=[StructField("node_distribution",StringType(), True) , StructField("degree_distribution",DoubleType(), True)]
schema=StructType(field)
sqlContext = SQLContext(sc)
deg=sqlContext.createDataFrame(sc.parallelize(data), schema)
deg.show()
+-----------------+-------------------+
|node_distribution|degree_distribution|
+-----------------+-------------------+
|            10.0%|                1.0|
|            20.0%|                1.0|
|            30.0%|                1.0|
|            40.0%|                1.0|
|            50.0%|                1.0|
|            60.0%|                2.0|
|            70.0%|                2.0|
|            80.0%|                2.0|
|            90.0%|                3.0|
|            95.0%|                6.0|
|            98.0%|               16.0|
|            99.0%|               31.0|
|           100.0%|              708.0|
+-----------------+-------------------+

compare the degree distribution KL 
correlation among features

--> means 99% of nodes have degree less than equal to 31 


