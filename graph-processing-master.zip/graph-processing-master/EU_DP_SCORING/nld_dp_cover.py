import pyspark.sql.functions as F
from pyspark.sql.types import *
import networkx as nx
from graphframes import *
from pyspark.mllib.clustering import PowerIterationClustering, PowerIterationClusteringModel
from itertools import chain, combinations
import math
from operator import itemgetter
from collections import Counter
from collections import defaultdict
from os import sys, path
import community as community_louvain
from pyspark.sql.functions import lit


"""
Dp cover problem

A dp can be scored low if its producing majority of redundant old data.

So, the minimum dps with whom alone, the whole graph can be made are scored high and the dps which are not part , are producing redundant data

Similar to set cover classical problem

the newness metric can also be with respect to old data(we get incremental data and compare that with existing data)
"""

THE APPROACH- 
we are finding, in our final cleaned cc nodes, how much of each cc is contirbuting to that
since we dont use any parallel edges and repeated nodes , so a dps nodes are made disticnt 
TAKE THE MERGED CC, AND FIND ALL NODES IN that 
NOW, TAKE ALL DPS AND THE NODES THEY HAVE SEEN 
1. finding how much of the data a dp sees is in actual present in merged cc(coz most of the tube data is lost and dps that produced those are not useful for us)
	Just find for every dp how much percent of their data is among merged cc nodes 

2. After the above, just remove all the unrequired nodes from every dps list and now we need to find the minimum dp cover that covers the required all nodes 

3. Scoring based on above 2 points, INPROGRESS (may be score based on how much of part they contirbute to total set )

CURRENTLY JUST USING THE VERTICES INFO AND NOT THE COMPONENT INFO , SO THE FINAL VERTICES TO APPLY CC DF IS ENOUGH

path="gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/graph/cleanup/country=NLD/Prudhvi/NLD_Graph_cleaning_new"
edges_path_nontube="gs://gcs-ireland-all-eu-daap-idu-bootstrap-internal-zeotap-com/run__20201123/zeoGraphEdges_idu_524/country=NLD"
edges_path_tube="gs://gcs-ireland-all-eu-daap-idu-bootstrap-internal-zeotap-com/run__20201123/tubeGraphEdges_idu_524/country=NLD"
edges_path_nontube_req=path+"edges_nontube_with_askedtypes"
all_vertices_path=path+"/final_vertices_to_apply_cc"
all_edges_path=path+"/final_edges_to_apply_cc"
long_mapped_ids_path = path+"data/all_ids_with_long_mapping"

#now get every dp and the nodes they seen
# dpid-vertex id(long) df
try:
	edges_tube=spark.read.parquet(edges_path_tube)
	edges_nontube =spark.read.parquet(edges_path_nontube_req)
	# DataFrame[vertex1: string, vertex1type: string, vertex2: string, vertex2type: string, dpid: int, timestamp: bigint, recordType: string]
	dp_tube=edges_tube.select('dpid','vertex1','vertex1type').distinct().union(edges_tube.select('dpid','vertex2','vertex2type').distinct())
	dp_nontube=edges_nontube.select('dpid','vertex1','vertex1type').distinct().union(edges_nontube.select('dpid','vertex2','vertex2type').distinct())
	# dp_tube.union(dp_nontube).distinct().write.mode('overwrite').parquet(path+"dpids_with_its_vertices")
	dp_vertices=spark.read.parquet(path+'dpids_with_its_vertices')
	# #now join with long mapped ids 
	long_mapped_ids=spark.read.parquet(long_mapped_ids_path)
	multiple_count=dp_vertices.count()
	# # 17142650  the count of all vertices seen by dps( more than actual count coz one vertex can be seen by more than one dp) 
	# dp_vertices.join(long_mapped_ids,[long_mapped_ids.id==dp_vertices.vertex1,long_mapped_ids.type==dp_vertices.vertex1type]).drop('vertex1','vertex1type').write.mode('overwrite').parquet(path+'dpids_with_its_vertices_long_mapped')
	dp_ids=spark.read.parquet(path+'dpids_with_its_vertices_long_mapped')
	# # 17142650
	dp_longs=dp_ids.select('dpid','long_id')
	all_vertices=spark.read.parquet(all_vertices_path)
	allvs=all_vertices.count()
	# # 311671
	# # DataFrame[id: bigint]
	# dp_longs.join(all_vertices,all_vertices.id==dp_longs.long_id).drop('id').write.mode('overwrite').parquet(path+'dpids_with_its_final_vertices')
	dp_reqids=spark.read.parquet(path+'dpids_with_its_final_vertices')
	#ALL THE ABOVE PATHS ARE WRITTEN IN DP_IND_FEATURES
	#this df contains dpid and only those ids which are present in final all vertices 
	reqdps=dp_reqids.select('dpid').distinct().count()
	# 26 so out of 59 only 26 dps have seen ids which are present in final vertices 
	# THE REMAINING DPS WILL BE GIVEN A NEGATIVE SCORE OF -1 
	reqvs=dp_reqids.count()
	print(reqvs>=allvs)
	# 329466 (> 311671  coz an id can be seen by multiple dps)
	print(allvs==dp_reqids.select('long_id').distinct().count())
	# True  as expected
	#NOW DO THE STEP 1 
	#COLLECT ALL DPIDS 
	#USEFULNESS
	dps=dp_longs.select('dpid').distinct().collect()
	dp_score1=defaultdict(int)
	total=0
	usefuls=0
	for i in dps:
		curr_dp=i[0]
		total_seen_ids=dp_longs.filter(F.col('dpid')==curr_dp).select('long_id').distinct().count()
		useful_ids=dp_reqids.filter(F.col('dpid')==curr_dp).select('long_id').distinct().count()
		dp_score1[curr_dp]=useful_ids/total_seen_ids
		usefuls+=useful_ids
		total+=total_seen_ids  
	print(total==multiple_count)
	print(usefuls==reqvs)
	# True, True
	# total=(total ids+multiple dps=dp_longs.distinct().count())
	# usefuls= (total req ids+multiple dps=dp_reqids.count())
	for i in dp_score1.keys():
		dp_score1[i]="{:.8f}".format(float((dp_score1[i])))
	print("inital score is done")
	#REPEAT THE SAMETHING FOR EDGES ALSO
	#THE EDGES DFS RE ALREADY WRITTEN IN below CODE
	# {'307': '0.00000000', '75': '0.00000000', '876': '0.00035958', '678': '0.68051334', '1147': '0.00000000', '233': '0.00000000', '239': '0.00000000', '314': '0.00003802', '1258': '0.00018419', '63': '0.00000000', '598': '0.00098135', '1222': '1.00000000', '820': '1.00000000', '1361': '0.00002476', '979': '0.00031485', '556': '0.00000000', '1141': '1.00000000', '667': '1.00000000', '1257': '0.00000000', '1396': '0.99328032', '135': '0.00000000', '86': '0.00000000', '1332': '1.00000000', '105': '0.00021240', '575': '0.00000000', '529': '0.00028091', '1380': '0.00000000', '800': '0.00000000', '685': '0.00000000', '87': '0.00021368', '120': '0.00000000', '335': '0.00000000', '404': '1.00000000', '738': '0.59397247', '338': '0.00000000', '963': '0.00000000', '654': '0.00000000', '336': '0.00000000', '871': '0.00292612', '521': '0.00000000', '634': '1.00000000', '374': '0.00000000', '1110': '0.01425178', '516': '0.00000000', '637': '0.00000000', '1292': '0.00117890', '1480': '0.00000000', '370': '0.00000000', '625': '0.00000000', '59': '0.01006297', '1252': '0.00000000', '799': '0.00000000', '229': '1.00000000', '1148': '0.00000000', '95': '0.00000000', '648': '0.01274705', '395': '0.01323988', '331': '0.00000000', '12': '0.00000000'}
	# so, now all dps are given a positive score based on above dict values if value>0, if value=0 then a negative score of -0.5 can be given 
	dps=dp_reqids.select('dpid').distinct().collect()
	dps=list(map(lambda x:x[0],dps))
	print(len(dps)==reqdps)
	#26 (lendps)
	#the brute force NP solution for set cover is not possible to implemet
	#the number 28 was for belgiu only
	#28 dps 2^28 subsets for each subsets, there are dpids inside the subsets and for those dpids, filter and count union areperformed on dfs
	#so, follow greedy approximate algorithm
	#initally included elements=I
	#keep adding subsets to it, and at any point the subset u pich should have max [SI-I] value, i.e max no.of new elements it ha to give
	print('dp cover starts')
	schema = StructType([
	  StructField('long_id', LongType(), False),
	  ])
	included_ids=spark.sparkContext.parallelize([]).toDF(schema)
	n=len(dps)
	threshold=0.99
	total_cover=all_vertices.count()
	seendpids=set()
	while(included_ids.count()<threshold*total_cover):
		maxval=0
		maxdpid=-1
		for dpid in dps:
			if(dpid in seendpids):
				continue
			curr_ids=dp_reqids.filter(F.col('dpid')==dpid).select('long_id').distinct()
			diff=curr_ids.subtract(included_ids).distinct()
			curr_count=diff.count()
			if(curr_count>maxval):
					maxval=curr_count
					maxdpid=dpid
		if(maxdpid==-1):
			print("ERRORRRR!!!!")
			break
		print(included_ids.count(),maxdpid,seendpids,maxval)
		included_ids=included_ids.union(dp_reqids.filter(F.col('dpid')==maxdpid).select('long_id').distinct()).distinct()
		seendpids.add(maxdpid)
		print("UPDATED",included_ids.count())
		print(seendpids)
	dp_score_cover=defaultdict(int)
	#now score -
	for i in seendpids:
		dp_score_cover[i]= "{:.8f}".format(float( ( dp_reqids.filter(F.col('dpid')==i).distinct().count() / total_cover )))
except Exception as e:
	print("No",e)


seendpids- {'738', '1141', '1396'}
included_ids.count()-
309086 (>=308554.29)
{'738': '0.04015452', '1141': '0.02375903', '1396': '0.97225600'}
#The scoring shouldnt be in other of how the greedy algo chose the dpids
coz say a dpid1 has 99% data and other dpid2 has 99.1% , so dpid2 will be chosen with score 99.1 and the other dpid will then be scored only 0.1 around
so 


now again, the dps in seendpids are scored based on count of how much they seen/total count and other remaining are not given any score(not even a negative score)

since this score is very crucial may be it neeed to be scaled up by alpha 
alpha=1.5




#THE SAME DP COVER CAN BE DONE FOR EDGES AS WELL-


try:
	dp_longedges= spark.read.parquet(path+"dp_edges_mapped_to_long")
	#  (along with timestamps and multiple dpids) 
	all_edges=spark.read.parquet(all_edges_path)	
	e=all_edges.count()
	# # 422394
	# DataFrame[id: bigint]
	dp_req_edges=spark.read.parquet(path+'dp_req_edges_with_longs').select('dpid','src','dst').distinct()		
	req_edgescount=dp_req_edges.count()
	print(req_edgescount>=e)
	# 433936- since an edge is seen by multiple dps
	#NOW DO THE STEP 1 
	#COLLECT ALL DPIDS 
	dps=dp_longedges.select('dpid').distinct().collect()
	dp_score_edges=defaultdict(int)
	total=0
	usefuls=0
	for i in dps:
		curr_dp=i[0]
		total_seen_edges=dp_longedges.filter(F.col('dpid')==curr_dp).select('src_long_id','dst_long_id').distinct().count()
		useful_edges=dp_req_edges.filter(F.col('dpid')==curr_dp).select('src','dst').distinct().count()
		print(curr_dp,useful_edges,total_seen_edges)
		dp_score_edges[curr_dp]="{:.8f}".format(float((useful_edges/total_seen_edges)))
		usefuls+=useful_edges
		total+=total_seen_edges  
print(total==dp_longedges.select('dpid','src_long_id','dst_long_id').distinct().count(),total)
print(usefuls==req_edgescount)
# 13567066 True
	# total=(= total edges and multiple dps also =dp_longedges.select('dpid','src_long_id','dst_long_id').distinct().count())
	# usefuls= (=total req edges and multiple dps also=dp_req_edges.distinct().count())
	#  
	# so, now all dps are given a positive score based on above dict values if value>0, if value=0 then a negative score of -0.5 can be given 
try:
	dps=dp_req_edges.select('dpid').distinct().collect()
	dps=list(map(lambda x:x[0],dps))
	#the brute force NP solution for set cover is not possible to implemet
	#28 dps 2^28 subsets for each subsets, there are dpids inside the subsets and for those dpids, filter and count union areperformed on dfs
	#so, follow greedy approximate algorithm
	#initally included elements=I
	#keep adding subsets to it, and at any point the subset u pich should have max [SI-I] value, i.e max no.of new elements it ha to give
	print('edge cover starts')
	dp_req_edges=dp_req_edges.select('dpid','src','dst').distinct()
	schema = StructType([
	  StructField('src', LongType(), False),
	  StructField('dst', LongType(), False),
	  ])
	included_edges=spark.sparkContext.parallelize([]).toDF(schema)
	n=len(dps)
	threshold=0.99
	total_cover=all_edges.count()
	# 
	seendpids=set()
	while(included_edges.count()<threshold*total_cover):
		maxval=0
		maxdpid=-1
		for dpid in dps:
			if(dpid in seendpids):
				continue
			curr_edges=dp_req_edges.filter(F.col('dpid')==dpid).select('src','dst').distinct()
			diff=curr_edges.subtract(included_edges).distinct()
			curr_count=diff.count()
			if(curr_count>maxval):
					maxval=curr_count
					maxdpid=dpid
		if(maxdpid==-1):
			print("ERRORRRR!!!!")
			break
		print(included_edges.count(),maxdpid,seendpids,maxval)
		included_edges=included_edges.union(dp_req_edges.filter(F.col('dpid')==maxdpid).select('src','dst').distinct()).distinct()
		seendpids.add(maxdpid)
		print("UPDATED",included_edges.count())
		print(seendpids)
	dp_score_coveredges=defaultdict(int)
	for i in seendpids:
		dp_score_coveredges[i]= "{:.8f}".format(float( ( dp_req_edges.filter(F.col('dpid')==i).distinct().count() / total_cover )))
except Exception as error:
	print('No',error)

 {'738': '0.05909885', '1141': '0.02160542', '1396': '0.93429594'}
seendpids- {'738', '1141', '1396'}
0.99*total_cover
included_edges.count()-
418889  (>=0.99*422394 =418170.06)
0.99*total_cover
#now the scoring shouldnt be in other of how the greedy algo chose the dpids
coz say a dpid1 has 99% data and other dpid2 has 99.1% , so dpid2 will be chosen with score 99.1 and the other dpid will then be scored only 0.1 around
so 



now again, the dps in seendpids are scored based on count of how much they seen/total count and other remaining are not given any score(not even a negative score)

since this score is very crucial may be it neeed to be scaled up by alpha 
alpha=1.5







