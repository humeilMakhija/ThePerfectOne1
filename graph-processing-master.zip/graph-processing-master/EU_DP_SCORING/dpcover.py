import pyspark.sql.functions as F
from pyspark.sql.types import *
import networkx as nx
from graphframes import *
from pyspark.mllib.clustering import PowerIterationClustering, PowerIterationClusteringModel
from itertools import chain, combinations
import math
from operator import itemgetter
from collections import Counter
from collections import defaultdict
from os import sys, path
import community as community_louvain
from pyspark.sql.functions import lit


"""
Dp cover problem

A dp can be scored low if its producing majority of redundant old data.

So, the minimum dps with whom alone, the whole graph can be made are scored high and the dps which are not part , are producing redundant data

Similar to set cover classical problem

the newness metric can also be with respect to old data(we get incremental data and compare that with existing data)
"""

THE APPROACH- 
we are finding, in our final cleaned cc nodes, how much of each cc is contirbuting to that
since we dont use any parallel edges and repeated nodes , so a dps nodes are made disticnt 
TAKE THE MERGED CC, AND FIND ALL NODES IN that 
NOW, TAKE ALL DPS AND THE NODES THEY HAVE SEEN 
1. finding how much of the data a dp sees is in actual present in merged cc(coz most of the tube data is lost and dps that produced those are not useful for us)
	Just find for every dp how much percent of their data is among merged cc nodes 

2. After the above, just remove all the unrequired nodes from every dps list and now we need to find the minimum dp cover that covers the required all nodes 

3. Scoring based on above 2 points, INPROGRESS (may be score based on how much of part they contirbute to total set )

CURRENTLY JUST USING THE VERTICES INFO AND NOT THE COMPONENT INFO , SO THE FINAL VERTICES TO APPLY CC DF IS ENOUGH

path="gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/graph/cleanup/country=BEL/Prudhvi/BEL_Graph_cleaning_new"
edges_path_tube="gs://gcs-ireland-all-eu-daap-idu-bootstrap-internal-zeotap-com/run__20201123/tubeGraphEdges_idu_524/country=BEL"
edges_path_nontube_req=path+"edges_nontube_with_askedtypes"
all_vertices_path=path+"/final_vertices_to_apply_cc"
long_mapped_ids_path = path+"data/all_ids_with_long_mapping"

#now get every dp and the nodes they seen
# dpid-vertex id(long) df 
edges_tube=spark.read.parquet(edges_path_tube)
edges_nontube =spark.read.parquet(edges_path_nontube_req)
# DataFrame[vertex1: string, vertex1type: string, vertex2: string, vertex2type: string, dpid: int, timestamp: bigint, recordType: string]

dp_tube=edges_tube.select('dpid','vertex1','vertex1type').distinct().union(edges_tube.select('dpid','vertex2','vertex2type').distinct())
dp_nontube=edges_nontube.select('dpid','vertex1','vertex1type').distinct().union(edges_nontube.select('dpid','vertex2','vertex2type').distinct())
# dp_tube.union(dp_nontube).distinct().write.mode('overwrite').parquet(path+"dpids_with_its_vertices")
dp_vertices=spark.read.parquet(path+'dpids_with_its_vertices')
# #now join with long mapped ids 
long_mapped_ids=spark.read.parquet(long_mapped_ids_path)
# dp_vertices.select('dpid').distinct().count()
# # 57 no.of dps
dp_vertices.count()
# # 11777376 the count of all vertices seen by dps( more than actual count coz one vertex can be seen by more than one dp) (10535222 - the actual count neglecting multiple dps)

# dp_vertices.join(long_mapped_ids,[long_mapped_ids.id==dp_vertices.vertex1,long_mapped_ids.type==dp_vertices.vertex1type]).drop('vertex1','vertex1type').write.mode('overwrite').parquet(path+'dpids_with_its_vertices_long_mapped')
dp_ids=spark.read.parquet(path+'dpids_with_its_vertices_long_mapped')
# # 11777376

# dp_longs=dp_ids.select('dpid','long_id')
all_vertices=spark.read.parquet(all_vertices_path)
# # 78212
# # DataFrame[id: bigint]
# dp_longs.join(all_vertices,all_vertices.id==dp_longs.long_id).drop('id').write.mode('overwrite').parquet(path+'dpids_with_its_final_vertices')
dp_reqids=spark.read.parquet(path+'dpids_with_its_final_vertices')
#ALL THE ABOVE PATHS ARE WRITTEN IN DP_IND_FEATURES
#this df contains dpid and only those ids which are present in final all vertices 
dp_reqids.select('dpid').distinct().count()
# 28 so out of 57 only 28 dps have seen ids which are present in final vertices 
THE REMAINING DPS WILL BE GIVEN A NEGATIVE SCORE OF -1 
dp_reqids.count()
# 82161  (> 78212  coz an id can be seen by multiple dps)
dp_reqids.select('long_id').distinct().count()
# 78212   as expected


#NOW DO THE STEP 1 
#COLLECT ALL DPIDS 
dps=dp_longs.select('dpid').distinct().collect()
dp_score1=defaultdict(int)
total=0
usefuls=0
for i in dps:
	curr_dp=i[0]
	total_seen_ids=dp_longs.filter(F.col('dpid')==curr_dp).select('long_id').distinct().count()
	useful_ids=dp_reqids.filter(F.col('dpid')==curr_dp).select('long_id').distinct().count()
	dp_score1[curr_dp]=useful_ids/total_seen_ids
	usefuls+=useful_ids
	total+=total_seen_ids  

# total=11777376 (total ids+multiple dps=dp_longs.distinct().count())
# usefuls=82161 (total req ids+multiple dps=dp_reqids.count())
for i in dp_score1.keys():
	dp_score1[i]="{:.8f}".format(float((dp_score1[i])))

#REPEAT THE SAMETHING FOR EDGES ALSO
#THE EDGES DFS RE ALREADY WRITTEN IN OTHER CODE
{'307': '0.00000000', '63': '0.00000000', '1396': '0.96426823', '335': '0.06696429', '1380': '0.00000000', '226': '0.00000000', '598': '0.00008720', '1222': '1.00000000', '667': '1.00000000', '86': '0.00000000', '521': '0.00000000', '1110': '0.00562523', '625': '0.00000000', '648': '0.00653642', '1258': '0.00012409', '685': '0.00000000', '738': '0.25330999', '637': '0.00006369', '1147': '0.00000000', '1141': '1.00000000', '525': '1.00000000', '575': '0.00000000', '516': '0.00000000', '395': '0.01397516', '331': '0.00000000', '239': '0.00000000', '979': '0.00023227', '135': '0.00000000', '105': '0.00000000', '678': '0.50538922', '233': '0.00000000', '556': '0.00000000', '1332': '1.00000000', '120': '0.04132231', '871': '0.00413508', '799': '0.00000000', '75': '0.00000000', '314': '0.00006845', '87': '0.00027247', '404': '1.00000000', '338': '0.00000000', '654': '0.00000000', '634': '1.00000000', '370': '0.00000000', '1252': '0.00000000', '12': '0.00000000', '876': '0.00266400', '529': '0.00020813', '963': '0.00000000', '1292': '0.00485830', '1480': '0.00000000', '59': '0.00352798', '1361': '0.00005618', '800': '0.00000000', '336': '0.00000000', '620': '0.00000000', '229': '1.00000000'})#approach 2 

so, now all dps are given a positive score based on above dict values if value>0, if value=0 then a negative score of -0.5 can be given 

dps=dp_reqids.select('dpid').distinct().collect()
dps=list(map(lambda x:x[0],dps))


#the brute force NP solution for set cover is not possible to implemet
#28 dps 2^28 subsets for each subsets, there are dpids inside the subsets and for those dpids, filter and count union areperformed on dfs

#so, follow greedy approximate algorithm
#initally included elements=I
#keep adding subsets to it, and at any point the subset u pich should have max [SI-I] value, i.e max no.of new elements it ha to give


schema = StructType([
  StructField('long_id', LongType(), False),
  ])
included_ids=spark.sparkContext.parallelize([]).toDF(schema)
n=len(dps)
threshold=0.97
total=all_vertices.count()
seendpids=set()
while(included_ids.count()<threshold*total):
	maxval=0
	maxdpid=-1
	for dpid in dps:
		if(dpid in seendpids):
			continue
		curr_ids=dp_reqids.filter(F.col('dpid')==dpid).select('long_id').distinct()
		diff=curr_ids.subtract(included_ids).distinct()
		curr_count=diff.count()
		if(curr_count>maxval):
				maxval=curr_count
				maxdpid=dpid
	if(maxdpid==-1):
		print("ERRORRRR!!!!")
		break
	print(included_ids.count(),maxdpid,seendpids,maxval)
	included_ids=included_ids.union(dp_reqids.filter(F.col('dpid')==maxdpid).select('long_id').distinct()).distinct()
	seendpids.add(maxdpid)
	print("UPDATED",included_ids.count())
	print(seendpids)

seendpids- {'1332', '1396', '87'}
included_ids.count()-
76665 (>=0.97* 78212)

#now the scoring shouldnt be in other of how the greedy algo chose the dpids
coz say a dpid1 has 99% data and other dpid2 has 99.1% , so dpid2 will be chosen with score 99.1 and the other dpid will then be scored only 0.1 around
so 

#now score -
dp_score_cover=defaultdict(int)
for i in seendpids:
	dp_score_cover[i]= "{:.8f}".format(float( ( dp_reqids.filter(F.col('dpid')==i).distinct().count() / total )))

->
{'1332': '0.01053547', '1396': '0.95714213', '87': '0.01657035'})

now again, the dps in seendpids are scored based on count of how much they seen/total count and other remaining are not given any score(not even a negative score)

since this score is very crucial may be it neeed to be scaled up by alpha 
alpha=1.5



#THE SAME DP COVER CAN BE DONE FOR EDGES AS WELL-



dp_longedges= spark.read.parquet(path+"dp_edges_mapped_to_long")
# 10993511 (along with timestamps and multiple dpids) 
all_edges=spark.read.parquet(all_edges_path)	
# # 109776
# DataFrame[id: bigint]
dp_req_edges=spark.read.parquet(path+'dp_req_edges_with_longs').select('dpid','src','dst').distinct()		
# 111920  - since an edge is seen by multiple dps


#NOW DO THE STEP 1 
#COLLECT ALL DPIDS 
dps=dp_longedges.select('dpid').distinct().collect()
dp_score_edges=defaultdict(int)
total=0
usefuls=0
for i in dps:
	curr_dp=i[0]
	total_seen_edges=dp_longedges.filter(F.col('dpid')==curr_dp).select('src_long_id','dst_long_id').distinct().count()
	useful_edges=dp_req_edges.filter(F.col('dpid')==curr_dp).select('src','dst').distinct().count()
	print(curr_dp,useful_edges,total_seen_edges)
	dp_score_edges[curr_dp]="{:.8f}".format(float((useful_edges/total_seen_edges)))
	usefuls+=useful_edges
	total+=total_seen_edges  

# total=8958492 (= total edges and multiple dps also =dp_longedges.select('dpid','src_long_id','dst_long_id').distinct().count())
# usefuls=111920 (=total req edges and multiple dps also=dp_req_edges.distinct().count())


 {'307': '0.00000000', '63': '0.00000000', '1396': '0.98661884', '335': '0.06930693', '1380': '0.00000000', '226': '0.00000000', '598': '0.00008721', '1222': '1.00000000', '667': '1.00000000', '86': '0.00000000', '521': '0.00000000', '1110': '0.00572656', '625': '0.00000000', '648': '0.00645793', '1258': '0.00012088', '685': '0.00000000', '738': '0.50727651', '637': '0.00006369', '1147': '0.00000000', '1141': '1.00000000', '525': '1.00000000', '575': '0.00000000', '516': '0.00000000', '395': '0.01543210', '331': '0.00000000', '239': '0.00000000', '979': '0.00023224', '135': '0.00000000', '105': '0.00000000', '678': '0.48282443', '233': '0.00000000', '556': '0.00000000', '1332': '1.00000000', '120': '0.04147465', '871': '0.00253378', '799': '0.00000000', '75': '0.00000000', '314': '0.00006844', '87': '0.00032675', '404': '1.00000000', '338': '0.00000000', '654': '0.00000000', '634': '1.00000000', '370': '0.00000000', '1252': '0.00000000', '12': '0.00000000', '876': '0.00266312', '529': '0.00021197', '963': '0.00000000', '1292': '0.00466252', '1480': '0.00000000', '59': '0.00353903', '1361': '0.00005464', '800': '0.00000000', '336': '0.00000000', '620': '0.00000000', '229': '1.00000000'})
so, now all dps are given a positive score based on above dict values if value>0, if value=0 then a negative score of -0.5 can be given 

dps=dp_req_edges.select('dpid').distinct().collect()
dps=list(map(lambda x:x[0],dps))


#the brute force NP solution for set cover is not possible to implemet
#28 dps 2^28 subsets for each subsets, there are dpids inside the subsets and for those dpids, filter and count union areperformed on dfs

#so, follow greedy approximate algorithm
#initally included elements=I
#keep adding subsets to it, and at any point the subset u pich should have max [SI-I] value, i.e max no.of new elements it ha to give

dp_req_edges=dp_req_edges.select('dpid','src','dst').distinct()
schema = StructType([
  StructField('src', LongType(), False),
  StructField('dst', LongType(), False),
  ])
included_edges=spark.sparkContext.parallelize([]).toDF(schema)
n=len(dps)
threshold=0.97
total=all_edges.count()
# 109776
seendpids=set()
while(included_edges.count()<threshold*total):
	maxval=0
	maxdpid=-1
	for dpid in dps:
		if(dpid in seendpids):
			continue
		curr_edges=dp_req_edges.filter(F.col('dpid')==dpid).select('src','dst').distinct()
		diff=curr_edges.subtract(included_edges).distinct()
		curr_count=diff.count()
		if(curr_count>maxval):
				maxval=curr_count
				maxdpid=dpid
	if(maxdpid==-1):
		print("ERRORRRR!!!!")
		break
	print(included_edges.count(),maxdpid,seendpids,maxval)
	included_edges=included_edges.union(dp_req_edges.filter(F.col('dpid')==maxdpid).select('src','dst').distinct()).distinct()
	seendpids.add(maxdpid)
	print("UPDATED",included_edges.count())
	print(seendpids)

seendpids- {'738', '1396'}
included_edges.count()-
106563 (>=0.97* 109776=106482.72)

#now the scoring shouldnt be in other of how the greedy algo chose the dpids
coz say a dpid1 has 99% data and other dpid2 has 99.1% , so dpid2 will be chosen with score 99.1 and the other dpid will then be scored only 0.1 around
so 

#now score -
dp_score_coveredges=defaultdict(int)
for i in seendpids:
	dp_score_coveredges[i]= "{:.8f}".format(float( ( dp_req_edges.filter(F.col('dpid')==i).distinct().count() / total )))

->
{'738': '0.04223145', '1396': '0.93964983'})

now again, the dps in seendpids are scored based on count of how much they seen/total count and other remaining are not given any score(not even a negative score)

since this score is very crucial may be it neeed to be scaled up by alpha 
alpha=1.5







