import pyspark.sql.functions as F
from pyspark.sql.types import *
import networkx as nx
from graphframes import *
from pyspark.mllib.clustering import PowerIterationClustering, PowerIterationClusteringModel
from itertools import chain, combinations
import math
from operator import itemgetter
from collections import Counter
from collections import defaultdict
from os import sys, path
import community as community_louvain
from pyspark.sql.functions import lit

path="gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/graph/cleanup/country=ESP/Prudhvi/ESP_Graph_cleaning_new"
edges_path_nontube="gs://gcs-ireland-all-eu-daap-idu-bootstrap-internal-zeotap-com/run__20201123/zeoGraphEdges_idu_524/country=ESP"
edges_path_tube="gs://gcs-ireland-all-eu-daap-idu-bootstrap-internal-zeotap-com/run__20201123/tubeGraphEdges_idu_524/country=ESP"
edges_path_nontube_req=path+"edges_nontube_with_askedtypes"

edges_distinct_nontube_path=path+"/edges_distinct_nontube"
edges_distinct_tube_path=path+"/edges_distinct_tube"
vertices_from_edges_tube_path=path+"/vertices_from_edges_distinct_tube"
vertices_from_edges_nontube_path=path+"/vertices_from_edges_distinct_nontube"
total_vertices_path= path +"/total_vertices_tubeandnontube"
long_mapped_ids_path = path+"data/all_ids_with_long_mapping"
all_vertices_path=path+"/final_vertices_to_apply_cc"
all_edges_path=path+"/final_edges_to_apply_cc"


STRUCTURE BASED-

try:
	#SO WE ARE TAKING ALL THE DPS(57/57 ) BUT NOT THE ONLY 28DPS WHICH GAVE THE ALL_EDGES 
dp_longedges= spark.read.parquet(path+"dp_edges_mapped_to_long")
#need to apply cc on each dp graph 
dp_longedges=dp_longedges.select('src_long_id','dst_long_id',"dpid").distinct().withColumnRenamed('src_long_id','src').withColumnRenamed('dst_long_id','dst')
dps_edges_count=dp_longedges.count()
# 4327274484	
dp_longedges.groupby('dpid').count().sort(F.col('count').desc()).show()
+----+---------+                                                                
|dpid|    count|
+----+---------+
|  87|873825928|
|1361|613033827|
| 738|598583189|
| 307|506981634|
|1258|484183863|
| 331|324035886|
| 105|237316356|
|  12|192332591|
| 678|104457345|
| 314| 70288156|
| 233| 51213475|
|  86| 50302662|
| 979| 37799034|
| 963| 27000913|
| 135| 22343682|
| 625| 18317390|
| 338| 17234521|
| 598| 10498907|
| 529|  9179422|
| 229|  8787631|
+----+---------+
	# clearly break them into components first
	def GraphFrameCreation(edges_mapped , vertex_mapped , path):
		graph=GraphFrame(vertex_mapped , edges_mapped)
		print(graph)
		sc.setCheckpointDir(path+"/Prudhvi/checkpoint_dir")
		conn_comp=graph.connectedComponents(algorithm="graphframes", checkpointInterval=2, broadcastThreshold=100000)
		# conn_comp.write.mode("overwrite").parquet(cc_path)
		# print("cc run successfull")
		# conn_comp1=spark.read.parquet(cc_path)
		# conn_comp1.groupby("component").count().sort(F.col("count").desc()).show()  # just showing the cc's based on their size
		return conn_comp
	dps=dp_longedges.select('dpid').distinct().collect()
	dps=list(map(lambda x:x[0],dps))
	# ['307', '63', '1396', '335', '1085', '810', '1357', '21', '118', '1344', '1380', '1129', '374', '376', '1314', '598', '1222', '667', '86', '522', '521', '807', '1110', '322', '1055', '625', '1148', '648', '1258', '685', '738', '637', '1147', '68', '820', '1141', '525', '575', '516', '1415', '611', '95', '395', '331', '372', '239', '979', '135', '105', '1316', '24', '678', '233', '556', '1332', '346', '1353', '120', '871', '799', '75', '314', '29', '806', '87', '404', '338', '654', '634', '1076', '370', '1252', '12', '876', '1348', '329', '37', '809', '529', '45', '1443', '963', '808', '1292', '1480', '59', '33', '1361', '1257', '1271', '800', '336', '35', '620', '229']
try:
	schema = StructType([
		  StructField('id', LongType(), False),
		  StructField('component', LongType(), False),
		  StructField('dpid', StringType(), False),
		  ])
	dps=['307', '63', '1396', '335', '1085', '810', '1357', '21', '118', '1344', '1380', '1129', '374', '376', '1314', '598', '1222', '667', '86', '522', '521', '807', '1110', '322', '1055', '625', '1148', '648', '1258', '685', '738', '637', '1147', '68', '820', '1141', '525', '575', '516', '1415', '611', '95', '395', '331', '372', '239', '979', '135', '105', '1316', '24', '678', '233', '556', '1332', '346', '1353', '120', '871', '799', '75', '314', '29', '806', '87', '404', '338', '654', '634', '1076', '370', '1252', '12', '876', '1348', '329', '37', '809', '529', '45', '1443', '963', '808', '1292', '1480', '59', '33', '1361', '1257', '1271', '800', '336', '35', '620', '229']
	# final_df=spark.sparkContext.parallelize([]).toDF(schema)
	final_df=spark.read.parquet(path+'final_dpids_comps'+str(60))
	for ind in range(61,len(dps)): #95 length
		dp=dps[ind]
		curr_df=dp_longedges.filter(F.col('dpid')==dp)
		edge_df=curr_df.select('src','dst').distinct()
		vertex_df=curr_df.select('src').withColumnRenamed('src','id').union(curr_df.select('dst').withColumnRenamed("dst","id")).distinct()
		returned_df=GraphFrameCreation(edge_df,vertex_df,path)
		returned_df=returned_df.withColumn('dpid',lit(dp))
		final_df=final_df.union(returned_df)
		if(ind%5==0):
			final_df.write.mode('overwrite').parquet(path+'final_dpids_comps'+str(ind))
			print(ind,dp,"written")
			final_df=spark.read.parquet(path+'final_dpids_comps'+str(ind))
		if(ind==len(dps)-1):
			final_df.write.mode('overwrite').parquet(path+'all_dp_comps')
			print("final_df is written")
		print(ind,dp,"done")
		# DataFrame[dpid: string, component: bigint, edges: array<struct<_1:bigint,_2:bigint>>]
		# distinct dps-52
		#now u got every dp graph(just filter that dpid)
		#make that dpgraph into nx graph and find required structure features for every cc
except Exception as e:
	print(e)



x=spark.read.parquet(path+'all_dp_comps')
# 2333229239
dp_longedges.select('dpid','src').union(dp_longedges.select('dpid','dst')).distinct().count()
# 2333229239 
x.groupby('dpid','component').count().sort(F.col('count').desc()).show()
+----+---------+-----+                                                          
|dpid|component|count|
+----+---------+-----+
| 598|     1901|29712|
| 331|    93555|24949|
| 331|   156464|14396|
| 338|   178470|12704|
| 331|   403281|11226|
| 338|  1485128| 6944|
| 338|   977220| 5804|
|1396|     5350| 5504|
| 331|   628314| 4487|
| 331|   141118| 4377|
|1361|  2327990| 3452|
| 338|   220260| 3383|
| 233|  2729111| 3352|
| 331|  1355423| 3175|
| 307|   359196| 2831|
| 307|  1013538| 2476|
|  12|  3326790| 2418|
|  12|  2419343| 2400|
| 307|   153040| 2196|
| 307|  3507882| 2190|
+----+---------+-----+

def gettraversibleedges_c(comps_final,final_edges_to_apply_cc,data=""):
	comps_final=comps_final.withColumnRenamed('dpid','dpid_')
	max_comp_intermediate_edges=comps_final.join(final_edges_to_apply_cc, [comps_final.id == final_edges_to_apply_cc.src,comps_final.dpid_==final_edges_to_apply_cc.dpid]).drop("id","dpid_")
	max_comp_intermediate_edges=max_comp_intermediate_edges.withColumnRenamed("component","src_component")
	max_comp_edges=max_comp_intermediate_edges.join(comps_final , [comps_final.id == max_comp_intermediate_edges.dst,comps_final.dpid_==max_comp_intermediate_edges.dpid]).drop("id","dpid_").withColumnRenamed("component","dst_component")
	return max_comp_edges
x=spark.read.parquet(path+'all_dp_comps')
# 4648446431 
dp_longedges.select('dpid','src').union(dp_longedges.select('dpid','dst')).distinct().count()
# 4648446431  
x.groupby('dpid','component').count().sort(F.col('count').desc()).show()

a=dp_longedges.distinct().count()
# 4327274484
# DataFrame[src: bigint, dst: bigint, dpid: string]
b=dp_longedges.select('src','dst').distinct().count()
#3347431974
dpidccs=spark.read.parquet(path+'all_dp_comps')
dpid_ccedges=gettraversibleedges_c(dpidccs,dp_longedges) 
dpid_ccedges=dpid_ccedges.drop('src_component').withColumnRenamed('dst_component','component')
dpid_ccedges.write.mode('overwrite').parquet(path+'dpid_cc_edges_')
dpid_ccedges=spark.read.parquet(path+'dpid_cc_edges_')
c=dpid_ccedges.count()
# 4327274484      
d=dpid_ccedges.select('src','dst').distinct().count()
# 3347431974 
e=dpid_ccedges.select('src','dst','dpid').distinct().count()
# 4327274484 
dpid_ccedges.groupby('dpid','component').count().sort(F.col('count').desc()).show()
+----+---------+-----+                                                          
|dpid|component|count|
+----+---------+-----+
| 598|     1901|34462|
| 331|    93555|25782|
| 331|   156464|15649|
| 338|   178470|13181|
| 331|   403281|11534|
| 338|  1485128| 7291|
|1396|     5350| 6253|
| 338|   977220| 5840|
|  12|  3326790| 5585|
| 331|   628314| 4670|
| 307|  3507882| 4615|
| 331|   141118| 4561|
| 307|  2407352| 4317|
| 307|  4323573| 3984|
| 307|   828131| 3908|
| 963|  1405445| 3853|
| 135|  1163730| 3725|
|1361|  2327990| 3701|
| 738|  1975792| 3566|
| 233|  2729111| 3504|
+----+---------+-----+


dpid_ccedges.groupby('dpid','component').agg(F.collect_list( F.struct(F.col('src'),F.col('dst'))).alias('edges')).write.mode('overwrite').parquet(path+'dpids_with_ccs_edges')
dpids_with_ccs=spark.read.parquet(path+'dpids_with_ccs_edges')
# 1066957014

try: 
	print("structural features start")
	dpids_with_ccs=spark.read.parquet(path+'dpids_with_ccs_edges')
	allccs=1066957014
	def get_structural_features(x):
		edges=list(map(lambda x:tuple(x),x['edges']))
		graph_nx=nx.from_edgelist(edges)
		avg_clustering_coef=nx.average_clustering(graph_nx)
		node_cutset=len(nx.minimum_node_cut(graph_nx))
		# edge_cutset=len(nx.minimum_edge_cut(graph_nx))
		# radius=nx.radius(graph_nx)
		# diameter=nx.diameter(graph_nx)
		# periphery_length=len(nx.periphery(graph_nx))
		# size_of_cc=len(graph_nx.nodes())
		# max_cliq=max((nx.node_clique_number(graph_nx)).values()) #called omega(G)
		return x['dpid'],x['edges'],x['component'],avg_clustering_coef,node_cutset
	# dpids_with_ccs.rdd.map(lambda x: get_structural_features(x)).toDF(["dpid","edges","component","avg_clustering_coef","node_cutset"]).write.mode('overwrite').parquet(path+'cc_edges_dps_with_avg_cluster_nodecut')
	a=spark.read.parquet(path+'cc_edges_dps_with_avg_cluster_nodecut')
	# 1050966762 
	dpids_with_ccs.join(a,on=['dpid','component'],how='left_anti').write.mode('overwrite').parquet(path+'dpids_with_ccs_edges_remaining_a')
	dpids_with_ccs_rem=spark.read.parquet(path+'dpids_with_ccs_edges_remaining_a')
	# 15990252 
	print('rem start')
	dpids_with_ccs_rem.rdd.map(lambda x: get_structural_features(x)).toDF(["dpid","edges","component","avg_clustering_coef","node_cutset"]).write.mode('overwrite').parquet(path+'cc_edges_dps_with_avg_cluster_nodecut_remain')
	a2=spark.read.parquet(path+'cc_edges_dps_with_avg_cluster_nodecut_remain')
	# 14921903
	dpids_with_ccs_rem.join(a2,on=['dpid','component'],how='left_anti').write.mode('overwrite').parquet(path+'dpids_with_ccs_edges_remaining_a2')
	dpids_with_ccs_rem2=spark.read.parquet(path+'dpids_with_ccs_edges_remaining_a2')
	# 1068349
	def getsize(x):
		return x['dpid'],x['component'],x['edges'],len(x['edges'])
	sizes=dpids_with_ccs_rem2.rdd.map(lambda x :getsize(x)).toDF(['dpid','component','edges','size_of_cc'])
	sizes.sort(F.col('size_of_cc').desc()).show()
	dpids_with_ccs_smalls=dpids_with_ccs_rem2.rdd.map(lambda x :getsize(x)).toDF(['dpid','component','edges','size_of_cc']).filter(F.col('size_of_cc')<25000).select('dpid','component','edges')
	#1068347 
	dpids_with_ccs_smalls.rdd.map(lambda x: get_structural_features(x)).toDF(["dpid","edges","component","avg_clustering_coef","node_cutset"]).write.mode('overwrite').parquet(path+'cc_edges_dps_with_avg_cluster_nodecut_smalls')
	a3=spark.read.parquet(path+'cc_edges_dps_with_avg_cluster_nodecut_smalls')
	a=a.union(a2)
	a=a.union(a3)
	a.write.mode('overwrite').parquet(path+'cc_edges_dps_with_avg_cluster_nodecut_except_2bigs')
	# 1066957012
try:
	a=spark.read.parquet(path+'cc_edges_dps_with_avg_cluster_nodecut_except_2bigs')
	print("a done",a.count())
	def get_structural_features(x):
		edges=list(map(lambda x:tuple(x),x['edges']))
		graph_nx=nx.from_edgelist(edges)
		# avg_clustering_coef=nx.average_clustering(graph_nx)
		# node_cutset=len(nx.minimum_node_cut(graph_nx))
		# edge_cutset=len(nx.minimum_edge_cut(graph_nx))
		radius,diameter,periphery_length,centre=find_distancemeasures(graph_nx)
		# periphery_length=len(nx.periphery(graph_nx))
		# size_of_cc=len(graph_nx.nodes())
		# max_cliq=max((nx.node_clique_number(graph_nx)).values()) #called omega(G)
		return x['dpid'],x['edges'],x['component'],x['avg_clustering_coef'],x['node_cutset'],radius,diameter,len(periphery_length),len(centre)
	a.rdd.map(lambda x: get_structural_features(x)).toDF(["dpid","edges","component","avg_clustering_coef","node_cutset","radius","diameter","periphery_length","centre_length"]).write.mode('overwrite').parquet(path+'cc_edges_dps_with_avg_cluster_nodecut_rad_dia_peri_centr_except_2bigs')
	b=spark.read.parquet(path+'cc_edges_dps_with_avg_cluster_nodecut_rad_dia_peri_centr_except_2bigs')
	print("b done")
	def get_structural_features(x):
		edges=list(map(lambda x:tuple(x),x['edges']))
		graph_nx=nx.from_edgelist(edges)
		# avg_clustering_coef=nx.average_clustering(graph_nx)
		# node_cutset=len(nx.minimum_node_cut(graph_nx))
		# edge_cutset=len(nx.minimum_edge_cut(graph_nx))
		# radius=nx.radius(graph_nx)
		# diameter=nx.diameter(graph_nx)
		# periphery_length=len(nx.periphery(graph_nx))
		size_of_cc=len(graph_nx.nodes())
		max_cliq=max((nx.node_clique_number(graph_nx)).values()) #called omega(G)
		return x['dpid'],x['edges'],x['component'],x['avg_clustering_coef'],x['node_cutset'],x['radius'],x['diameter'],x['periphery_length'],x['centre_length'],size_of_cc,max_cliq
	b.rdd.map(lambda x: get_structural_features(x)).toDF([ "dpid","edges","component","avg_clustering_coef","node_cutset","radius","diameter","periphery_length","centre_length","size_of_cc","max_clique"]).write.mode('overwrite').parquet(path+'cc_edges_dps_with_structural_features_except_2bigs')
	print("c done")
	structures=spark.read.parquet(path+'cc_edges_dps_with_structural_features_except_2bigs')
	print(structures.count()==allccs)
	# 1066957012                                                                       
except Exception as error:
	print(error)
#find vertex degree distribution


try:
	allccs=1066957012 
	import numpy as np
	def vertex_dist(x):
		edges=list(map(lambda x:tuple(x),x['edges']))
		graph_nx=nx.from_edgelist(edges)
		degrees=list(map(lambda x: x[1],list(graph_nx.degree(list(graph_nx.nodes())))))
		quant=[0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,0.95,0.98,0.99,1.0]
		res=list(map(int,list(np.quantile(degrees,quant))))
		return x['dpid'],x['component'],x['edges'],res
	dpids_with_ccs=spark.read.parquet(path+'dpids_with_ccs_edges')
	dpids_with_ccs.rdd.map(lambda x: vertex_dist(x)).toDF(["dpid","component","edges","vertex_distribution"]).write.mode('overwrite').parquet(path+'dpids_with_ccs_with_degree_dist')
	degree_dpids=spark.read.parquet(path+'dpids_with_ccs_with_degree_dist')
	degree_dpids=degree_dpids.select("dpid","component","edges",F.col("vertex_distribution")[0],F.col("vertex_distribution")[1],F.col("vertex_distribution")[2],F.col("vertex_distribution")[3],F.col("vertex_distribution")[4],F.col("vertex_distribution")[5],F.col("vertex_distribution")[6],F.col("vertex_distribution")[7],F.col("vertex_distribution")[8],F.col("vertex_distribution")[9],F.col("vertex_distribution")[10],F.col("vertex_distribution")[11],F.col("vertex_distribution")[12])
	quant=[0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,0.95,0.98,0.99,1.0]
	for i in range(13):
		name='vertex_distribution['+str(i)+']'
		to='degree_quantile_'+str(int(100*quant[i]))
		degree_dpids=degree_dpids.withColumnRenamed(name,to) 
	degree_dpids.write.mode('overwrite').parquet(path+'dpids_with_ccs_with_degree_distribution')
	#join with structures
	degree_dpids=spark.read.parquet(path+'dpids_with_ccs_with_degree_distribution')
	degree_dpids=degree_dpids.withColumnRenamed('dpid','dpid_').withColumnRenamed('component','component_').withColumnRenamed('edges','edges_')
	structures.join(degree_dpids,[degree_dpids.dpid_==structures.dpid,structures.component==degree_dpids.component_]).drop('dpid_','component_','edges_').write.mode('overwrite').parquet(path+'dpids_with_all_comp_cc_features_except_2bigs')
	all_fetus=spark.read.parquet(path+'dpids_with_all_comp_cc_features_except_2bigs')
	print(all_fetus.count()==allccs)
	#True
except Exception as error:
	print("No",error)


#now independent features(no components)
try:
	import datetime
	dpids_with_ccs=spark.read.parquet(path+'dpids_with_ccs_edges')
	distinct_dps=dpids_with_ccs.select('dpid').distinct().count()
	#
	required_dps=dpids_with_ccs.select('dpid').distinct()
	#find dpid- days seen
	edges_nontube=spark.read.parquet(path+"edges_nontube_with_askedtypes")
	edges_tube=spark.read.parquet(edges_path_tube) 
	# DataFrame[vertex1: string, vertex1type: string, vertex2: string, vertex2type: string, dpid: string, timestamp: string, recordType: string]
	all_edges=edges_nontube.union(edges_tube)#.distinct()->dont do distinct()
	#now get vertices from these edges
	all_edges=all_edges.withColumn('timestamp',F.col('timestamp')[0:10])
	def findDay(datedtime):
		date=datedtime[:10]
		time=datedtime[10:]
		# if(time=='00:00:00'):
		# 	return "-1"
		year, month, day = (int(i) for i in date.split('-'))     
		born = datetime.date(year, month, day) 
		return born.strftime("%A")
	all_edges=all_edges.withColumn("datetime",F.from_unixtime(F.col("timestamp")))
	#remove all ingested
	all_edges=all_edges.filter(~ F.col('datetime').like("%00:00:00") )
	findday = F.udf(lambda x : findDay(x))
	all_edges=all_edges.withColumnRenamed("datetime","datedtime")
	all_edges_day=all_edges.withColumn("day",lit(findday(F.col("datedtime"))))
	#all non ingested edges with dpids and days
	all_edges_day.write.mode('overwrite').parquet(path+'edges_with_dpids_days')
	all_edges_day=spark.read.parquet(path+'edges_with_dpids_days')
	# day_list=all_edges_day.groupby('dpid').agg(F.collect_list(F.col('day')))
	df1=all_edges_day.groupby('dpid',"day").count()
	df2=df1.groupby("dpid").agg(F.map_from_entries(F.collect_list(F.struct("day","count"))).alias("day_counts"))
	noninges_dps=all_edges_day.select('dpid').distinct().count()
	print("here")
	# #-remaining are ingested
	from collections import Counter 
	def countdays(x):
		days=x['day_counts']
		daydict=defaultdict(int)
		daydict['Sunday']=0
		daydict['Monday']=0
		daydict['Tuesday']=0
		daydict['Wednesday']=0
		daydict['Thursday']=0
		daydict['Friday']=0
		daydict['Saturday']=0
		for i in days.keys():
			daydict[i]+=days[i]
		total=sum(daydict.values())
		return x['dpid'],daydict['Sunday']/total,daydict['Monday']/total,daydict['Tuesday']/total,daydict['Wednesday']/total,daydict['Thursday']/total,daydict['Friday']/total,daydict['Saturday']/total,total
	df2.rdd.map(lambda x:countdays(x)).toDF(['dpid','Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','total_days']).write.mode('overwrite').parquet(path+'dpid_with_day_frequencies')
	day_freq=spark.read.parquet(path+'dpid_with_day_frequencies')
	#find mean time on day
	all_edges_day=spark.read.parquet(path+'edges_with_dpids_days')
	dpid_time=all_edges_day.select('dpid','timestamp')
	dpid_time=dpid_time.groupby('dpid').agg(F.mean('timestamp')).withColumnRenamed('avg(timestamp)','avg_timestamp')
	dpid_time=dpid_time.withColumn("avg_datetime",F.from_unixtime(F.col("avg_timestamp")))
	dpid_time.write.mode('overwrite').parquet(path+'dpid_with_avg_timestamp')
	dpid_time=spark.read.parquet(path+'dpid_with_avg_timestamp')
	print("here1")
	dpid_time=dpid_time.withColumnRenamed('dpid','dpid_')
	#join with day_freq
	join1=dpid_time.join(day_freq,day_freq.dpid==dpid_time.dpid_).drop('dpid_','total_days').distinct()
	join1.write.mode('overwrite').parquet(path+'/join1')
	join1=spark.read.parquet(path+'/join1')
	print(join1.count()==noninges_dps)
	#True get remaining dps
	rem_dps=dpids_with_ccs.select('dpid').distinct().subtract(dpid_time.select('dpid_').distinct()).collect()
	# [Row(dpid='1222'), Row(dpid='1141'), Row(dpid='667'), Row(dpid='525'), Row(dpid='1332'), Row(dpid='634'), Row(dpid='229'), Row(dpid='12')]
	rem_dps_df=[]
	for i in rem_dps:
		curr=[i[0]]
		for j in range(9):
			curr.append(-1)
		rem_dps_df.append(curr)
	dummy_df=spark.createDataFrame(rem_dps_df,['dpid','Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','avg_timestamp','avg_datetime'])
	join2=join1.select('dpid','Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','avg_timestamp','avg_datetime').union(dummy_df)
	join2.write.mode('overwrite').parquet(path+'/join2')
	join2=spark.read.parquet(path+'/join2')
	print(join2.count()==distinct_dps)
	# True find offline online count
	edges_nontube=spark.read.parquet(path+"edges_nontube_with_askedtypes")
	edges_tube=spark.read.parquet(edges_path_tube) 
	# DataFrame[vertex1: string, vertex1type: string, vertex2: string, vertex2type: string, dpid: string, timestamp: string, recordType: string]
	all_edges=edges_nontube.union(edges_tube)#.distinct()->dont do distinct()
	#now get vertices from these edges
	all_edges.select('vertex1','vertex1type','timestamp','dpid').withColumnRenamed('vertex1','string_id').withColumnRenamed('vertex1type','type').union(all_edges.select('vertex2','vertex2type','timestamp','dpid').withColumnRenamed('vertex2','string_id').withColumnRenamed('vertex2type','type')).write.mode('overwrite').parquet(path+'embed_trails'+'/vertices_with_dpids')
	#find offline online count
	vertices_with_dpids=spark.read.parquet(path+'embed_trails'+'/vertices_with_dpids')
	df=vertices_with_dpids.withColumn('id_type',F.when(F.col('type').like("id_mid%"), 'on').otherwise('off'))
	# off_on=df.groupby('dpid').agg(F.collect_list('id_type'))
	df1=df.groupby('dpid',"id_type").count()
	off_on=df1.groupby("dpid").agg(F.map_from_entries(F.collect_list(F.struct("id_type","count"))).alias("id_type_counts"))
	print("here3")
	def countoff_on(x):
		types=x['id_type_counts']
		on=0
		off=0
		for i in types.keys():
			if(i=='on'):
				on+=types[i]
			else:
				off+=types[i]
		return x['dpid'],on/(on+off),off/(on+off)
	off_on.rdd.map(lambda x:countoff_on(x)).toDF(['dpid','online_percent','offline_percent']).write.mode('overwrite').parquet(path+'dpids_with_off_on_percent')
	df=spark.read.parquet(path+'dpids_with_off_on_percent')
	df=df.withColumnRenamed('dpid','dpid_')
	join3=df.join(join2, df.dpid_==join2.dpid).drop('dpid_')
	join3.write.mode('overwrite').parquet(path+'/join3')
	join3=spark.read.parquet(path+'/join3')
	#get mean cc size
	def getsize(x):
		return x['dpid'],x['component'],len(x['edges'])
	structures=dpids_with_ccs.rdd.map(lambda x :getsize(x)).toDF(['dpid','component','size_of_cc'])
	mean_cc=structures.groupby('dpid').agg(F.mean('size_of_cc')).alias('mean_cc_size')
	mean_cc=mean_cc.withColumnRenamed('avg(size_of_cc)','mean_cc_size')
	mean_cc.write.mode("overwrite").parquet(path+'dpids_with_mean_cc_size')
	mean_cc=spark.read.parquet(path+'dpids_with_mean_cc_size')
	mean_cc=mean_cc.withColumnRenamed('dpid','dpid_')
	join4=mean_cc.join(join3,mean_cc.dpid_==join3.dpid).drop('dpid_')
	join4.write.mode('overwrite').parquet(path+'/join4')
	join4=spark.read.parquet(path+'/join4')
	print("here4")
	#no.of cc / total c.c in graph
	dpid_noccs=structures.groupby('dpid').count().withColumnRenamed('count','count_of_ccs')
	total_ccs=structures.count()
	dpid_p_ccs=dpid_noccs.withColumn('count_of_ccs',F.col('count_of_ccs')/total_ccs).withColumnRenamed('count_of_ccs','percent_of_ccs_seen')
	dpid_p_ccs.write.mode('overwrite').parquet(path+'dpids_with_percent_of_ccs')
	dpid_p_ccs=spark.read.parquet(path+'dpids_with_percent_of_ccs').withColumnRenamed('dpid','dpid_')
	join5=join4.join(dpid_p_ccs,dpid_p_ccs.dpid_==join4.dpid).drop('dpid_')
	# no.of skewed cc (online and offline) - an indepenedent feature
	dpid_edges=dpids_with_ccs.select('dpid','edges')
	dp_ids=spark.read.parquet(path+'dpids_with_its_vertices_long_mapped')
	def breakedges(x):
		t=x['edges']
		flat_list = [item for sublist in t for item in sublist]
		flat_list=list(set(flat_list))
		return x['dpid'],min(flat_list),flat_list
	dpid_edges.rdd.map(lambda x:breakedges(x)).toDF(['dpid','cc_id','ids']).write.mode('overwrite').parquet(path+'dpids_with_cc_id_ids')
	x=spark.read.parquet(path+'dpids_with_cc_id_ids')
	explo=x.select('dpid','cc_id',F.explode('ids'))
	#  
	print("here5")
	dp_ids=dp_ids.select('id','type','long_id').distinct()
	df=explo.join(dp_ids,[dp_ids.long_id==explo.col]).drop('col')
	df.write.mode('overwrite').parquet(path+'dpid_cc_ids_with_type')
	df=spark.read.parquet(path+'dpid_cc_ids_with_type')
	# dpid_types=df.groupby('dpid','cc_id').agg(F.collect_list('type').alias('types'))
	df1=df.groupby('dpid',"cc_id","type").count()
	dpid_types=df1.groupby("dpid","cc_id").agg(F.map_from_entries(F.collect_list(F.struct("type","count"))).alias("type_counts"))
	# DataFrame[dpid: string, cc_id: bigint, types: array<string>]
	def flagskewed(x):
		types=x['type_counts']
		onlines=0
		offlines=0
		for i in types.keys():
			if(i[0:3]=='id_'):
				onlines+=types[i]
			else:
				offlines+=types[i] 
		flag=""
		if(onlines!=0 and offlines!=0):
			flag='not_skewed'
		elif(onlines==0):
			flag='offline_skewed'
		else:
			flag='online_skewed'
		return x['dpid'],x['cc_id'],flag 
	dpid_types.rdd.map(lambda x:flagskewed(x)).toDF(['dpid','cc_id','Skew_Flag']).write.mode('overwrite').parquet(path+'dpid_ccids_skewflag')
	dpid_skewflag=spark.read.parquet(path+'dpid_ccids_skewflag')
	# 
	# df=dpid_skewflag.groupby('dpid').agg(F.collect_list('Skew_Flag').alias('skew_ccs'))
	df1=dpid_skewflag.groupby('dpid',"Skew_Flag").count()
	df=df1.groupby("dpid").agg(F.map_from_entries(F.collect_list(F.struct("Skew_Flag","count"))).alias("flag_counts"))
	# 
	def flagskews(x):
		totalskews=x['flag_counts']
		total_ccs=0
		online_skew=0
		offline_skew=0
		not_skew=0
		for i in totalskews.keys():
			if(i=='online_skewed'):
				online_skew+=totalskews[i]
			elif(i=='not_skewed'):
				not_skew+=totalskews[i]
			else:
				offline_skew+=totalskews[i]
			total_ccs+=totalskews[i]
		return x['dpid'],(online_skew/total_ccs),(offline_skew/total_ccs),(not_skew/total_ccs),(total_ccs)
	df.rdd.map(lambda x:flagskews(x)).toDF(['dpid','online_skewed_percent','offline_skewed_percent','not_skewed_percent','total_ccs']).write.mode('overwrite').parquet(path+'dpids_with_skew_ratios')
	dpid_with_skews=spark.read.parquet(path+'dpids_with_skew_ratios').withColumnRenamed('dpid','dpid_')
	print("here6")
	join5.join(dpid_with_skews,dpid_with_skews.dpid_==join5.dpid).drop('dpid_').write.mode('overwrite').parquet(path+'dpid_with_comp_independent_features')
	dps_ind_fetus=spark.read.parquet(path+'dpid_with_comp_independent_features')
	print(dps_ind_fetus.count()==distinct_dps)
	#95  
except Exception as error:
	print("No",error)



now we have all the dps with required comp features, few features like mean timestamp, are there for only realdps, so for remaining give a value of -1
just make a df with all features 

try the dp scoring based on indepenedent features first and then on the bucket one 

try:
	dps_ind_fetus=spark.read.parquet(path+'dpid_with_comp_independent_features')
	dps_ind_fetus=dps_ind_fetus.drop('total_ccs')
	# the avg_datetime is the string but we need integer which is avg timestamp, basically it is the number of milliseconds from a prefixed time(jan1 1970)
	dps_ind_fetus=dps_ind_fetus.drop('avg_datetime')
	dps_ind_fetus=dps_ind_fetus.select('dpid','mean_cc_size', 'online_percent', 'offline_percent', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'avg_timestamp', 'percent_of_ccs_seen', 'online_skewed_percent', 'offline_skewed_percent', 'not_skewed_percent')
	features=dps_ind_fetus.rdd.map(lambda row : row).collect()
	dpids=[]
	all_features=[]
	for i in features:
		currf=[]
		for ind,fs in enumerate(i):
			if(ind==0):
				dpids.append(fs)
			else:
				currf.append(fs)
		all_features.append(currf)
	# all_features: 57*15
	def pairwise_distances_weights(features):
		result=[]
		n=len(features)
		for i in range(n):
			result_for_i=[]
			for j in range(n):
				vectora=features[i]
				vectorb=features[j]
				distance=0
				m=len(vectorb)
				for k in range(m):
					if(vectorb[k]==-1 or vectora[k]==-1):
						continue
					distance+=(vectora[k]-vectorb[k])**2
				if(distance==0):
					result_for_i.append(float('inf'))
				else:
					result_for_i.append(1/(distance**0.5))
			result.append(result_for_i)
		return result
	#while taking eucledian distance the -1 values are ignored in the sum
	#the value returned is 1/distance, sicne we are using them as weights
	pairwise_dist=pairwise_distances_weights(all_features)
	score_df=spark.createDataFrame(pairwise_dist)
	score_df.write.mode('overwrite').parquet(path+'euclidian_distances_comp_independent')
	score_df=spark.read.parquet(path+'euclidian_distances_comp_independent')
	# 57*57
	#now we got distances, need to convert them to weights
	#so less the distance, more the weight, so 1/ distance 
	# normalize the weights row wise (since each row are the weights for each dp)
	#while normalising, the inf will become 1 and the maxchosen can be 1.5*(max of remaining values)
	def custom_normalize(weights):
		normalized=[]
		for w in weights:
			curr=w[:]
			curr.sort()
			second_max=curr[-2]
			chosen_min=curr[0]
			chosen_max=1.5*second_max
			curr_normalized=[]
			ranged=chosen_max-chosen_min
			for i in w:
				if(i==float('inf')):
					curr_normalized.append(1)
				else:
					curr_normalized.append((i-chosen_min)/ranged)
			normalized.append(curr_normalized)
		return normalized
	normalized=custom_normalize(pairwise_dist)
	normalized=list(map(lambda x:(list(map(lambda y:float(y),x))),normalized))
	normalweights_df=spark.createDataFrame(normalized)
	normalweights_df.write.mode('overwrite').parquet(path+'normalized_euclidian_weights_comp_indfeatures')
	#u got the weights of each dp to every other d
	# now score them using pagerank similar algo 
	# initial scores=1/n for all dps 
	def scoredps(weights,iterations=20):
		numdps=len(weights)
		damp=0.85
		score_dps=[1/numdps]*numdps #intial score 
		newscoredps=[0]*numdps 
		while(iterations):
			iterations-=1
			for i in range(numdps):
				score=0
				for j in range(numdps):
					score+=(weights[i][j]*score_dps[j])
				newscoredps[i]= (1-damp)/numdps + damp*score 
			for i in range(numdps):
				score_dps[i]=newscoredps[i]
		a=score_dps
		norm = [(float(i)-min(a))/(max(a)-min(a)) for i in a]
		return score_dps,norm
	dp_scores,normal_dp_scores=scoredps(normalized,100)
	dpscores_id={}
	for ind,i in enumerate(dpids):
		dpscores_id[i]=normal_dp_scores[ind]
	dpscores_list=list(map(lambda x:[x,dpscores_id[x]],dpscores_id))
	dpid_with_scores=spark.createDataFrame(dpscores_list,['dpid','comparitive_ind_score'])
	dpid_with_scores.write.mode('overwrite').parquet(path+'dpids_with_comparitive_independent_feature_scores')
except Exception as error:
	print(error)


	#returns list of tuplelists ([0]-dpid, [1]-the score)

#just a scoring function, all of the above things put together




#before dng the scoring for cc based features
#find correlation among columns and drop high corrleated columns
all_fetus=spark.read.parquet(path+'dpids_with_all_comp_cc_features_except_2bigs')
all_fetus=all_fetus.drop('edges','component','dpid')
from pyspark.ml.stat import Correlation
from pyspark.ml.feature import VectorAssembler
import numpy
# convert to vector column first
vector_col = "corr_features"
assembler = VectorAssembler(inputCols=all_fetus.columns, outputCol=vector_col)
df_vector = assembler.transform(all_fetus).select(vector_col)
# get correlation matrix
matrix = Correlation.corr(df_vector, vector_col)
corr_matrix=matrix.collect()[0]["pearson({})".format(vector_col)].values
corr_matrix=numpy.reshape(corr_matrix,(21,21))
#get correlatiom among columns 
corr_features=set()
for i in range(len(all_fetus.columns)):
    for j in range(i): #i not i+1, becoz, if(i+1, then j=i and corr[i][i]is always 1)
        if abs(corr_matrix[i][j]) > 0.97:
            colname = all_fetus.columns[i]
            corr_features.add(colname)

corr_features
# {'degree_quantile_50', 'degree_quantile_30', 'degree_quantile_60', 'degree_quantile_10', 'degree_quantile_40', 'degree_quantile_70', 'degree_quantile_99', 'degree_quantile_20', 'degree_quantile_100', 'degree_quantile_80'}

# these three have high correlation with some other columns, so removung these wont effect, since there are already very similar columns in df 
#we have the degree distributions for all dpids 
#just check the similairty between degree distributions all pairs
#so cannot be done for alldps_ccs
#try to do after getting the buckets 





now we need to group dp into three categories, high dense, mid dense, low dense 


all_fetus=spark.read.parquet(path+'dpids_with_all_comp_cc_features_')
cc_sizes=all_fetus.select('size_of_cc')
array_of_percent=[0.1,0.2,0.333,0.666,0.7,0.8,0.9,0.95,0.98,0.99,1.0]
array_of_percent_mapped=list(map(lambda x : str(x*100) + "%" , array_of_percent))
comp_data_array=cc_sizes.approxQuantile("size_of_cc" , array_of_percent  ,0.001)
data=list(zip(array_of_percent_mapped , comp_data_array))
field=[StructField("size_distribution",StringType(), True) , StructField("size_of_cc_value",DoubleType(), True)]
schema=StructType(field)
sqlContext = SQLContext(sc)
siz=sqlContext.createDataFrame(sc.parallelize(data), schema)
siz.show()
+-------------------+----------------+                                          
|  size_distribution|size_of_cc_value|
+-------------------+----------------+
|              10.0%|             2.0|
|              20.0%|             2.0|
|33.300000000000004%|             2.0|
| 66.60000000000001%|             4.0|
|              70.0%|             5.0|
|              80.0%|             7.0|
|              90.0%|            11.0|
|              95.0%|            13.0|
|              98.0%|            14.0|
|              99.0%|            16.0|
|             100.0%|         14396.0|
+-------------------+----------------+

#so the buckts 
try:
	all_fetus=spark.read.parquet(path+'dpids_with_all_comp_cc_features_except_2bigs')
	total_dps=all_fetus.select('dpid').distinct().count()
	#60
	all_fetus=all_fetus.drop('edges','component')
	# drop_cols=['degree_quantile_50', 'degree_quantile_90', 'degree_quantile_30', 'degree_quantile_60', 'degree_quantile_10', 'degree_quantile_40', 'degree_quantile_70', 'edge_cutset', 'node_cutset', 'degree_quantile_20', 'degree_quantile_100', 'max_clique', 'degree_quantile_80', 'degree_quantile_95']
	all_fetus=all_fetus.drop('degree_quantile_50', 'degree_quantile_30', 'degree_quantile_60', 'degree_quantile_10', 'degree_quantile_40', 'degree_quantile_70', 'degree_quantile_99', 'degree_quantile_20', 'degree_quantile_100', 'degree_quantile_80')
	bucket1=all_fetus.filter(F.col('size_of_cc')<=2)
	bucket2=all_fetus.filter( (F.col('size_of_cc')>2) & (F.col('size_of_cc')<=4)) 
	bucket3=all_fetus.filter(F.col('size_of_cc')>4)
	b1_c=bucket1.count()                                                                       
	b2_c=bucket2.count()  
	b3_c=bucket3.count()
	print(b1_c,b2_c,b3_c)
	print(b1_c+b2_c+b3_c==all_fetus.count())
	#   593682723 123540353 349733936
	#True
	# ideally each bucket size= / 3= 
	#now within each bucket take wieghted avg, the weight being size of cc
	# rem_cols=all_fetus.columns
	# base='F.sum(bucket1.'
	# b='bucket1.size_of_cc'
	# x=""
	# for i in range(1,len(rem_cols)):
	# 	col=rem_cols[i]
	# 	x+='('+base+col +'*'+b+')/'+base+'size_of_cc)).alias("'+'mean_'+col+'")'+','
try:
	meaned_bucket1=bucket1.groupBy("dpid").agg( (F.sum(bucket1.avg_clustering_coef*bucket1.size_of_cc)/F.sum(bucket1.size_of_cc)).alias("mean_avg_clustering_coef"),(F.sum(bucket1.node_cutset*bucket1.size_of_cc)/F.sum(bucket1.size_of_cc)).alias("mean_node_cutset"),(F.sum(bucket1.radius*bucket1.size_of_cc)/F.sum(bucket1.size_of_cc)).alias("mean_radius"),(F.sum(bucket1.diameter*bucket1.size_of_cc)/F.sum(bucket1.size_of_cc)).alias("mean_diameter"),(F.sum(bucket1.periphery_length*bucket1.size_of_cc)/F.sum(bucket1.size_of_cc)).alias("mean_periphery_length"),(F.sum(bucket1.centre_length*bucket1.size_of_cc)/F.sum(bucket1.size_of_cc)).alias("mean_centre_length"),(F.sum(bucket1.size_of_cc*bucket1.size_of_cc)/F.sum(bucket1.size_of_cc)).alias("mean_size_of_cc"),(F.sum(bucket1.max_clique*bucket1.size_of_cc)/F.sum(bucket1.size_of_cc)).alias("mean_max_clique"),(F.sum(bucket1.degree_quantile_90*bucket1.size_of_cc)/F.sum(bucket1.size_of_cc)).alias("mean_degree_quantile_90"),(F.sum(bucket1.degree_quantile_95*bucket1.size_of_cc)/F.sum(bucket1.size_of_cc)).alias("mean_degree_quantile_95"),(F.sum(bucket1.degree_quantile_98*bucket1.size_of_cc)/F.sum(bucket1.size_of_cc)).alias("mean_degree_quantile_98") )
	mb1c=meaned_bucket1.count()
	#  means, the remaining dps have no dps in this bukcet
	meaned_bucket2=bucket2.groupBy("dpid").agg( (F.sum(bucket2.avg_clustering_coef*bucket2.size_of_cc)/F.sum(bucket2.size_of_cc)).alias("mean_avg_clustering_coef"),(F.sum(bucket2.node_cutset*bucket2.size_of_cc)/F.sum(bucket2.size_of_cc)).alias("mean_node_cutset"),(F.sum(bucket2.radius*bucket2.size_of_cc)/F.sum(bucket2.size_of_cc)).alias("mean_radius"),(F.sum(bucket2.diameter*bucket2.size_of_cc)/F.sum(bucket2.size_of_cc)).alias("mean_diameter"),(F.sum(bucket2.periphery_length*bucket2.size_of_cc)/F.sum(bucket2.size_of_cc)).alias("mean_periphery_length"),(F.sum(bucket2.centre_length*bucket2.size_of_cc)/F.sum(bucket2.size_of_cc)).alias("mean_centre_length"),(F.sum(bucket2.size_of_cc*bucket2.size_of_cc)/F.sum(bucket2.size_of_cc)).alias("mean_size_of_cc"),(F.sum(bucket2.max_clique*bucket2.size_of_cc)/F.sum(bucket2.size_of_cc)).alias("mean_max_clique"),(F.sum(bucket2.degree_quantile_90*bucket2.size_of_cc)/F.sum(bucket2.size_of_cc)).alias("mean_degree_quantile_90"),(F.sum(bucket2.degree_quantile_95*bucket2.size_of_cc)/F.sum(bucket2.size_of_cc)).alias("mean_degree_quantile_95"),(F.sum(bucket2.degree_quantile_98*bucket2.size_of_cc)/F.sum(bucket2.size_of_cc)).alias("mean_degree_quantile_98") )
	mb2c=meaned_bucket2.count()
	meaned_bucket3=bucket3.groupBy("dpid").agg( (F.sum(bucket3.avg_clustering_coef*bucket3.size_of_cc)/F.sum(bucket3.size_of_cc)).alias("mean_avg_clustering_coef"),(F.sum(bucket3.node_cutset*bucket3.size_of_cc)/F.sum(bucket3.size_of_cc)).alias("mean_node_cutset"),(F.sum(bucket3.radius*bucket3.size_of_cc)/F.sum(bucket3.size_of_cc)).alias("mean_radius"),(F.sum(bucket3.diameter*bucket3.size_of_cc)/F.sum(bucket3.size_of_cc)).alias("mean_diameter"),(F.sum(bucket3.periphery_length*bucket3.size_of_cc)/F.sum(bucket3.size_of_cc)).alias("mean_periphery_length"),(F.sum(bucket3.centre_length*bucket3.size_of_cc)/F.sum(bucket3.size_of_cc)).alias("mean_centre_length"),(F.sum(bucket3.size_of_cc*bucket3.size_of_cc)/F.sum(bucket3.size_of_cc)).alias("mean_size_of_cc"),(F.sum(bucket3.max_clique*bucket3.size_of_cc)/F.sum(bucket3.size_of_cc)).alias("mean_max_clique"),(F.sum(bucket3.degree_quantile_90*bucket3.size_of_cc)/F.sum(bucket3.size_of_cc)).alias("mean_degree_quantile_90"),(F.sum(bucket3.degree_quantile_95*bucket3.size_of_cc)/F.sum(bucket3.size_of_cc)).alias("mean_degree_quantile_95"),(F.sum(bucket3.degree_quantile_98*bucket3.size_of_cc)/F.sum(bucket3.size_of_cc)).alias("mean_degree_quantile_98")  )
	mb3c=meaned_bucket3.count()
	#just check if all union buckets have 60 dpids 
	t=meaned_bucket1.select('dpid').distinct().union(meaned_bucket2.select('dpid').distinct().union(meaned_bucket3.select('dpid').distinct())).distinct().count()
	meaned_bucket1.write.mode('overwrite').parquet(path+'meaned_bucket1_comp_features')
	meaned_bucket2.write.mode('overwrite').parquet(path+'meaned_bucket2_comp_features')
	meaned_bucket3.write.mode('overwrite').parquet(path+'meaned_bucket3_comp_features')
	print(t==total_dps,mb1c,mb2c,mb3c,t)
	# True 86 83 91 95 
except :
	print('error')
	# DataFrame[dpid: string, mean_avg_clustering_coef: double, mean_node_cutset: double, mean_radius: double, mean_diameter: double, mean_periphery_length: double, mean_size_of_cc: double, mean_degree_quantile_90: double, mean_degree_quantile_95: double]
	# for the boundary of density 
	# take cc sizes and find [0,x/3],[x/2,2x/3],[2x/3,x], ccsizes-[min,max]
	# so traverse from min size to maxsize and keep adding no.of ccs under that current size 
	# now if the counter>=(no.of ccs/3), break at that point 
	# repeat / continue for the other 2 boundary points 
	# (or may be use quantile simply, 33.33% abd 66.666%, )
	# now within each bucket, groupby on dpid and write features as weighted sum of features(weight=sizeof cc)
	# so now we have,
	# three buckets-
	# B1-B2-B3- 
	# all dpids with feature
	# now just take each dp from a bucket say dp1 and its features- fb1(dp1)
	# now get the cosine SIMILARITY of this fb1dp1 with fbidpj (i=1,2,3, j-1-nth dp )
	# so basically, every dp will have a euclidian SIMILARITY valued array 
	# of size (no.of dps * 3 )
	# so now we got three buckets  and each bucket have some number of dpids with their mean features 
	# now neeed to score within each bucket , just like before
	# and need to score betwwen two buckets also 
	# so, may be each bucket dps have 3 scores with them
	# the most prominent one is internal bucket score and the other two are scores wrto other two buckets 
	# so for internal bucket score , just run the score dps code for three buckets 
	# , for the intra bucket score, do a similar code by sending the pairs buckets 
	# (before it was 57 dps with themselves, so 57*57 weights and 57 scores )
	# now it is say 35 dp1s and 42 dp2s, so instead of one for loop for 35 dps 
	# two separate loops for dp1-dp2 and dp2-dp1 
	# and keep updating scores  
	# for internal scores 
try:
	bucket1=spark.read.parquet(path+'meaned_bucket1_comp_features')
	bucket2=spark.read.parquet(path+'meaned_bucket2_comp_features')
	bucket3=spark.read.parquet(path+'meaned_bucket3_comp_features')
	#True 44 30 34
	# bucket1 already has dpid as first column 
	def scoredpids_intra(dpids_features):
		#expects a df with n rows (n=no.of dps)
		#note that the df should have dpid as its first columns
		# get features into a array
		# dpids_features=bucket1
		cols=dpids_features.columns
		if(cols[0]!='dpid'):
			print('ERRORR')
			print('Make the first column as dpid')
			return
		features=dpids_features.rdd.map(lambda row : row).collect()
		dpids=[]
		all_features=[]
		for i in features:
			currf=[]
			for ind,fs in enumerate(i):
				if(ind==0):
					dpids.append(fs)
				else:
					currf.append(fs)
			all_features.append(currf)
		print("ehre")
	#NOW GET WEIGHTS (THE EUCLEDIAN DISTANCE WITHIN THE ROW VECTORS)
		def scoredps(weights,iterations=20):
			numdps=len(weights)
			score_dps=[1/numdps]*numdps #intial score 
			damp=0.85
			newscoredps=[0]*numdps 
			while(iterations):
				iterations-=1
				for i in range(numdps):
					score=0
					for j in range(numdps):
						score+=(weights[i][j]*score_dps[j])
					newscoredps[i]=(1-damp)/numdps + damp*score
				for i in range(numdps):
					score_dps[i]=newscoredps[i]
			ab=score_dps
			if(max(ab)==min(ab)):
				norm=[1 for i in ab]
			else:
				norm = [(float(i)-min(ab))/(max(ab)-min(ab)) for i in ab]
			return score_dps,norm
		def custom_normalize(weights):
			normalized=[]
			for w in weights:
				curr=w[:]
				curr.sort()
				second_max=curr[-2]
				chosen_min=curr[0]
				chosen_max=1.5*second_max
				curr_normalized=[]
				ranged=chosen_max-chosen_min
				for i in w:
					if(i==float('inf')):
						curr_normalized.append(1)
					else:
						curr_normalized.append((i-chosen_min)/ranged)
				normalized.append(curr_normalized)
			return normalized
		def pairwise_distances_weights(features):
			result=[]
			n=len(features)
			for i in range(n):
				result_for_i=[]
				for j in range(n):
					vectora=features[i]
					vectorb=features[j]
					distance=0
					m=len(vectorb)
					for k in range(m):
						if(vectorb[k]==-1 or vectora[k]==-1):
							continue
						distance+=(vectora[k]-vectorb[k])**2
					if(distance==0):
						result_for_i.append(float('inf'))
					else:
						result_for_i.append(1/(distance**0.5))
				result.append(result_for_i)
			return result
		pairwise_dist=pairwise_distances_weights(all_features)
		print("me")
		normalized=custom_normalize(pairwise_dist)
		print("normal")
		normalized=list(map(lambda x:(list(map(lambda y:float(y),x))),normalized))
		print("ndnjf")
		#NOW JUST SCORE 
		print(len(normalized),len(normalized[0]))
		dp_scores,normal_dp_scores=scoredps(normalized,100)
		print("hiffj")
		dpscores_id={}
		for ind,i in enumerate(dpids):
			dpscores_id[i]=normal_dp_scores[ind]
		dpscores_list=list(map(lambda x:[x,dpscores_id[x]],dpscores_id))
		return dpscores_list
	#funcs
	def scoredpids_inter(bucketa,bucketb):
		#expects a df with n rows (n=no.of dps)
		#note that the df should have dpid as its first columns
		# get features into a array
		cols=bucketb.columns
		if(cols[0]!='dpid'):
			print('ERRORR')
			print('Make the first column of bucketb as dpid')
			return
		cols=bucketa.columns
		if(cols[0]!='dpid'):
			print('ERRORR')
			print('Make the first column of bucketa as dpid')
			return
		featuresa=bucketa.rdd.map(lambda row : row).collect()
		featuresb=bucketb.rdd.map(lambda row : row).collect()
		dpids_a=[]
		all_features_a=[]
		dpids_b=[]
		all_features_b=[]
		for i in featuresa:
			currf=[]
			for ind,fs in enumerate(i):
				if(ind==0):
					dpids_a.append(fs)
				else:
					currf.append(fs)
			all_features_a.append(currf)
		for i in featuresb:
			currf=[]
			for ind,fs in enumerate(i):
				if(ind==0):
					dpids_b.append(fs)
				else:
					currf.append(fs)
			all_features_b.append(currf)
	#NOW GET WEIGHTS (THE EUCLEDIAN DISTANCE WITHIN THE ROW VECTORS)
		def scoredpsinter(weights,iterations=20):
			numdpsa=len(weights)
			numdpsb=len(weights[0])
			score_dps_a=[1/numdpsa]*numdpsa #intial score 
			score_dps_b=[1/numdpsb]*numdpsb
			damp=0.85
			newscoredps_a=[0]*numdpsa
			newscoredps_b=[0]*numdpsb 
			while(iterations):
				iterations-=1
				for i in range(numdpsa):
					scorei=0
					for j in range(numdpsb):
						scorei+=(weights[i][j]*score_dps_b[j])
					newscoredps_a[i]=(1-damp)/numdpsa + damp*scorei 
				#scoring for A
				for j in range(numdpsb):
					scorej=0
					for i in range(numdpsa):
						scorej+= (weights[i][j]*score_dps_a[i])
					newscoredps_b[j]=(1-damp)/numdpsb + damp*scorej
				#scoring for B
				for i in range(numdpsa):
					score_dps_a[i]=newscoredps_a[i]
				for j in range(numdpsb):
					score_dps_b[j]=newscoredps_b[j]
			maxa=max(score_dps_a)
			mina=min(score_dps_a)
			maxb=max(score_dps_b)
			minb=min(score_dps_b)
			if(maxa==mina):
				norm_a=[1 for i in score_dps_a]
			else:
				norm_a = [(float(i)-mina)/(maxa-mina) for i in score_dps_a]
			if(maxb==minb):
				norm_b=[1 for i in score_dps_b]
			else:
				norm_b= [(float(i)-minb)/(maxb-minb) for i in score_dps_b]
			return score_dps_a,norm_a,score_dps_b,norm_b
		def custom_normalize(weights):
			normalized=[]
			for w in weights:
				curr=w[:]
				curr.sort()
				second_max=curr[-2]
				chosen_min=curr[0]
				chosen_max=1.5*second_max
				if(curr[-1]!=float('inf')):
					chosen_max=curr[-1]
				curr_normalized=[]
				ranged=chosen_max-chosen_min
				for i in w:
					if(i==float('inf')):
						curr_normalized.append(1)
					else:
						curr_normalized.append((i-chosen_min)/ranged)
				normalized.append(curr_normalized)
			return normalized
		def pairwise_distances_weights_duo(featuresa,featuresb):
			result=[]
			m=len(featuresa)
			n=len(featuresb)
			for i in range(m):
				result_for_i=[]
				for j in range(n):
					vectora=featuresa[i]
					vectorb=featuresb[j]
					distance=0
					l=len(vectorb)
					for k in range(l):
						if(vectorb[k]==-1 or vectora[k]==-1):
							continue
						distance+=(vectora[k]-vectorb[k])**2
					if(distance==0):
						result_for_i.append(float('inf'))
					else:
						result_for_i.append(1/(distance**0.5))
				result.append(result_for_i)
			return result
		pairwise_dist=pairwise_distances_weights_duo(all_features_a,all_features_b)
		#m*n matrix-> m- no.of rows of A , n-> num rows of B
		normalized=custom_normalize(pairwise_dist)
		normalized=list(map(lambda x:(list(map(lambda y:float(y),x))),normalized))
		#NOW JUST SCORE 
		dp_scores_a,normal_dp_scores_a,dp_scores_b,normal_dp_scores_b=scoredpsinter(normalized,100)
		dpscores_id_a={}
		for ind,i in enumerate(dpids_a):
			dpscores_id_a[i]=normal_dp_scores_a[ind]
		dpscores_id_b={}
		for ind,i in enumerate(dpids_b):
			dpscores_id_b[i]=normal_dp_scores_b[ind]
		dpscoresa_list=list(map(lambda x:[x,dpscores_id_a[x]],dpscores_id_a))
		dpscoresb_list=list(map(lambda x:[x,dpscores_id_b[x]],dpscores_id_b))
		return dpscoresa_list,dpscoresb_list
	#funcs
	bucket1_scoreslist=scoredpids_intra(bucket1)
	dpid_with_scores1=spark.createDataFrame(bucket1_scoreslist,['dpid','b1_scores_wrto_b1'])
	dpid_with_scores1.write.mode('overwrite').parquet(path+'dpids_with_comparitive_b1_scores_wrto_b1')
	print(dpid_with_scores1.count()==mb1c)
	#true
	bucket2_scoreslist=scoredpids_intra(bucket2)
	dpid_with_scores2=spark.createDataFrame(bucket2_scoreslist,['dpid','b2_scores_wrto_b2'])
	dpid_with_scores2.write.mode('overwrite').parquet(path+'dpids_with_comparitive_b2_scores_wrto_b2')
	print(dpid_with_scores2.count()==mb2c)
	# true
	bucket3_scoreslist=scoredpids_intra(bucket3)
	dpid_with_scores3=spark.createDataFrame(bucket3_scoreslist,['dpid','b3_scores_wrto_b3'])
	dpid_with_scores3.write.mode('overwrite').parquet(path+'dpids_with_comparitive_b3_scores_wrto_b3')
	print(dpid_with_scores3.count()==mb3c)
	# true
	#now score inter buckets 
	#now call for 1,2-1,3-2,3
	b1_scores_wrto_b2,b2_scores_wrto_b1=scoredpids_inter(bucket1,bucket2)
	b1_scores_wrto_b3,b3_scores_wrto_b1=scoredpids_inter(bucket1,bucket3)
	b2_scores_wrto_b3,b3_scores_wrto_b2=scoredpids_inter(bucket2,bucket3)
	b1b2=spark.createDataFrame(b1_scores_wrto_b2,['dpid','b1_scores_wrto_b2'])
	b1b2.write.mode('overwrite').parquet(path+'dpids_with_comparitive_b1_scores_wrto_b2')
	b1b3=spark.createDataFrame(b1_scores_wrto_b3,['dpid','b1_scores_wrto_b3'])
	b1b3.write.mode('overwrite').parquet(path+'dpids_with_comparitive_b1_scores_wrto_b3')
	#join with b1b1
	b1b2=b1b2.withColumnRenamed('dpid','dpid_')
	join1=b1b2.join(b1b3,b1b2.dpid_==b1b3.dpid).drop('dpid_')
	b1b1=spark.read.parquet(path+'dpids_with_comparitive_b1_scores_wrto_b1').withColumnRenamed('dpid','dpid_')
	join1.join(b1b1,b1b1.dpid_==join1.dpid).drop('dpid_').select('dpid','b1_scores_wrto_b1','b1_scores_wrto_b2','b1_scores_wrto_b3').write.mode('overwrite').parquet(path+'bucket1_dpids_with_intra_inter_scores')
	bucket1_scores=spark.read.parquet(path+'bucket1_dpids_with_intra_inter_scores')
	print(bucket1_scores.count()==mb1c)
	#true
	b2b3=spark.createDataFrame(b2_scores_wrto_b3,['dpid','b2_scores_wrto_b3'])
	b2b3.write.mode('overwrite').parquet(path+'dpids_with_comparitive_b2_scores_wrto_b3')
	b2b1=spark.createDataFrame(b2_scores_wrto_b1,['dpid','b2_scores_wrto_b1'])
	b2b1.write.mode('overwrite').parquet(path+'dpids_with_comparitive_b2_scores_wrto_b1')
	#join with b2b2
	b2b3=b2b3.withColumnRenamed('dpid','dpid_')
	join2=b2b3.join(b2b1,b2b3.dpid_==b2b1.dpid).drop('dpid_')
	b2b2=spark.read.parquet(path+'dpids_with_comparitive_b2_scores_wrto_b2').withColumnRenamed('dpid','dpid_')
	join2.join(b2b2,b2b2.dpid_==join2.dpid).drop('dpid_').select('dpid','b2_scores_wrto_b2','b2_scores_wrto_b1','b2_scores_wrto_b3').write.mode('overwrite').parquet(path+'bucket2_dpids_with_intra_inter_scores')
	bucket2_scores=spark.read.parquet(path+'bucket2_dpids_with_intra_inter_scores')
	print(bucket2_scores.count()==mb2c)
	#true
	b3b1=spark.createDataFrame(b3_scores_wrto_b1,['dpid','b3_scores_wrto_b1'])
	b3b1.write.mode('overwrite').parquet(path+'dpids_with_comparitive_b3_scores_wrto_b1')
	b3b2=spark.createDataFrame(b3_scores_wrto_b2,['dpid','b3_scores_wrto_b2'])
	b3b2.write.mode('overwrite').parquet(path+'dpids_with_comparitive_b3_scores_wrto_b2')
	#join with b3b3
	b3b2=b3b2.withColumnRenamed('dpid','dpid_')
	join3=b3b2.join(b3b1,b3b2.dpid_==b3b1.dpid).drop('dpid_')
	b3b3=spark.read.parquet(path+'dpids_with_comparitive_b3_scores_wrto_b3').withColumnRenamed('dpid','dpid_')
	join3.join(b3b3,b3b3.dpid_==join3.dpid).drop('dpid_').select('dpid','b3_scores_wrto_b3','b3_scores_wrto_b1','b3_scores_wrto_b2').write.mode('overwrite').parquet(path+'bucket3_dpids_with_intra_inter_scores')
	bucket3_scores=spark.read.parquet(path+'bucket3_dpids_with_intra_inter_scores')
	print(bucket3_scores.count()==mb3c)
	#true
	bucket2_scores.sort(F.col('b2_scores_wrto_b1').desc()).show()
except Exception as error:
	print(error)
