try:
	bucket1=spark.read.parquet(path+'meaned_bucket1_comp_features')
	bucket2=spark.read.parquet(path+'meaned_bucket2_comp_features')
	bucket3=spark.read.parquet(path+'meaned_bucket3_comp_features')
	mb1c=meaned_bucket1.count()
	mb2c=meaned_bucket2.count()
	mb3c=meaned_bucket3.count()
	t=bucket1.select('dpid').distinct().union(bucket2.select('dpid').distinct().union(bucket3.select('dpid').distinct())).distinct().count()
	print(t==total_dps,mb1c,mb2c,mb3c)
	#True 44 30 34
	# bucket1 already has dpid as first column 
	def scoredpids_intra(dpids_features):
		#expects a df with n rows (n=no.of dps)
		#note that the df should have dpid as its first columns
		# get features into a array
		# dpids_features=bucket1
cols=dpids_features.columns
if(cols[0]!='dpid'):
	print('ERRORR')
	print('Make the first column as dpid')
	return
features=dpids_features.rdd.map(lambda row : row).collect()
dpids=[]
all_features=[]
for i in features:
	currf=[]
	for ind,fs in enumerate(i):
		if(ind==0):
			dpids.append(fs)
		else:
			currf.append(fs)
	all_features.append(currf)
		print("ehre")
	#NOW GET WEIGHTS (THE EUCLEDIAN DISTANCE WITHIN THE ROW VECTORS)
def scoredps(weights,iterations=20):
	numdps=len(weights)
	score_dps=[]*numdps #intial score 
	for i in range(numdps):
		score_dps.append(sum(weights[i]))
	print(score_dps)
	ab=score_dps
	if(max(ab)==min(ab)):
		norm=[1 for i in ab]
	else:
		norm = [(float(i)-min(ab))/(max(ab)-min(ab)) for i in ab]
	return score_dps,norm
	def custom_normalize(weights):
		normalized=[]
		for w in weights:
			curr=w[:]
			curr.sort()
			second_max=curr[-2]
			chosen_min=curr[0]
			chosen_max=1.5*second_max
			curr_normalized=[]
			ranged=chosen_max-chosen_min
			for i in w:
				if(i==float('inf')):
					curr_normalized.append(1)
				else:
					curr_normalized.append((i-chosen_min)/ranged)
			normalized.append(curr_normalized)
		return normalized
	def pairwise_distances_weights(features):
		result=[]
		n=len(features)
		for i in range(n):
			result_for_i=[]
			for j in range(n):
				vectora=features[i]
				vectorb=features[j]
				distance=0
				m=len(vectorb)
				for k in range(m):
					if(vectorb[k]==-1 or vectora[k]==-1):
						continue
					distance+=(vectora[k]-vectorb[k])**2
				if(distance==0):
					result_for_i.append(float('inf'))
				else:
					result_for_i.append(1/(distance**0.5))
			result.append(result_for_i)
		return result
		pairwise_dist=pairwise_distances_weights(all_features)
		print("me")
		normalized=custom_normalize(pairwise_dist)
		print("normal")
		normalized=list(map(lambda x:(list(map(lambda y:float(y),x))),normalized))
		print("ndnjf")
		#NOW JUST SCORE 
		print(len(normalized),len(normalized[0]))
		dp_scores,normal_dp_scores=scoredps(normalized,100)
		print("hiffj")
dpscores_id={}

for ind,i in enumerate(dpids):
	dpscores_id[i]=normal_dp_scores[ind]

dpscores_list=list(map(lambda x:[x,dpscores_id[x]],dpscores_id))
sort2=sorted(dpscores_list,key=lambda x:x[1])

x=bucket3.join(bucket3_scores,on=['dpid']).drop('mean_dpid','b3_scores_wrto_b2','b3_scores_wrto_b1').withColumnRenamed('b3_scores_wrto_b3','pagerank_score')

	# true
	# true
	#now score inter buckets 
dpid_with_scores3=spark.createDataFrame(dpscores_list,['dpid','corr_sum_score'])
dpid_with_scores3.join(x,on=['dpid']).select('dpid','pagerank_score','corr_sum_score', 'mean_avg_clustering_coef', 'mean_radius', 'mean_diameter', 'mean_periphery_length', 'mean_size_of_cc', 'mean_degree_quantile_98', 'mean_degree_quantile_99').write.mode('overwrite').parquet(path+'/bucket3_comp_indep_two_scores')
scores_b3=spark.read.parquet(path+'/bucket3_comp_indep_two_scores')

x=bucket3.join(bucket3_scores,on=['dpid']).drop('mean_dpid','b3_scores_wrto_b2','b3_scores_wrto_b1').withColumnRenamed('b3_scores_wrto_b3','pagerank_score')
dpid_with_scores3.join(x,on=['dpid']).withColumnRenamed('b3_scores_wrto_b3','correlation_sum_score').write.mode('overwrite').parquet(path+'/bucket3_comp_indep_two_scores')
scores_b3=spark.read.parquet(path+'/bucket3_comp_indep_two_scores').select('dpid','pagerank_score','correlation_sum_score', 'mean_avg_clustering_coef', 'mean_radius', 'mean_diameter', 'mean_periphery_length', 'mean_size_of_cc', 'mean_degree_quantile_98', 'mean_degree_quantile_99')

corr_fs=scores_b3.select('pagerank_score','corr_sum_score')
pd_df=corr_fs.toPandas()

#get correlatiom among columns 
pd_df.corr(method ='kendall')  #make all coulmns into bigint 

scores_b3.sort(F.col('corr_sum_score').desc()).show(34)
scores_b3.sort(F.col('pagerank_score').desc()).show(34)


	