
__all__ = ['eccentricity', 'diameter', 'radius', 'periphery', 'center']

import networkx

def eccentricity(G, v=None, sp=None):
    order=G.order()
    e={}
    for n in G.nbunch_iter(v):
        if sp is None:
            length=networkx.single_source_shortest_path_length(G,n)
            L = len(length)
        else:
            try:
                length=sp[n]
                L = len(length)
            except TypeError:
                raise networkx.NetworkXError('Format of "sp" is invalid.')
        if L != order:
            msg = "Graph not connected: infinite path length"
            raise networkx.NetworkXError(msg)
            
        e[n]=max(length.values())
    if v in G:
        return e[v]  # return single value
    else:
        return e

def find_distancemeasures(G,e=None):
    if e is None:
        e=eccentricity(G)
    diameter=max(e.values())
    radius=min(e.values())
    p=[v for v in e if e[v]==diameter]
    c=[v for v in e if e[v]==radius]
    return radius,diameter,p,c

