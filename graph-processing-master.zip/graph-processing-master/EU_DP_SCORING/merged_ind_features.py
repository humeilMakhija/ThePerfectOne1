import pyspark.sql.functions as F
from pyspark.sql.types import *
import networkx as nx
from graphframes import *
from pyspark.mllib.clustering import PowerIterationClustering, PowerIterationClusteringModel
from itertools import chain, combinations
import math
from operator import itemgetter
from collections import Counter
from collections import defaultdict
from os import sys, path
import community as community_louvain
from pyspark.sql.functions import lit
# paths
path="gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/graph/cleanup/country=merged/Prudhvi/merged_Graph_cleaning_new"
edges_path_nontube="gs://gcs-ireland-all-eu-daap-idu-bootstrap-internal-zeotap-com/run__20201123/zeoGraphEdges_idu_524/country="
edges_path_nontube_req=path+"edges_nontube_with_askedtypes"
# created ones
edges_distinct_nontube_path=path+"/edges_distinct_nontube"
vertices_from_edges_nontube_path=path+"/vertices_from_edges_distinct_nontube"
total_vertices_path= path +"/total_vertices_tubeandnontube"
long_mapped_ids_path = path+"data/all_ids_with_long_mapping"
all_edges_path=path+"Prudhvi/"+"nontube"+"/edges_mapped"
all_vertices_path=path+"/vertices_mapped_to_long_from_edges_nontube"
POL
FIN
SWE
DNK
NOR


u need -
edgestube, edges nontube req, long_mapped_ids, all edges path (final edges to apply cc)

try:
	# edges_tube=spark.read.parquet(edges_path_tube)
	edges_nontube =spark.read.parquet(edges_path_nontube_req)
	# DataFrame[vertex1: string, vertex1type: string, vertex2: string, vertex2type: string, dpid: int, timestamp: bigint, recordType: string]
	# dp_tube=edges_tube.select('dpid','vertex1','vertex1type','vertex2','vertex2type','timestamp').distinct()
	dp_nontube=edges_nontube.select('dpid','vertex1','vertex1type','vertex2','vertex2type','timestamp').distinct().write.mode('overwrite').parquet(path+"dpids_with_its_edges")
	dp_edges=spark.read.parquet(path+'dpids_with_its_edges')
	# 2232008
	#map to long
	long_mapped_ids=spark.read.parquet(long_mapped_ids_path)
	intermediate_edges = long_mapped_ids.join(dp_edges , [long_mapped_ids.id == dp_edges.vertex1 , long_mapped_ids.type == dp_edges.vertex1type]).drop("id","type").withColumnRenamed("long_id" , "src_long_id")
	long_mapped_ids.join(intermediate_edges , [long_mapped_ids.id == intermediate_edges.vertex2 , long_mapped_ids.type == intermediate_edges.vertex2type]).drop("id","type").withColumnRenamed("long_id" , "dst_long_id").write.mode("overwrite").parquet(path+"dp_edges_mapped_to_long")
	dp_longedges= spark.read.parquet(path+"dp_edges_mapped_to_long")
	c=dp_longedges.count()
	# 2232008
	all_dps_count=(dp_longedges.select('dpid').distinct().count())
	# 13
	#all required edges
try:
	all_edges=spark.read.parquet(all_edges_path).select("src_long_id" , "dst_long_id").withColumnRenamed("src_long_id" , "src").withColumnRenamed("dst_long_id" , "dst")	
	dp_longedges.join(all_edges,[all_edges.src==dp_longedges.src_long_id,all_edges.dst==dp_longedges.dst_long_id]).drop('src_long_id','dst_long_id').write.mode('overwrite').parquet(path+'dp_req_edges_with_longs')
	#IT NEEDS TO BE DONE FOR SRC=DST AND DST=SRC ALSO 
	dp_req_edges=spark.read.parquet(path+'dp_req_edges_with_longs')		
	dp_req_edges=dp_req_edges.withColumn("datetime",F.from_unixtime(F.col("timestamp")))
	total=all_edges.count()
	print("total_edges",total)
	# total_edges 400492
	dp_req_count=dp_req_edges.count()
	#0  since an edge is seen by multiple dps and also timestamps
	total_fromdps=dp_req_edges.select('src','dst').distinct().count()
	print(total_fromdps==total)
	# True - as expected
	dps=dp_req_edges.select('dpid').distinct().collect()
	dps=list(map(lambda x:x[0],dps))
	required_dps_count=len(dps)
	#13
	# THE REMAINING 52-32 ARE ANYWAYS NEGATIVE SCORED IN DPCOVER CODE 
	#now give score 
	# score based on ingestion percent-
	dp_score_inges=defaultdict(int)
	for dp in dps:
		dp_score_inges[dp]="{:.8f}".format(float( -(dp_req_edges.filter(F.col('dpid')==dp).where(F.col('datetime').like("%00:00:00")).distinct().count()/dp_req_edges.filter(F.col('dpid')==dp).distinct().count()) ))
	# now the actual score based on ingestion percent shouldnt be very high so scale it down by alpha 
	alpha=0.05
	for i in dp_score_inges.keys():
		if(float(dp_score_inges[i])!=0):
			dp_score_inges[i]=alpha*float(dp_score_inges[i])
	#  {'678': -0.05, '598': -0.05, '1222': -0.05, '820': -0.05, '1141': -0.05, '667': -0.05, '1396': -0.05, '1332': -0.05, '1110': -0.05, '404': -0.012012987000000001, '738': -0.05, '634': -0.05, '229': -0.05}
	#score based on no.of off-on links given
	#again it is seen only on all_edges becoz thats what is finnaly useful to us-
	dp_score_off_on=defaultdict(int)
	for dp in dps:
		dp_score_off_on[dp]="{:.8f}".format(float( (  (dp_req_edges.filter(F.col('dpid')==dp).filter(F.col("vertex1type")[0:2] == "id").filter(F.col("vertex2type")[0:2] != "id").count()+dp_req_edges.filter(F.col('dpid')==dp).filter(F.col("vertex2type")[0:2] == "id").filter(F.col("vertex1type")[0:2] != "id").count()) / dp_req_edges.filter(F.col('dpid')==dp).distinct().count() )))
	# {'678': '0.00000000', '598': '0.83333333', '1222': '0.81747982', '820': '1.00000000', '1141': '0.79794844', '667': '0.87715931', '1396': '0.63515844', '1332': '0.00000000', '1110': '0.52119129', '404': '1.00000000', '738': '0.00000000', '634': '0.00000000', '229': '1.00000000'}
	alpha=1.1 
	print("off-on done")
	#now score based on how much of links only this dp has seen (onlyme edges/all edges I saw)
	# to get only me edges 
	# grp by wrt edges 
	dp_req_edges=dp_req_edges.select('dpid','src','dst','timestamp')
	only_mes=dp_req_edges.select('dpid','src','dst').distinct().groupby('src','dst').count().filter(F.col('count')==1)
	only_mescount=only_mes.count()
	print(only_mescount<=total)
	#392766(out of total)
	only_mes=only_mes.withColumnRenamed('src','src_').withColumnRenamed('dst','dst_')
	df=only_mes.join(dp_req_edges,[dp_req_edges.src==only_mes.src_, dp_req_edges.dst==only_mes.dst_]).drop('src_','dst_').write.mode('overwrite').parquet(path+'only_me_edges_dpids')
	dp_only=spark.read.parquet(path+'only_me_edges_dpids')
	dp_edgeonly=dp_only.select('src','dst','dpid').distinct()
	e=dp_edgeonly.count()
	print(e==only_mescount)
	# True
	dp_edgeonly.select('dpid').distinct().count()
	# 13
	dp_alones=dp_edgeonly.select('dpid').distinct().collect()
	dp_alones=list(map(lambda x:x[0],dp_alones))
	dp_score_aloness=defaultdict(int)
	total_edges=dp_req_edges.select('src','dst').distinct().count()
	print(total==total_edges)
	#True
	for dp in dp_alones:
		alone_count=dp_edgeonly.filter(F.col('dpid')==dp).distinct().count()
		print(dp,alone_count)
		dp_score_aloness[dp]="{:.8f}".format(float( ( alone_count/total_edges)))
	#   {'678': '0.00118854', '598': '0.00001498', '1222': '0.00226222', '820': '0.00002497', '1141': '0.01157576', '667': '0.00072661', '1396': '0.92923954', '1332': '0.00000250', '1110': '0.00012734', '404': '0.00001498', '738': '0.03546638', '634': '0.00000499', '229': '0.00005993'}
except Exception as e:
	print("No",e)

#now this score is to be scale accordingly
# if a dp produces 2 edges and both are new,score will be 1 which is very high for 2 edges
# so the scale factor can be percent of edges seen 
#THIS SCALING IS NOW DONE DIRECTLY IN THE ABOVE LOOP ONLY
# for dps in dp_score_aloness.keys():
# 	seencount=dp_req_edges.filter(F.col('dpid')==dps).select('src','dst').distinct().count()
# 	#this scaling can be added in the above for loop only 
# 	print(dps,seencount)
# 	dp_score_aloness[dps]="{:.8f}".format(float( (seencount/total_edges*float(dp_score_aloness[dps]))))
# {'1396': '0.92344411', '335': '0.00007288', '598': '0.00034616', '1222': '0.00098382', '667': '0.00051013', '1110': '0.00009109', '648': '0.00088362', '1258': '0.00056479', '738': '0.02948732', '1141': '0.00936452', '395': '0.00004555', '979': '0.00036438', '678': '0.00112046', '1332': '0.00376221', '120': '0.00002733', '871': '0.00001822', '87': '0.00888172', '634': '0.00000911', '876': '0.00003644', '529': '0.00005466', '1292': '0.00005466', '59': '0.00059211', '1361': '0.00067410', '229': '0.00007288'}
#so, if dp has seen x amount of only me edges , then those x may be good or bad
#so dp need to be scored in accordance with anomal value of those x edges
#so to score edges, betweeness centrality can be used
# more the bc, means it is near to bridge and so it can be anomaly
# now may be the score we use can be 1/bc (since more bc , more it is a bride, so more anomaly, less score)
#BC Implementation-
try:
	all_edges=spark.read.parquet(all_edges_path).select("src_long_id" , "dst_long_id").withColumnRenamed("src_long_id" , "src").withColumnRenamed("dst_long_id" , "dst")
	cc_path_tube_nontube=path+"data/connected_components_data_nontube" #only nnontube coz its merged countires
	cc_final=spark.read.parquet(cc_path_tube_nontube)
	final_edges_to_apply_cc=spark.read.parquet(all_edges_path).select("src_long_id" , "dst_long_id").withColumnRenamed("src_long_id" , "src").withColumnRenamed("dst_long_id" , "dst")
	max_comp_intermediate_edges=cc_final.join(final_edges_to_apply_cc, [cc_final.id == final_edges_to_apply_cc.src]).drop("id")
	max_comp_intermediate_edges=max_comp_intermediate_edges.withColumnRenamed("component","src_component")
	max_comp_intermediate_edges.join(cc_final , [cc_final.id == max_comp_intermediate_edges.dst]).drop("id").withColumnRenamed("component","dst_component").write.mode("overwrite").parquet(path+"cc_merged_with_edges")
	cc_with_edges=spark.read.parquet(path+"cc_merged_with_edges")
	edge_count=cc_with_edges.count()
	print(edge_count==total)
	# True 
	trav_edges_cc=cc_with_edges.filter(F.col('src_component')==F.col('dst_component')).drop('dst_component').withColumnRenamed('src_component','component')
	df=trav_edges_cc.groupby('component').agg( F.collect_list( F.struct(F.col('src'),F.col('dst'))).alias('edges'))
	#DF WITH COMPONENT-EDGE_LIST
	# def getcount(x):
	# 	return x['component'],len(x['edges'])
	# cdf=df.rdd.map(lambda x:getcount(x)).toDF(['comp','count'])
	# cdf.select('count').groupBy().sum().collect()
	# # 109776 - sum of counts
	# cdf=cdf.withColumnRenamed('count','countcdf')
	# test=cdf.join(interm,interm.component==cdf.comp).drop('comp')
	# #2657 
	# test.filter(F.col('countcdf')!=F.col('count')).count()
	def bc_edge(x):
		edges=list(map(lambda x:tuple(x),x['edges']))
		graph_nx=nx.from_edgelist(edges)
		edge_bcs=nx.edge_betweenness_centrality(graph_nx)
		return x['component'],edge_bcs
	print("bcedge start")
	interm=df.rdd.map(lambda x: bc_edge(x)).toDF([ "component","edges_with_bcs"])
	interm_=interm.select("component",F.explode("edges_with_bcs"))
	interm_.select('component','key.*','value').withColumnRenamed('_1','src').withColumnRenamed('_2','dst').withColumnRenamed('value','edge_bc').write.mode('overwrite').parquet(path+'edges_with_edgebcs')
	x=spark.read.parquet(path+'edges_with_edgebcs')
	edge_bcs_count=x.count()
	print(edge_bcs_count,total)
	# 395636 400492  coz it counted all undirected edges only and in the dataset there are b0th a-b and b-a edges
	# now use the dp_edgeonly df here 
	x=x.withColumnRenamed('src','src_').withColumnRenamed('dst','dst_')
	dp_only=spark.read.parquet(path+'only_me_edges_dpids')
	dp_edgeonly=dp_only.select('src','dst','dpid').distinct()
	curr=dp_edgeonly.join(x,[x.src_==dp_edgeonly.src,x.dst_==dp_edgeonly.dst]).drop('src_','dst_')
	#  remaining are revrse direction edges
	curr=curr.union(dp_edgeonly.join(x,[x.dst_==dp_edgeonly.src,x.src_==dp_edgeonly.dst]).drop('src_','dst_'))
	curr.write.mode('overwrite').parquet(path+'aone_edges_with_edgebc')
	aloneedges=spark.read.parquet(path+'aone_edges_with_edgebc')
	alone_dp_count=aloneedges.count()
	print(alone_dp_count==e)
	#True
	aloneedges=aloneedges.withColumn('edge_score',1/F.col('edge_bc'))
	#scale the score between 0 -1
	def scalecolumn(df,col):
		from pyspark.ml.feature import MinMaxScaler
		from pyspark.ml.feature import VectorAssembler
		from pyspark.ml import Pipeline
		from pyspark.sql.functions import udf
		from pyspark.sql.types import DoubleType
		# UDF for converting column type from vector to double type
		unlist = udf(lambda x: round(float(list(x)[0]),3), DoubleType())
		assembler = VectorAssembler(inputCols=[col],outputCol=col+"_Vect")
		# MinMaxScaler Transformation
		scaler = MinMaxScaler(inputCol=col+"_Vect", outputCol=col+"_Scaled")
		# Pipeline of VectorAssembler and MinMaxScaler
		pipeline = Pipeline(stages=[assembler, scaler])
		# Fitting pipeline on dataframe
		returndf= pipeline.fit(df).transform(df).withColumn(col+"_Scaled", unlist(col+"_Scaled")).drop(col+"_Vect")
		return returndf
	dpid_with_edgescore=aloneedges.groupby('dpid').agg(F.avg(F.col('edge_score')).alias('avg_edgescore'))
	#now get avg edge_score for a dpid 
	dumm=scalecolumn(dpid_with_edgescore,'avg_edgescore')
	dumm.write.mode('overwrite').parquet(path+'dpid_with_avg_edgescore_scaled')
	dpids_edgescore=spark.read.parquet(path+'dpid_with_avg_edgescore_scaled')
	dpids_edgescore=dpids_edgescore.collect()
	#DEFINE DP_SCORE_ALONESS 
	for dp,_,score in dpids_edgescore:
		dp_score_aloness[dp]=score*float(dp_score_aloness[str(dp)])
except Exception as e:
	print("No",e)
#  {'678': 0.00118854, '598': 7.49e-08, '1222': 5.429328e-05, '820': 2.497e-08, '1141': 0.00032412128, '667': 1.8891860000000002e-05, '1396': 0.1951403034, '1332': 1e-08, '1110': 3.31084e-06, '404': 0.0, '738': 0.02099609696, '634': 1.1476999999999999e-07, '229': 2.9965e-07}
JENKS NATURAL BREAK ALGO 


#do the same for ids
# how many of new ids only this dp has seen 
try:
	# edges_tube=spark.read.parquet(edges_path_tube)
	edges_nontube =spark.read.parquet(edges_path_nontube_req)
	# dp_tube=edges_tube.select('dpid','vertex1','vertex1type').distinct().union(edges_tube.select('dpid','vertex2','vertex2type').distinct())
	dp_nontube=edges_nontube.select('dpid','vertex1','vertex1type').distinct().union(edges_nontube.select('dpid','vertex2','vertex2type').distinct()).distinct().write.mode('overwrite').parquet(path+"dpids_with_its_vertices")
	# dp_tube.union(dp_nontube).distinct().write.mode('overwrite').parquet(path+"dpids_with_its_vertices")
	dp_vertices=spark.read.parquet(path+'dpids_with_its_vertices')
	#now join with long mapped ids 
	long_mapped_ids=spark.read.parquet(long_mapped_ids_path)
	all_dps=dp_vertices.select('dpid').distinct().count()
	# 13 no.of dps
	multiple_count=dp_vertices.count()
	# 301620 the count of all vertices seen by dps( more than actual count coz one vertex can be seen by more than one dp) 
	dp_vertices.join(long_mapped_ids,[long_mapped_ids.id==dp_vertices.vertex1,long_mapped_ids.type==dp_vertices.vertex1type]).drop('vertex1','vertex1type').distinct().write.mode('overwrite').parquet(path+'dpids_with_its_vertices_long_mapped')
	dp_ids=spark.read.parquet(path+'dpids_with_its_vertices_long_mapped')
	dp_longs=dp_ids.select('dpid','long_id')
	all_vertices=spark.read.parquet(all_vertices_path)
	allvs=all_vertices.count()
	# 288901
	# DataFrame[id: bigint]
	dp_longs.join(all_vertices,all_vertices.id==dp_longs.long_id).drop('id').distinct().write.mode('overwrite').parquet(path+'dpids_with_its_final_vertices')
	dp_reqids=spark.read.parquet(path+'dpids_with_its_final_vertices')
	dpidvs=dp_reqids.count()
	# 301620
	distinctids=dp_reqids.select('long_id').distinct().count()
	print(allvs==distinctids)
	#True
	#now grp by wrto id 
	alone_ids=dp_reqids.groupby('long_id').count().distinct().filter(F.col('count')==1)
	alone_ids=alone_ids.withColumnRenamed('long_id','long_id_').drop('count')
	alones=alone_ids.count()
	print(alones<=allvs)
	# 277817
	alone_ids.join(dp_reqids,dp_reqids.long_id==alone_ids.long_id_).drop('long_id_').write.mode('overwrite').parquet(path+'only_me_ids_dpids')
	aloneid_dps=spark.read.parquet(path+'only_me_ids_dpids')
	print(aloneid_dps.count()==alones)
	#true
	alone_dps=aloneid_dps.select('dpid').distinct().collect()
	alone_dps=list(map(lambda x:x[0],alone_dps))
	print(len(alone_dps))
	# 13
	dpidscore_aloness=defaultdict(int)
	total_ids=dp_reqids.select('long_id').distinct().count()
	#288901
	#coz based on above scaling logic, 
	for dp in alone_dps:
		alone_count=aloneid_dps.filter(F.col('dpid')==dp).distinct().count()
		print(alone_count,total_ids)
		dpidscore_aloness[dp]="{:.8f}".format(float( ( alone_count/total_ids )))
except Exception as e:
	print("No",e)

 #  {'678': '0.00005538', '598': '0.00002423', '1222': '0.00284873', '820': '0.00003808', '1141': '0.01103838', '667': '0.00090342', '1396': '0.94092440', '1332': '0.00000346', '1110': '0.00006231', '404': '0.00002769', '738': '0.00559707', '634': '0.00000692', '229': '0.00010384'}
    # now same as before, the ids have to scored based on anaomaly



# so node bc can be used in a similar way 
try:
	cc_with_edges=spark.read.parquet(path+"cc_merged_with_edges")
	trav_edges_cc=cc_with_edges.filter(F.col('src_component')==F.col('dst_component')).drop('dst_component').withColumnRenamed('src_component','component')
	df=trav_edges_cc.groupby('component').agg( F.collect_list( F.struct(F.col('src'),F.col('dst'))).alias('edges'))
	def bc_node(x):
		edges=list(map(lambda x:tuple(x),x['edges']))
		graph_nx=nx.from_edgelist(edges)
		node_bcs=nx.betweenness_centrality(graph_nx)
		return x['component'],node_bcs
	print("node_bc start")
	interm=df.rdd.map(lambda x: bc_node(x)).toDF([ "component","nodes_with_bcs"])
	interm_=interm.select("component",F.explode("nodes_with_bcs"))
	interm_.withColumnRenamed('key','id').withColumnRenamed('value','node_bc').write.mode('overwrite').parquet(path+'nodes_with_nodebcs')
	nodebcs=spark.read.parquet(path+'nodes_with_nodebcs')
	print(nodebcs.count()==distinctids)
	# True as expected 
	aloneid_dps=spark.read.parquet(path+'only_me_ids_dpids')
	curr=aloneid_dps.join(nodebcs,nodebcs.id==aloneid_dps.long_id).drop('long_id')
	curr.write.mode('overwrite').parquet(path+'alone_ids_with_nodebc')
	curr=spark.read.parquet(path+'alone_ids_with_nodebc')
	node_scores=curr.withColumn('node_score',1/F.col('node_bc'))
	# dpid_with_nodescore.select('avg_nodescore').withColumn('isNull_node_bc',F.col('avg_nodescore').isNull()).where('isNull_node_bc = True').count()
	#scale the score between 0 -1
	def scalecolumn(df,col):
		from pyspark.ml.feature import MinMaxScaler
		from pyspark.ml.feature import VectorAssembler
		from pyspark.ml import Pipeline
		from pyspark.sql.functions import udf
		from pyspark.sql.types import DoubleType
		# UDF for converting column type from vector to double type
		unlist = udf(lambda x: round(float(list(x)[0]),3), DoubleType())
		assembler = VectorAssembler(inputCols=[col],outputCol=col+"_Vect")
		# MinMaxScaler Transformation
		scaler = MinMaxScaler(inputCol=col+"_Vect", outputCol=col+"_Scaled")
		# Pipeline of VectorAssembler and MinMaxScaler
		pipeline = Pipeline(stages=[assembler, scaler])
		# Fitting pipeline on dataframe
		returndf= pipeline.fit(df).transform(df).withColumn(col+"_Scaled", unlist(col+"_Scaled")).drop(col+"_Vect")
		return returndf
	dpid_with_nodescore=node_scores.groupby('dpid').agg(F.avg(F.col('node_score')).alias('avg_nodescore'))
	#now get avg node_score for a dpid 
	dpid_with_nodescore=dpid_with_nodescore.fillna({'avg_nodescore':1})
	dum=scalecolumn(dpid_with_nodescore,'avg_nodescore')
	dum.write.mode('overwrite').parquet(path+'dpid_with_avg_nodescore_scaled')
	dum=spark.read.parquet(path+'dpid_with_avg_nodescore_scaled')
	dpids_nodescore=dum.collect()
for dp,_,score in dpids_nodescore:
	dpidscore_aloness[dp]=score*float(dpidscore_aloness[str(dp)])
#  {'678': 0.0, '598': 0.0, '1222': 0.0, '820': 0.0, '1141': 0.00068437956, '667': 0.0, '1396': 0.9409244, '1332': 0.0, '1110': 0.0, '404': 0.0, '738': 0.00058209528, '634': 0.0, '229': 0.0})
except Exception as e:
	print("No",e)


#DPCOVER CODE
try:
	# edges_tube=spark.read.parquet(edges_path_tube)
	edges_nontube =spark.read.parquet(edges_path_nontube_req)
	# DataFrame[vertex1: string, vertex1type: string, vertex2: string, vertex2type: string, dpid: int, timestamp: bigint, recordType: string]
	# dp_tube=edges_tube.select('dpid','vertex1','vertex1type').distinct().union(edges_tube.select('dpid','vertex2','vertex2type').distinct())
	# dp_nontube=edges_nontube.select('dpid','vertex1','vertex1type').distinct().union(edges_nontube.select('dpid','vertex2','vertex2type').distinct())
	# dp_tube.union(dp_nontube).distinct().write.mode('overwrite').parquet(path+"dpids_with_its_vertices")
	dp_vertices=spark.read.parquet(path+'dpids_with_its_vertices')
	# #now join with long mapped ids 
	long_mapped_ids=spark.read.parquet(long_mapped_ids_path)
	multiple_count=dp_vertices.count()
	# # 301620 the count of all vertices seen by dps( more than actual count coz one vertex can be seen by more than one dp) 
	# dp_vertices.join(long_mapped_ids,[long_mapped_ids.id==dp_vertices.vertex1,long_mapped_ids.type==dp_vertices.vertex1type]).drop('vertex1','vertex1type').write.mode('overwrite').parquet(path+'dpids_with_its_vertices_long_mapped')
	dp_ids=spark.read.parquet(path+'dpids_with_its_vertices_long_mapped')
	dp_longs=dp_ids.select('dpid','long_id')
	all_vertices=spark.read.parquet(all_vertices_path)
	allvs=all_vertices.count()
	# # 288901
	# # DataFrame[id: bigint]
	# dp_longs.join(all_vertices,all_vertices.id==dp_longs.long_id).drop('id').write.mode('overwrite').parquet(path+'dpids_with_its_final_vertices')
	dp_reqids=spark.read.parquet(path+'dpids_with_its_final_vertices')
	#ALL THE ABOVE PATHS ARE WRITTEN IN DP_IND_FEATURES
	#this df contains dpid and only those ids which are present in final all vertices 
	reqdps=dp_reqids.select('dpid').distinct().count()
	# 13 so out of all only those dps have seen ids which are present in final vertices 
	# THE REMAINING DPS WILL BE GIVEN A NEGATIVE SCORE OF -1 
	reqvs=dp_reqids.count()
	print(reqvs>=allvs)
	# 301620 (coz an id can be seen by multiple dps)
	print(allvs==dp_reqids.select('long_id').distinct().count())
	# True  as expected
	#NOW DO THE STEP 1 
	#COLLECT ALL DPIDS 
	dps=dp_longs.select('dpid').distinct().collect()
	dp_score1=defaultdict(int)
	total=0
	usefuls=0
	for i in dps:
		curr_dp=i[0]
		total_seen_ids=dp_longs.filter(F.col('dpid')==curr_dp).select('long_id').distinct().count()
		useful_ids=dp_reqids.filter(F.col('dpid')==curr_dp).select('long_id').distinct().count()
		dp_score1[curr_dp]=useful_ids/total_seen_ids
		usefuls+=useful_ids
		total+=total_seen_ids  
	print(total==multiple_count)
	print(usefuls==reqvs)
	# True, True
	# total=(total ids+multiple dps=dp_longs.distinct().count())
	# usefuls= (total req ids+multiple dps=dp_reqids.count())
	for i in dp_score1.keys():
		dp_score1[i]="{:.8f}".format(float((dp_score1[i])))
	print("inital score is done")
	#REPEAT THE SAMETHING FOR EDGES ALSO
	#THE EDGES DFS RE ALREADY WRITTEN IN below CODE
	# {'678': '1.00000000', '598': '1.00000000', '1222': '1.00000000', '820': '1.00000000', '1141': '1.00000000', '667': '1.00000000', '1396': '1.00000000', '1332': '1.00000000', '1110': '1.00000000', '404': '1.00000000', '738': '1.00000000', '634': '1.00000000', '229': '1.00000000'}
	# so, now all dps are given a positive score based on above dict values if value>0, if value=0 then a negative score of -0.5 can be given 
	#ALLL 1S COZ EVERYTHING IS USED FOR MERGED COUNTIRES
	dps=dp_reqids.select('dpid').distinct().collect()
	dps=list(map(lambda x:x[0],dps))
	print(len(dps)==reqdps)
except Exception as error:
	print(error)
	#26 (lendps)
	#the brute force NP solution for set cover is not possible to implemet
	#the number 28 was for belgiu only
	#28 dps 2^28 subsets for each subsets, there are dpids inside the subsets and for those dpids, filter and count union areperformed on dfs
	#so, follow greedy approximate algorithm
	#initally included elements=I
	#keep adding subsets to it, and at any point the subset u pich should have max [SI-I] value, i.e max no.of new elements it ha to give
try:
	print('dp cover starts')
	schema = StructType([
	  StructField('long_id', LongType(), False),
	  ])
	included_ids=spark.sparkContext.parallelize([]).toDF(schema)
	n=len(dps)
	threshold=0.99
	total_cover=all_vertices.count()
	seendpids=set()
	print("total_cover is ",total_cover,threshold*total_cover)
	# total_cover is  288901 286011.99 
	while(included_ids.count()<threshold*total_cover):
		maxval=0
		maxdpid=-1
		for dpid in dps:
			if(dpid in seendpids):
				continue
			curr_ids=dp_reqids.filter(F.col('dpid')==dpid).select('long_id').distinct()
			diff=curr_ids.subtract(included_ids).distinct()
			curr_count=diff.count()
			if(curr_count>maxval):
					maxval=curr_count
					maxdpid=dpid
		if(maxdpid==-1):
			print("ERRORRRR!!!!")
			break
		print(included_ids.count(),maxdpid,seendpids,maxval)
		included_ids=included_ids.union(dp_reqids.filter(F.col('dpid')==maxdpid).select('long_id').distinct()).distinct()
		seendpids.add(maxdpid)
		print("UPDATED",included_ids.count())
		print(seendpids)
	dp_score_cover=defaultdict(int)
	#now score -
	for i in seendpids:
		dp_score_cover[i]= "{:.8f}".format(float( ( dp_reqids.filter(F.col('dpid')==i).distinct().count() / total_cover )))
except Exception as e:
	print("No",e)



seendpids-{'1141', '1396'} 
included_ids.count()-
286017 
 {'1141': '0.01800963', '1396': '0.97878858'}
#The scoring shouldnt be in other of how the greedy algo chose the dpids
coz say a dpid1 has 99% data and other dpid2 has 99.1% , so dpid2 will be chosen with score 99.1 and the other dpid will then be scored only 0.1 around
so 


now again, the dps in seendpids are scored based on count of how much they seen/total count and other remaining are not given any score(not even a negative score)

since this score is very crucial may be it neeed to be scaled up by alpha 
alpha=1.5




#THE SAME DP COVER CAN BE DONE FOR EDGES AS WELL-


try:
	dp_longedges= spark.read.parquet(path+"dp_edges_mapped_to_long")
	#  (along with timestamps and multiple dpids) 
	all_edges=spark.read.parquet(all_edges_path).select("src_long_id" , "dst_long_id").withColumnRenamed("src_long_id" , "src").withColumnRenamed("dst_long_id" , "dst")	
	e=all_edges.count()
	# # 400492
	# DataFrame[id: bigint]
	dp_req_edges=spark.read.parquet(path+'dp_req_edges_with_longs').select('dpid','src','dst').distinct()		
	req_edgescount=dp_req_edges.count()
	print(req_edgescount>=e)
	#408510 since an edge is seen by multiple dps
	#NOW DO THE STEP 1 
	#COLLECT ALL DPIDS 
	dps=dp_longedges.select('dpid').distinct().collect()
	dp_score_edges=defaultdict(int)
	total=0
	usefuls=0
	for i in dps:
		curr_dp=i[0]
		total_seen_edges=dp_longedges.filter(F.col('dpid')==curr_dp).select('src_long_id','dst_long_id').distinct().count()
		useful_edges=dp_req_edges.filter(F.col('dpid')==curr_dp).select('src','dst').distinct().count()
		print(curr_dp,useful_edges,total_seen_edges)
		dp_score_edges[curr_dp]="{:.8f}".format(float((useful_edges/total_seen_edges)))
		usefuls+=useful_edges
		total+=total_seen_edges  
	print(total==dp_longedges.select('dpid','src_long_id','dst_long_id').distinct().count(),total)
	print(usefuls==req_edgescount)
except Exception as e:
	print(e)
	 # {'678': '1.00000000', '598': '1.00000000', '1222': '1.00000000', '820': '1.00000000', '1141': '1.00000000', '667': '1.00000000', '1396': '1.00000000', '1332': '1.00000000', '1110': '1.00000000', '404': '1.00000000', '738': '1.00000000', '634': '1.00000000', '229': '1.00000000'}/
	# total=(= total edges and multiple dps also =dp_longedges.select('dpid','src_long_id','dst_long_id').distinct().count())
	# usefuls= (=total req edges and multiple dps also=dp_req_edges.distinct().count())
	#  
	# so, now all dps are given a positive score based on above dict values if value>0, if value=0 then a negative score of -0.5 can be given 
try:
	dps=dp_req_edges.select('dpid').distinct().collect()
	dps=list(map(lambda x:x[0],dps))
	#the brute force NP solution for set cover is not possible to implemet
	#28 dps 2^28 subsets for each subsets, there are dpids inside the subsets and for those dpids, filter and count union areperformed on dfs
	#so, follow greedy approximate algorithm
	#initally included elements=I
	#keep adding subsets to it, and at any point the subset u pich should have max [SI-I] value, i.e max no.of new elements it ha to give
	print('edge cover starts')
	dp_req_edges=dp_req_edges.select('dpid','src','dst').distinct()
	schema = StructType([
	  StructField('src', LongType(), False),
	  StructField('dst', LongType(), False),
	  ])
	included_edges=spark.sparkContext.parallelize([]).toDF(schema)
	n=len(dps)
	threshold=0.99
	total_cover=all_edges.count()
	# 
	seendpids=set()
	print("total_cover is ",total_cover,threshold*total_cover)
	# total_cover is  400492 396487.08  
	while(included_edges.count()<threshold*total_cover):
		maxval=0
		maxdpid=-1
		for dpid in dps:
			if(dpid in seendpids):
				continue
			curr_edges=dp_req_edges.filter(F.col('dpid')==dpid).select('src','dst').distinct()
			diff=curr_edges.subtract(included_edges).distinct()
			curr_count=diff.count()
			if(curr_count>maxval):
					maxval=curr_count
					maxdpid=dpid
		if(maxdpid==-1):
			print("ERRORRRR!!!!")
			break
		print(included_edges.count(),maxdpid,seendpids,maxval)
		included_edges=included_edges.union(dp_req_edges.filter(F.col('dpid')==maxdpid).select('src','dst').distinct()).distinct()
		seendpids.add(maxdpid)
		print("UPDATED",included_edges.count())
		print(seendpids)
	dp_score_coveredges=defaultdict(int)
	for i in seendpids:
		dp_score_coveredges[i]= "{:.8f}".format(float( ( dp_req_edges.filter(F.col('dpid')==i).distinct().count() / total_cover )))
except Exception as error:
	print('No',error)

print(dp_score_coveredges)

{'738', '1141', '1396'}
included_ids.count()-
398682 
{'738': '0.05026068', '1141': '0.01562578', '1396': '0.94701767'}


