import pyspark.sql.functions as F
from pyspark.sql.types import *
import networkx as nx
from graphframes import *
from pyspark.mllib.clustering import PowerIterationClustering, PowerIterationClusteringModel
from itertools import chain, combinations
import math
from operator import itemgetter
from collections import Counter
from collections import defaultdict
from os import sys, path
import community as community_louvain
from pyspark.sql.functions import lit

path="gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/graph/cleanup/country=ITA/Prudhvi/ITA_Graph_cleaning_new"
edges_path_nontube="gs://gcs-ireland-all-eu-daap-idu-bootstrap-internal-zeotap-com/run__20201123/zeoGraphEdges_idu_524/country=ITA"
edges_path_tube="gs://gcs-ireland-all-eu-daap-idu-bootstrap-internal-zeotap-com/run__20201123/tubeGraphEdges_idu_524/country=ITA"
edges_path_nontube_req=path+'edges_nontube_with_askedtypes'
edges_distinct_nontube_path=path+"/edges_distinct_nontube"
edges_distinct_tube_path=path+"/edges_distinct_tube"
vertices_from_edges_tube_path=path+"/vertices_from_edges_distinct_tube"
vertices_from_edges_nontube_path=path+"/vertices_from_edges_distinct_nontube"
total_vertices_path= path +"/total_vertices_tubeandnontube"
long_mapped_ids_path = path+"data/all_ids_with_long_mapping"
all_vertices_path=path+"/final_vertices_to_apply_cc"
all_edges_path=path+"/final_edges_to_apply_cc"



try:
	edges_tube=spark.read.parquet(edges_path_tube)
	edges_nontube =spark.read.parquet(edges_path_nontube_req)
	# DataFrame[vertex1: string, vertex1type: string, vertex2: string, vertex2type: string, dpid: int, timestamp: bigint, recordType: string]
	dp_tube=edges_tube.select('dpid','vertex1','vertex1type','vertex2','vertex2type','timestamp').distinct()
	dp_nontube=edges_nontube.select('dpid','vertex1','vertex1type','vertex2','vertex2type','timestamp').distinct()
	dp_tube.union(dp_nontube).distinct().write.mode('overwrite').parquet(path+"dpids_with_its_edges")
	dp_edges=spark.read.parquet(path+'dpids_with_its_edges')
	# 11267714
	#map to long
	long_mapped_ids=spark.read.parquet(long_mapped_ids_path)
	intermediate_edges = long_mapped_ids.join(dp_edges , [long_mapped_ids.id == dp_edges.vertex1 , long_mapped_ids.type == dp_edges.vertex1type]).drop("id","type").withColumnRenamed("long_id" , "src_long_id")
	long_mapped_ids.join(intermediate_edges , [long_mapped_ids.id == intermediate_edges.vertex2 , long_mapped_ids.type == intermediate_edges.vertex2type]).drop("id","type").withColumnRenamed("long_id" , "dst_long_id").write.mode("overwrite").parquet(path+"dp_edges_mapped_to_long")
	dp_longedges= spark.read.parquet(path+"dp_edges_mapped_to_long")
	c=dp_longedges.count()
	# 7097206477
	all_dps_count=(dp_longedges.select('dpid').distinct().count())
	# 95
	#all required edges
	all_edges=spark.read.parquet(all_edges_path)	
	dp_longedges.join(all_edges,[all_edges.src==dp_longedges.src_long_id,all_edges.dst==dp_longedges.dst_long_id]).drop('src_long_id','dst_long_id').write.mode('overwrite').parquet(path+'dp_req_edges_with_longs')
	#IT NEEDS TO BE DONE FOR SRC=DST AND DST=SRC ALSO 
	dp_req_edges=spark.read.parquet(path+'dp_req_edges_with_longs')		
	dp_req_edges=dp_req_edges.withColumn("datetime",F.from_unixtime(F.col("timestamp")))
	total=all_edges.count()
	print("total_edges",total)
	# total_edges 1895575051 
	dp_req_count=dp_req_edges.count()
	# 5417066178- since an edge is seen by multiple dps and also timestamps
	total_fromdps=dp_req_edges.select('src','dst').distinct().count()
	print(total_fromdps==total)
	# True - as expected
	dps=dp_req_edges.select('dpid').distinct().collect()
	dps=list(map(lambda x:x[0],dps))
	required_dps_count=len(dps)
	#92
	# THE REMAINING 52-32 ARE ANYWAYS NEGATIVE SCORED IN DPCOVER CODE 
	#now give score 
	# score based on ingestion percent-
	dp_score_inges=defaultdict(int)
	for dp in dps:
		dp_score_inges[dp]="{:.8f}".format(float( -(dp_req_edges.filter(F.col('dpid')==dp).where(F.col('datetime').like("%00:00:00")).distinct().count()/dp_req_edges.filter(F.col('dpid')==dp).distinct().count()) ))
	# now the actual score based on ingestion percent shouldnt be very high so scale it down by alpha 
	alpha=0.05
	for i in dp_score_inges.keys():
		if(float(dp_score_inges[i])!=0):
			dp_score_inges[i]=alpha*float(dp_score_inges[i])
	# {'979': -1.48e-07, '87': -1.41e-07, '1314': '-0.00000000', '372': '-0.00000000', '18': '-0.00000000', '75': '-0.00000000', '120': -3.735e-07, '1271': '-0.00000000', '525': -0.05, '118': '-0.00000000', '335': -2.125e-07, '1316': '-0.00000000', '1302': '-0.00000000', '1148': '-0.00000000', '135': '-0.00000000', '1129': '-0.00000000', '1146': '-0.00000000', '33': '-0.00000000', '648': -1.31e-07, '24': '-0.00000000', '806': '-0.00000000', '395': -1.315e-07, '63': '-0.00000000', '331': '-0.00000000', '1249': '-0.00000000', '637': -5.155e-07, '1292': -1.33e-07, '1480': '-0.00000000', '529': -2.2450000000000003e-07, '800': -0.049977767000000006, '1361': -1.9050000000000002e-07, '307': '-0.00000000', '685': '-0.00000000', '556': '-0.00000000', '1076': '-0.00000000', '667': -0.04965206850000001, '876': -3.825e-07, '1257': -1.245e-07, '329': '-0.00000000', '1147': -1.5700000000000002e-07, '229': -0.05, '1396': -0.049914375500000004, '338': '-0.00000000', '963': '-0.00000000', '1077': '-0.00000000', '86': '-0.00000000', '654': '-0.00000000', '239': '-0.00000000', '346': '-0.00000000', '1085': -1.1200000000000001e-07, '105': '-0.00000000', '516': '-0.00000000', '1415': '-0.00000000', '12': -0.05, '21': -0.05, '611': '-0.00000000', '820': -0.05, '625': '-0.00000000', '521': '-0.00000000', '29': '-0.00000000', '1429': '-0.00000000', '59': -1.365e-07, '1252': '-0.00000000', '808': '-0.00000000', '634': -0.05, '807': '-0.00000000', '1141': -0.03959473350000001, '27': '-0.00000000', '620': '-0.00000000', '799': '-0.00000000', '678': -0.048564632, '1110': -0.025894108500000002, '404': -0.0229155675, '738': -0.048136882, '95': '-0.00000000', '376': '-0.00000000', '233': '-0.00000000', '416': '-0.00000000', '1332': -0.05, '336': '-0.00000000', '314': -1.8e-07, '1258': -1.5850000000000002e-07, '575': '-0.00000000', '871': -1.335e-07, '810': '-0.00000000', '598': -0.010148560000000001, '809': '-0.00000000', '1055': '-0.00000000', '370': '-0.00000000', '1380': -1.675e-07, '1222': -0.04999998, '522': -0.05}
	#score based on no.of off-on links given
	#again it is seen only on all_edges becoz thats what is finnaly useful to us-
	dp_score_off_on=defaultdict(int)
	for dp in dps:
		dp_score_off_on[dp]="{:.8f}".format(float( (  (dp_req_edges.filter(F.col('dpid')==dp).filter(F.col("vertex1type")[0:2] == "id").filter(F.col("vertex2type")[0:2] != "id").count()+dp_req_edges.filter(F.col('dpid')==dp).filter(F.col("vertex2type")[0:2] == "id").filter(F.col("vertex1type")[0:2] != "id").count()) / dp_req_edges.filter(F.col('dpid')==dp).distinct().count() )))
	# {'979': '0.00000000', '87': '0.00000000', '1314': '0.00000000', '372': '0.00000000', '18': '0.00000000', '75': '0.00000000', '120': '0.00000000', '1271': '0.00000000', '525': '0.00000000', '118': '0.00000000', '335': '0.00000000', '1316': '0.00000000', '1302': '0.00000000', '1148': '0.00000000', '135': '0.00000000', '1129': '0.00000000', '1146': '0.00000000', '33': '0.00000000', '648': '0.00000000', '24': '0.00000000', '806': '0.00000000', '395': '0.00000000', '63': '0.00000000', '331': '0.00000000', '1249': '0.00000000', '637': '0.00000000', '1292': '0.00000000', '1480': '0.00000000', '529': '0.00000000', '800': '0.01305905', '1361': '0.00000000', '307': '0.00000000', '685': '0.00000000', '556': '0.00000000', '1076': '0.00000000', '667': '0.65950403', '876': '0.00000000', '1257': '0.00000000', '329': '0.00000000', '1147': '0.00000000', '229': '1.00000000', '1396': '0.50175790', '338': '0.00000000', '963': '0.00000000', '1077': '0.00000000', '86': '0.00000000', '654': '0.00000000', '239': '0.00000000', '346': '0.00000000', '1085': '0.00000000', '105': '0.00000000', '516': '0.00000000', '1415': '0.00000000', '12': '0.00000000', '21': '0.50074093', '611': '0.00000000', '820': '0.91850862', '625': '0.00000000', '521': '0.00000000', '29': '0.00000000', '1429': '0.00000000', '59': '0.00000000', '1252': '0.00000000', '808': '0.00000000', '634': '0.00000000', '807': '0.00000000', '1141': '0.45205639', '27': '0.00000000', '620': '0.00000000', '799': '0.00000000', '678': '0.00000000', '1110': '0.17112411', '404': '0.99527286', '738': '0.00000000', '95': '0.00000000', '376': '0.00000000', '233': '0.00000000', '416': '0.00000000', '1332': '0.00000000', '336': '0.00000000', '314': '0.00000000', '1258': '0.00000000', '575': '0.00000000', '871': '0.00000000', '810': '0.00000000', '598': '0.15429263', '809': '0.00000000', '1055': '0.00000000', '370': '0.00000000', '1380': '0.00000000', '1222': '0.66888939', '522': '0.67857143'}
	alpha=1.1 
	print("off-on done")
	#now score based on how much of links only this dp has seen (onlyme edges/all edges I saw)
	# to get only me edges 
	# grp by wrt edges 
	dp_req_edges=dp_req_edges.select('dpid','src','dst','timestamp')
	only_mes=dp_req_edges.select('dpid','src','dst').distinct().groupby('src','dst').count().filter(F.col('count')==1)
	only_mescount=only_mes.count()
	print(only_mescount<=total)
	#1635737160(out of total)
	only_mes=only_mes.withColumnRenamed('src','src_').withColumnRenamed('dst','dst_')
	df=only_mes.join(dp_req_edges,[dp_req_edges.src==only_mes.src_, dp_req_edges.dst==only_mes.dst_]).drop('src_','dst_').write.mode('overwrite').parquet(path+'only_me_edges_dpids')
	dp_only=spark.read.parquet(path+'only_me_edges_dpids')
	dp_edgeonly=dp_only.select('src','dst','dpid').distinct()
	e=dp_edgeonly.count()
	print(e==only_mescount)
	# True
	d=dp_edgeonly.select('dpid').distinct().count()
	# 89  
	dp_alones=dp_edgeonly.select('dpid').distinct().collect()
	dp_alones=list(map(lambda x:x[0],dp_alones))
	dp_score_aloness=defaultdict(int)
	total_edges=dp_req_edges.select('src','dst').distinct().count()
	print(total==total_edges)
	#True
	for dp in dp_alones:
		alone_count=dp_edgeonly.filter(F.col('dpid')==dp).distinct().count()
		print(dp,alone_count)
		dp_score_aloness[dp]="{:.8f}".format(float( ( alone_count/total_edges)))
	#   {'979': '0.01176215', '87': '0.16215127', '1314': '0.00000894', '372': '0.00000966', '18': '0.00000000', '75': '0.00000004', '120': '0.00157226', '1271': '0.00000013', '525': '0.00000485', '118': '0.00000011', '335': '0.00073901', '1316': '0.00000001', '1302': '0.00000000', '1148': '0.00000856', '135': '0.00000390', '1129': '0.00000000', '33': '0.00000035', '648': '0.01943775', '24': '0.00000000', '806': '0.00000014', '395': '0.01269545', '63': '0.00000098', '331': '0.00003544', '1249': '0.00000000', '637': '0.00001081', '1292': '0.00669134', '1480': '0.00000009', '529': '0.00069776', '800': '0.00000572', '1361': '0.02232556', '307': '0.00007624', '685': '0.00000156', '556': '0.00000011', '1076': '0.00000023', '667': '0.00128393', '876': '0.00039013', '1257': '0.00275043', '329': '0.00000002', '1147': '0.00034961', '229': '0.00113667', '1396': '0.09106578', '338': '0.00000176', '963': '0.00000750', '1077': '0.00000000', '86': '0.00000362', '654': '0.00001753', '239': '0.00000010', '346': '0.00000052', '1085': '0.00152587', '105': '0.00005145', '516': '0.00000152', '1415': '0.00000009', '12': '0.00001102', '21': '0.00031565', '611': '0.00000499', '820': '0.00328268', '625': '0.00000914', '521': '0.00000029', '1429': '0.00000000', '59': '0.02380404', '1252': '0.00000472', '808': '0.00000271', '634': '0.00000508', '807': '0.00000017', '1141': '0.03514176', '27': '0.00000001', '620': '0.00000188', '799': '0.00001973', '678': '0.01255957', '1110': '0.00059655', '404': '0.00018022', '738': '0.42689020', '95': '0.00001952', '376': '0.00000001', '233': '0.00000633', '416': '0.00000009', '1332': '0.00000243', '336': '0.00000007', '314': '0.00156123', '1258': '0.01540688', '575': '0.00000093', '871': '0.00542279', '810': '0.00000000', '598': '0.00013862', '809': '0.00000043', '370': '0.00000043', '1380': '0.00020979', '1222': '0.00049710', '522': '0.00000001'}
except Exception as e:
	print("No",e)

#now this score is to be scale accordingly
# if a dp produces 2 edges and both are new,score will be 1 which is very high for 2 edges
# so the scale factor can be percent of edges seen 
#THIS SCALING IS NOW DONE DIRECTLY IN THE ABOVE LOOP ONLY
# for dps in dp_score_aloness.keys():
# 	seencount=dp_req_edges.filter(F.col('dpid')==dps).select('src','dst').distinct().count()
# 	#this scaling can be added in the above for loop only 
# 	print(dps,seencount)
# 	dp_score_aloness[dps]="{:.8f}".format(float( (seencount/total_edges*float(dp_score_aloness[dps]))))
# {'1396': '0.92344411', '335': '0.00007288', '598': '0.00034616', '1222': '0.00098382', '667': '0.00051013', '1110': '0.00009109', '648': '0.00088362', '1258': '0.00056479', '738': '0.02948732', '1141': '0.00936452', '395': '0.00004555', '979': '0.00036438', '678': '0.00112046', '1332': '0.00376221', '120': '0.00002733', '871': '0.00001822', '87': '0.00888172', '634': '0.00000911', '876': '0.00003644', '529': '0.00005466', '1292': '0.00005466', '59': '0.00059211', '1361': '0.00067410', '229': '0.00007288'}
#so, if dp has seen x amount of only me edges , then those x may be good or bad
#so dp need to be scored in accordance with anomal value of those x edges
#so to score edges, betweeness centrality can be used
# more the bc, means it is near to bridge and so it can be anomaly
# now may be the score we use can be 1/bc (since more bc , more it is a bride, so more anomaly, less score)
#BC Implementation-
try:
	total=1895575051 
	e=1635737160
	all_edges=spark.read.parquet(all_edges_path)
	cc_path_tube_nontube=path+"/connected_component_tube_nontube"
	cc_final=spark.read.parquet(cc_path_tube_nontube)
	# cc_final.groupby('component').count().filter(F.col('count')>900).count()
	final_edges_to_apply_cc=spark.read.parquet(path+"/final_edges_to_apply_cc")
	max_comp_intermediate_edges=cc_final.join(final_edges_to_apply_cc, [cc_final.id == final_edges_to_apply_cc.src]).drop("id")
	max_comp_intermediate_edges=max_comp_intermediate_edges.withColumnRenamed("component","src_component")
	max_comp_intermediate_edges.join(cc_final , [cc_final.id == max_comp_intermediate_edges.dst]).drop("id").withColumnRenamed("component","dst_component").write.mode("overwrite").parquet(path+"cc_merged_with_edges")
	cc_with_edges=spark.read.parquet(path+"cc_merged_with_edges")
	edge_count=cc_with_edges.count()
	print(edge_count==total)
	# True
	trav_edges_cc=cc_with_edges.filter(F.col('src_component')==F.col('dst_component')).drop('dst_component').withColumnRenamed('src_component','component')
	# 1895575051
	df=trav_edges_cc.groupby('component').agg( F.collect_list( F.struct(F.col('src'),F.col('dst'))).alias('edges'))
	# 131,008,530  
	cc_counts=cc_final.groupby('component').count()
	cc_counts.filter(F.col('count')==).show()
	#DF WITH COMPONENT-EDGE_LIST
	# def getcount(x):
	# 	return x['component'],len(x['edges'])
	# cdf=df.rdd.map(lambda x:getcount(x)).toDF(['comp','count'])
	# cdf.select('count').groupBy().sum().collect()
	# # 109776 - sum of counts
	# cdf=cdf.withColumnRenamed('count','countcdf')
	# test=cdf.join(interm,interm.component==cdf.comp).drop('comp')
	# #2657 
	# test.filter(F.col('countcdf')!=F.col('count')).count()
	def bc_edge(x):
		edges=list(map(lambda x:tuple(x),x['edges']))
		graph_nx=nx.from_edgelist(edges)
		edge_bcs=nx.edge_betweenness_centrality(graph_nx)
		return x['component'],edge_bcs
	print("bcedge start")
	df.rdd.map(lambda x: bc_edge(x)).toDF([ "component","edges_with_bcs"]).write.mode('overwrite').parquet(path+'edgesbcs_interm')
	interm=spark.read.parquet(path+'edgesbcs_interm')
	# 71,627,947
	interm_=interm.select("component",F.explode("edges_with_bcs"))
	interm_.select('component','key.*','value').withColumnRenamed('_1','src').withColumnRenamed('_2','dst').withColumnRenamed('value','edge_bc').write.mode('overwrite').parquet(path+'edges_with_edgebcs_')
	x=spark.read.parquet(path+'edges_with_edgebcs_')
	# 1567961170 incorrect one, the final edgebc code is in other code and the path is also different 
	x=spark.read.parquet(path+'all_edges_with_their_edgebcs')
	edge_bcs_count=x.count()
	print(edge_bcs_count,total)
	# 1652636450 1895575051  coz it counted all undirected edges only and in the dataset there are b0th a-b and b-a edges
	# now use the dp_edgeonly df here 
try:
	x=x.withColumnRenamed('src','src_').withColumnRenamed('dst','dst_')
	dp_only=spark.read.parquet(path+'only_me_edges_dpids')
	dp_edgeonly=dp_only.select('src','dst','dpid').distinct()
	curr=dp_edgeonly.join(x,[x.src_==dp_edgeonly.src,x.dst_==dp_edgeonly.dst]).drop('src_','dst_')
	#    remaining are revrse direction edges
	curr=curr.union(dp_edgeonly.join(x,[x.dst_==dp_edgeonly.src,x.src_==dp_edgeonly.dst]).drop('src_','dst_'))
	curr.write.mode('overwrite').parquet(path+'aone_edges_with_edgebc')
	aloneedges=spark.read.parquet(path+'aone_edges_with_edgebc')
	alone_dp_count=aloneedges.count()
	print(alone_dp_count==e)
	#False-> the 311 edges are intraversible ones (cluster-cluster) 
	GIVE BC VALUE FOR ALL THESE INTRAV EDGES AS dA.dB/(dA+dB)**2 
	FINAL BC VALUE IS IF 4 EDGES BETWEEN 2 CLUSTERS, THOSE 4 WILL SCALED DOWN BY 4
	aloneedges=aloneedges.withColumn('edge_score',1/F.col('edge_bc'))
	#scale the score between 0 -1
	def scalecolumn(df,col):
		from pyspark.ml.feature import MinMaxScaler
		from pyspark.ml.feature import VectorAssembler
		from pyspark.ml import Pipeline
		from pyspark.sql.functions import udf
		from pyspark.sql.types import DoubleType
		# UDF for converting column type from vector to double type
		unlist = udf(lambda x: round(float(list(x)[0]),3), DoubleType())
		assembler = VectorAssembler(inputCols=[col],outputCol=col+"_Vect")
		# MinMaxScaler Transformation
		scaler = MinMaxScaler(inputCol=col+"_Vect", outputCol=col+"_Scaled")
		# Pipeline of VectorAssembler and MinMaxScaler
		pipeline = Pipeline(stages=[assembler, scaler])
		# Fitting pipeline on dataframe
		returndf= pipeline.fit(df).transform(df).withColumn(col+"_Scaled", unlist(col+"_Scaled")).drop(col+"_Vect")
		return returndf
	dpid_with_edgescore=aloneedges.groupby('dpid').agg(F.avg(F.col('edge_score')).alias('avg_edgescore'))
	#now get avg edge_score for a dpid 
	dumm=scalecolumn(dpid_with_edgescore,'avg_edgescore')
	dumm.write.mode('overwrite').parquet(path+'dpid_with_avg_edgescore_scaled')
	dpids_edgescore=spark.read.parquet(path+'dpid_with_avg_edgescore_scaled')
	dpids_edgescore=dpids_edgescore.collect()
	#DEFINE DP_SCORE_ALONESS 
	for dp,_,score in dpids_edgescore:
		dp_score_aloness[dp]=score*float(dp_score_aloness[str(dp)])
except Exception as e:
	print("No",e)
# {'979': 0.00059986965, '87': 0.00032430253999999996, '1314': 0.0, '372': 0.0, '18': 0.0, '75': 0.0, '120': 1.729486e-05, '1271': 0.0, '525': 0.0, '118': 0.0, '335': 3.547248e-05, '1316': 0.0, '1302': 0.0, '1148': 0.0, '135': 2.34e-08, '1129': 0.0, '33': 0.0, '648': 0.000544257, '24': 0.0, '806': 0.0, '395': 1.269545e-05, '63': 0.0, '331': 1.4176e-07, '1249': 0.0, '637': 1.081e-08, '1292': 0.00014051814, '1480': 0.0, '529': 3.419024e-05, '800': 0.0, '1361': 0.00087069684, '307': 8.386399999999999e-07, '685': 0.0, '556': 0.0, '1076': 0.0, '667': 8.345545e-05, '876': 0.00014512835999999998, '1257': 9.076419e-05, '329': 0.0, '1147': 6.64259e-06, '229': 1.13667e-06, '1396': 0.0336943386, '338': 0.0, '963': 0.0, '1077': 0.0, '86': 0.0, '654': 8.589700000000001e-07, '239': 0.0, '346': 0.0, '1085': 0.0, '105': 1.2348e-06, '516': 0.0, '1415': 0.0, '12': 0.0, '21': 0.0, '611': 4.99e-06, '820': 3.939216e-05, '625': 9.140000000000001e-09, '521': 0.0, '1429': 0.0, '59': 0.00035706059999999996, '1252': 0.0, '808': 0.0, '634': 0.0, '807': 0.0, '1141': 0.0010542528, '27': 0.0, '620': 0.0, '799': 1.7756999999999997e-07, '678': 8.791699e-05, '1110': 5.965500000000001e-06, '404': 1.8022e-07, '738': 0.004268902, '95': 3.904e-08, '376': 0.0, '233': 6.33e-09, '416': 0.0, '1332': 0.0, '336': 0.0, '314': 7.650027000000001e-05, '1258': 0.00049302016, '575': 0.0, '871': 0.00012472417, '810': 0.0, '598': 8.73306e-06, '809': 0.0, '370': 0.0, '1380': 8.811180000000002e-06, '1222': 1.4913e-05, '522': 0.0}

JENKS NATURAL BREAK ALGO 


#do the same for ids
# how many of new ids only this dp has seen 
try:
	edges_tube=spark.read.parquet(edges_path_tube)
	edges_nontube =spark.read.parquet(edges_path_nontube_req)
	dp_tube=edges_tube.select('dpid','vertex1','vertex1type').distinct().union(edges_tube.select('dpid','vertex2','vertex2type').distinct())
	dp_nontube=edges_nontube.select('dpid','vertex1','vertex1type').distinct().union(edges_nontube.select('dpid','vertex2','vertex2type').distinct())
	dp_tube.union(dp_nontube).distinct().write.mode('overwrite').parquet(path+"dpids_with_its_vertices")
	dp_vertices=spark.read.parquet(path+'dpids_with_its_vertices')
	#now join with long mapped ids 
	long_mapped_ids=spark.read.parquet(long_mapped_ids_path)
	all_dps=dp_vertices.select('dpid').distinct().count()
	# 95 no.of dps
	multiple_count=dp_vertices.count()
	#3502526054 the count of all vertices seen by dps( more than actual count coz one vertex can be seen by more than one dp) 
	dp_vertices.join(long_mapped_ids,[long_mapped_ids.id==dp_vertices.vertex1,long_mapped_ids.type==dp_vertices.vertex1type]).drop('vertex1','vertex1type').write.mode('overwrite').parquet(path+'dpids_with_its_vertices_long_mapped')
	dp_ids=spark.read.parquet(path+'dpids_with_its_vertices_long_mapped')
	dp_longs=dp_ids.select('dpid','long_id')
	all_vertices=spark.read.parquet(all_vertices_path)
	allvs=all_vertices.count()
	# 1164707461
	# DataFrame[id: bigint]
	dp_longs.join(all_vertices,all_vertices.id==dp_longs.long_id).drop('id').write.mode('overwrite').parquet(path+'dpids_with_its_final_vertices')
	dp_reqids=spark.read.parquet(path+'dpids_with_its_final_vertices')
	dpidvs=dp_reqids.count()
	# 1803322559
	distinctids=dp_reqids.select('long_id').distinct().count()
	print(allvs==distinctids)
	#True
	#now grp by wrto id 
	alone_ids=dp_reqids.groupby('long_id').count().distinct().filter(F.col('count')==1)
	alone_ids=alone_ids.withColumnRenamed('long_id','long_id_').drop('count')
	alones=alone_ids.count()
	print(alones<=allvs)
	# 849422201
	alone_ids.join(dp_reqids,dp_reqids.long_id==alone_ids.long_id_).drop('long_id_').write.mode('overwrite').parquet(path+'only_me_ids_dpids')
	aloneid_dps=spark.read.parquet(path+'only_me_ids_dpids')
	print(aloneid_dps.count()==alones)
	#true
	alone_dps=aloneid_dps.select('dpid').distinct().collect()
	alone_dps=list(map(lambda x:x[0],alone_dps))
	print(len(alone_dps))
	# 88
	dpidscore_aloness=defaultdict(int)
	total_ids=dp_reqids.select('long_id').distinct().count()
	#1164707461
	#coz based on above scaling logic, 
	for dp in alone_dps:
		alone_count=aloneid_dps.filter(F.col('dpid')==dp).distinct().count()
		print(alone_count,total_ids)
		dpidscore_aloness[dp]="{:.8f}".format(float( ( alone_count/total_ids )))
except Exception as e:
	print("No",e)

 # {'979': '0.00852718', '87': '0.19840155', '1314': '0.00001012', '372': '0.00001094', '18': '0.00000001', '75': '0.00000004', '120': '0.00155993', '1271': '0.00000015', '525': '0.00000492', '118': '0.00000013', '335': '0.00079112', '1316': '0.00000001', '1302': '0.00000001', '1148': '0.00000952', '135': '0.00000487', '1129': '0.00000000', '33': '0.00000047', '648': '0.02108851', '24': '0.00000001', '806': '0.00000017', '395': '0.02051429', '63': '0.00000106', '331': '0.00003924', '1249': '0.00000000', '637': '0.00001621', '1292': '0.00760343', '1480': '0.00000012', '529': '0.00058680', '800': '0.00001055', '1361': '0.02728432', '307': '0.00007805', '685': '0.00000129', '556': '0.00000015', '1076': '0.00000022', '667': '0.00136518', '876': '0.00043756', '1257': '0.00279836', '329': '0.00000001', '1147': '0.00040223', '229': '0.00203227', '1396': '0.06892960', '338': '0.00000206', '963': '0.00000870', '1077': '0.00000000', '86': '0.00000389', '654': '0.00001897', '239': '0.00000007', '346': '0.00000060', '1085': '0.00248169', '105': '0.00003598', '516': '0.00000175', '1415': '0.00000009', '12': '0.00000133', '21': '0.00033191', '611': '0.00000563', '820': '0.00159611', '625': '0.00001487', '521': '0.00000032', '1429': '0.00000000', '59': '0.02706826', '1252': '0.00000318', '808': '0.00000313', '634': '0.00000793', '807': '0.00000020', '1141': '0.02193482', '27': '0.00000002', '620': '0.00000230', '799': '0.00002534', '678': '0.01586441', '1110': '0.00054655', '404': '0.00021345', '738': '0.27713183', '95': '0.00002250', '376': '0.00000002', '233': '0.00000700', '416': '0.00000012', '1332': '0.00000610', '336': '0.00000006', '314': '0.00124341', '1258': '0.01134487', '575': '0.00000065', '871': '0.00591242', '598': '0.00012760', '809': '0.00000048', '370': '0.00000052', '1380': '0.00015588', '1222': '0.00066323', '522': '0.00000001'}
   # now same as before, the ids have to scored based on anaomaly



+-------+-------------------+-----------------+                                 
|summary|          component|            count|
+-------+-------------------+-----------------+
|  count|          131008530|        131008530|
|   mean|4.952963530763093E8|8.890317760225232|
| stddev|5.173111584289163E8|81.55838930265556|
|    min|                  0|                2|
|    25%|          106059616|                2|
|    50%|          303760146|                5|
|    75%|          723867160|               11|
|    max|         2690006301|           904814|
+-------+-------------------+-----------------+



# so node bc can be used in a similar way 
try:
	cc_with_edges=spark.read.parquet(path+"cc_merged_with_edges")
	trav_edges_cc=cc_with_edges.filter(F.col('src_component')==F.col('dst_component')).drop('dst_component').withColumnRenamed('src_component','component')
	df=trav_edges_cc.groupby('component').agg( F.collect_list( F.struct(F.col('src'),F.col('dst'))).alias('edges')).filter(F.col('component')!=515).write.mode('overwrite').parquet(path+'/intermdf')
	df=spark.read.parquet(path+'/intermdf')
	print("star")
	def custom_bc_node(x,k):
		edges=list(map(lambda x:tuple(x),x['edges']))
		graph_nx=nx.from_edgelist(edges)
		node_bcs=betweenness_centrality(graph_nx,k)
		return x['component'],node_bcs
	print("node_bc start")
	k=5000
	interm=df.rdd.map(lambda x: custom_bc_node(x,k)).toDF([ "component","nodes_with_bcs"])
	print("ghere")
	interm_=interm.select("component",F.explode("nodes_with_bcs"))
	interm_.withColumnRenamed('key','id').withColumnRenamed('value','node_bc').write.mode('overwrite').parquet(path+'nodes_with_nodebcs-except_515comp')
	nodebcs=spark.read.parquet(path+'nodes_with_nodebcs-except_515comp')
	#1155877975 
	#check 
	c=trav_edges_cc.filter(F.col('component')!=515).select('src').union(trav_edges_cc.filter(F.col('component')!=515).select('dst').withColumnRenamed('dst','src')).distinct().count()
	# 1163802647
	totalcomps=trav_edges_cc.filter(F.col('component')!=515).select('component').distinct()
	comps=nodebcs.select('component').distinct()
	subcomps=totalcomps.subtract(comps)
	cc_counts=spark.read.parquet(path+'/final_ccs_counts')
	subcomps=subcomps.withColumnRenamed('component','component_')
	x=subcomps.join(cc_counts,cc_counts.component==subcomps.component_).drop('component_')
	def sum_col(df, col):
    	return df.select(F.sum(col)).collect()[0][0]
    print(sum_col(x,'count')) #- match
    df=spark.read.parquet(path+'/intermdf')
    df_=df.join(subcomps,subcomps.component_==df.component).drop('component_')
    # 873678  
    df_.write.mode('overwrite').parquet(path+'/interimdf')
    df_=spark.read.parquet(path+'/interimdf')
    k=2000
    df_.rdd.map(lambda x: custom_bc_node(x,k)).toDF([ "component","nodes_with_bcs"]).write.mode('overwrite').parquet(path+'nodebcs_interm1')
    interm=spark.read.parquet(path+'nodebcs_interm1')
	interm_=interm.select("component",F.explode("nodes_with_bcs"))
	interm_.withColumnRenamed('key','id').withColumnRenamed('value','node_bc').write.mode('overwrite').parquet(path+'nodes_with_nodebcs2-except_515comp')
	nodebcs=spark.read.parquet(path+'nodes_with_nodebcs2-except_515comp')
	#match 
	#final nodebcs 
	nodebcs2=spark.read.parquet(path+'nodes_with_nodebcs-except_515comp')
	nodebcs.union(nodebcs2).distinct().write.mode('overwrite').parquet(path+'nodewithbcs_except515comp')
	nodebcs=spark.read.parquet(path+'nodewithbcs_except515comp')
	# 1163802647  
	# as excpected
	final_df_edges=spark.read.parquet(path+'comp515_final_communites_with_edges') #is done above in edgebc implementation purpose 
	# 1770144 
	final_df_edges.select('src').union(final_df_edges.select('dst')).distinct().count()
	 # 904814
	df=final_df_edges.groupby('component').agg( F.collect_list( F.struct(F.col('src'),F.col('dst'))).alias('edges'))
	#76
	k=10000
	df.rdd.map(lambda x: custom_bc_node(x,k)).toDF([ "component","nodes_with_bcs"]).write.mode('overwrite').parquet(path+'comp515_nodebcs')
	interm=spark.read.parquet(path+'comp515_nodebcs') # written for italy
	#75
	sub=df.join(interm,on=['component'],how='left_anti') #as expected comp1310, the biggest(92657 was leftout)
	sub.rdd.map(lambda x: custom_bc_node(x,k)).toDF([ "component","nodes_with_bcs"]).write.mode('overwrite').parquet(path+'comp515_nodebcs_2')
	interm_=interm.select("component",F.explode("nodes_with_bcs"))
	interm_.withColumnRenamed('key','id').withColumnRenamed('value','node_bc').write.mode('overwrite').parquet(path+'nodes_with_nodebcs-515comp')
	nodebcs_515=spark.read.parquet(path+'nodes_with_nodebcs-515comp')
except:
	print(2)


	nodebcs=nodebcs_515.union(spark.read.parquet(path+'nodewithbcs_except515comp'))
	nodebcs.write.mode('overwrite').parquet(path+'nodes_withbcs_allnodes')
	nodebcs=spark.read.parquet(path+'nodes_withbcs_allnodes')
	distinctids=1164707461
	print(nodebcs.count()==distinctids)
	# 
try:
	aloneid_dps=spark.read.parquet(path+'only_me_ids_dpids')
	curr=aloneid_dps.join(nodebcs,nodebcs.id==aloneid_dps.long_id).drop('long_id')
	curr.write.mode('overwrite').parquet(path+'alone_ids_with_nodebc')
	curr=spark.read.parquet(path+'alone_ids_with_nodebc')
	node_scores=curr.withColumn('node_score',1/F.col('node_bc'))
	# dpid_with_nodescore.select('avg_nodescore').withColumn('isNull_node_bc',F.col('avg_nodescore').isNull()).where('isNull_node_bc = True').count()
	#scale the score between 0 -1
	def scalecolumn(df,col):
		from pyspark.ml.feature import MinMaxScaler
		from pyspark.ml.feature import VectorAssembler
		from pyspark.ml import Pipeline
		from pyspark.sql.functions import udf
		from pyspark.sql.types import DoubleType
		# UDF for converting column type from vector to double type
		unlist = udf(lambda x: round(float(list(x)[0]),3), DoubleType())
		assembler = VectorAssembler(inputCols=[col],outputCol=col+"_Vect")
		# MinMaxScaler Transformation
		scaler = MinMaxScaler(inputCol=col+"_Vect", outputCol=col+"_Scaled")
		# Pipeline of VectorAssembler and MinMaxScaler
		pipeline = Pipeline(stages=[assembler, scaler])
		# Fitting pipeline on dataframe
		returndf= pipeline.fit(df).transform(df).withColumn(col+"_Scaled", unlist(col+"_Scaled")).drop(col+"_Vect")
		return returndf
	dpid_with_nodescore=node_scores.groupby('dpid').agg(F.avg(F.col('node_score')).alias('avg_nodescore'))
	#now get avg node_score for a dpid 
	dpid_with_nodescore=dpid_with_nodescore.fillna({'avg_nodescore':1})
	dum=scalecolumn(dpid_with_nodescore,'avg_nodescore')
	dum.write.mode('overwrite').parquet(path+'dpid_with_avg_nodescore_scaled')
	dum=spark.read.parquet(path+'dpid_with_avg_nodescore_scaled')
	dpids_nodescore=dum.collect()
	for dp,_,score in dpids_nodescore:
		dpidscore_aloness[dp]=score*float(dpidscore_aloness[str(dp)])
# 
except Exception as e:
	print("No",e)

{'979': 8.52718e-05, '87': 0.03591068055, '1314': 1.30548e-06, '372': 1.1487e-06, '18': 0.0, '75': 8.000000000000001e-11, '120': 0.0001715923, '1271': 0.0, '525': 1.6236e-07, '118': 0.0, '335': 6.961856e-05, '1316': 0.0, '1302': 0.0, '1148': 1.15192e-06, '135': 3.896e-08, '1129': 0.0, '33': 0.0, '648': 0.00626328747, '24': 0.0, '806': 0.0, '395': 0.0018462861, '63': 0.0, '331': 4.630319999999999e-06, '1249': 0.0, '637': 8.105e-08, '1292': 0.006113157720000001, '1480': 0.0, '529': 1.7604e-06, '800': 2.1205500000000004e-06, '1361': 0.00256472608, '307': 4.29275e-06, '685': 2.5799999999999998e-09, '556': 0.0, '1076': 0.0, '667': 3.139914e-05, '876': 1.31268e-06, '1257': 0.00032181140000000005, '329': 0.0, '1147': 3.740739e-05, '229': 8.535534000000001e-05, '1396': 0.0336376448, '338': 0.0, '963': 1.6529999999999998e-07, '1077': 0.0, '86': 8.5191e-07, '654': 1.47966e-06, '239': 0.0, '346': 0.0, '1085': 3.2261969999999995e-05, '105': 3.9577999999999996e-07, '516': 1.295e-07, '1415': 0.0, '12': 1.3034000000000001e-07, '21': 9.9573e-07, '611': 0.0, '820': 0.00014205379, '625': 1.9331e-07, '521': 2.0480000000000002e-08, '1429': 0.0, '59': 0.0022195973200000003, '1252': 2.2260000000000002e-08, '808': 0.0, '634': 7.93e-09, '807': 0.0, '1141': 0.0071068816800000005, '27': 0.0, '620': 0.0, '799': 3.2942e-07, '678': 0.00012691528, '1110': 0.00054655, '404': 5.76315e-06, '738': 0.01053100954, '95': 2.3175e-06, '376': 0.0, '233': 7e-09, '416': 0.0, '1332': 1.22e-08, '336': 0.0, '314': 1.3677509999999998e-05, '1258': 0.00024958714, '575': 6.5e-10, '871': 0.00041978181999999996, '598': 2.47544e-05, '809': 0.0, '370': 0.0, '1380': 3.1176000000000003e-07, '1222': 0.00010014773, '522': 0.0}



for bcedge of big COMPs - 
break it into communityies nd we get bc of inside community ND FOR inter community edges , the bc= m*n / (m+n)**2 -> m,n are the size of the clusters




#DPCOVER CODE
try:
	edges_tube=spark.read.parquet(edges_path_tube)
	edges_nontube =spark.read.parquet(edges_path_nontube_req)
	# DataFrame[vertex1: string, vertex1type: string, vertex2: string, vertex2type: string, dpid: int, timestamp: bigint, recordType: string]
	dp_tube=edges_tube.select('dpid','vertex1','vertex1type').distinct().union(edges_tube.select('dpid','vertex2','vertex2type').distinct())
	dp_nontube=edges_nontube.select('dpid','vertex1','vertex1type').distinct().union(edges_nontube.select('dpid','vertex2','vertex2type').distinct())
	# dp_tube.union(dp_nontube).distinct().write.mode('overwrite').parquet(path+"dpids_with_its_vertices")
	dp_vertices=spark.read.parquet(path+'dpids_with_its_vertices')
	# #now join with long mapped ids 
	long_mapped_ids=spark.read.parquet(long_mapped_ids_path)
	multiple_count=dp_vertices.count()
	# # 3502526054 the count of all vertices seen by dps( more than actual count coz one vertex can be seen by more than one dp) 
	# dp_vertices.join(long_mapped_ids,[long_mapped_ids.id==dp_vertices.vertex1,long_mapped_ids.type==dp_vertices.vertex1type]).drop('vertex1','vertex1type').write.mode('overwrite').parquet(path+'dpids_with_its_vertices_long_mapped')
	dp_ids=spark.read.parquet(path+'dpids_with_its_vertices_long_mapped')
	dp_longs=dp_ids.select('dpid','long_id')
	all_vertices=spark.read.parquet(all_vertices_path)
	allvs=all_vertices.count()
	# # 1164707461
	# # DataFrame[id: bigint]
	# dp_longs.join(all_vertices,all_vertices.id==dp_longs.long_id).drop('id').write.mode('overwrite').parquet(path+'dpids_with_its_final_vertices')
	dp_reqids=spark.read.parquet(path+'dpids_with_its_final_vertices')
	#ALL THE ABOVE PATHS ARE WRITTEN IN DP_IND_FEATURES
	#this df contains dpid and only those ids which are present in final all vertices 
	reqdps=dp_reqids.select('dpid').distinct().count()
	# 92 so out of all only those dps have seen ids which are present in final vertices 
	# THE REMAINING DPS WILL BE GIVEN A NEGATIVE SCORE OF -1 
	reqvs=dp_reqids.count()
	print(reqvs>=allvs)
	# 1803322559 (coz an id can be seen by multiple dps)
	print(allvs==dp_reqids.select('long_id').distinct().count())
	# True  as expected
	#NOW DO THE STEP 1 
	#COLLECT ALL DPIDS 
	dps=dp_longs.select('dpid').distinct().collect()
	dp_score1=defaultdict(int)
	total=0
	usefuls=0
	for i in dps:
		curr_dp=i[0]
		total_seen_ids=dp_longs.filter(F.col('dpid')==curr_dp).select('long_id').distinct().count()
		useful_ids=dp_reqids.filter(F.col('dpid')==curr_dp).select('long_id').distinct().count()
		dp_score1[curr_dp]=useful_ids/total_seen_ids
		usefuls+=useful_ids
		total+=total_seen_ids  
	print(total==multiple_count)
	print(usefuls==reqvs)
	# True, True
	# total=(total ids+multiple dps=dp_longs.distinct().count())
	# usefuls= (total req ids+multiple dps=dp_reqids.count())
	for i in dp_score1.keys():
		dp_score1[i]="{:.8f}".format(float((dp_score1[i])))
	print("inital score is done")
	#REPEAT THE SAMETHING FOR EDGES ALSO
	#THE EDGES DFS RE ALREADY WRITTEN IN below CODE
	# {'979': '0.47618764', '87': '0.27902302', '1314': '0.53156606', '372': '0.14964249', '18': '0.45977011', '75': '0.11669226', '120': '0.60524892', '1271': '0.59082094', '525': '1.00000000', '118': '0.20672910', '335': '0.60991359', '1316': '0.29629630', '1302': '0.14743590', '1148': '0.44955502', '135': '0.70664403', '1129': '0.26829268', '1146': '1.00000000', '33': '0.17360199', '648': '0.42465729', '24': '0.15384615', '806': '0.54743083', '395': '0.41872278', '63': '0.58427383', '331': '0.56916241', '1249': '0.10526316', '637': '0.54851439', '1292': '0.53503503', '1480': '0.35663754', '529': '0.64262004', '800': '0.99832435', '1361': '0.59918729', '307': '0.55814027', '685': '0.48047711', '556': '0.27368866', '1076': '0.29617136', '667': '0.99932634', '876': '0.83162397', '1257': '0.65776403', '329': '0.18550107', '1147': '0.51018523', '229': '1.00000000', '1396': '0.98699671', '338': '0.49055676', '963': '0.47717773', '1077': '0.32000000', '86': '0.65230251', '654': '0.34027209', '239': '0.30586788', '346': '0.42080153', '1085': '0.70371322', '105': '0.48268633', '516': '0.35857498', '1415': '0.26398779', '784': '0.00000000', '12': '0.46876351', '21': '1.00000000', '611': '0.47549616', '820': '1.00000000', '521': '0.21815934', '625': '0.46046518', '29': '0.09917355', '1429': '0.32608696', '59': '0.34007180', '1252': '0.34802548', '808': '0.58145513', '634': '1.00000000', '807': '0.47980027', '1141': '0.65978603', '27': '0.30223881', '374': '0.00000000', '620': '0.30571562', '799': '0.23135035', '678': '0.98305651', '1110': '0.87091949', '404': '1.00000000', '738': '0.99227823', '95': '0.39412330', '376': '0.69811321', '233': '0.50625219', '416': '0.21690922', '1332': '1.00000000', '336': '0.51983299', '314': '0.40303777', '1258': '0.43023836', '575': '0.56370192', '871': '0.54416436', '810': '0.14864865', '809': '0.16410202', '598': '0.55239752', '1055': '0.34482759', '370': '0.62233629', '1380': '0.61332237', '1222': '0.99999418', '45': '0.00000000', '522': '1.00000000'}
	# so, now all dps are given a positive score based on above dict values if value>0, if value=0 then a negative score of -0.5 can be given 
	dps=dp_reqids.select('dpid').distinct().collect()
	dps=list(map(lambda x:x[0],dps))
	print(len(dps)==reqdps)
except Exception as error:
	print(error)
	#92 (lendps)
	#the brute force NP solution for set cover is not possible to implemet
	#the number 28 was for belgiu only
	#28 dps 2^28 subsets for each subsets, there are dpids inside the subsets and for those dpids, filter and count union areperformed on dfs
	#so, follow greedy approximate algorithm
	#initally included elements=I
	#keep adding subsets to it, and at any point the subset u pich should have max [SI-I] value, i.e max no.of new elements it ha to give
try:
	print('dp cover starts')
	dp_reqids=spark.read.parquet(path+'dpids_with_its_final_vertices')
	dps=dp_reqids.select('dpid').distinct().collect()
	dps=list(map(lambda x:x[0],dps))
	schema = StructType([
	  StructField('long_id', LongType(), False),
	  ])
	included_ids=spark.sparkContext.parallelize([]).toDF(schema)
	n=len(dps)
	threshold=0.97
	all_vertices=spark.read.parquet(all_vertices_path)
	total_cover=all_vertices.count()
	seendpids={'59', '678', '648', '1361', '738', '395', '87', '1258', '1141', '1396'}
	for i in seendpids:
		included_ids=included_ids.union(dp_reqids.filter(F.col('dpid')==i).select('long_id').distinct()).distinct()
	print("total_cover is ",total_cover,threshold*total_cover)
	# total_cover is  1164707461 1129766237.17 
	while(included_ids.count()<threshold*total_cover):
		maxval=0
		maxdpid=-1
		for ind,dpid in enumerate(dps):
			if(dpid in seendpids):
				continue
			curr_ids=dp_reqids.filter(F.col('dpid')==dpid).select('long_id').distinct()
			diff=curr_ids.subtract(included_ids).distinct()
			curr_count=diff.count()
			if(curr_count>maxval):
					maxval=curr_count
					maxdpid=dpid
			print("here",ind)
		if(maxdpid==-1):
			print("ERRORRRR!!!!")
			break
		print(included_ids.count(),maxdpid,seendpids,maxval)
		included_ids=included_ids.union(dp_reqids.filter(F.col('dpid')==maxdpid).select('long_id').distinct()).distinct()
		seendpids.add(maxdpid)
		print("UPDATED",ind,included_ids.count())
		print(seendpids)
	dp_score_cover=defaultdict(int)
	#now score -
	for i in seendpids:
		dp_score_cover[i]= "{:.8f}".format(float( ( dp_reqids.filter(F.col('dpid')==i).distinct().count() / total_cover )))
	print(dp_score_cover)
except Exception as e:
	print("No",e)
	
UPDATED 909563466                                                               
{'738', '1361', '1396', '87'}
UPDATED 971777089                                                               
{'1361', '738', '87', '59', '1396'}
UPDATED 1010263849                                                              
{'648', '1361', '738', '87', '59', '1396'}
UPDATED 1041071179                                                              
{'648', '1361', '738', '87', '59', '1141', '1396'}
UPDATED 1065311719
{'648', '1361', '738', '87', '1258', '59', '1141', '1396'}
UPDATED 1089209483                                                              
{'59', '648', '1361', '738', '395', '87', '1258', '1141', '1396'}
UPDATED 1108623151                                                              
{'59', '678', '648', '1361', '738', '395', '87', '1258', '1141', '1396'}

{'678': '0.05380161', '648': '0.09463086', '1361': '0.11597027', '738': '0.41417970', '395': '0.03699461', '87': '0.24909892', '1258': '0.09298074', '59': '0.11133325', '1141': '0.05702463', '1396': '0.09490490'}
	
	#The scoring shouldnt be in other of how the greedy algo chose the dpids
	# coz say a dpid1 has 99% data and other dpid2 has 99.1% , so dpid2 will be chosen with score 99.1 and the other dpid will then be scored only 0.1 around
	# so 
	# now again, the dps in seendpids are scored based on count of how much they seen/total count and other remaining are not given any score(not even a negative score)
	# since this score is very crucial may be it neeed to be scaled up by alpha 
	# alpha=1.5


try:
	dp_longedges= spark.read.parquet(path+"dp_edges_mapped_to_long")
	#  (along with timestamps and multiple dpids) 
	all_edges=spark.read.parquet(all_edges_path)	
	e=all_edges.count()
	# # 1895575051
	# DataFrame[id: bigint]
	dp_req_edges=spark.read.parquet(path+'dp_req_edges_with_longs').select('dpid','src','dst').distinct()		
	req_edgescount=dp_req_edges.count()
	print(req_edgescount>=e)
	# 2278808488 since an edge is seen by multiple dps
	#NOW DO THE STEP 1 
	#COLLECT ALL DPIDS 
	dps=dp_longedges.select('dpid').distinct().collect()
	dp_score_edges=defaultdict(int)
	total=0
	usefuls=0
	for i in dps:
		curr_dp=i[0]
		total_seen_edges=dp_longedges.filter(F.col('dpid')==curr_dp).select('src_long_id','dst_long_id').distinct().count()
		useful_edges=dp_req_edges.filter(F.col('dpid')==curr_dp).select('src','dst').distinct().count()
		print(curr_dp,useful_edges,total_seen_edges)
		dp_score_edges[curr_dp]="{:.8f}".format(float((useful_edges/total_seen_edges)))
		usefuls+=useful_edges
		total+=total_seen_edges  
	print(total==dp_longedges.select('dpid','src_long_id','dst_long_id').distinct().count(),total)
	# True 3472276068 
	print(usefuls==req_edgescount)
	# True 2278808488
	print("hey",dp_score_edges)
	# {'307': '0.57437294', '1314': '0.56883790', '876': '0.83171095', '1147': '0.52608598', '678': '0.98143928', '233': '0.53857400', '1146': '1.00000000', '63': '0.58653120', '598': '0.56108526', '1222': '0.99999739', '820': '1.00000000', '556': '0.27357176', '1141': '0.79179570', '667': '0.99955982', '525': '1.00000000', '329': '0.19277108', '1396': '0.99609270', '86': '0.66378127', '1332': '1.00000000', '346': '0.43707796', '575': '0.57750279', '809': '0.16850862', '529': '0.65234123', '45': '0.00000000', '522': '1.00000000', '120': '0.63596680', '335': '0.62731046', '963': '0.49958922', '1085': '0.69985022', '871': '0.57383678', '784': '0.00000000', '810': '0.15873016', '521': '0.22882916', '808': '0.63433531', '807': '0.49202265', '1110': '0.89990169', '516': '0.36825603', '1415': '0.29199756', '21': '1.00000000', '1292': '0.56938620', '1480': '0.35566774', '1055': '0.32000000', '611': '0.47964507', '625': '0.43103240', '59': '0.43490275', '799': '0.22858996', '1302': '0.15107914', '1148': '0.50098410', '95': '0.41121747', '648': '0.49212861', '395': '0.41618674', '331': '0.58058947', '1429': '0.32500000', '372': '0.22147420', '18': '0.46153846', '27': '0.30508475', '75': '0.12364425', '118': '0.28844057', '33': '0.19773276', '239': '0.29811819', '314': '0.40434541', '1258': '0.48769693', '1249': '0.06896552', '1361': '0.60453684', '979': '0.53898361', '29': '0.10377358', '1257': '0.68511850', '1271': '0.61837192', '135': '0.70680987', '806': '0.58468677', '105': '0.52733430', '1380': '0.62120089', '800': '0.99896418', '685': '0.48690622', '87': '0.38570413', '404': '1.00000000', '1316': '0.35802469', '738': '0.99728338', '338': '0.53760881', '416': '0.22807018', '1129': '0.25000000', '654': '0.35124690', '336': '0.53438557', '24': '0.16666667', '634': '1.00000000', '1076': '0.30708661', '374': '0.00000000', '1077': '0.35643564', '637': '0.54870811', '370': '0.62219906', '1252': '0.38688920', '620': '0.30896700', '229': '1.00000000', '376': '0.69791667', '12': '0.48533305'}
	dps=dp_req_edges.select('dpid').distinct().collect()
	dps=list(map(lambda x:x[0],dps))
	# ['307', '1314', '876', '678', '1147', '233', '1146', '63', '598', '1222', '820', '556', '1141', '667', '525', '329', '1396', '86', '1332', '346', '575', '809', '529', '522', '120', '335', '963', '1085', '871', '810', '521', '808', '807', '1110', '516', '1415', '21', '1292', '1480', '1055', '611', '625', '59', '799', '1302', '1148', '95', '648', '395', '331', '1429', '372', '18', '27', '75', '118', '33', '239', '314', '1258', '1249', '1361', '979', '29', '1257', '1271', '135', '806', '105', '1380', '800', '685', '87', '404', '1316', '738', '338', '416', '1129', '654', '336', '24', '634', '1076', '1077', '637', '370', '1252', '620', '229', '376', '12']
	#the brute force NP solution for set cover is not possible to implemet
	#28 dps 2^28 subsets for each subsets, there are dpids inside the subsets and for those dpids, filter and count union areperformed on dfs
	#so, follow greedy approximate algorithm
	#initally included elements=I
	#keep adding subsets to it, and at any point the subset u pich should have max [SI-I] value, i.e max no.of new elements it ha to give
except :
	print("m")

try:
	print('edge cover starts')
	all_edges=spark.read.parquet(all_edges_path)	
	dp_req_edges=spark.read.parquet(path+'dp_req_edges_with_longs').select('dpid','src','dst').distinct()		
	dps=['307', '1314', '876', '678', '1147', '233', '1146', '63', '598', '1222', '820', '556', '1141', '667', '525', '329', '1396', '86', '1332', '346', '575', '809', '529', '522', '120', '335', '963', '1085', '871', '810', '521', '808', '807', '1110', '516', '1415', '21', '1292', '1480', '1055', '611', '625', '59', '799', '1302', '1148', '95', '648', '395', '331', '1429', '372', '18', '27', '75', '118', '33', '239', '314', '1258', '1249', '1361', '979', '29', '1257', '1271', '135', '806', '105', '1380', '800', '685', '87', '404', '1316', '738', '338', '416', '1129', '654', '336', '24', '634', '1076', '1077', '637', '370', '1252', '620', '229', '376', '12']
	dp_req_edges=dp_req_edges.select('dpid','src','dst').distinct()
	schema = StructType([
	  StructField('src', LongType(), False),
	  StructField('dst', LongType(), False),
	  ])
	included_edges=spark.sparkContext.parallelize([]).toDF(schema)
	n=len(dps)
	threshold=0.97
	total_cover=all_edges.count()
	# 
	seendpids=set()
	print("total_cover is ",total_cover,threshold*total_cover)
	# total_cover is  1895575051 1838707799.47
	while(included_edges.count()<threshold*total_cover):
		maxval=0
		maxdpid=-1
		for ind,dpid in enumerate(dps):
			if(dpid in seendpids):
				continue
			curr_edges=dp_req_edges.filter(F.col('dpid')==dpid).select('src','dst').distinct()
			diff=curr_edges.subtract(included_edges).distinct()
			curr_count=diff.count()
			if(curr_count>maxval):
					maxval=curr_count
					maxdpid=dpid
			print("here",ind)
		if(maxdpid==-1):
			print("ERRORRRR!!!!")
			break
		print(included_edges.count(),maxdpid,seendpids,maxval)
		included_edges=included_edges.union(dp_req_edges.filter(F.col('dpid')==maxdpid).select('src','dst').distinct()).distinct()
		seendpids.add(maxdpid)
		print("UPDATED",included_edges.count())
		print(seendpids)
	dp_score_coveredges=defaultdict(int)
	for i in seendpids:
		dp_score_coveredges[i]= "{:.8f}".format(float( ( dp_req_edges.filter(F.col('dpid')==i).distinct().count() / total_cover )))
	print(dp_score_coveredges)
except Exception as error:
	print('No',error)

print(dp_score_coveredges)



918568957 87 {'738'} 312530315                                                  
UPDATED 1231099272      
		1838707799.47                                                        
{'738', '87'}

UPDATED 1512930441                                                              
{'738', '59', '1396', '87'}

UPDATED 1591426815                                                              
{'738', '87', '59', '1141', '1396'}


 {'738': '0.48458591', '87': '0.16499053', '59': '0.06981484', '1141': '0.05029274', '1396': '0.09944080'}
 
seendpids- 
0.99*total_cover
included_edges.count()-

0.99*total_cover
#now the scoring shouldnt be in other of how the greedy algo chose the dpids
coz say a dpid1 has 99% data and other dpid2 has 99.1% , so dpid2 will be chosen with score 99.1 and the other dpid will then be scored only 0.1 around
so 



now again, the dps in seendpids are scored based on count of how much they seen/total count and other remaining are not given any score(not even a negative score)

since this score is very crucial may be it neeed to be scaled up by alpha 
alpha=1.5





