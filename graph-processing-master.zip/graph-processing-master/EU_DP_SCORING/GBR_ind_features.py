import pyspark.sql.functions as F
from pyspark.sql.types import *
import networkx as nx
from graphframes import *
from pyspark.mllib.clustering import PowerIterationClustering, PowerIterationClusteringModel
from itertools import chain, combinations
import math
from operator import itemgetter
from collections import Counter
from collections import defaultdict
from os import sys, path
import community as community_louvain
from pyspark.sql.functions import lit

path="gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/graph/cleanup/country=UK/Prudhvi/UK_Graph_cleaning_new"
edges_path_nontube_req=path+"edges_nontube_with_askedtypes"
edges_path_nontube="gs://gcs-ireland-all-eu-daap-idu-bootstrap-internal-zeotap-com/run__20201123/zeoGraphEdges_idu_524/country=GBR"
edges_path_tube="gs://gcs-ireland-all-eu-daap-idu-bootstrap-internal-zeotap-com/run__20201123/tubeGraphEdges_idu_524/country=GBR"
total_vertices_path= path +"/total_vertices_tubeandnontube"
long_mapped_ids_path = "gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/graph/cleanup_tests/country=GBR/data/vertex_set/all_ids_with_long_mapping"
all_vertices_path="gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/graph/cleanup_tests/country=GBR/data/final_graph/tube_and_non_tube_vertices"
all_edges_path="gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/graph/cleanup_tests/country=GBR/data/final_graph/tube_and_non_tube_edges"

edges_tube=spark.read.parquet(edges_path_tube)
edges_nontube =spark.read.parquet(edges_path_nontube)
edges_nontube=edges_nontube.filter( ( (F.col('vertex1Type')=='cellphone_number_withcode_sha256') | (F.col('vertex1Type')=='cellphone_number_withoutcode_sha256') | (F.col('vertex1Type')=='email_sha256_lowercase') | (F.col('vertex1Type')=='email_sha256_uppercase') | (F.col('vertex1Type').startswith('id_mid')) ) & ( (F.col('vertex2Type')=='cellphone_number_withcode_sha256') | (F.col('vertex2Type')=='cellphone_number_withoutcode_sha256') | (F.col('vertex2Type')=='email_sha256_lowercase') | (F.col('vertex2Type')=='email_sha256_uppercase') | (F.col('vertex2Type').startswith('id_mid')) ) )
edges_nontube.write.mode('overwrite').parquet(path+'edges_nontube_with_askedtypes')


try:
	edges_tube=spark.read.parquet(edges_path_tube)
	edges_nontube =spark.read.parquet(edges_path_nontube_req)
	# DataFrame[vertex1: string, vertex1type: string, vertex2: string, vertex2type: string, dpid: int, timestamp: bigint, recordType: string]
	dp_tube=edges_tube.select('dpid','vertex1','vertex1type','vertex2','vertex2type','timestamp').distinct()
	dp_nontube=edges_nontube.select('dpid','vertex1','vertex1type','vertex2','vertex2type','timestamp').distinct()
	dp_tube.union(dp_nontube).distinct().write.mode('overwrite').parquet(path+"dpids_with_its_edges")
	dp_edges=spark.read.parquet(path+'dpids_with_its_edges')
	print(dp_edges.count(),"h1")
	# 5119994807
	#map to long
	long_mapped_ids=spark.read.parquet(long_mapped_ids_path)
	long_mapped_ids=long_mapped_ids.withColumnRenamed('string_id','id').drop('graph_type_flag')
	intermediate_edges = long_mapped_ids.join(dp_edges , [long_mapped_ids.id == dp_edges.vertex1 , long_mapped_ids.type == dp_edges.vertex1type]).drop("id","type").withColumnRenamed("long_id" , "src_long_id")
	long_mapped_ids.join(intermediate_edges , [long_mapped_ids.id == intermediate_edges.vertex2 , long_mapped_ids.type == intermediate_edges.vertex2type]).drop("id","type").withColumnRenamed("long_id" , "dst_long_id").write.mode("overwrite").parquet(path+"dp_edges_mapped_to_long")
	dp_longedges= spark.read.parquet(path+"dp_edges_mapped_to_long")
	c=dp_longedges.count()
	# 5119994807
	all_dps_count=(dp_longedges.select('dpid').distinct().count())
	# 100
	#all required edges
	all_edges=spark.read.parquet(all_edges_path)	
	dp_longedges.join(all_edges,[all_edges.src==dp_longedges.src_long_id,all_edges.dst==dp_longedges.dst_long_id]).drop('src_long_id','dst_long_id').write.mode('overwrite').parquet(path+'dp_req_edges_with_longs')
	#IT NEEDS TO BE DONE FOR SRC=DST AND DST=SRC ALSO 
	dp_req_edges=spark.read.parquet(path+'dp_req_edges_with_longs')		
	dp_req_edges=dp_req_edges.withColumn("datetime",F.from_unixtime(F.col("timestamp")))
	total=all_edges.count()
	print("total_edges",total)
	# total_edges 1537285584  
	dp_req_count=dp_req_edges.count()
	# 4276130543- since an edge is seen by multiple dps and also timestamps
	total_fromdps=dp_req_edges.select('src','dst').distinct().count()
	print(total_fromdps==total)
	# True - as expected
	dps=dp_req_edges.select('dpid').distinct().collect()
	dps=list(map(lambda x:x[0],dps))
	required_dps_count=len(dps)
	#85
	# THE REMAINING 52-32 ARE ANYWAYS NEGATIVE SCORED IN DPCOVER CODE 
	#now give score 
	# score based on ingestion percent-
	print(":am here")
	dp_score_inges=defaultdict(int)
	for dp in dps:
		dp_score_inges[dp]="{:.8f}".format(float( -(dp_req_edges.filter(F.col('dpid')==dp).where(F.col('datetime').like("%00:00:00")).distinct().count()/dp_req_edges.filter(F.col('dpid')==dp).distinct().count()) ))
	# now the actual score based on ingestion percent shouldnt be very high so scale it down by alpha 
	alpha=0.05
	for i in dp_score_inges.keys():
		if(float(dp_score_inges[i])!=0):
			dp_score_inges[i]=alpha*float(dp_score_inges[i])
	# {'307': -6.85e-08, '1314': '-0.00000000', '876': -2.9950000000000005e-07, '678': -0.047137160000000004, '1147': '-0.00000000', '233': '-0.00000000', '63': '-0.00000000', '598': -0.017208447499999998, '1222': -0.049995783, '820': -0.05, '556': '-0.00000000', '1141': -0.0259713875, '667': -0.049018127, '525': -0.05, '329': '-0.00000000', '1396': -0.0499559415, '86': '-0.00000000', '627': '-0.00000000', '1332': -0.05, '346': '-0.00000000', '575': -4.16e-07, '809': '-0.00000000', '529': -2.135e-07, '522': -0.05, '120': '-0.00000000', '335': '-0.00000000', '963': -1.7965000000000003e-06, '1085': -3.635e-07, '871': '-0.00000000', '810': '-0.00000000', '521': '-0.00000000', '808': '-0.00000000', '807': '-0.00000000', '1110': -0.027212217500000004, '103': '-0.00000000', '516': '-0.00000000', '1415': '-0.00000000', '21': -0.05, '1292': '-0.00000000', '1480': '-0.00000000', '1055': '-0.00000000', '611': '-0.00000000', '625': '-0.00000000', '59': -2.27e-07, '799': -6.900000000000001e-07, '1148': '-0.00000000', '95': '-0.00000000', '648': -2.7250000000000004e-07, '395': -9.100000000000001e-08, '331': -8.85e-08, '372': '-0.00000000', '75': '-0.00000000', '239': '-0.00000000', '314': -1.7400000000000002e-07, '1258': -3.42e-07, '1361': -3.205e-07, '979': -1.9e-07, '29': '-0.00000000', '1257': '-0.00000000', '1271': '-0.00000000', '135': -1.8925e-06, '806': '-0.00000000', '105': -9.850000000000002e-08, '1380': -2.92e-07, '226': '-0.00000000', '800': -0.049716186, '685': '-0.00000000', '87': -2.42e-07, '404': -0.011477924, '1316': '-0.00000000', '738': -0.0482913565, '338': '-0.00000000', '1129': '-0.00000000', '654': '-0.00000000', '336': '-0.00000000', '634': -0.05, '1076': '-0.00000000', '374': '-0.00000000', '637': -3.1050000000000003e-07, '370': '-0.00000000', '1252': '-0.00000000', '620': '-0.00000000', '229': -0.05, '376': '-0.00000000', '12': -0.05}
	#score based on no.of off-on links given
	#again it is seen only on all_edges becoz thats what is finnaly useful to us-
	print("heree")
	dp_score_off_on=defaultdict(int)
	for dp in dps:
		dp_score_off_on[dp]="{:.8f}".format(float( (  (dp_req_edges.filter(F.col('dpid')==dp).filter(F.col("vertex1type")[0:2] == "id").filter(F.col("vertex2type")[0:2] != "id").count()+dp_req_edges.filter(F.col('dpid')==dp).filter(F.col("vertex2type")[0:2] == "id").filter(F.col("vertex1type")[0:2] != "id").count()) / dp_req_edges.filter(F.col('dpid')==dp).distinct().count() )))
	# {'307': '0.00000000', '1314': '0.00000000', '876': '0.00000000', '678': '0.00000000', '1147': '0.00000000', '233': '0.00000000', '63': '0.00000000', '598': '0.26395171', '1222': '0.81332630', '820': '0.92515593', '556': '0.00000000', '1141': '0.19402744', '667': '0.67039275', '525': '0.00000000', '329': '0.00000000', '1396': '0.58308152', '86': '0.00000000', '627': '0.00000000', '1332': '0.00000000', '346': '0.00000000', '575': '0.00000000', '809': '0.00000000', '529': '0.00000000', '522': '0.69230769', '120': '0.00000000', '335': '0.00000000', '963': '0.00000000', '1085': '0.00000000', '871': '0.00000000', '810': '0.00000000', '521': '0.00000000', '808': '0.00000000', '807': '0.00000000', '1110': '0.20848449', '103': '0.00000000', '516': '0.00000000', '1415': '0.00000000', '21': '0.50094147', '1292': '0.00000000', '1480': '0.00000000', '1055': '0.00000000', '611': '0.00000000', '625': '0.00000000', '59': '0.00000000', '799': '0.00000000', '1148': '0.00000000', '95': '0.00000000', '648': '0.00000000', '395': '0.00000000', '331': '0.00000000', '372': '0.00000000', '75': '0.00000000', '239': '0.00000000', '314': '0.00000000', '1258': '0.00000000', '1361': '0.00000000', '979': '0.00000000', '29': '0.00000000', '1257': '0.00000000', '1271': '0.00000000', '135': '0.00000000', '806': '0.00000000', '105': '0.00000000', '1380': '0.00000000', '226': '0.00000000', '800': '0.01156150', '685': '0.00000000', '87': '0.00000000', '404': '0.79048189', '1316': '0.00000000', '738': '0.00000000', '338': '0.00000000', '1129': '0.00000000', '654': '0.00000000', '336': '0.00000000', '634': '0.00000000', '1076': '0.00000000', '374': '0.00000000', '637': '0.00000000', '370': '0.00000000', '1252': '0.00000000', '620': '0.00000000', '229': '1.00000000', '376': '0.00000000', '12': '0.00000000'}
	alpha=1.1 
	print("off-on done")
	#now score based on how much of links only this dp has seen (onlyme edges/all edges I saw)
	# to get only me edges 
	# grp by wrt edges 
	dp_req_edges=dp_req_edges.select('dpid','src','dst','timestamp')
	only_mes=dp_req_edges.select('dpid','src','dst').distinct().groupby('src','dst').count().filter(F.col('count')==1)
	only_mescount=only_mes.count()
	print(only_mescount<=total)
	#1389285833(out of total)
	only_mes=only_mes.withColumnRenamed('src','src_').withColumnRenamed('dst','dst_')
	df=only_mes.join(dp_req_edges,[dp_req_edges.src==only_mes.src_, dp_req_edges.dst==only_mes.dst_]).drop('src_','dst_').write.mode('overwrite').parquet(path+'only_me_edges_dpids')
	dp_only=spark.read.parquet(path+'only_me_edges_dpids')
	dp_edgeonly=dp_only.select('src','dst','dpid').distinct()
	e=dp_edgeonly.count()
	print(e==only_mescount)
	# True
	d=dp_edgeonly.select('dpid').distinct().count()
	# 85
	dp_alones=dp_edgeonly.select('dpid').distinct().collect()
	dp_alones=list(map(lambda x:x[0],dp_alones))
	dp_score_aloness=defaultdict(int)
	total_edges=dp_req_edges.select('src','dst').distinct().count()
	print(total==total_edges)
	#True
	for dp in dp_alones:
		alone_count=dp_edgeonly.filter(F.col('dpid')==dp).distinct().count()
		print(dp,alone_count)
		dp_score_aloness[dp]="{:.8f}".format(float( ( alone_count/total_edges)))
	#   {'307': '0.00019682', '1314': '0.00000006', '876': '0.00383112', '678': '0.08685414', '1147': '0.00000636', '233': '0.00002666', '63': '0.00000220', '598': '0.00010828', '1222': '0.00001623', '820': '0.00000161', '556': '0.00000112', '1141': '0.00014637', '667': '0.00000105', '525': '0.00163352', '329': '0.00000026', '1396': '0.00062779', '86': '0.00001126', '627': '0.00000300', '1332': '0.00000267', '346': '0.00000002', '575': '0.00003476', '809': '0.00000011', '529': '0.00476971', '522': '0.00000002', '120': '0.00000576', '335': '0.00000359', '963': '0.00001266', '1085': '0.00005138', '871': '0.00003770', '810': '0.00000003', '521': '0.00000826', '808': '0.00000002', '807': '0.00000024', '1110': '0.00212894', '103': '0.00000000', '516': '0.00001173', '1415': '0.00000012', '21': '0.00022607', '1292': '0.00004733', '1480': '0.00000025', '1055': '0.00000001', '611': '0.00000009', '625': '0.00003230', '59': '0.00016810', '799': '0.00002922', '1148': '0.00000837', '95': '0.00000011', '648': '0.00022033', '395': '0.00035915', '331': '0.00007368', '372': '0.00009705', '75': '0.00000028', '239': '0.00000133', '314': '0.01414682', '1258': '0.00324488', '1361': '0.07886129', '979': '0.02846417', '29': '0.00000010', '1257': '0.00005066', '1271': '0.00000042', '135': '0.00000976', '806': '0.00003787', '105': '0.00015541', '1380': '0.00786562', '226': '0.00000000', '800': '0.00000258', '685': '0.00000167', '87': '0.11541531', '404': '0.01385475', '1316': '0.00000001', '738': '0.53765510', '338': '0.00000663', '1129': '0.00000001', '654': '0.00001008', '336': '0.00000156', '634': '0.00000809', '1076': '0.00000042', '374': '0.00000011', '637': '0.00005111', '370': '0.00000187', '1252': '0.00000329', '620': '0.00000257', '229': '0.00205968', '376': '0.00000001', '12': '0.00001548'}
except Exception as e:
	print("No",e)

#now this score is to be scale accordingly
# if a dp produces 2 edges and both are new,score will be 1 which is very high for 2 edges
# so the scale factor can be percent of edges seen 
#THIS SCALING IS NOW DONE DIRECTLY IN THE ABOVE LOOP ONLY
# for dps in dp_score_aloness.keys():
# 	seencount=dp_req_edges.filter(F.col('dpid')==dps).select('src','dst').distinct().count()
# 	#this scaling can be added in the above for loop only 
# 	print(dps,seencount)
# 	dp_score_aloness[dps]="{:.8f}".format(float( (seencount/total_edges*float(dp_score_aloness[dps]))))
# {'1396': '0.92344411', '335': '0.00007288', '598': '0.00034616', '1222': '0.00098382', '667': '0.00051013', '1110': '0.00009109', '648': '0.00088362', '1258': '0.00056479', '738': '0.02948732', '1141': '0.00936452', '395': '0.00004555', '979': '0.00036438', '678': '0.00112046', '1332': '0.00376221', '120': '0.00002733', '871': '0.00001822', '87': '0.00888172', '634': '0.00000911', '876': '0.00003644', '529': '0.00005466', '1292': '0.00005466', '59': '0.00059211', '1361': '0.00067410', '229': '0.00007288'}
#so, if dp has seen x amount of only me edges , then those x may be good or bad
#so dp need to be scored in accordance with anomal value of those x edges
#so to score edges, betweeness centrality can be used
# more the bc, means it is near to bridge and so it can be anomaly
# now may be the score we use can be 1/bc (since more bc , more it is a bride, so more anomaly, less score)
#BC Implementation-
try:
	total=1537285584 
	e=1389285833
	all_edges=spark.read.parquet(all_edges_path)
	cc_path_tube_nontube="gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/graph/cleanup_tests/country=GBR/data/final_graph/final_graph/cc"
	cc_final=spark.read.parquet(cc_path_tube_nontube)
	# cc_final.groupby('component').count().filter(F.col('count')>900).count()
	final_edges_to_apply_cc=spark.read.parquet(all_edges_path)
	max_comp_intermediate_edges=cc_final.join(final_edges_to_apply_cc, [cc_final.id == final_edges_to_apply_cc.src]).drop("id")
	max_comp_intermediate_edges=max_comp_intermediate_edges.withColumnRenamed("component","src_component")
	max_comp_intermediate_edges.join(cc_final , [cc_final.id == max_comp_intermediate_edges.dst]).drop("id").withColumnRenamed("component","dst_component").write.mode("overwrite").parquet(path+"cc_merged_with_edges")
	cc_with_edges=spark.read.parquet(path+"cc_merged_with_edges")
	edge_count=cc_with_edges.count()
	print(edge_count==total)
	# True
	trav_edges_cc=cc_with_edges.filter(F.col('src_component')==F.col('dst_component')).drop('dst_component').withColumnRenamed('src_component','component')
	trav_edges_cc.groupby('component').count().sort(F.col('count').desc()).show()
	# 1537285584 
try:
	df=trav_edges_cc.groupby('component').agg( F.collect_list( F.struct(F.col('src'),F.col('dst'))).alias('edges'))
	dfcount=df.count()
	print("dfc",dfcount)
	#   dfc 194170800
	#DF WITH COMPONENT-EDGE_LIST
	# def getcount(x):
	# 	return x['component'],len(x['edges'])
	# cdf=df.rdd.map(lambda x:getcount(x)).toDF(['comp','count'])
	# cdf.select('count').groupBy().sum().collect()
	# # 109776 - sum of counts
	# cdf=cdf.withColumnRenamed('count','countcdf')
	# test=cdf.join(interm,interm.component==cdf.comp).drop('comp')
	# #2657 
	# test.filter(F.col('countcdf')!=F.col('count')).count()
	def bc_edge(x):
		edges=list(map(lambda x:tuple(x),x['edges']))
		graph_nx=nx.from_edgelist(edges)
		edge_bcs=nx.edge_betweenness_centrality(graph_nx)
		return x['component'],edge_bcs
	print("bcedge start")
	df.rdd.map(lambda x: bc_edge(x)).toDF([ "component","edges_with_bcs"]).write.mode('overwrite').parquet(path+'edgesbcs_interm')
	interm=spark.read.parquet(path+'edgesbcs_interm')
	print(interm.count()==dfcount)
	# 71,627,947
	interm_=interm.select("component",F.explode("edges_with_bcs"))
	interm_.select('component','key.*','value').withColumnRenamed('_1','src').withColumnRenamed('_2','dst').withColumnRenamed('value','edge_bc').write.mode('overwrite').parquet(path+'edges_with_edgebcs')
	x=spark.read.parquet(path+'edges_with_edgebcs')
	edge_bcs_count=x.count()
	print(edge_bcs_count,total)
	# 1376391020 1537285584  coz it counted all undirected edges only and in the dataset there are b0th a-b and b-a edges
	# now use the dp_edgeonly df here 
	x=x.withColumnRenamed('src','src_').withColumnRenamed('dst','dst_')
	dp_only=spark.read.parquet(path+'only_me_edges_dpids')
	dp_edgeonly=dp_only.select('src','dst','dpid').distinct()
	curr=dp_edgeonly.join(x,[x.src_==dp_edgeonly.src,x.dst_==dp_edgeonly.dst]).drop('src_','dst_')
	#    remaining are revrse direction edges
	curr=curr.union(dp_edgeonly.join(x,[x.dst_==dp_edgeonly.src,x.src_==dp_edgeonly.dst]).drop('src_','dst_'))
	curr.write.mode('overwrite').parquet(path+'aone_edges_with_edgebc')
	aloneedges=spark.read.parquet(path+'aone_edges_with_edgebc')
	alone_dp_count=aloneedges.count()
	print(alone_dp_count==e)
	#	True 
	aloneedges=aloneedges.withColumn('edge_score',1/F.col('edge_bc'))
	#scale the score between 0 -1
	def scalecolumn(df,col):
		from pyspark.ml.feature import MinMaxScaler
		from pyspark.ml.feature import VectorAssembler
		from pyspark.ml import Pipeline
		from pyspark.sql.functions import udf
		from pyspark.sql.types import DoubleType
		# UDF for converting column type from vector to double type
		unlist = udf(lambda x: round(float(list(x)[0]),3), DoubleType())
		assembler = VectorAssembler(inputCols=[col],outputCol=col+"_Vect")
		# MinMaxScaler Transformation
		scaler = MinMaxScaler(inputCol=col+"_Vect", outputCol=col+"_Scaled")
		# Pipeline of VectorAssembler and MinMaxScaler
		pipeline = Pipeline(stages=[assembler, scaler])
		# Fitting pipeline on dataframe
		returndf= pipeline.fit(df).transform(df).withColumn(col+"_Scaled", unlist(col+"_Scaled")).drop(col+"_Vect")
		return returndf
	dpid_with_edgescore=aloneedges.groupby('dpid').agg(F.avg(F.col('edge_score')).alias('avg_edgescore'))
	#now get avg edge_score for a dpid 
	dumm=scalecolumn(dpid_with_edgescore,'avg_edgescore')
	dumm.write.mode('overwrite').parquet(path+'dpid_with_avg_edgescore_scaled')
	dpids_edgescore=spark.read.parquet(path+'dpid_with_avg_edgescore_scaled')
	dpids_edgescore=dpids_edgescore.collect()
	#DEFINE DP_SCORE_ALONESS 
	for dp,_,score in dpids_edgescore:
		dp_score_aloness[dp]=score*float(dp_score_aloness[str(dp)])
except Exception as e:
	print("No",e)
# {'307': 2.55866e-06, '1314': 6e-10, '876': 1.91556e-05, '678': 0.010075080240000001, '1147': 7.632e-08, '233': 3.7323999999999997e-07, '63': 2.2000000000000002e-08, '598': 2.739484e-05, '1222': 3.0025499999999997e-06, '820': 4.0250000000000006e-08, '556': 1.008e-08, '1141': 5.269319999999999e-06, '667': 6.195e-08, '525': 9.80112e-06, '329': 1.3e-09, '1396': 0.00062779, '86': 2.3083e-06, '627': -0.0, '1332': 2.4029999999999997e-08, '346': 2e-10, '575': 2.4332e-07, '809': 9.899999999999999e-10, '529': 9.062449e-05, '522': 2e-10, '120': 7.487999999999999e-08, '335': 9.693e-08, '963': 1.3926e-07, '1085': 5.138e-07, '871': 9.802e-07, '810': 2.4e-10, '521': 8.260000000000001e-08, '808': 2e-10, '807': 2.1599999999999996e-09, '1110': 0.00012986534, '103': 0.0, '516': 9.384e-08, '1415': 9.6e-10, '21': 1.58249e-06, '1292': 7.0995e-07, '1480': 2.25e-09, '1055': 2.1000000000000002e-10, '611': 7.2e-10, '625': 7.752e-07, '59': 2.5215e-06, '799': 2.3376000000000002e-07, '1148': 7.532999999999999e-08, '95': 1.3200000000000002e-09, '648': 3.7456100000000005e-06, '395': 2.8732e-06, '331': 8.1048e-07, '372': 9.705e-07, '75': 1.9600000000000003e-09, '239': 5.32e-09, '314': 7.07341e-05, '1258': 0.00012006055999999998, '1361': 0.0008674741899999999, '979': 0.00017078502000000001, '29': 1e-09, '1257': 5.5726e-07, '1271': 3.78e-09, '135': 2.3423999999999999e-07, '806': 3.4083e-07, '105': 1.5541e-06, '1380': 0.00022810298, '226': 0.0, '800': 2.8379999999999997e-08, '685': 2.171e-08, '87': 0.00092332248, '404': 0.00012469275, '1316': 8.000000000000001e-11, '738': 0.1107569506, '338': 7.956e-08, '1129': 5e-11, '654': 9.072e-08, '336': 1.404e-08, '634': 6.472e-08, '1076': 2.52e-09, '374': 7.7e-10, '637': 3.5777e-07, '370': 3.7400000000000004e-08, '1252': 2.303e-08, '620': 3.084e-08, '229': 2.05968e-05, '376': 8.000000000000001e-11, '12': 4.644e-07}
JENKS NATURAL BREAK ALGO 


#do the same for ids
# how many of new ids only this dp has seen 
try:
	edges_tube=spark.read.parquet(edges_path_tube)
	edges_nontube =spark.read.parquet(edges_path_nontube_req)
	dp_tube=edges_tube.select('dpid','vertex1','vertex1type').distinct().union(edges_tube.select('dpid','vertex2','vertex2type').distinct())
	dp_nontube=edges_nontube.select('dpid','vertex1','vertex1type').distinct().union(edges_nontube.select('dpid','vertex2','vertex2type').distinct())
	dp_tube.union(dp_nontube).distinct().write.mode('overwrite').parquet(path+"dpids_with_its_vertices")
	dp_vertices=spark.read.parquet(path+'dpids_with_its_vertices')
	#now join with long mapped ids 
	long_mapped_ids=spark.read.parquet(long_mapped_ids_path)
	long_mapped_ids=long_mapped_ids.withColumnRenamed('string_id','id').drop('graph_type_flag')
	all_dps=dp_vertices.select('dpid').distinct().count()
	# 100 no.of dps
	multiple_count=dp_vertices.count()
	#2438298445 the count of all vertices seen by dps( more than actual count coz one vertex can be seen by more than one dp) 
	dp_vertices.join(long_mapped_ids,[long_mapped_ids.id==dp_vertices.vertex1,long_mapped_ids.type==dp_vertices.vertex1type]).drop('vertex1','vertex1type').write.mode('overwrite').parquet(path+'dpids_with_its_vertices_long_mapped')
	dp_ids=spark.read.parquet(path+'dpids_with_its_vertices_long_mapped')
	dp_longs=dp_ids.select('dpid','long_id')
	all_vertices=spark.read.parquet(all_vertices_path)
	allvs=all_vertices.count()
	# 1049133801
	# DataFrame[id: bigint]
	dp_longs.join(all_vertices,all_vertices.id==dp_longs.long_id).drop('id').write.mode('overwrite').parquet(path+'dpids_with_its_final_vertices')
	dp_reqids=spark.read.parquet(path+'dpids_with_its_final_vertices')
	dpidvs=dp_reqids.count()
	# 1461622107
	distinctids=dp_reqids.select('long_id').distinct().count()
	print(allvs==distinctids)
	#True
	#now grp by wrto id 
	alone_ids=dp_reqids.groupby('long_id').count().distinct().filter(F.col('count')==1)
	alone_ids=alone_ids.withColumnRenamed('long_id','long_id_').drop('count')
	alones=alone_ids.count()
	print(alones<=allvs)
	# 825002348
	alone_ids.join(dp_reqids,dp_reqids.long_id==alone_ids.long_id_).drop('long_id_').write.mode('overwrite').parquet(path+'only_me_ids_dpids')
	aloneid_dps=spark.read.parquet(path+'only_me_ids_dpids')
	print(aloneid_dps.count()==alones)
	#true
	alone_dps=aloneid_dps.select('dpid').distinct().collect()
	alone_dps=list(map(lambda x:x[0],alone_dps))
	print(len(alone_dps))
	# 85
	dpidscore_aloness=defaultdict(int)
	total_ids=dp_reqids.select('long_id').distinct().count()
	#1049133801
	#coz based on above scaling logic, 
	for dp in alone_dps:
		alone_count=aloneid_dps.filter(F.col('dpid')==dp).distinct().count()
		print(alone_count,total_ids)
		dpidscore_aloness[dp]="{:.8f}".format(float( ( alone_count/total_ids )))
except Exception as e:
	print("No",e)

 # {'307': '0.00019241', '1314': '0.00000006', '876': '0.00553124', '678': '0.12913916', '1147': '0.00000733', '233': '0.00002913', '63': '0.00000242', '598': '0.00007928', '1222': '0.00002211', '820': '0.00000138', '556': '0.00000139', '1141': '0.00014088', '667': '0.00000112', '525': '0.00243695', '329': '0.00000007', '1396': '0.00062238', '627': '0.00000773', '86': '0.00001203', '1332': '0.00000453', '346': '0.00000002', '575': '0.00001383', '809': '0.00000012', '529': '0.00364399', '522': '0.00000002', '120': '0.00000544', '335': '0.00000352', '963': '0.00001470', '1085': '0.00007522', '871': '0.00004180', '810': '0.00000004', '521': '0.00000849', '808': '0.00000001', '807': '0.00000029', '1110': '0.00184873', '103': '0.00000001', '516': '0.00001343', '1415': '0.00000013', '21': '0.00020643', '1292': '0.00004891', '1480': '0.00000034', '1055': '0.00000001', '611': '0.00000008', '625': '0.00004721', '59': '0.00017911', '799': '0.00003863', '1148': '0.00000928', '95': '0.00000011', '648': '0.00022453', '395': '0.00052504', '331': '0.00008196', '372': '0.00010706', '75': '0.00000027', '239': '0.00000067', '314': '0.01213665', '1258': '0.00196192', '1361': '0.09961122', '979': '0.02902648', '29': '0.00000009', '1257': '0.00005428', '1271': '0.00000047', '135': '0.00001164', '806': '0.00004200', '105': '0.00010190', '1380': '0.00476341', '226': '0.00000000', '800': '0.00000327', '685': '0.00000136', '87': '0.13468012', '404': '0.01156238', '1316': '0.00000001', '738': '0.34579852', '338': '0.00000723', '1129': '0.00000002', '654': '0.00001119', '336': '0.00000171', '634': '0.00001138', '1076': '0.00000047', '374': '0.00000015', '637': '0.00007176', '370': '0.00000207', '1252': '0.00000170', '620': '0.00000305', '229': '0.00112627', '376': '0.00000002', '12': '0.00000148'}
   # now same as before, the ids have to scored based on anaomaly






# so node bc can be used in a similar way 
try:
	cc_with_edges=spark.read.parquet(path+"cc_merged_with_edges")
	trav_edges_cc=cc_with_edges.filter(F.col('src_component')==F.col('dst_component')).drop('dst_component').withColumnRenamed('src_component','component')
	df=trav_edges_cc.groupby('component').agg( F.collect_list( F.struct(F.col('src'),F.col('dst'))).alias('edges'))
	def bc_node(x):
		edges=list(map(lambda x:tuple(x),x['edges']))
		graph_nx=nx.from_edgelist(edges)
		node_bcs=nx.betweenness_centrality(graph_nx)
		return x['component'],node_bcs
	print("node_bc start")
	interm=df.rdd.map(lambda x: bc_node(x)).toDF([ "component","nodes_with_bcs"])
	interm_=interm.select("component",F.explode("nodes_with_bcs"))
	interm_.withColumnRenamed('key','id').withColumnRenamed('value','node_bc').write.mode('overwrite').parquet(path+'nodes_with_nodebcs')
	nodebcs=spark.read.parquet(path+'nodes_with_nodebcs')
	print(nodebcs.count()==distinctids)
	# 19984 as expected 
	aloneid_dps=spark.read.parquet(path+'only_me_ids_dpids')
	curr=aloneid_dps.join(nodebcs,nodebcs.id==aloneid_dps.long_id).drop('long_id')
	curr.write.mode('overwrite').parquet(path+'alone_ids_with_nodebc')
	curr=spark.read.parquet(path+'alone_ids_with_nodebc')
	node_scores=curr.withColumn('node_score',1/F.col('node_bc'))
	# dpid_with_nodescore.select('avg_nodescore').withColumn('isNull_node_bc',F.col('avg_nodescore').isNull()).where('isNull_node_bc = True').count()
	#scale the score between 0 -1
	def scalecolumn(df,col):
		from pyspark.ml.feature import MinMaxScaler
		from pyspark.ml.feature import VectorAssembler
		from pyspark.ml import Pipeline
		from pyspark.sql.functions import udf
		from pyspark.sql.types import DoubleType
		# UDF for converting column type from vector to double type
		unlist = udf(lambda x: round(float(list(x)[0]),3), DoubleType())
		assembler = VectorAssembler(inputCols=[col],outputCol=col+"_Vect")
		# MinMaxScaler Transformation
		scaler = MinMaxScaler(inputCol=col+"_Vect", outputCol=col+"_Scaled")
		# Pipeline of VectorAssembler and MinMaxScaler
		pipeline = Pipeline(stages=[assembler, scaler])
		# Fitting pipeline on dataframe
		returndf= pipeline.fit(df).transform(df).withColumn(col+"_Scaled", unlist(col+"_Scaled")).drop(col+"_Vect")
		return returndf
	dpid_with_nodescore=node_scores.groupby('dpid').agg(F.avg(F.col('node_score')).alias('avg_nodescore'))
	#now get avg node_score for a dpid 
	dpid_with_nodescore=dpid_with_nodescore.fillna({'avg_nodescore':1})
	dum=scalecolumn(dpid_with_nodescore,'avg_nodescore')
	dum.write.mode('overwrite').parquet(path+'dpid_with_avg_nodescore_scaled')
	dum=spark.read.parquet(path+'dpid_with_avg_nodescore_scaled')
	dpids_nodescore=dum.collect()
	for dp,_,score in dpids_nodescore:
		dpidscore_aloness[dp]=score*float(dpidscore_aloness[str(dp)])
#  {'307': 5.753059e-05, '1314': 0.0, '876': 0.0, '678': 0.00038741748, '1147': 6.597e-08, '233': 2.73822e-06, '63': 0.0, '598': 6.413752000000001e-05, '1222': 8.844e-08, '820': 3.174e-08, '556': 0.0, '1141': 1.070688e-05, '667': 1.12e-09, '525': 0.0, '329': 0.0, '1396': 0.00024210582, '627': 0.0, '86': 1.99698e-06, '1332': 1.359e-08, '346': 0.0, '575': 0.0, '809': 0.0, '529': 0.0, '522': 0.0, '120': 7.616e-08, '335': 6.335999999999999e-08, '963': 1.4700000000000001e-08, '1085': 7.522000000000001e-08, '871': 2.09e-07, '810': 0.0, '521': 0.0, '808': 0.0, '807': 0.0, '1110': 0.00184873, '103': 0.0, '516': 5.372e-08, '1415': 0.0, '21': 0.0, '1292': 3.9128e-07, '1480': 0.0, '1055': 0.0, '611': 0.0, '625': 2.3605e-07, '59': 1.07466e-06, '799': 0.0, '1148': 1.856e-08, '95': 0.0, '648': 1.7962399999999999e-06, '395': 4.7253599999999994e-06, '331': 4.999559999999999e-06, '372': 5.353e-07, '75': 0.0, '239': 0.0, '314': 1.213665e-05, '1258': 3.92384e-06, '1361': 0.00268950294, '979': 2.902648e-05, '29': 0.0, '1257': 1.5741200000000002e-06, '1271': 0.0, '135': 0.0, '806': 0.0, '105': 4.7893e-06, '1380': 2.8580460000000002e-05, '226': 0.0, '800': 0.0, '685': 0.0, '87': 0.0006734006, '404': 0.00016187332, '1316': 0.0, '738': 0.00207479112, '338': 1.2074100000000001e-06, '1129': 0.0, '654': 1.119e-08, '336': 0.0, '634': 0.0, '1076': 0.0, '374': 0.0, '637': 0.0, '370': 6.9138e-07, '1252': 0.0, '620': 0.0, '229': 1.12627e-06, '376': 0.0, '12': 1.776e-08}
except Exception as e:
	print("No",e)




for bcedge of big COMPs - 
break it into communityies nd we get bc of inside community ND FOR inter community edges , the bc= m*n / (m+n)**2 -> m,n are the size of the clusters




#DPCOVER CODE
try:
	edges_tube=spark.read.parquet(edges_path_tube)
	edges_nontube =spark.read.parquet(edges_path_nontube_req)
	# DataFrame[vertex1: string, vertex1type: string, vertex2: string, vertex2type: string, dpid: int, timestamp: bigint, recordType: string]
	dp_tube=edges_tube.select('dpid','vertex1','vertex1type').distinct().union(edges_tube.select('dpid','vertex2','vertex2type').distinct())
	dp_nontube=edges_nontube.select('dpid','vertex1','vertex1type').distinct().union(edges_nontube.select('dpid','vertex2','vertex2type').distinct())
	# dp_tube.union(dp_nontube).distinct().write.mode('overwrite').parquet(path+"dpids_with_its_vertices")
	dp_vertices=spark.read.parquet(path+'dpids_with_its_vertices')
	# #now join with long mapped ids 
	long_mapped_ids=spark.read.parquet(long_mapped_ids_path)
	long_mapped_ids=long_mapped_ids.withColumnRenamed('string_id','id').drop('graph_type_flag')
	multiple_count=dp_vertices.count()
	# # 2438298445the count of all vertices seen by dps( more than actual count coz one vertex can be seen by more than one dp) 
	# dp_vertices.join(long_mapped_ids,[long_mapped_ids.id==dp_vertices.vertex1,long_mapped_ids.type==dp_vertices.vertex1type]).drop('vertex1','vertex1type').write.mode('overwrite').parquet(path+'dpids_with_its_vertices_long_mapped')
	dp_ids=spark.read.parquet(path+'dpids_with_its_vertices_long_mapped')
	dp_longs=dp_ids.select('dpid','long_id')
	all_vertices=spark.read.parquet(all_vertices_path)
	allvs=all_vertices.count()
	# # 1049133801
	# # DataFrame[id: bigint]
	# dp_longs.join(all_vertices,all_vertices.id==dp_longs.long_id).drop('id').write.mode('overwrite').parquet(path+'dpids_with_its_final_vertices')
	dp_reqids=spark.read.parquet(path+'dpids_with_its_final_vertices')
	#ALL THE ABOVE PATHS ARE WRITTEN IN DP_IND_FEATURES
	#this df contains dpid and only those ids which are present in final all vertices 
	reqdps=dp_reqids.select('dpid').distinct().count()
	# 85 so out of all only those dps have seen ids which are present in final vertices 
	# THE REMAINING DPS WILL BE GIVEN A NEGATIVE SCORE OF -1 
	reqvs=dp_reqids.count()
	print(reqvs>=allvs)
	# 1461622107 (coz an id can be seen by multiple dps)
	print(allvs==dp_reqids.select('long_id').distinct().count())
	# True  as expected
	#NOW DO THE STEP 1 
	#COLLECT ALL DPIDS 
	dps=dp_longs.select('dpid').distinct().collect()
	dp_score1=defaultdict(int)
	total=0
	usefuls=0
	for i in dps:
		curr_dp=i[0]
		total_seen_ids=dp_longs.filter(F.col('dpid')==curr_dp).select('long_id').distinct().count()
		useful_ids=dp_reqids.filter(F.col('dpid')==curr_dp).select('long_id').distinct().count()
		dp_score1[curr_dp]=useful_ids/total_seen_ids
		usefuls+=useful_ids
		total+=total_seen_ids  
	print(total==multiple_count)
	print(usefuls==reqvs)
	# True, True
	# total=(total ids+multiple dps=dp_longs.distinct().count())
	# usefuls= (total req ids+multiple dps=dp_reqids.count())
	for i in dp_score1.keys():
		dp_score1[i]="{:.8f}".format(float((dp_score1[i])))
	print("inital score is done")
	#REPEAT THE SAMETHING FOR EDGES ALSO
	#THE EDGES DFS RE ALREADY WRITTEN IN below CODE
	# {'307': '0.46127480', '1314': '0.46956522', '876': '0.72939098', '678': '0.90506446', '1147': '0.38096101', '233': '0.49046950', '63': '0.52226404', '598': '0.40109333', '90901': '0.00000000', '1222': '0.99977126', '820': '1.00000000', '556': '0.27083029', '1141': '0.54356933', '667': '0.98127925', '525': '1.00000000', '329': '0.25344694', '1396': '0.99211478', '86': '0.54054112', '627': '1.00000000', '58': '0.00000000', '1332': '1.00000000', '346': '0.68421053', '1353': '0.00000000', '575': '0.61719529', '809': '0.27010622', '529': '0.66112978', '45': '0.00000000', '522': '1.00000000', '613': '0.00000000', '120': '0.45257777', '335': '0.49059516', '963': '0.31786223', '1085': '0.45721700', '871': '0.46315751', '810': '0.73134328', '521': '0.15698684', '808': '0.53389831', '807': '0.37246416', '1110': '0.92362407', '103': '1.00000000', '516': '0.47605009', '1415': '0.16627289', '21': '1.00000000', '1292': '0.41101757', '1480': '0.29030085', '1055': '0.58490566', '611': '0.33570160', '625': '0.45981027', '59': '0.35521119', '799': '0.23005003', '1148': '0.39859391', '95': '0.41564792', '648': '0.39767413', '395': '0.49774761', '331': '0.49140008', '121': '0.00000000', '50': '0.00000000', '372': '0.13918850', '75': '0.34387910', '33': '0.00000000', '239': '0.18276565', '314': '0.25968190', '56': '0.00000000', '1258': '0.44926904', '216': '0.00000000', '1361': '0.67345928', '979': '0.52612566', '29': '0.47001091', '1257': '0.32528550', '1271': '0.50104885', '104': '0.00000000', '135': '0.68342842', '806': '0.61541959', '105': '0.43551996', '1380': '0.66213613', '226': '0.25714286', '800': '0.96313685', '685': '0.47574283', '87': '0.25051251', '404': '1.00000000', '1316': '0.28717949', '738': '0.99642929', '338': '0.36151481', '1129': '0.25935829', '416': '0.00000000', '654': '0.36797635', '336': '0.56553826', '24': '0.00000000', '634': '1.00000000', '35': '0.00000000', '1076': '0.41052632', '374': '0.02938753', '637': '0.47735495', '370': '0.62050391', '1252': '0.32910221', '100': '0.00000000', '620': '0.31475980', '229': '1.00000000', '376': '0.77697842', '12': '0.47231004'}
	# so, now all dps are given a positive score based on above dict values if value>0, if value=0 then a negative score of -0.5 can be given 
	dps=dp_reqids.select('dpid').distinct().collect()
	dps=list(map(lambda x:x[0],dps))
	# ['307', '1314', '876', '678', '1147', '233', '63', '598', '1222', '820', '556', '1141', '667', '525', '329', '1396', '86', '627', '1332', '346', '575', '809', '529', '522', '120', '335', '963', '1085', '871', '810', '521', '808', '807', '1110', '103', '516', '1415', '21', '1292', '1480', '1055', '611', '625', '59', '799', '1148', '95', '648', '395', '331', '372', '75', '239', '314', '1258', '1361', '979', '29', '1257', '1271', '135', '806', '105', '1380', '226', '800', '685', '87', '404', '1316', '738', '338', '1129', '654', '336', '634', '1076', '374', '637', '370', '1252', '620', '229', '376', '12']
	print(len(dps)==reqdps)
except Exception as error:
	print(error)
	#92 (lendps)
	#the brute force NP solution for set cover is not possible to implemet
	#the number 28 was for belgiu only
	#28 dps 2^28 subsets for each subsets, there are dpids inside the subsets and for those dpids, filter and count union areperformed on dfs
	#so, follow greedy approximate algorithm
	#initally included elements=I
	#keep adding subsets to it, and at any point the subset u pich should have max [SI-I] value, i.e max no.of new elements it ha to give
try:
	print('dp cover starts')
	# dp_reqids=spark.read.parquet(path+'dpids_with_its_final_vertices')
	# dps=dp_reqids.select('dpid').distinct().collect()
	# dps=list(map(lambda x:x[0],dps))
	dps=['307', '1314', '876', '678', '1147', '233', '63', '598', '1222', '820', '556', '1141', '667', '525', '329', '1396', '86', '627', '1332', '346', '575', '809', '529', '522', '120', '335', '963', '1085', '871', '810', '521', '808', '807', '1110', '103', '516', '1415', '21', '1292', '1480', '1055', '611', '625', '59', '799', '1148', '95', '648', '395', '331', '372', '75', '239', '314', '1258', '1361', '979', '29', '1257', '1271', '135', '806', '105', '1380', '226', '800', '685', '87', '404', '1316', '738', '338', '1129', '654', '336', '634', '1076', '374', '637', '370', '1252', '620', '229', '376', '12']
	schema = StructType([
	  StructField('long_id', LongType(), False),
	  ])
	included_ids=spark.sparkContext.parallelize([]).toDF(schema)
	n=len(dps)
	threshold=0.97
	all_vertices=spark.read.parquet(all_vertices_path)
	total_cover=all_vertices.count()
	seendpids=set()
	for i in seendpids:
		included_ids=included_ids.union(dp_reqids.filter(F.col('dpid')==i).select('long_id').distinct()).distinct()
	print("total_cover is ",total_cover,threshold*total_cover)
	# total_cover is   1049133801 1017659786.97  
	while(included_ids.count()<threshold*total_cover):
		maxval=0
		maxdpid=-1
		for ind,dpid in enumerate(dps):
			if(dpid in seendpids):
				continue
			curr_ids=dp_reqids.filter(F.col('dpid')==dpid).select('long_id').distinct()
			diff=curr_ids.subtract(included_ids).distinct()
			curr_count=diff.count()
			if(curr_count>maxval):
					maxval=curr_count
					maxdpid=dpid
			print("here",ind,maxdpid,maxval)
		if(maxdpid==-1):
			print("ERRORRRR!!!!")
			break
		print(included_ids.count(),maxdpid,seendpids,maxval)
		included_ids=included_ids.union(dp_reqids.filter(F.col('dpid')==maxdpid).select('long_id').distinct()).distinct()
		seendpids.add(maxdpid)
		print("UPDATED",ind,included_ids.count())
		print(seendpids)
	dp_score_cover=defaultdict(int)
	#now score -
	for i in seendpids:
		dp_score_cover[i]= "{:.8f}".format(float( ( dp_reqids.filter(F.col('dpid')==i).distinct().count() / total_cover )))
	print(dp_score_cover)
except Exception as e:
	print("No",e)
	
UPDATED 84 948950774                                                            
{'738', '1361', '678', '87'}
{'738': '0.48516011', '1361': '0.18757525', '678': '0.23821062', '87': '0.18132036'}
	#The scoring shouldnt be in other of how the greedy algo chose the dpids
	# coz say a dpid1 has 99% data and other dpid2 has 99.1% , so dpid2 will be chosen with score 99.1 and the other dpid will then be scored only 0.1 around
	# so 
	# now again, the dps in seendpids are scored based on count of how much they seen/total count and other remaining are not given any score(not even a negative score)
	# since this score is very crucial may be it neeed to be scaled up by alpha 
	# alpha=1.5


try:
	dp_longedges= spark.read.parquet(path+"dp_edges_mapped_to_long")
	#  (along with timestamps and multiple dpids) 
	all_edges=spark.read.parquet(all_edges_path)	
	e=all_edges.count()
	# # 1537285584
	# DataFrame[id: bigint]
	dp_req_edges=spark.read.parquet(path+'dp_req_edges_with_longs').select('dpid','src','dst').distinct()		
	req_edgescount=dp_req_edges.count()
	print(req_edgescount>=e)
	# 1719847897 since an edge is seen by multiple dps
	#NOW DO THE STEP 1 
	#COLLECT ALL DPIDS 
	dps=dp_longedges.select('dpid').distinct().collect()
	dp_score_edges=defaultdict(int)
	total=0
	usefuls=0
	for i in dps:
		curr_dp=i[0]
		total_seen_edges=dp_longedges.filter(F.col('dpid')==curr_dp).select('src_long_id','dst_long_id').distinct().count()
		useful_edges=dp_req_edges.filter(F.col('dpid')==curr_dp).select('src','dst').distinct().count()
		print(curr_dp,useful_edges,total_seen_edges)
		dp_score_edges[curr_dp]="{:.8f}".format(float((useful_edges/total_seen_edges)))
		usefuls+=useful_edges
		total+=total_seen_edges  
	print(total==dp_longedges.select('dpid','src_long_id','dst_long_id').distinct().count(),total)
	# True 2366935567 
	print(usefuls==req_edgescount)
	# True
	print("hey",dp_score_edges)
	# {'307': '0.48918157', '1314': '0.48387097', '876': '0.72951973', '678': '0.90029594', '1147': '0.40211312', '233': '0.55173930', '63': '0.52449220', '598': '0.42256835', '90901': '0.00000000', '1222': '0.99988819', '820': '1.00000000', '556': '0.26640287', '1141': '0.60389694', '667': '0.98189614', '525': '1.00000000', '329': '0.25188188', '1396': '0.99689275', '86': '0.56380045', '627': '1.00000000', '58': '0.00000000', '1332': '1.00000000', '346': '0.68345324', '1353': '0.00000000', '575': '0.61109152', '809': '0.28196147', '529': '0.69013176', '45': '0.00000000', '522': '1.00000000', '613': '0.00000000', '120': '0.45723138', '335': '0.49530556', '963': '0.34429265', '1085': '0.45257758', '871': '0.46946386', '810': '0.75862069', '521': '0.19598807', '808': '0.55940594', '807': '0.38808777', '1110': '0.94257206', '103': '1.00000000', '516': '0.48762887', '1415': '0.18817006', '21': '1.00000000', '1292': '0.43677913', '1480': '0.28962428', '1055': '0.61538462', '611': '0.34274586', '625': '0.44512995', '59': '0.40611654', '799': '0.23477398', '1148': '0.47160848', '95': '0.42243646', '648': '0.44674914', '395': '0.47309209', '331': '0.52648833', '121': '0.00000000', '50': '0.00000000', '372': '0.21588729', '75': '0.35309793', '33': '0.00000000', '239': '0.17836626', '314': '0.30009421', '56': '0.00000000', '1258': '0.45547905', '216': '0.00000000', '1361': '0.67728849', '979': '0.58484545', '29': '0.49403341', '1257': '0.33159876', '1271': '0.52867133', '104': '0.00000000', '135': '0.68103351', '806': '0.67594066', '105': '0.48213421', '1380': '0.66337554', '226': '0.24242424', '800': '0.97934363', '685': '0.47745883', '87': '0.32998516', '404': '1.00000000', '1316': '0.32258065', '738': '0.99853502', '338': '0.44279641', '1129': '0.27891156', '416': '0.00000000', '654': '0.37461066', '336': '0.59264613', '24': '0.00000000', '634': '1.00000000', '35': '0.00000000', '1076': '0.40460721', '374': '0.02984625', '637': '0.47656548', '370': '0.62566223', '1252': '0.32660479', '100': '0.00000000', '620': '0.32936135', '229': '1.00000000', '376': '0.76612903', '12': '0.48471496'}
	dps=dp_req_edges.select('dpid').distinct().collect()
	dps=list(map(lambda x:x[0],dps))
	# ['307', '1314', '876', '678', '1147', '233', '1146', '63', '598', '1222', '820', '556', '1141', '667', '525', '329', '1396', '86', '1332', '346', '575', '809', '529', '522', '120', '335', '963', '1085', '871', '810', '521', '808', '807', '1110', '516', '1415', '21', '1292', '1480', '1055', '611', '625', '59', '799', '1302', '1148', '95', '648', '395', '331', '1429', '372', '18', '27', '75', '118', '33', '239', '314', '1258', '1249', '1361', '979', '29', '1257', '1271', '135', '806', '105', '1380', '800', '685', '87', '404', '1316', '738', '338', '416', '1129', '654', '336', '24', '634', '1076', '1077', '637', '370', '1252', '620', '229', '376', '12']
	#the brute force NP solution for set cover is not possible to implemet
	#28 dps 2^28 subsets for each subsets, there are dpids inside the subsets and for those dpids, filter and count union areperformed on dfs
	#so, follow greedy approximate algorithm
	#initally included elements=I
	#keep adding subsets to it, and at any point the subset u pich should have max [SI-I] value, i.e max no.of new elements it ha to give
except :
	print("m")

try:
	print('edge cover starts')
	all_edges=spark.read.parquet(all_edges_path)	
	dp_req_edges=spark.read.parquet(path+'dp_req_edges_with_longs').select('dpid','src','dst').distinct()		
	dps=['307', '1314', '876', '678', '1147', '233', '63', '598', '1222', '820', '556', '1141', '667', '525', '329', '1396', '86', '627', '1332', '346', '575', '809', '529', '522', '120', '335', '963', '1085', '871', '810', '521', '808', '807', '1110', '103', '516', '1415', '21', '1292', '1480', '1055', '611', '625', '59', '799', '1148', '95', '648', '395', '331', '372', '75', '239', '314', '1258', '1361', '979', '29', '1257', '1271', '135', '806', '105', '1380', '226', '800', '685', '87', '404', '1316', '738', '338', '1129', '654', '336', '634', '1076', '374', '637', '370', '1252', '620', '229', '376', '12']
	dp_req_edges=dp_req_edges.select('dpid','src','dst').distinct()
	schema = StructType([
	  StructField('src', LongType(), False),
	  StructField('dst', LongType(), False),
	  ])
	included_edges=spark.sparkContext.parallelize([]).toDF(schema)
	n=len(dps)
	threshold=0.97
	total_cover=all_edges.count()
	# 
	seendpids={'738', '1361', '87'}
	for i in seendpids:
		included_edges=included_edges.union(dp_req_edges.filter(F.col('dpid')==i).select('src','dst').distinct()).distinct()
	print("total_cover is ",total_cover,threshold*total_cover)
	# 1537285584 1491167016.48 
	while(included_edges.count()<threshold*total_cover):
		maxval=0
		maxdpid=-1
		if(len(seendpids)==3):
			maxval=137125000
			maxdpid='678'
		for ind,dpid in enumerate(dps):
			if(dpid in seendpids):
				continue
			if(len(seendpids)==3):
				if(ind<=47):
					continue
			curr_edges=dp_req_edges.filter(F.col('dpid')==dpid).select('src','dst').distinct()
			diff=curr_edges.subtract(included_edges).distinct()
			curr_count=diff.count()
			if(curr_count>maxval):
					maxval=curr_count
					maxdpid=dpid
			print("here",ind,maxdpid,maxval)
		if(maxdpid==-1):
			print("ERRORRRR!!!!")
			break
		print(included_edges.count(),maxdpid,seendpids,maxval)
		included_edges=included_edges.union(dp_req_edges.filter(F.col('dpid')==maxdpid).select('src','dst').distinct()).distinct()
		seendpids.add(maxdpid)
		print("UPDATED",included_edges.count())
		print(seendpids)
	dp_score_coveredges=defaultdict(int)
	for i in seendpids:
		dp_score_coveredges[i]= "{:.8f}".format(float( ( dp_req_edges.filter(F.col('dpid')==i).distinct().count() / total_cover )))
	print(dp_score_coveredges)
except Exception as error:
	print('No',error)

print(dp_score_coveredges)

UPDATED 1436280772                                                              
{'678', '1361', '738', '979', '87'}


{'678': '0.17883929', '1361': '0.17522058', '738': '0.88244182', '979': '0.04210612', '87': '0.16982921'}
#now the scoring shouldnt be in other of how the greedy algo chose the dpids
coz say a dpid1 has 99% data and other dpid2 has 99.1% , so dpid2 will be chosen with score 99.1 and the other dpid will then be scored only 0.1 around
so 



now again, the dps in seendpids are scored based on count of how much they seen/total count and other remaining are not given any score(not even a negative score)

since this score is very crucial may be it neeed to be scaled up by alpha 
alpha=1.5





