import pyspark.sql.functions as F
from pyspark.sql.types import *
import networkx as nx
from graphframes import *
from pyspark.mllib.clustering import PowerIterationClustering, PowerIterationClusteringModel
from itertools import chain, combinations
import math
from operator import itemgetter
from collections import Counter
from collections import defaultdict
from os import sys, path
import community as community_louvain
from pyspark.sql.functions import lit

path="gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/graph/cleanup/country=UK/Prudhvi/UK_Graph_cleaning_new"
edges_path_nontube_req=path+"edges_nontube_with_askedtypes"
edges_path_nontube="gs://gcs-ireland-all-eu-daap-idu-bootstrap-internal-zeotap-com/run__20201123/zeoGraphEdges_idu_524/country=GBR"
edges_path_tube="gs://gcs-ireland-all-eu-daap-idu-bootstrap-internal-zeotap-com/run__20201123/tubeGraphEdges_idu_524/country=GBR"
total_vertices_path= path +"/total_vertices_tubeandnontube"
long_mapped_ids_path = "gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/graph/cleanup_tests/country=GBR/data/vertex_set/all_ids_with_long_mapping"
all_vertices_path="gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/graph/cleanup_tests/country=GBR/data/final_graph/tube_and_non_tube_vertices"
all_edges_path="gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/graph/cleanup_tests/country=GBR/data/final_graph/tube_and_non_tube_edges"
gen_path="gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/graph/cleanup/country=ALL/Prudhvi/DP_scoring/"


country=edges_path_nontube[-3:]
#AUT DONE
#CHE DONE
#BEL DONE
#LUX DONE
#merged done
#NLD DONE
#DEU DONE
#ITA DONE
#ESP DONE
#UK DONE
dp_longedges= spark.read.parquet(path+"dp_edges_mapped_to_long")
all_dps=(dp_longedges.select('dpid').distinct().collect())
#now make a map with these dps
try:
	inges_score_scaled={'307': -6.85e-08, '1314': '-0.00000000', '876': -2.9950000000000005e-07, '678': -0.047137160000000004, '1147': '-0.00000000', '233': '-0.00000000', '63': '-0.00000000', '598': -0.017208447499999998, '1222': -0.049995783, '820': -0.05, '556': '-0.00000000', '1141': -0.0259713875, '667': -0.049018127, '525': -0.05, '329': '-0.00000000', '1396': -0.0499559415, '86': '-0.00000000', '627': '-0.00000000', '1332': -0.05, '346': '-0.00000000', '575': -4.16e-07, '809': '-0.00000000', '529': -2.135e-07, '522': -0.05, '120': '-0.00000000', '335': '-0.00000000', '963': -1.7965000000000003e-06, '1085': -3.635e-07, '871': '-0.00000000', '810': '-0.00000000', '521': '-0.00000000', '808': '-0.00000000', '807': '-0.00000000', '1110': -0.027212217500000004, '103': '-0.00000000', '516': '-0.00000000', '1415': '-0.00000000', '21': -0.05, '1292': '-0.00000000', '1480': '-0.00000000', '1055': '-0.00000000', '611': '-0.00000000', '625': '-0.00000000', '59': -2.27e-07, '799': -6.900000000000001e-07, '1148': '-0.00000000', '95': '-0.00000000', '648': -2.7250000000000004e-07, '395': -9.100000000000001e-08, '331': -8.85e-08, '372': '-0.00000000', '75': '-0.00000000', '239': '-0.00000000', '314': -1.7400000000000002e-07, '1258': -3.42e-07, '1361': -3.205e-07, '979': -1.9e-07, '29': '-0.00000000', '1257': '-0.00000000', '1271': '-0.00000000', '135': -1.8925e-06, '806': '-0.00000000', '105': -9.850000000000002e-08, '1380': -2.92e-07, '226': '-0.00000000', '800': -0.049716186, '685': '-0.00000000', '87': -2.42e-07, '404': -0.011477924, '1316': '-0.00000000', '738': -0.0482913565, '338': '-0.00000000', '1129': '-0.00000000', '654': '-0.00000000', '336': '-0.00000000', '634': -0.05, '1076': '-0.00000000', '374': '-0.00000000', '637': -3.1050000000000003e-07, '370': '-0.00000000', '1252': '-0.00000000', '620': '-0.00000000', '229': -0.05, '376': '-0.00000000', '12': -0.05}
	off_on_score={'307': '0.00000000', '1314': '0.00000000', '876': '0.00000000', '678': '0.00000000', '1147': '0.00000000', '233': '0.00000000', '63': '0.00000000', '598': '0.26395171', '1222': '0.81332630', '820': '0.92515593', '556': '0.00000000', '1141': '0.19402744', '667': '0.67039275', '525': '0.00000000', '329': '0.00000000', '1396': '0.58308152', '86': '0.00000000', '627': '0.00000000', '1332': '0.00000000', '346': '0.00000000', '575': '0.00000000', '809': '0.00000000', '529': '0.00000000', '522': '0.69230769', '120': '0.00000000', '335': '0.00000000', '963': '0.00000000', '1085': '0.00000000', '871': '0.00000000', '810': '0.00000000', '521': '0.00000000', '808': '0.00000000', '807': '0.00000000', '1110': '0.20848449', '103': '0.00000000', '516': '0.00000000', '1415': '0.00000000', '21': '0.50094147', '1292': '0.00000000', '1480': '0.00000000', '1055': '0.00000000', '611': '0.00000000', '625': '0.00000000', '59': '0.00000000', '799': '0.00000000', '1148': '0.00000000', '95': '0.00000000', '648': '0.00000000', '395': '0.00000000', '331': '0.00000000', '372': '0.00000000', '75': '0.00000000', '239': '0.00000000', '314': '0.00000000', '1258': '0.00000000', '1361': '0.00000000', '979': '0.00000000', '29': '0.00000000', '1257': '0.00000000', '1271': '0.00000000', '135': '0.00000000', '806': '0.00000000', '105': '0.00000000', '1380': '0.00000000', '226': '0.00000000', '800': '0.01156150', '685': '0.00000000', '87': '0.00000000', '404': '0.79048189', '1316': '0.00000000', '738': '0.00000000', '338': '0.00000000', '1129': '0.00000000', '654': '0.00000000', '336': '0.00000000', '634': '0.00000000', '1076': '0.00000000', '374': '0.00000000', '637': '0.00000000', '370': '0.00000000', '1252': '0.00000000', '620': '0.00000000', '229': '1.00000000', '376': '0.00000000', '12': '0.00000000'}
	edge_aloness={'307': 2.55866e-06, '1314': 6e-10, '876': 1.91556e-05, '678': 0.010075080240000001, '1147': 7.632e-08, '233': 3.7323999999999997e-07, '63': 2.2000000000000002e-08, '598': 2.739484e-05, '1222': 3.0025499999999997e-06, '820': 4.0250000000000006e-08, '556': 1.008e-08, '1141': 5.269319999999999e-06, '667': 6.195e-08, '525': 9.80112e-06, '329': 1.3e-09, '1396': 0.00062779, '86': 2.3083e-06, '627': -0.0, '1332': 2.4029999999999997e-08, '346': 2e-10, '575': 2.4332e-07, '809': 9.899999999999999e-10, '529': 9.062449e-05, '522': 2e-10, '120': 7.487999999999999e-08, '335': 9.693e-08, '963': 1.3926e-07, '1085': 5.138e-07, '871': 9.802e-07, '810': 2.4e-10, '521': 8.260000000000001e-08, '808': 2e-10, '807': 2.1599999999999996e-09, '1110': 0.00012986534, '103': 0.0, '516': 9.384e-08, '1415': 9.6e-10, '21': 1.58249e-06, '1292': 7.0995e-07, '1480': 2.25e-09, '1055': 2.1000000000000002e-10, '611': 7.2e-10, '625': 7.752e-07, '59': 2.5215e-06, '799': 2.3376000000000002e-07, '1148': 7.532999999999999e-08, '95': 1.3200000000000002e-09, '648': 3.7456100000000005e-06, '395': 2.8732e-06, '331': 8.1048e-07, '372': 9.705e-07, '75': 1.9600000000000003e-09, '239': 5.32e-09, '314': 7.07341e-05, '1258': 0.00012006055999999998, '1361': 0.0008674741899999999, '979': 0.00017078502000000001, '29': 1e-09, '1257': 5.5726e-07, '1271': 3.78e-09, '135': 2.3423999999999999e-07, '806': 3.4083e-07, '105': 1.5541e-06, '1380': 0.00022810298, '226': 0.0, '800': 2.8379999999999997e-08, '685': 2.171e-08, '87': 0.00092332248, '404': 0.00012469275, '1316': 8.000000000000001e-11, '738': 0.1107569506, '338': 7.956e-08, '1129': 5e-11, '654': 9.072e-08, '336': 1.404e-08, '634': 6.472e-08, '1076': 2.52e-09, '374': 7.7e-10, '637': 3.5777e-07, '370': 3.7400000000000004e-08, '1252': 2.303e-08, '620': 3.084e-08, '229': 2.05968e-05, '376': 8.000000000000001e-11, '12': 4.644e-07}
	node_aloness={'307': 5.753059e-05, '1314': 0.0, '876': 0.0, '678': 0.00038741748, '1147': 6.597e-08, '233': 2.73822e-06, '63': 0.0, '598': 6.413752000000001e-05, '1222': 8.844e-08, '820': 3.174e-08, '556': 0.0, '1141': 1.070688e-05, '667': 1.12e-09, '525': 0.0, '329': 0.0, '1396': 0.00024210582, '627': 0.0, '86': 1.99698e-06, '1332': 1.359e-08, '346': 0.0, '575': 0.0, '809': 0.0, '529': 0.0, '522': 0.0, '120': 7.616e-08, '335': 6.335999999999999e-08, '963': 1.4700000000000001e-08, '1085': 7.522000000000001e-08, '871': 2.09e-07, '810': 0.0, '521': 0.0, '808': 0.0, '807': 0.0, '1110': 0.00184873, '103': 0.0, '516': 5.372e-08, '1415': 0.0, '21': 0.0, '1292': 3.9128e-07, '1480': 0.0, '1055': 0.0, '611': 0.0, '625': 2.3605e-07, '59': 1.07466e-06, '799': 0.0, '1148': 1.856e-08, '95': 0.0, '648': 1.7962399999999999e-06, '395': 4.7253599999999994e-06, '331': 4.999559999999999e-06, '372': 5.353e-07, '75': 0.0, '239': 0.0, '314': 1.213665e-05, '1258': 3.92384e-06, '1361': 0.00268950294, '979': 2.902648e-05, '29': 0.0, '1257': 1.5741200000000002e-06, '1271': 0.0, '135': 0.0, '806': 0.0, '105': 4.7893e-06, '1380': 2.8580460000000002e-05, '226': 0.0, '800': 0.0, '685': 0.0, '87': 0.0006734006, '404': 0.00016187332, '1316': 0.0, '738': 0.00207479112, '338': 1.2074100000000001e-06, '1129': 0.0, '654': 1.119e-08, '336': 0.0, '634': 0.0, '1076': 0.0, '374': 0.0, '637': 0.0, '370': 6.9138e-07, '1252': 0.0, '620': 0.0, '229': 1.12627e-06, '376': 0.0, '12': 1.776e-08}
	node_requires={'307': '0.46127480', '1314': '0.46956522', '876': '0.72939098', '678': '0.90506446', '1147': '0.38096101', '233': '0.49046950', '63': '0.52226404', '598': '0.40109333', '90901': '0.00000000', '1222': '0.99977126', '820': '1.00000000', '556': '0.27083029', '1141': '0.54356933', '667': '0.98127925', '525': '1.00000000', '329': '0.25344694', '1396': '0.99211478', '86': '0.54054112', '627': '1.00000000', '58': '0.00000000', '1332': '1.00000000', '346': '0.68421053', '1353': '0.00000000', '575': '0.61719529', '809': '0.27010622', '529': '0.66112978', '45': '0.00000000', '522': '1.00000000', '613': '0.00000000', '120': '0.45257777', '335': '0.49059516', '963': '0.31786223', '1085': '0.45721700', '871': '0.46315751', '810': '0.73134328', '521': '0.15698684', '808': '0.53389831', '807': '0.37246416', '1110': '0.92362407', '103': '1.00000000', '516': '0.47605009', '1415': '0.16627289', '21': '1.00000000', '1292': '0.41101757', '1480': '0.29030085', '1055': '0.58490566', '611': '0.33570160', '625': '0.45981027', '59': '0.35521119', '799': '0.23005003', '1148': '0.39859391', '95': '0.41564792', '648': '0.39767413', '395': '0.49774761', '331': '0.49140008', '121': '0.00000000', '50': '0.00000000', '372': '0.13918850', '75': '0.34387910', '33': '0.00000000', '239': '0.18276565', '314': '0.25968190', '56': '0.00000000', '1258': '0.44926904', '216': '0.00000000', '1361': '0.67345928', '979': '0.52612566', '29': '0.47001091', '1257': '0.32528550', '1271': '0.50104885', '104': '0.00000000', '135': '0.68342842', '806': '0.61541959', '105': '0.43551996', '1380': '0.66213613', '226': '0.25714286', '800': '0.96313685', '685': '0.47574283', '87': '0.25051251', '404': '1.00000000', '1316': '0.28717949', '738': '0.99642929', '338': '0.36151481', '1129': '0.25935829', '416': '0.00000000', '654': '0.36797635', '336': '0.56553826', '24': '0.00000000', '634': '1.00000000', '35': '0.00000000', '1076': '0.41052632', '374': '0.02938753', '637': '0.47735495', '370': '0.62050391', '1252': '0.32910221', '100': '0.00000000', '620': '0.31475980', '229': '1.00000000', '376': '0.77697842', '12': '0.47231004'}
	#for this , if dp is not there, then a negative score(-0.3) and or if score is 0, then also a negative score
	node_cover={'738': '0.48516011', '1361': '0.18757525', '678': '0.23821062', '87': '0.18132036'} 
	edge_requires={'307': '0.48918157', '1314': '0.48387097', '876': '0.72951973', '678': '0.90029594', '1147': '0.40211312', '233': '0.55173930', '63': '0.52449220', '598': '0.42256835', '90901': '0.00000000', '1222': '0.99988819', '820': '1.00000000', '556': '0.26640287', '1141': '0.60389694', '667': '0.98189614', '525': '1.00000000', '329': '0.25188188', '1396': '0.99689275', '86': '0.56380045', '627': '1.00000000', '58': '0.00000000', '1332': '1.00000000', '346': '0.68345324', '1353': '0.00000000', '575': '0.61109152', '809': '0.28196147', '529': '0.69013176', '45': '0.00000000', '522': '1.00000000', '613': '0.00000000', '120': '0.45723138', '335': '0.49530556', '963': '0.34429265', '1085': '0.45257758', '871': '0.46946386', '810': '0.75862069', '521': '0.19598807', '808': '0.55940594', '807': '0.38808777', '1110': '0.94257206', '103': '1.00000000', '516': '0.48762887', '1415': '0.18817006', '21': '1.00000000', '1292': '0.43677913', '1480': '0.28962428', '1055': '0.61538462', '611': '0.34274586', '625': '0.44512995', '59': '0.40611654', '799': '0.23477398', '1148': '0.47160848', '95': '0.42243646', '648': '0.44674914', '395': '0.47309209', '331': '0.52648833', '121': '0.00000000', '50': '0.00000000', '372': '0.21588729', '75': '0.35309793', '33': '0.00000000', '239': '0.17836626', '314': '0.30009421', '56': '0.00000000', '1258': '0.45547905', '216': '0.00000000', '1361': '0.67728849', '979': '0.58484545', '29': '0.49403341', '1257': '0.33159876', '1271': '0.52867133', '104': '0.00000000', '135': '0.68103351', '806': '0.67594066', '105': '0.48213421', '1380': '0.66337554', '226': '0.24242424', '800': '0.97934363', '685': '0.47745883', '87': '0.32998516', '404': '1.00000000', '1316': '0.32258065', '738': '0.99853502', '338': '0.44279641', '1129': '0.27891156', '416': '0.00000000', '654': '0.37461066', '336': '0.59264613', '24': '0.00000000', '634': '1.00000000', '35': '0.00000000', '1076': '0.40460721', '374': '0.02984625', '637': '0.47656548', '370': '0.62566223', '1252': '0.32660479', '100': '0.00000000', '620': '0.32936135', '229': '1.00000000', '376': '0.76612903', '12': '0.48471496'}
	edge_cover= {'678': '0.17883929', '1361': '0.17522058', '738': '0.88244182', '979': '0.04210612', '87': '0.16982921'}
except:
	print("e")

all_dps=list(map(lambda x:x[0],all_dps))
try:
	#8 different scores-
	print(len(all_dps))
	dp_map=defaultdict(list)
	for dp in all_dps:
		if(dp in inges_score_scaled and float(inges_score_scaled[dp])!=0):
				dp_map[dp].append(float(inges_score_scaled[dp]))
		else:
			dp_map[dp].append(0.0) #the nonexisent dps here are given negative score in requires_score
		if(dp in off_on_score):
			dp_map[dp].append(float(off_on_score[dp]))
		else:
			dp_map[dp].append(0.0)
		if(dp in edge_aloness):
			dp_map[dp].append(float(edge_aloness[dp]))
		else:
			dp_map[dp].append(0.0)
		if(dp in node_aloness):
			dp_map[dp].append(float(node_aloness[dp]))
		else:
			dp_map[dp].append(0.0)
		if(node_requires[dp]!=0):
			dp_map[dp].append(float(node_requires[dp]))
		else:
			dp_map[dp].append(-0.3)
		if(dp in node_cover):
			dp_map[dp].append(float(node_cover[dp]))
		else:
			dp_map[dp].append(0.0)
		if(edge_requires[dp]!=0):
			dp_map[dp].append(float(edge_requires[dp]))
		else:
			dp_map[dp].append(-0.3)
		if(dp in edge_cover):
			dp_map[dp].append(float(edge_cover[dp]))
		else:
			dp_map[dp].append(0.0)
	dp_scores=[]
	for dp in dp_map.keys():
		curr=[dp,country]
		curr.extend(dp_map[dp])
		dp_scores.append(curr)
	Columns = ["dpid","country","inges_score_scaled","off_on_score","edge_aloness","node_aloness","node_requires","node_cover","edge_requires","edge_cover"]
	scores_df= spark.createDataFrame(data=dp_scores, schema = Columns)
	scores_df.show()
	scores_df.write.mode('overwrite').parquet(path+'/all_final_ind_scores')
	scores_df=spark.read.parquet(path+'/all_final_ind_scores')
	#
	#comp scores
	comparitive_ind_scores=spark.read.parquet(path+'dpids_with_comparitive_independent_feature_scores')
	comparitive_ind_scores=comparitive_ind_scores.withColumn('country',lit(country))
	bucket3_scores=spark.read.parquet(path+'bucket3_dpids_with_intra_inter_scores')
	bucket2_scores=spark.read.parquet(path+'bucket2_dpids_with_intra_inter_scores')
	bucket1_scores=spark.read.parquet(path+'bucket1_dpids_with_intra_inter_scores')
	#union the remaining dps in every bucket
	bucket1_rem=list(set(all_dps)-set(list(map(lambda x:x[0],bucket1_scores.select('dpid').collect()))))
	bucket2_rem=list(set(all_dps)-set(list(map(lambda x:x[0],bucket2_scores.select('dpid').collect()))))
	bucket3_rem=list(set(all_dps)-set(list(map(lambda x:x[0],bucket3_scores.select('dpid').collect()))))
	bucket1_rem_list=[]
	for dp in bucket1_rem:
		bucket1_rem_list.append([dp,0.0,0.0,0.0])
	bucket2_rem_list=[]
	for dp in bucket2_rem:
		bucket2_rem_list.append([dp,0.0,0.0,0.0])
	bucket3_rem_list=[]
	for dp in bucket3_rem:
		bucket3_rem_list.append([dp,0.0,0.0,0.0])
	if(len(bucket1_rem_list)):
		bucket1_rem_df=spark.createDataFrame(data=bucket1_rem_list,schema=bucket1_scores.columns)
	if(len(bucket2_rem_list)):
		bucket2_rem_df=spark.createDataFrame(data=bucket2_rem_list,schema=bucket2_scores.columns)
	if(len(bucket3_rem_list)):
		bucket3_rem_df=spark.createDataFrame(data=bucket3_rem_list,schema=bucket3_scores.columns)
	if(len(bucket1_rem_list)):
		bucket1_scores=bucket1_scores.union(bucket1_rem_df)
	if(len(bucket2_rem_list)):
		bucket2_scores=bucket2_scores.union(bucket2_rem_df)
	if(len(bucket3_rem_list)):
		bucket3_scores=bucket3_scores.union(bucket3_rem_df)
	all_scores=bucket1_scores.join(bucket2_scores,on=['dpid'])
	all_scores=all_scores.join(bucket3_scores,on=['dpid'])
	final_comp_scores=all_scores.join(comparitive_ind_scores,on=['dpid'])
	final_comp_scores.write.mode('overwrite').parquet(path+'/all_comp_final_scores')
	final_comp_scores=spark.read.parquet(path+'/all_comp_final_scores')
	scores_df=spark.read.parquet(path+'/all_final_ind_scores')
	final_all_scores_df=scores_df.join(final_comp_scores,on=['dpid','country'])
	final_all_scores_df.write.mode('overwrite').parquet(path+'/all_final_comp_ind_scores')
	final_all_scores_df=spark.read.parquet(path+'/all_final_comp_ind_scores')
	print(len(all_dps)==final_all_scores_df.count())
	final_all_scores_df.show()
except Exception as e:
	print('errpr',e)



#mix all countries scores-
#AUT DONE
#CHE DONE
#BEL DONE
#LUX DONE
#merged done
#NLD DONE
#DEU DONE
#ITA DONE
#ESP DONE
#UK DONE

path1="gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/graph/cleanup/country="
path2='/Prudhvi/'
path3="_Graph_cleaning_new"
countries=['CHE','BEL','LUX','merged','NLD','DEU','ITA','ESP','GBR']
all_countries_scores=spark.read.parquet(path1+'AUT'+path2+'AUT'+path3+'/all_final_comp_ind_scores')
total=all_countries_scores.count()
print('AUT',total)
for i in countries:
	path=path1+i+path2+i+path3
	curr=spark.read.parquet(path+'/all_final_comp_ind_scores').count()
	print(i,curr)
	total+=curr
	all_countries_scores=all_countries_scores.union(spark.read.parquet(path+'/all_final_comp_ind_scores'))
gen_path="gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/graph/cleanup/country=ALL/Prudhvi/DP_scoring/"
all_countries_scores.write.mode('overwrite').parquet(gen_path+'all_countries_dpid_scores')
#673
all_countries_scores=spark.read.parquet(gen_path+'all_countries_dpid_scores')
# all_countries_scores.write.mode('overwrite').parquet(gen_path+'all_countries_dpid_scores_')
# all_countries_scores=spark.read.parquet(gen_path+'all_countries_dpid_scores_')
# # 673
# all_countries_scores.union(final_all_scores_df).write.mode('overwrite').parquet(gen_path+'all_countries_dpid_scores')
print(all_countries_scores.count()==total)
#True
all_countries_scores.select('dpid').distinct().count()
# 117 


why a dp is ranked one, in comparitive scoring (wht is the vector value reasonable for the same)

dps_ind_fetus=spark.read.parquet(path+'dpid_with_comp_independent_features')
dps_ind_fetus=dps_ind_fetus.drop('total_ccs')
# the avg_datetime is the string but we need integer which is avg timestamp, basically it is the number of milliseconds from a prefixed time(jan1 1970)
dps_ind_fetus=dps_ind_fetus.drop('avg_datetime')
dps_ind_fetus=dps_ind_fetus.select('dpid','mean_cc_size', 'online_percent', 'offline_percent', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'avg_timestamp', 'percent_of_ccs_seen', 'online_skewed_percent', 'offline_skewed_percent', 'not_skewed_percent')

countries=['AUT','CHE','BEL','LUX','merged','NLD','DEU','ITA','ESP']
path1="gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/graph/cleanup/country="
path2='/Prudhvi/'
path3="_Graph_cleaning_new"

for i in countries:
	path=path1+i+path2+i+path3
	print('COUNTRY IS ',i)
	dps_ind_fetus=spark.read.parquet(path+'dpid_with_comp_independent_features')
	dps_ind_fetus=dps_ind_fetus.drop('total_ccs')
	# the avg_datetime is the string but we need integer which is avg timestamp, basically it is the number of milliseconds from a prefixed time(jan1 1970)
	dps_ind_fetus=dps_ind_fetus.drop('avg_datetime')
	dps_ind_fetus=dps_ind_fetus.select('dpid','mean_cc_size', 'online_percent', 'offline_percent', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'avg_timestamp', 'percent_of_ccs_seen', 'online_skewed_percent', 'offline_skewed_percent', 'not_skewed_percent')
	comparitive_ind_scores=spark.read.parquet(path+'dpids_with_comparitive_independent_feature_scores')
	dps_ind_fetus.join(comparitive_ind_scores,on=['dpid']).sort(F.col('comparitive_ind_score').desc()).show(2)
	dps_ind_fetus.join(comparitive_ind_scores,on=['dpid']).sort(F.col('comparitive_ind_score').asc()).show(2)
	print('\n\n\n')
	bucket1=spark.read.parquet(path+'meaned_bucket1_comp_features')
	bucket2=spark.read.parquet(path+'meaned_bucket2_comp_features')
	bucket3=spark.read.parquet(path+'meaned_bucket3_comp_features')
	bucket3_scores=spark.read.parquet(path+'bucket3_dpids_with_intra_inter_scores')
	bucket2_scores=spark.read.parquet(path+'bucket2_dpids_with_intra_inter_scores')
	bucket1_scores=spark.read.parquet(path+'bucket1_dpids_with_intra_inter_scores')
	bucket1.join(bucket1_scores,on=['dpid']).drop('b1_scores_wrto_b2','b1_scores_wrto_b3').sort(F.col('b1_scores_wrto_b1').desc()).show(2)
	bucket1.join(bucket1_scores,on=['dpid']).drop('b1_scores_wrto_b2','b1_scores_wrto_b3').sort(F.col('b1_scores_wrto_b1').asc()).show(2)
	print('\n\n\n')
	bucket2.join(bucket2_scores,on=['dpid']).drop('b2_scores_wrto_b1','b2_scores_wrto_b3').sort(F.col('b2_scores_wrto_b3').desc()).show(2)
	bucket2.join(bucket2_scores,on=['dpid']).drop('b2_scores_wrto_b1','b2_scores_wrto_b3').sort(F.col('b2_scores_wrto_b3').asc()).show(2)
	print('\n\n\n')
	bucket3.join(bucket3_scores,on=['dpid']).drop('b3_scores_wrto_b2','b3_scores_wrto_b1').sort(F.col('b3_scores_wrto_b3').desc()).show(2)
	bucket3.join(bucket3_scores,on=['dpid']).drop('b3_scores_wrto_b2','b3_scores_wrto_b1').sort(F.col('b3_scores_wrto_b3').asc()).show(2)



#COMP FEATURES-


all_countries_scores=spark.read.parquet(gen_path+'all_countries_dpid_scores')
all_countries_scores=all_countries_scores.drop('b1_scores_wrto_b2', 'b1_scores_wrto_b3','b2_scores_wrto_b1', 'b2_scores_wrto_b3','b3_scores_wrto_b2', 'b3_scores_wrto_b1').withColumnRenamed('b1_scores_wrto_b1','bucket1_score').withColumnRenamed('b2_scores_wrto_b2','bucket2_score').withColumnRenamed('b3_scores_wrto_b3','bucket3_score')
all_countries_scores=all_countries_scores.withColumn('final_score',F.col('inges_score_scaled')+F.col('off_on_score')+F.col('edge_aloness')+F.col('node_aloness')+F.col('node_requires')+F.col('node_cover')+F.col('edge_requires')+F.col('edge_cover')+F.col('bucket1_score')+F.col('bucket2_score')+F.col('bucket3_score')+F.col('comparitive_ind_score'))


def scalecolumn(df,col):
		from pyspark.ml.feature import MinMaxScaler
		from pyspark.ml.feature import VectorAssembler
		from pyspark.ml import Pipeline
		from pyspark.sql.functions import udf
		from pyspark.sql.types import DoubleType
		# UDF for converting column type from vector to double type
		unlist = udf(lambda x: round(float(list(x)[0]),3), DoubleType())
		assembler = VectorAssembler(inputCols=[col],outputCol=col+"_Vect")
		# MinMaxScaler Transformation
		scaler = MinMaxScaler(inputCol=col+"_Vect", outputCol=col+"_Scaled")
		# Pipeline of VectorAssembler and MinMaxScaler
		pipeline = Pipeline(stages=[assembler, scaler])
		# Fitting pipeline on dataframe
		returndf= pipeline.fit(df).transform(df).withColumn(col+"_Scaled", unlist(col+"_Scaled")).drop(col+"_Vect")
		return returndf
# dumm=scalecolumn(,'avg_edgescore')
# all_countries_scores.groupby('dpid','country')
countries=['AUT', 'CHE', 'BEL', 'LUX','MERGED', 'NLD', 'DEU', 'ITA', 'ESP']
for ind,i in enumerate(countries):
	curr=all_countries_scores.filter(F.col('country')==i)
	scaled=scalecolumn(curr,'final_score')
	if(ind==0):
		final_countries_score=scaled 
	else:
		final_countries_score=final_countries_score.union(scaled)

final_countries_score=final_countries_score.drop('final_score')
final_countries_score.write.mode('overwrite').parquet(gen_path+'all_countries_dpid_scores_with_final_scores')
final_countries_score=spark.read.parquet(gen_path+'all_countries_dpid_scores_with_final_scores')
# 673

# final_all_scores_df=final_all_scores_df.drop('b1_scores_wrto_b2', 'b1_scores_wrto_b3','b2_scores_wrto_b1', 'b2_scores_wrto_b3','b3_scores_wrto_b2', 'b3_scores_wrto_b1').withColumnRenamed('b1_scores_wrto_b1','bucket1_score').withColumnRenamed('b2_scores_wrto_b2','bucket2_score').withColumnRenamed('b3_scores_wrto_b3','bucket3_score')
# final_all_scores_df=final_all_scores_df.withColumn('final_score',F.col('inges_score_scaled')+F.col('off_on_score')+F.col('edge_aloness')+F.col('node_aloness')+F.col('node_requires')+F.col('node_cover')+F.col('edge_requires')+F.col('edge_cover')+F.col('bucket1_score')+F.col('bucket2_score')+F.col('bucket3_score')+F.col('comparitive_ind_score'))
# scaled=scalecolumn(final_all_scores_df,'final_score').drop('final_score')
# # final_countries_score.write.mode('overwrite').parquet(gen_path+'all_countries_dpid_scores_with_final_scores_')
# final_countries_score=spark.read.parquet(gen_path+'all_countries_dpid_scores_with_final_scores_')
# final_countries_score.union(scaled).write.mode('overwrite').parquet(gen_path+'all_countries_dpid_scores_with_final_scores')
# final_countries_score=spark.read.parquet(gen_path+'all_countries_dpid_scores_with_final_scores')
final_countries_score.select('dpid').distinct().count()
# 117 
final_countries_score.select('country').distinct().count()
#10

#make single score for a dp
individual_dp_scores=final_countries_score.select('dpid','country','final_score_Scaled')
all_dps=individual_dp_scores.select('dpid').distinct().collect()
all_dps=list(map(lambda x:x[0],all_dps))
dpid_finalscore=defaultdict(int)
countries=['AUT','CHE','BEL','LUX','merged','NLD','DEU','ITA','ESP']

for ind,dp in enumerate(all_dps): #108
	country_scores=individual_dp_scores.filter(F.col('dpid')==dp).groupby('dpid').agg(F.map_from_entries(F.collect_list(F.struct("country","final_score_Scaled"))).alias("map")).select('map').collect()[0][0]
	print(dp,country_scores,ind)
	total_count=0
	score=0
	for i in country_scores.keys():
		if(i=='MERGED'):
			i='merged'
		path=path1+i+path2+i+path3
		edges_count=spark.read.parquet(path+'dpids_with_its_edges').select('dpid','vertex1','vertex1type','vertex2','vertex2type','timestamp').filter(F.col('dpid')==dp).distinct().count()
		print(dp,i,edges_count)
		total_count+=edges_count
		if(i=='merged'):
			i='MERGED'
		score+=(country_scores[i]*edges_count)
	dpid_finalscore[dp]=(score/total_count)

print(dpid_finalscore)
{'307': 0.5347462685143234, '63': 0.4803518875954588}
dpid_scores=[]
for i in dpid_finalscore.keys():
	dpid_scores.append([i,dpid_finalscore[i]])

print(len(dpid_scores))
dpid_score_df=spark.createDataFrame(data=dpid_scores,schema=['dpid','score'])
def scalecolumn(df,col):
		from pyspark.ml.feature import MinMaxScaler
		from pyspark.ml.feature import VectorAssembler
		from pyspark.ml import Pipeline
		from pyspark.sql.functions import udf
		from pyspark.sql.types import DoubleType
		# UDF for converting column type from vector to double type
		unlist = udf(lambda x: round(float(list(x)[0]),3), DoubleType())
		assembler = VectorAssembler(inputCols=[col],outputCol=col+"_Vect")
		# MinMaxScaler Transformation
		scaler = MinMaxScaler(inputCol=col+"_Vect", outputCol=col+"_scaled")
		# Pipeline of VectorAssembler and MinMaxScaler
		pipeline = Pipeline(stages=[assembler, scaler])
		# Fitting pipeline on dataframe
		returndf= pipeline.fit(df).transform(df).withColumn(col+"_scaled", unlist(col+"_scaled")).drop(col+"_Vect")
		return returndf
dpid_score_df_scaled=scalecolumn(dpid_score_df,'score')
dpid_score_df_scaled.write.mode('overwrite').parquet(gen_path+'/all_dpids_scored')
dpid_score_df_scaled=spark.read.parquet(gen_path+'/all_dpids_scored')
dpid_score_df_scaled.count()
#108
dpid_score_df_scaled.sort(F.col('score_scaled').desc()).show()

+----+------------------+------------+                                          
|dpid|             score|score_scaled|
+----+------------------+------------+
| 820|0.9999704533790085|         1.0|
| 522|0.9998619474403767|         1.0|
| 229|0.8556428513264316|       0.856|
| 667|0.8158680430941943|       0.816|
|  21| 0.803318517270363|       0.803|
|1222|0.7761331818185017|       0.776|
| 738|0.7714551433838209|       0.771|
| 404|0.7544222197885897|       0.754|
| 678|0.6927129366479486|       0.693|
| 800|0.6698231529213641|        0.67|
| 634|0.6606521491288024|       0.661|
|1332| 0.652235387247095|       0.652|
| 525|0.6371693016058004|       0.637|
|1396|0.6160199192289934|       0.616|
| 876|0.6043991853548965|       0.604|
|1110|0.6020221374332352|       0.602|
|1141|0.5780114426036576|       0.578|
| 135|0.5594003103183334|       0.559|
|1361|0.5524272440816078|       0.552|
| 307|0.5347462685143234|       0.535|
+----+------------------+------------+


all_countries_scores.write.csv('all_countries_dpid_scores.csv')
csv=spark.read.csv('all_countries_dpid_scores.csv')
import csv
with open('all_countries_dpid_scores.csv', 'r') as csvfile:
    reader = csv.reader(csvfile, skipinitialspace=True)
    for row in reader:
        print(row)
