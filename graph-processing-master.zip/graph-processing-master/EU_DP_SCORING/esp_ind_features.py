import pyspark.sql.functions as F
from pyspark.sql.types import *
import networkx as nx
from graphframes import *
from pyspark.mllib.clustering import PowerIterationClustering, PowerIterationClusteringModel
from itertools import chain, combinations
import math
from operator import itemgetter
from collections import Counter
from collections import defaultdict
from os import sys, path
import community as community_louvain
from pyspark.sql.functions import lit

path="gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/graph/cleanup/country=ESP/Prudhvi/ESP_Graph_cleaning_new"
edges_path_nontube="gs://gcs-ireland-all-eu-daap-idu-bootstrap-internal-zeotap-com/run__20201123/zeoGraphEdges_idu_524/country=ESP"
edges_path_tube="gs://gcs-ireland-all-eu-daap-idu-bootstrap-internal-zeotap-com/run__20201123/tubeGraphEdges_idu_524/country=ESP"
edges_path_nontube_req=path+"edges_nontube_with_askedtypes"

edges_distinct_nontube_path=path+"/edges_distinct_nontube"
edges_distinct_tube_path=path+"/edges_distinct_tube"
vertices_from_edges_tube_path=path+"/vertices_from_edges_distinct_tube"
vertices_from_edges_nontube_path=path+"/vertices_from_edges_distinct_nontube"
total_vertices_path= path +"/total_vertices_tubeandnontube"
long_mapped_ids_path = path+"data/all_ids_with_long_mapping"
all_vertices_path=path+"/final_vertices_to_apply_cc"
all_edges_path=path+"/final_edges_to_apply_cc"


try:
	edges_tube=spark.read.parquet(edges_path_tube)
	edges_nontube =spark.read.parquet(edges_path_nontube_req)
	# DataFrame[vertex1: string, vertex1type: string, vertex2: string, vertex2type: string, dpid: int, timestamp: bigint, recordType: string]
	def map_to_long(df):
		long_mapped_ids=spark.read.parquet(long_mapped_ids_path)
		intermediate_edges = long_mapped_ids.join(df , [long_mapped_ids.id == df.vertex1 , long_mapped_ids.type == df.vertex1type]).drop("id","type").withColumnRenamed("long_id" , "src_long_id")
		long_edges=long_mapped_ids.join(intermediate_edges , [long_mapped_ids.id == intermediate_edges.vertex2 , long_mapped_ids.type == intermediate_edges.vertex2type]).drop("id","type").withColumnRenamed("long_id" , "dst_long_id")
		return long_edges
	long_edges_tube=map_to_long(edges_tube)
	long_edges_nontube=map_to_long(edges_nontube)
	long_edges_tube.write.mode('overwrite').parquet(path+'/long_edges_tube')
	long_edges_nontube.write.mode('overwrite').parquet(path+'/long_edges_nontube')
	long_edges_tube=spark.read.parquet(path+'/long_edges_tube')
	# 7156935317   (distinct count)
	long_edges_nontube=spark.read.parquet(path+'/long_edges_nontube')
	# 1686456610  (distinct count)
	#first union over long ids and then join remaining cols
	dp_tube=long_edges_tube.select('dpid','timestamp','src_long_id','dst_long_id').distinct()
	# 7,156,935,317
	dp_nontube=long_edges_nontube.select('dpid','timestamp','src_long_id','dst_long_id').distinct()
	dp_tube.union(dp_nontube).distinct().write.mode('overwrite').parquet(path+"dpids_with_its_edges_longs")
	dp_longs=spark.read.parquet(path+'dpids_with_its_edges_longs')
	# 8843391853
dp_longs.join(long_mapped_ids,long_mapped_ids.long_id==dp_longs.src_long_id).drop('long_id').withColumnRenamed('id','vertex1').withColumnRenamed('type','vertex1type').write.mode('overwrite').parquet(path+'intermdpids_edges')
interm=spark.read.parquet(path+'intermdpids_edges')
interm.join(long_mapped_ids,long_mapped_ids.long_id==interm.dst_long_id).withColumnRenamed('id','vertex2').withColumnRenamed('type','vertex2type').write.mode('overwrite').parquet(path+'dpids_with_its_edges')
#map to long
dp_edges=spark.read.parquet(path+'dpids_with_its_edges').withColumnRenamed('src_long_id','src').withColumnRenamed('dst_long_id','dst').drop('long_id')
# 8843391853 
try:
	#repeated step 
	long_mapped_ids=spark.read.parquet(long_mapped_ids_path)
	intermediate_edges = long_mapped_ids.join(dp_edges , [long_mapped_ids.id == dp_edges.vertex1 , long_mapped_ids.type == dp_edges.vertex1type]).drop("id","type").withColumnRenamed("long_id" , "src_long_id")
	long_mapped_ids.join(intermediate_edges , [long_mapped_ids.id == intermediate_edges.vertex2 , long_mapped_ids.type == intermediate_edges.vertex2type]).drop("id","type").withColumnRenamed("long_id" , "dst_long_id").write.mode("overwrite").parquet(path+"dp_edges_mapped_to_long")
	dp_longedges= spark.read.parquet(path+"dp_edges_mapped_to_long").drop('src','dst')
	c=dp_longedges.count()
	# 8843391853
	all_dps_count=(dp_longedges.select('dpid').distinct().count())
	# 95
	#all required edges
	all_edges=spark.read.parquet(all_edges_path)	
	dp_longedges.join(all_edges,[all_edges.src==dp_longedges.src_long_id,all_edges.dst==dp_longedges.dst_long_id]).drop('src_long_id','dst_long_id').write.mode('overwrite').parquet(path+'dp_req_edges_with_longs')
	#IT NEEDS TO BE DONE FOR SRC=DST AND DST=SRC ALSO 
	dp_req_edges=spark.read.parquet(path+'dp_req_edges_with_longs')		
try:
	dp_req_edges=dp_req_edges.withColumn("datetime",F.from_unixtime(F.col("timestamp")))
	total=all_edges.count()
	print("total_edges",total)
	# total_edges  1,689,391,301  
	dp_req_count=dp_req_edges.count()
	# 6478555559 - since an edge is seen by multiple dps and also timestamps
	total_fromdps=dp_req_edges.select('src','dst').distinct().count()
try:
	print(total_fromdps==total)
	# True - as expected 
	dps=dp_req_edges.select('dpid').distinct().collect()
	dps=list(map(lambda x:x[0],dps))
	required_dps_count=len(dps)
	print(required_dps_count,"req")
	#90 req 
	# THE REMAINING 52-32 ARE ANYWAYS NEGATIVE SCORED IN DPCOVER CODE 
	#now give score 
	# score based on ingestion percent-
	dp_score_inges=defaultdict(int)
	for dp in dps:
		dp_score_inges[dp]="{:.8f}".format(float( -(dp_req_edges.filter(F.col('dpid')==dp).where(F.col('datetime').like("%00:00:00")).distinct().count()/dp_req_edges.filter(F.col('dpid')==dp).distinct().count()) ))
	# now the actual score based on ingestion percent shouldnt be very high so scale it down by alpha 
	alpha=0.05
	for i in dp_score_inges.keys():
		if(float(dp_score_inges[i])!=0):
			dp_score_inges[i]=alpha*float(dp_score_inges[i])
	# {'307': -2.505e-07, '63': -9.3e-08, '1396': -0.049956364, '335': '-0.00000000', '1085': -2.62e-07, '810': '-0.00000000', '1357': '-0.00000000', '21': -0.05, '1380': -4.18e-07, '1129': '-0.00000000', '374': '-0.00000000', '376': '-0.00000000', '1314': '-0.00000000', '598': -0.0033494790000000007, '1222': -0.05, '667': -0.0497286295, '86': -1.505e-07, '522': -0.05, '521': '-0.00000000', '807': '-0.00000000', '1110': -0.025901657500000005, '322': '-0.00000000', '1055': '-0.00000000', '625': -3.2450000000000003e-07, '1148': '-0.00000000', '648': -6.945000000000001e-07, '1258': -2.43e-07, '685': -3.385e-07, '738': -0.04819894450000001, '637': -3.185e-07, '1147': '-0.00000000', '68': '-0.00000000', '820': -0.05, '1141': -0.0309165245, '525': -0.05, '575': '-0.00000000', '516': '-0.00000000', '1415': '-0.00000000', '611': '-0.00000000', '95': '-0.00000000', '395': '-0.00000000', '331': -2.855e-07, '372': '-0.00000000', '239': '-0.00000000', '979': -2.48e-07, '135': -2.0700000000000001e-07, '105': -1.86e-07, '1316': '-0.00000000', '24': '-0.00000000', '678': -0.048945838000000005, '233': -2.76e-07, '556': '-0.00000000', '1332': -0.05, '346': '-0.00000000', '120': '-0.00000000', '871': -6.765e-07, '799': '-0.00000000', '75': '-0.00000000', '314': -2.425e-07, '29': '-0.00000000', '806': '-0.00000000', '87': -2.675e-07, '404': -0.0235261005, '338': -3.13e-07, '654': '-0.00000000', '634': -0.05, '1076': '-0.00000000', '370': -3.01e-07, '1252': -5.33e-07, '12': -0.05, '876': -2.41e-07, '1348': '-0.00000000', '329': '-0.00000000', '809': '-0.00000000', '529': -2.5399999999999997e-07, '45': '-0.00000000', '1443': '-0.00000000', '963': -3.3100000000000004e-07, '808': '-0.00000000', '1292': '-0.00000000', '1480': '-0.00000000', '59': -3.505e-07, '1361': -2.8600000000000005e-07, '1257': '-0.00000000', '1271': '-0.00000000', '800': -0.0499182235, '336': '-0.00000000', '35': '-0.00000000', '620': '-0.00000000', '229': -0.05}
	#score based on no.of off-on links given
	#again it is seen only on all_edges becoz thats what is finnaly useful to us-
	dp_score_off_on=defaultdict(int)
	for dp in dps:
		dp_score_off_on[dp]="{:.8f}".format(float( (  (dp_req_edges.filter(F.col('dpid')==dp).filter(F.col("vertex1type")[0:2] == "id").filter(F.col("vertex2type")[0:2] != "id").count()+dp_req_edges.filter(F.col('dpid')==dp).filter(F.col("vertex2type")[0:2] == "id").filter(F.col("vertex1type")[0:2] != "id").count()) / dp_req_edges.filter(F.col('dpid')==dp).distinct().count() )))
	#  {'307': '0.00000000', '63': '0.00000000', '1396': '0.58213318', '335': '0.00000000', '1085': '0.00000000', '810': '0.00000000', '1357': '0.00000000', '21': '0.71466396', '1380': '0.00000000', '1129': '0.00000000', '374': '0.00000000', '376': '0.00000000', '1314': '0.00000000', '598': '0.05041819', '1222': '0.57158991', '667': '0.66123926', '86': '0.00000000', '522': '0.81245725', '521': '0.00000000', '807': '0.00000000', '1110': '0.16278908', '322': '0.00000000', '1055': '0.00000000', '625': '0.00000000', '1148': '0.00000000', '648': '0.00000000', '1258': '0.00000000', '685': '0.00000000', '738': '0.00000000', '637': '0.00000000', '1147': '0.00000000', '68': '0.00000000', '820': '0.92608089', '1141': '0.22621401', '525': '0.00000000', '575': '0.00000000', '516': '0.00000000', '1415': '0.00000000', '611': '0.00000000', '95': '0.00000000', '395': '0.00000000', '331': '0.00000000', '372': '0.00000000', '239': '0.00000000', '979': '0.00000000', '135': '0.00000000', '105': '0.00000000', '1316': '0.00000000', '24': '0.00000000', '678': '0.00000000', '233': '0.00000000', '556': '0.00000000', '1332': '0.00000000', '346': '0.00000000', '120': '0.00000000', '871': '0.00000000', '799': '0.00000000', '75': '0.00000000', '314': '0.00000000', '29': '0.00000000', '806': '0.00000000', '87': '0.00000000', '404': '0.99279616', '338': '0.00000000', '654': '0.00000000', '634': '0.00000000', '1076': '0.00000000', '370': '0.00000000', '1252': '0.00000000', '12': '0.00000000', '876': '0.00000000', '1348': '0.00000000', '329': '0.00000000', '809': '0.00000000', '529': '0.00000000', '45': '0.00000000', '1443': '0.00000000', '963': '0.00000000', '808': '0.00000000', '1292': '0.00000000', '1480': '0.00000000', '59': '0.00000000', '1361': '0.00000000', '1257': '0.00000000', '1271': '0.00000000', '800': '0.02635138', '336': '0.00000000', '35': '0.00000000', '620': '0.00000000', '229': '1.00000000'}
	alpha=1.1 
	print("off-on done")
	#now score based on how much of links only this dp has seen (onlyme edges/all edges I saw)
	# to get only me edges 
	# grp by wrt edges 
	dp_req_edges=dp_req_edges.select('dpid','src','dst','timestamp')
	only_mes=dp_req_edges.select('dpid','src','dst').distinct().groupby('src','dst').count().filter(F.col('count')==1)
	only_mescount=only_mes.count()
	print(only_mescount<=total)
	#1239139100(out of total)
	only_mes=only_mes.withColumnRenamed('src','src_').withColumnRenamed('dst','dst_')
	df=only_mes.join(dp_req_edges,[dp_req_edges.src==only_mes.src_, dp_req_edges.dst==only_mes.dst_]).drop('src_','dst_').write.mode('overwrite').parquet(path+'only_me_edges_dpids')
	dp_only=spark.read.parquet(path+'only_me_edges_dpids')
	dp_edgeonly=dp_only.select('src','dst','dpid').distinct()
	e=dp_edgeonly.count()
	print(e==only_mescount)
	# True
	d=dp_edgeonly.select('dpid').distinct().count()
	# 89
	dp_alones=dp_edgeonly.select('dpid').distinct().collect()
	dp_alones=list(map(lambda x:x[0],dp_alones))
	dp_score_aloness=defaultdict(int)
	total_edges=dp_req_edges.select('src','dst').distinct().count()
	print(total==total_edges)
	#True
	for dp in dp_alones:
		alone_count=dp_edgeonly.filter(F.col('dpid')==dp).distinct().count()
		print(dp,alone_count)
		dp_score_aloness[dp]="{:.8f}".format(float( ( alone_count/total_edges)))
	#   {'307': '0.03469095', '63': '0.00029198', '1396': '0.00026600', '335': '0.00000139', '1085': '0.00291571', '810': '0.00000001', '1357': '0.00000000', '21': '0.00458912', '1380': '0.00013614', '1129': '0.00000000', '374': '0.00000000', '376': '0.00000059', '1314': '0.00000007', '598': '0.00042983', '1222': '0.00005773', '667': '0.00000056', '86': '0.00281274', '522': '0.00002458', '521': '0.00000010', '807': '0.00003799', '1110': '0.00105598', '322': '0.00000002', '1055': '0.00000252', '625': '0.00495124', '1148': '0.00000013', '648': '0.00019728', '1258': '0.03458308', '685': '0.00012692', '738': '0.28999064', '637': '0.00023376', '1147': '0.00003505', '68': '0.00000000', '820': '0.00000040', '1141': '0.00005269', '525': '0.00000695', '575': '0.00000137', '516': '0.00000063', '1415': '0.00000124', '611': '0.00000003', '95': '0.00000005', '395': '0.00002107', '331': '0.00577815', '372': '0.00000424', '239': '0.00000007', '979': '0.00204969', '135': '0.00116897', '105': '0.01107666', '1316': '0.00000013', '24': '0.00000002', '678': '0.04654241', '233': '0.00256948', '556': '0.00000006', '1332': '0.00000069', '346': '0.00000000', '120': '0.00000254', '871': '0.00001194', '799': '0.00005612', '75': '0.00000001', '314': '0.00340194', '29': '0.00000001', '806': '0.00000037', '87': '0.20406117', '404': '0.00027230', '338': '0.00095411', '654': '0.00000720', '634': '0.00001002', '1076': '0.00000052', '370': '0.00033211', '1252': '0.00011989', '12': '0.01353435', '876': '0.00013750', '1348': '0.00000000', '329': '0.00000002', '809': '0.00000016', '529': '0.00021226', '45': '0.00000010', '963': '0.00121938', '808': '0.00000000', '1292': '0.00001825', '1480': '0.00000021', '59': '0.00007067', '1361': '0.05794093', '1257': '0.00002278', '1271': '0.00001309', '800': '0.00250824', '336': '0.00000004', '35': '0.00000001', '620': '0.00000492', '229': '0.00186228'}
except Exception as e:
	print("errrorr",e)


try:
	total=1689391301
	e=1239139100
	all_edges=spark.read.parquet(all_edges_path)
	cc_path_tube_nontube=path+"/connected_component_tube_nontube"
	cc_final=spark.read.parquet(cc_path_tube_nontube)
	# cc_final.groupby('component').count().filter(F.col('count')>900).count()
	final_edges_to_apply_cc=spark.read.parquet(path+"/final_edges_to_apply_cc")
	max_comp_intermediate_edges=cc_final.join(final_edges_to_apply_cc, [cc_final.id == final_edges_to_apply_cc.src]).drop("id")
	max_comp_intermediate_edges=max_comp_intermediate_edges.withColumnRenamed("component","src_component")
	max_comp_intermediate_edges.join(cc_final , [cc_final.id == max_comp_intermediate_edges.dst]).drop("id").withColumnRenamed("component","dst_component").write.mode("overwrite").parquet(path+"cc_merged_with_edges")
	cc_with_edges=spark.read.parquet(path+"cc_merged_with_edges")
	edge_count=cc_with_edges.count()
	print(edge_count==total)
	# True 1689391301
	trav_edges_cc=cc_with_edges.filter(F.col('src_component')==F.col('dst_component')).drop('dst_component').withColumnRenamed('src_component','component')
	# 1689391301
	trav_edges_cc.groupby('component').count().sort(F.col('count').desc()).show()
except:
	print('errpr')
+---------+-----+                                                               
|component|count|
+---------+-----+
|   128648|25277|
|   372513|22431|
|    86221|22345|
|   224857| 9233|
|   647175| 7103|
|    35436| 6738|
|   469604| 6048|
|   635953| 5950|
|   409835| 5813|
|    32864| 5571|
|  2233923| 5197|
|  1091082| 5122|
|   359196| 4650|
|    85300| 4493|
|  1361081| 4472|
|   213675| 4318|
|  4998181| 4242|
|   836737| 4208|
|   323330| 4091|
|  4768240| 4066|
+---------+-----+

df=trav_edges_cc.groupby('component').agg( F.collect_list( F.struct(F.col('src'),F.col('dst'))).alias('edges'))
# 125596759 
df.write.mode('overwrite').parquet(path+'/df_edgebcs_interm')
df_=spark.read.parquet(path+'/df_edgebcs_interm')
	#DF WITH COMPONENT-EDGE_LIST
	# def getcount(x):
	# 	return x['component'],len(x['edges'])
	# cdf=df.rdd.map(lambda x:getcount(x)).toDF(['comp','count'])
	# cdf.select('count').groupBy().sum().collect()
	# # 109776 - sum of counts
	# cdf=cdf.withColumnRenamed('count','countcdf')
	# test=cdf.join(interm,interm.component==cdf.comp).drop('comp')
	# #2657 
	# test.filter(F.col('countcdf')!=F.col('count')).count()
try:
	def bc_edge(x):
		edges=list(map(lambda x:tuple(x),x['edges']))
		graph_nx=nx.from_edgelist(edges)
		edge_bcs=nx.edge_betweenness_centrality(graph_nx)
		return x['component'],edge_bcs
	print("bcedge start")
	df_.rdd.map(lambda x: bc_edge(x)).toDF([ "component","edges_with_bcs"]).write.mode('overwrite').parquet(path+'edgesbcs_interm')
	interm=spark.read.parquet(path+'edgesbcs_interm')
	#interm.count()
	# 125303171
	df2=df_.join(interm,on=['component'],how='left_anti')    
	df2.write.mode('overwrite').parquet(path+'/df2_edgesbcs_interm')
	df2=spark.read.parquet(path+'/df2_edgesbcs_interm')
	# 293588 
  	df2.rdd.map(lambda x: bc_edge(x)).toDF([ "component","edges_with_bcs"]).write.mode('overwrite').parquet(path+'edgesbcs_interm_2')
	interm2=spark.read.parquet(path+'edgesbcs_interm_2')
	interm=interm.union(interm2)
	interm_=interm.select("component",F.explode("edges_with_bcs"))
	interm_.select('component','key.*','value').withColumnRenamed('_1','src').withColumnRenamed('_2','dst').withColumnRenamed('value','edge_bc').write.mode('overwrite').parquet(path+'all_edges_with_their_edgebcs')
	x=spark.read.parquet(path+'all_edges_with_their_edgebcs')
	edge_bcs_count=x.count()
	print(edge_bcs_count,total)
	# 1393523331 1689391301 coz it counted all undirected edges only and in the dataset there are b0th a-b and b-a edges
	# now use the dp_edgeonly df here 
except:
	print('errr')

try:
	x=x.withColumnRenamed('src','src_').withColumnRenamed('dst','dst_')
	dp_only=spark.read.parquet(path+'only_me_edges_dpids')
	dp_edgeonly=dp_only.select('src','dst','dpid').distinct()
	curr=dp_edgeonly.join(x,[x.src_==dp_edgeonly.src,x.dst_==dp_edgeonly.dst]).drop('src_','dst_')
	#    remaining are revrse direction edges
	e=1239139100
	curr=curr.union(dp_edgeonly.join(x,[x.dst_==dp_edgeonly.src,x.src_==dp_edgeonly.dst]).drop('src_','dst_'))
	curr.write.mode('overwrite').parquet(path+'aone_edges_with_edgebc')
	aloneedges=spark.read.parquet(path+'aone_edges_with_edgebc')
	alone_dp_count=aloneedges.count()
	print(alone_dp_count==e,alone_dp_count-e,e,alone_dp_count)
	#True 0 1239139100 1239139100 
	# GIVE BC VALUE FOR ALL THESE INTRAV EDGES AS dA.dB/(dA+dB)**2 
	# FINAL BC VALUE IS IF 4 EDGES BETWEEN 2 CLUSTERS, THOSE 4 WILL SCALED DOWN BY 4
	aloneedges=aloneedges.withColumn('edge_score',1/F.col('edge_bc'))
	#scale the score between 0 -1
try:
	def scalecolumn(df,col):
		from pyspark.ml.feature import MinMaxScaler
		from pyspark.ml.feature import VectorAssembler
		from pyspark.ml import Pipeline
		from pyspark.sql.functions import udf
		from pyspark.sql.types import DoubleType
		# UDF for converting column type from vector to double type
		unlist = udf(lambda x: round(float(list(x)[0]),3), DoubleType())
		assembler = VectorAssembler(inputCols=[col],outputCol=col+"_Vect")
		# MinMaxScaler Transformation
		scaler = MinMaxScaler(inputCol=col+"_Vect", outputCol=col+"_Scaled")
		# Pipeline of VectorAssembler and MinMaxScaler
		pipeline = Pipeline(stages=[assembler, scaler])
		# Fitting pipeline on dataframe
		returndf= pipeline.fit(df).transform(df).withColumn(col+"_Scaled", unlist(col+"_Scaled")).drop(col+"_Vect")
		return returndf
	dpid_with_edgescore=aloneedges.groupby('dpid').agg(F.avg(F.col('edge_score')).alias('avg_edgescore'))
	#now get avg edge_score for a dpid 
	dumm=scalecolumn(dpid_with_edgescore,'avg_edgescore')
	dumm.write.mode('overwrite').parquet(path+'dpid_with_avg_edgescore_scaled')
	dpids_edgescore=spark.read.parquet(path+'dpid_with_avg_edgescore_scaled')
	dpids_edgescore=dpids_edgescore.collect()
	#DEFINE DP_SCORE_ALONESS 
	for dp,_,score in dpids_edgescore:
		dp_score_aloness[dp]=score*float(dp_score_aloness[str(dp)])
except Exception as e:
	print("No",e)
# {'307': 0.00031221855, '63': 1.16792e-06, '1396': 8.0332e-05, '335': 4.5870000000000006e-08, '1085': 1.166284e-05, '810': 2.0000000000000002e-11, '1357': 0.0, '21': 0.0, '1380': 8.44068e-06, '1129': 0.0, '374': 0.0, '376': 1.7699999999999999e-09, '1314': 3.5000000000000003e-10, '598': 2.7079290000000003e-05, '1222': 6.29257e-06, '667': 5.6000000000000005e-09, '86': 1.6876440000000003e-05, '522': 1.3027399999999999e-06, '521': 3e-10, '807': 1.1397000000000001e-07, '1110': 0.00019218835999999998, '322': 4.0000000000000004e-11, '1055': 2.772e-08, '625': 4.9512400000000004e-05, '1148': 5.2e-10, '648': 1.3809600000000002e-06, '1258': 0.00020749848, '685': 3.8076000000000003e-07, '738': 0.28999064, '637': 1.1688000000000001e-06, '1147': 1.0515e-07, '68': 0.0, '820': 3.5999999999999996e-09, '1141': 9.484199999999999e-07, '525': 1.39e-08, '575': 2.74e-09, '516': 1.26e-09, '1415': 3.72e-09, '611': 9e-11, '95': 1e-10, '395': 6.321e-08, '331': 2.889075e-05, '372': 1.272e-08, '239': 7e-11, '979': 2.0496899999999998e-06, '135': 1.636558e-05, '105': 0.00017722656, '1316': 2.6e-10, '24': 4.0000000000000004e-11, '678': 0.026715343339999996, '233': 1.541688e-05, '556': 1.8e-10, '1332': 4.83e-09, '346': 0.0, '120': 8.636e-08, '871': 9.552e-08, '799': 2.2448e-07, '75': 7e-11, '314': 6.8038800000000005e-06, '29': 2.0000000000000002e-11, '806': 7.4e-10, '87': 0.00061218351, '404': 1.6338000000000001e-06, '338': 1.144932e-05, '654': 5.04e-08, '634': 2.0040000000000003e-08, '1076': 1.56e-09, '370': 1.32844e-06, '1252': 1.031054e-05, '12': 0.00112335105, '876': 4.125e-07, '1348': 0.0, '329': 0.0, '809': 3.2000000000000003e-10, '529': 8.4904e-07, '45': 3e-10, '963': 9.75504e-06, '808': 0.0, '1292': 1.2775e-07, '1480': 1.68e-09, '59': 4.2402e-07, '1361': 0.00017382279, '1257': 2.278e-07, '1271': 6.545000000000001e-08, '800': 9.029664e-05, '336': 8.000000000000001e-11, '35': 2.0000000000000002e-11, '620': 1.968e-08, '229': 1.86228e-06}
JENKS NATURAL BREAK ALGO 


#do the same for ids
# how many of new ids only this dp has seen 
try:
	# edges_tube=spark.read.parquet(edges_path_tube)
	# edges_nontube =spark.read.parquet(edges_path_nontube_req)
	# dp_tube=edges_tube.select('dpid','vertex1','vertex1type').distinct().union(edges_tube.select('dpid','vertex2','vertex2type').distinct())
	# dp_nontube=edges_nontube.select('dpid','vertex1','vertex1type').distinct().union(edges_nontube.select('dpid','vertex2','vertex2type').distinct())
	# dp_tube.union(dp_nontube).distinct().write.mode('overwrite').parquet(path+"dpids_with_its_vertices")
	# dp_vertices=spark.read.parquet(path+'dpids_with_its_vertices')
	dp_longs=spark.read.parquet(path+'dpids_with_its_edges_longs')
	dp_edges=spark.read.parquet(path+'dpids_with_its_edges').withColumnRenamed('src_long_id','src').withColumnRenamed('dst_long_id','dst').drop('long_id')
	#bioth are same only almost
	#now join with long mapped ids 
	long_mapped_ids=spark.read.parquet(long_mapped_ids_path)
	all_dps=dp_longs.select('dpid').distinct().count()
	# 95 no.of dps
	dp_edges.select('dpid','src','vertex1','vertex1type').withColumnRenamed('src','long_id').withColumnRenamed('vertex1','id').withColumnRenamed('vertex1type','type').union(dp_edges.select('dpid','dst','vertex2','vertex2type').withColumnRenamed('dst','long_id').withColumnRenamed('vertex2','id').withColumnRenamed('vertex2type','type')).distinct().write.mode('overwrite').parquet(path+'dpids_with_its_vertices_long_mapped')
	# dp_vertices.join(long_mapped_ids,[long_mapped_ids.id==dp_vertices.vertex1,long_mapped_ids.type==dp_vertices.vertex1type]).drop('vertex1','vertex1type').write.mode('overwrite').parquet(path+'dpids_with_its_vertices_long_mapped')
	dp_ids=spark.read.parquet(path+'dpids_with_its_vertices_long_mapped')	
	# 4648446431
	multiple_count=dp_ids.count()
	#4648446431 the count of all vertices seen by dps( more than actual count coz one vertex can be seen by more than one dp) 
	dp_longs=dp_ids.select('dpid','long_id')
	all_vertices=spark.read.parquet(all_vertices_path)
	allvs=all_vertices.count()
	# 1146931079
	# DataFrame[id: bigint]
	# dp_req_edges=spark.read.parquet(path+'dp_req_edges_with_longs')	
	dp_longs.join(all_vertices,all_vertices.id==dp_longs.long_id).drop('id').write.mode('overwrite').parquet(path+'dpids_with_its_final_vertices')
	dp_reqids=spark.read.parquet(path+'dpids_with_its_final_vertices')
	dpidvs=dp_reqids.count()
	# 2252221275
	distinctids=dp_reqids.select('long_id').distinct().count()
	print(allvs==distinctids)
	#True
	#now grp by wrto id 
try:
	alone_ids=dp_reqids.groupby('long_id').count().distinct().filter(F.col('count')==1)
	alone_ids=alone_ids.withColumnRenamed('long_id','long_id_').drop('count')
	alones=alone_ids.count()
	print(alones<=allvs)
	# 687984304
	alone_ids.join(dp_reqids,dp_reqids.long_id==alone_ids.long_id_).drop('long_id_').write.mode('overwrite').parquet(path+'only_me_ids_dpids')
	aloneid_dps=spark.read.parquet(path+'only_me_ids_dpids')
	print(aloneid_dps.count()==alones)
	#true
	alone_dps=aloneid_dps.select('dpid').distinct().collect()
	alone_dps=list(map(lambda x:x[0],alone_dps))
	print(len(alone_dps))
	# 87
	dpidscore_aloness=defaultdict(int)
	total_ids=dp_reqids.select('long_id').distinct().count()
	#1146931079
	#coz based on above scaling logic, 
	for dp in alone_dps:
		alone_count=aloneid_dps.filter(F.col('dpid')==dp).distinct().count()
		print(alone_count,total_ids)
		dpidscore_aloness[dp]="{:.8f}".format(float( ( alone_count/total_ids )))
except Exception as e:
	print("No",e)

 # {'307': '0.03516947', '63': '0.00032347', '1396': '0.00026010', '335': '0.00000141', '1085': '0.00428146', '810': '0.00000002', '21': '0.00705766', '1380': '0.00009414', '374': '0.00000001', '376': '0.00000068', '1314': '0.00000008', '598': '0.00032520', '1222': '0.00006147', '667': '0.00000063', '86': '0.00294185', '522': '0.00002635', '521': '0.00000011', '807': '0.00004591', '1110': '0.00082445', '322': '0.00000003', '1055': '0.00000294', '625': '0.00726663', '1148': '0.00000015', '648': '0.00019603', '1258': '0.02727575', '685': '0.00010660', '738': '0.16133339', '637': '0.00033648', '1147': '0.00004019', '68': '0.00000000', '820': '0.00000039', '1141': '0.00004958', '525': '0.00000602', '575': '0.00000087', '516': '0.00000073', '1415': '0.00000141', '611': '0.00000003', '95': '0.00000005', '395': '0.00003099', '331': '0.00620105', '372': '0.00000461', '239': '0.00000003', '979': '0.00136868', '135': '0.00137853', '105': '0.00761477', '1316': '0.00000015', '24': '0.00000002', '678': '0.04485634', '233': '0.00284315', '556': '0.00000008', '1332': '0.00000123', '346': '0.00000000', '120': '0.00000232', '871': '0.00001302', '799': '0.00007038', '75': '0.00000001', '314': '0.00237831', '29': '0.00000001', '806': '0.00000045', '87': '0.20787948', '404': '0.00026453', '338': '0.00099576', '654': '0.00000800', '634': '0.00001416', '1076': '0.00000050', '370': '0.00039204', '1252': '0.00007548', '12': '0.00139500', '876': '0.00019040', '1348': '0.00000000', '329': '0.00000001', '809': '0.00000020', '529': '0.00017856', '45': '0.00000013', '963': '0.00139336', '808': '0.00000000', '1292': '0.00001880', '1480': '0.00000026', '59': '0.00007515', '1361': '0.06460834', '1257': '0.00002370', '1271': '0.00001443', '800': '0.00462766', '336': '0.00000004', '35': '0.00000002', '620': '0.00000570', '229': '0.00289045'}
   # now same as before, the ids have to scored based on anaomaly



+-------+-------------------+-----------------+                                 
|summary|          component|            count|
+-------+-------------------+-----------------+
|  count|          131008530|        131008530|
|   mean|4.952963530763093E8|8.890317760225232|
| stddev|5.173111584289163E8|81.55838930265556|
|    min|                  0|                2|
|    25%|          106059616|                2|
|    50%|          303760146|                5|
|    75%|          723867160|               11|
|    max|         2690006301|           904814|
+-------+-------------------+-----------------+


# so node bc can be used in a similar way 
try:
	allvs=1146931079
	cc_with_edges=spark.read.parquet(path+"cc_merged_with_edges")
	# trav_edges_cc=cc_with_edges.filter(F.col('src_component')==F.col('dst_component')).drop('dst_component').withColumnRenamed('src_component','component')
	# df=trav_edges_cc.groupby('component').agg( F.collect_list( F.struct(F.col('src'),F.col('dst'))).alias('edges')).filter(F.col('component')!=515).write.mode('overwrite').parquet(path+'/intermdf')
	df_=spark.read.parquet(path+'/df_edgebcs_interm')
	print("star")
	def bc_node(x):
		edges=list(map(lambda x:tuple(x),x['edges']))
		graph_nx=nx.from_edgelist(edges)
		node_bcs=nx.betweenness_centrality(graph_nx)
		return x['component'],node_bcs
	print("bcnode start")
	df_.rdd.map(lambda x: bc_node(x)).toDF([ "component","nodes_with_bcs"]).write.mode('overwrite').parquet(path+'nodesbcs_interm')
	interm=spark.read.parquet(path+'nodesbcs_interm')
	# 95187404
	interm_=interm.select("component",F.explode("nodes_with_bcs"))
	interm_.withColumnRenamed('key','id').withColumnRenamed('value','node_bc').write.mode('overwrite').parquet(path+'all_comps_with_their_nodebcs')
	x=spark.read.parquet(path+'all_comps_with_their_nodebcs')
	node_bcs_count=x.count()
	# 1146931079
	print(node_bcs_count==allvs)
	#tRUE
except:
	print("ERRORRRR")


try:
	nodebcs=spark.read.parquet(path+'all_comps_with_their_nodebcs')
	# 7387004 as expected 
	aloneid_dps=spark.read.parquet(path+'only_me_ids_dpids')
	curr=aloneid_dps.join(nodebcs,nodebcs.id==aloneid_dps.long_id).drop('long_id')
	curr.write.mode('overwrite').parquet(path+'alone_ids_with_nodebc')
	curr=spark.read.parquet(path+'alone_ids_with_nodebc')
	node_scores=curr.withColumn('node_score',1/F.col('node_bc'))
	# dpid_with_nodescore.select('avg_nodescore').withColumn('isNull_node_bc',F.col('avg_nodescore').isNull()).where('isNull_node_bc = True').count()
	#scale the score between 0 -1
	def scalecolumn(df,col):
		from pyspark.ml.feature import MinMaxScaler
		from pyspark.ml.feature import VectorAssembler
		from pyspark.ml import Pipeline
		from pyspark.sql.functions import udf
		from pyspark.sql.types import DoubleType
		# UDF for converting column type from vector to double type
		unlist = udf(lambda x: round(float(list(x)[0]),3), DoubleType())
		assembler = VectorAssembler(inputCols=[col],outputCol=col+"_Vect")
		# MinMaxScaler Transformation
		scaler = MinMaxScaler(inputCol=col+"_Vect", outputCol=col+"_Scaled")
		# Pipeline of VectorAssembler and MinMaxScaler
		pipeline = Pipeline(stages=[assembler, scaler])
		# Fitting pipeline on dataframe
		returndf= pipeline.fit(df).transform(df).withColumn(col+"_Scaled", unlist(col+"_Scaled")).drop(col+"_Vect")
		return returndf
	dpid_with_nodescore=node_scores.groupby('dpid').agg(F.avg(F.col('node_score')).alias('avg_nodescore'))
	#now get avg node_score for a dpid 
	dpid_with_nodescore=dpid_with_nodescore.fillna({'avg_nodescore':1})
	dum=scalecolumn(dpid_with_nodescore,'avg_nodescore')
	dum.write.mode('overwrite').parquet(path+'dpid_with_avg_nodescore_scaled')
	dum=spark.read.parquet(path+'dpid_with_avg_nodescore_scaled')
	dpids_nodescore=dum.collect()
	for dp,_,score in dpids_nodescore:
		dpidscore_aloness[dp]=score*float(dpidscore_aloness[str(dp)])
# 
except Exception as e:
	print("No",e)




for bcedge of big COMPs - 
break it into communityies nd we get bc of inside community ND FOR inter community edges , the bc= m*n / (m+n)**2 -> m,n are the size of the clusters


{'307': 0.00189915138, '63': 3.8816400000000005e-06, '1396': 2.6009999999999997e-06, '335': 0.0, '1085': 4.28146e-06, '810': 0.0, '21': 0.0, '1380': 0.0, '374': 0.0, '376': 0.0, '1314': 8.000000000000001e-11, '598': 2.37396e-05, '1222': 6.147000000000001e-08, '667': 0.0, '86': 0.00294185, '522': 3.0566e-06, '521': 0.0, '807': 4.591e-08, '1110': 0.00013108755, '322': 0.0, '1055': 0.0, '625': 0.0, '1148': 0.0, '648': 9.8015e-07, '1258': 0.000109103, '685': 1.066e-07, '738': 0.0019360006799999999, '637': 6.7296e-07, '1147': 4.019e-08, '68': 0.0, '820': 1.17e-09, '1141': 1.9832000000000002e-07, '525': 0.0, '575': 0.0, '516': 0.0, '1415': 0.0, '611': 0.0, '95': 0.0, '395': 3.099e-08, '331': 9.301574999999999e-05, '372': 0.0, '239': 0.0, '979': 0.0, '135': 0.00020540096999999998, '105': 1.522954e-05, '1316': 0.0, '24': 0.0, '678': 0.00026913804000000004, '233': 2.84315e-05, '556': 0.0, '1332': 0.0, '346': 0.0, '120': 0.0, '871': 7.812e-08, '799': 7.038e-08, '75': 0.0, '314': 2.37831e-06, '29': 0.0, '806': 0.0, '87': 0.00062363844, '404': 5.2906e-07, '338': 3.584736e-05, '654': 0.0, '634': 0.0, '1076': 0.0, '370': 1.56816e-06, '1252': 7.548e-08, '12': 5.58e-06, '876': 1.9039999999999998e-07, '1348': 0.0, '329': 0.0, '809': 0.0, '529': 0.0, '45': 0.0, '963': 2.368712e-05, '808': 0.0, '1292': 1.504e-07, '1480': 0.0, '59': 1.503e-07, '1361': 0.00058147506, '1257': 1.4220000000000002e-07, '1271': 0.0, '800': 0.00025914895999999997, '336': 0.0, '35': 0.0, '620': 0.0, '229': 0.0}


#DPCOVER CODE
try:
	edges_tube=spark.read.parquet(edges_path_tube)
	edges_nontube =spark.read.parquet(edges_path_nontube_req)
	# DataFrame[vertex1: string, vertex1type: string, vertex2: string, vertex2type: string, dpid: int, timestamp: bigint, recordType: string]
	# dp_tube=edges_tube.select('dpid','vertex1','vertex1type').distinct().union(edges_tube.select('dpid','vertex2','vertex2type').distinct())
	# dp_nontube=edges_nontube.select('dpid','vertex1','vertex1type').distinct().union(edges_nontube.select('dpid','vertex2','vertex2type').distinct())
	# dp_tube.union(dp_nontube).distinct().write.mode('overwrite').parquet(path+"dpids_with_its_vertices")
	# dp_vertices=spark.read.parquet(path+'dpids_with_its_vertices')
	#now join with long mapped ids 
	long_mapped_ids=spark.read.parquet(long_mapped_ids_path)
	# multiple_count=dp_vertices.count()
	multiple_count=4648446431
	# # 4648446431 the count of all vertices seen by dps( more than actual count coz one vertex can be seen by more than one dp) 
	# dp_vertices.join(long_mapped_ids,[long_mapped_ids.id==dp_vertices.vertex1,long_mapped_ids.type==dp_vertices.vertex1type]).drop('vertex1','vertex1type').write.mode('overwrite').parquet(path+'dpids_with_its_vertices_long_mapped')
	dp_ids=spark.read.parquet(path+'dpids_with_its_vertices_long_mapped')
	# DataFrame[dpid: string, id: string, type: string, long_id: bigint]
	dp_longs=dp_ids.select('dpid','long_id')
	all_vertices=spark.read.parquet(all_vertices_path)
	allvs=all_vertices.count()
	# 1146931079
	# DataFrame[id: bigint]
	# dp_longs.join(all_vertices,all_vertices.id==dp_longs.long_id).drop('id').write.mode('overwrite').parquet(path+'dpids_with_its_final_vertices')
	dp_reqids=spark.read.parquet(path+'dpids_with_its_final_vertices')
	# DataFrame[dpid: string, long_id: bigint]
	#ALL THE ABOVE PATHS ARE WRITTEN IN DP_IND_FEATURES
	#this df contains dpid and only those ids which are present in final all vertices 
	reqdps=dp_reqids.select('dpid').distinct().count()
	print("reqdps",reqdps)
	# 90 so out of all only those dps have seen ids which are present in final vertices 
	# THE REMAINING DPS WILL BE GIVEN A NEGATIVE SCORE OF -1 
	reqvs=dp_reqids.count()
	print(reqvs>=allvs)
	# 2252221275 (coz an id can be seen by multiple dps)
	print(allvs==dp_reqids.select('long_id').distinct().count())
	# True  as expected
	#NOW DO THE STEP 1 
	#COLLECT ALL DPIDS 
	dps=dp_longs.select('dpid').distinct().collect()
	dp_score1=defaultdict(int)
	total=0
	usefuls=0
	for i in dps:
		curr_dp=i[0]
		total_seen_ids=dp_longs.filter(F.col('dpid')==curr_dp).select('long_id').distinct().count()
		useful_ids=dp_reqids.filter(F.col('dpid')==curr_dp).select('long_id').distinct().count()
		dp_score1[curr_dp]=useful_ids/total_seen_ids
		usefuls+=useful_ids
		total+=total_seen_ids  
	print(total==multiple_count)
	print(usefuls==reqvs)
	# True, True
	# total=(total ids+multiple dps=dp_longs.distinct().count())
	# usefuls= (total req ids+multiple dps=dp_reqids.count())
	for i in dp_score1.keys():
		dp_score1[i]="{:.8f}".format(float((dp_score1[i])))
	print("inital score is done")
	#REPEAT THE SAMETHING FOR EDGES ALSO
	#THE EDGES DFS RE ALREADY WRITTEN IN below CODE
	# {'307': '0.50132442', '63': '0.70075594', '1396': '0.99257856', '335': '0.46244985', '1085': '0.71598546', '810': '0.45061728', '1357': '1.00000000', '21': '1.00000000', '118': '0.00000000', '1344': '0.00000000', '1380': '0.69723002', '1129': '1.00000000', '374': '0.10434783', '376': '0.34307652', '1314': '0.38101788', '598': '0.64331269', '1222': '0.99997966', '667': '0.98141264', '86': '0.68639397', '522': '0.99994429', '521': '0.17712915', '807': '0.53683083', '1110': '0.89635779', '322': '0.65267176', '1055': '0.53966754', '625': '0.48423637', '1148': '0.50252101', '648': '0.59175383', '1258': '0.38485236', '685': '0.57131102', '738': '0.99365640', '637': '0.70427796', '1147': '0.58615139', '68': '0.50000000', '820': '1.00000000', '1141': '0.53353628', '525': '1.00000000', '575': '0.61065896', '516': '0.39398585', '1415': '0.58344687', '611': '0.68000000', '95': '0.46818923', '395': '0.39432335', '331': '0.18321024', '372': '0.12029256', '239': '0.33102972', '979': '0.62677867', '135': '0.86856065', '105': '0.47860219', '1316': '0.66768760', '24': '0.02329498', '678': '0.97440345', '233': '0.47977608', '556': '0.39687138', '1332': '1.00000000', '346': '0.08955224', '1353': '0.00000000', '120': '0.46393996', '871': '0.48892079', '799': '0.36296095', '75': '0.21421616', '314': '0.50079634', '29': '0.40178571', '806': '0.61597322', '87': '0.30948577', '404': '1.00000000', '338': '0.32217696', '654': '0.39244210', '634': '1.00000000', '1076': '0.31886541', '370': '0.70719814', '1252': '0.61281597', '12': '0.40560831', '876': '0.82939099', '1348': '0.16000000', '329': '0.17434620', '37': '0.00000000', '809': '0.20590443', '529': '0.71876827', '45': '0.09414402', '1443': '1.00000000', '963': '0.47583133', '808': '0.47826087', '1292': '0.43061385', '1480': '0.35760369', '59': '0.35134058', '33': '0.00000000', '1361': '0.57270759', '1257': '0.62445861', '1271': '0.73069147', '800': '0.99788097', '336': '0.67016317', '35': '0.37569061', '620': '0.35367262', '229': '1.00000000'}
	# so, now all dps are given a positive score based on above dict values if value>0, if value=0 then a negative score of -0.5 can be given 
	dps=dp_reqids.select('dpid').distinct().collect()
	dps=list(map(lambda x:x[0],dps))
	print(len(dps)==reqdps)
except Exception as error:
	print(error)
	#92 (lendps)
	#the brute force NP solution for set cover is not possible to implemet
	#the number 28 was for belgiu only
	#28 dps 2^28 subsets for each subsets, there are dpids inside the subsets and for those dpids, filter and count union areperformed on dfs
	#so, follow greedy approximate algorithm
	#initally included elements=I
	#keep adding subsets to it, and at any point the subset u pich should have max [SI-I] value, i.e max no.of new elements it ha to give
try:
	dps=['307', '63', '1396', '335', '1085', '810', '1357', '21', '1380', '1129', '374', '376', '1314', '598', '1222', '667', '86', '522', '521', '807', '1110', '322', '1055', '625', '1148', '648', '1258', '685', '738', '637', '1147', '68', '820', '1141', '525', '575', '516', '1415', '611', '95', '395', '331', '372', '239', '979', '135', '105', '1316', '24', '678', '233', '556', '1332', '346', '120', '871', '799', '75', '314', '29', '806', '87', '404', '338', '654', '634', '1076', '370', '1252', '12', '876', '1348', '329', '809', '529', '45', '1443', '963', '808', '1292', '1480', '59', '1361', '1257', '1271', '800', '336', '35', '620', '229']
	print('dp cover starts')
	dp_reqids=spark.read.parquet(path+'dpids_with_its_final_vertices')
	# dps=dp_reqids.select('dpid').distinct().collect()
	# dps=list(map(lambda x:x[0],dps))
	schema = StructType([
	  StructField('long_id', LongType(), False),
	  ])
	included_ids=spark.sparkContext.parallelize([]).toDF(schema)
	n=len(dps)
	threshold=0.97
	all_vertices=spark.read.parquet(all_vertices_path)
	total_cover=all_vertices.count()
	seendpids={'678', '1361', '738', '307', '87'}
	for i in seendpids:
		included_ids=included_ids.union(dp_reqids.filter(F.col('dpid')==i).select('long_id').distinct()).distinct()
	print("total_cover =",total_cover,threshold*total_cover)
	# total_cover=1146931079 1112523146.6299999
	while(included_ids.count()<threshold*total_cover):
		maxval=0
		maxdpid=-1
		for ind,dpid in enumerate(dps):
			if(dpid in seendpids):
				continue
			curr_ids=dp_reqids.filter(F.col('dpid')==dpid).select('long_id').distinct()
			diff=curr_ids.subtract(included_ids).distinct()
			curr_count=diff.count()
			if(curr_count>maxval):
					maxval=curr_count
					maxdpid=dpid
			print("here",ind)
		if(maxdpid==-1):
			print("ERRORRRR!!!!")
			break
		print(included_ids.count(),maxdpid,seendpids,maxval)
		included_ids=included_ids.union(dp_reqids.filter(F.col('dpid')==maxdpid).select('long_id').distinct()).distinct()
		seendpids.add(maxdpid)
		print("UPDATED",ind,included_ids.count())
		print(seendpids)
	dp_score_cover=defaultdict(int)
	#now score -
	for i in seendpids:
		dp_score_cover[i]= "{:.8f}".format(float( ( dp_reqids.filter(F.col('dpid')==i).distinct().count() / total_cover )))
print(dp_score_cover)
except Exception as e:
	print("No",e)
	
UPDATED 89 1063971255                                                           
{'678', '1361', '738', '307', '87', '1258'}
UPDATED 89 1075162959                                                           
seendpids={'678', '1361', '738', '307', '87', '1258', '229'}

{'678': '0.13466860', '1361': '0.30499398', '738': '0.27394641', '307': '0.23869045', '87': '0.28188580', '1258': '0.19386765', '229': '0.00975796'}

seendpids- 
included_ids.count()-
= 
#The scoring shouldnt be in other of how the greedy algo chose the dpids
# coz say a dpid1 has 99% data and other dpid2 has 99.1% , so dpid2 will be chosen with score 99.1 and the other dpid will then be scored only 0.1 around
# so 
# now again, the dps in seendpids are scored based on count of how much they seen/total count and other remaining are not given any score(not even a negative score)
# since this score is very crucial may be it neeed to be scaled up by alpha 
# alpha=1.5


try:
	dp_longedges= spark.read.parquet(path+"dp_edges_mapped_to_long")
	#  (along with timestamps and multiple dpids) 
	all_edges=spark.read.parquet(all_edges_path)	
	e=all_edges.count()
	# # 1689391301
	# DataFrame[id: bigint]
	dp_req_edges=spark.read.parquet(path+'dp_req_edges_with_longs').select('dpid','src','dst').distinct()		
	req_edgescount=dp_req_edges.count()
	print(req_edgescount>=e)
	# 2505728439 since an edge is seen by multiple dps
	#NOW DO THE STEP 1 
	#COLLECT ALL DPIDS 
	dps=dp_longedges.select('dpid').distinct().collect()
	dp_score_edges=defaultdict(int)
	total=0
	usefuls=0
	for i in dps:
		curr_dp=i[0]
		total_seen_edges=dp_longedges.filter(F.col('dpid')==curr_dp).select('src_long_id','dst_long_id').distinct().count()
		useful_edges=dp_req_edges.filter(F.col('dpid')==curr_dp).select('src','dst').distinct().count()
		print(curr_dp,useful_edges,total_seen_edges)
		dp_score_edges[curr_dp]="{:.8f}".format(float((useful_edges/total_seen_edges)))
		usefuls+=useful_edges
		total+=total_seen_edges  
	print(total==dp_longedges.select('dpid','src_long_id','dst_long_id').distinct().count(),total)
	# True 4327274484 
	print(usefuls==req_edgescount)
	# True 
	print("hey",dp_score_edges)
	#   {'307': '0.58181514', '1314': '0.44323484', '876': '0.82937321', '678': '0.97114164', '1147': '0.61481949', '68': '0.50000000', '1348': '0.13636364', '233': '0.54408423', '63': '0.70862931', '598': '0.64673837', '1222': '0.99988184', '820': '1.00000000', '556': '0.39199492', '1141': '0.58452804', '667': '0.98438855', '525': '1.00000000', '329': '0.17391304', '1396': '0.99694001', '86': '0.71763886', '1332': '1.00000000', '346': '0.08695652', '1353': '0.00000000', '37': '0.00000000', '575': '0.61452812', '809': '0.21404207', '529': '0.73019554', '45': '0.09576090', '522': '0.99997611', '120': '0.47190260', '335': '0.46690798', '1443': '1.00000000', '963': '0.54150532', '1085': '0.71198084', '871': '0.49444758', '810': '0.45578231', '521': '0.19661922', '808': '0.49367089', '1357': '1.00000000', '807': '0.56226697', '1110': '0.92225415', '322': '0.67521368', '516': '0.40391299', '1415': '0.61899644', '21': '1.00000000', '1292': '0.46028795', '1055': '0.56545026', '1480': '0.35859098', '611': '0.68013468', '625': '0.47345179', '59': '0.41097259', '799': '0.35113980', '1148': '0.54195459', '95': '0.47794118', '648': '0.63657800', '395': '0.38984646', '331': '0.19167013', '372': '0.18905325', '75': '0.22580645', '118': '0.00000000', '33': '0.00000000', '239': '0.32460733', '314': '0.55686822', '1258': '0.47813985', '1361': '0.59928168', '979': '0.65985787', '29': '0.37037037', '1257': '0.63516979', '1271': '0.75840814', '1344': '0.00000000', '135': '0.86893789', '806': '0.64184009', '105': '0.55658095', '1380': '0.70110277', '800': '0.99860166', '685': '0.57086727', '87': '0.42576527', '404': '1.00000000', '1316': '0.69981917', '738': '0.99775484', '338': '0.41355353', '1129': '1.00000000', '654': '0.42161418', '24': '0.03288889', '336': '0.68684211', '634': '1.00000000', '35': '0.39354839', '1076': '0.32777707', '374': '0.10576923', '637': '0.70422587', '370': '0.71120611', '1252': '0.63049893', '620': '0.36395835', '229': '1.00000000', '376': '0.35370471', '12': '0.48348442'}
	dps=dp_req_edges.select('dpid').distinct().collect()
	dps=list(map(lambda x:x[0],dps))
	# ['307', '1314', '876', '678', '1147', '68', '1348', '233', '63', '598', '1222', '820', '556', '1141', '667', '525', '329', '1396', '86', '1332', '346', '575', '809', '529', '45', '522', '120', '335', '1443', '963', '1085', '871', '810', '521', '808', '1357', '807', '1110', '322', '516', '1415', '21', '1292', '1055', '1480', '611', '625', '59', '799', '1148', '95', '648', '395', '331', '372', '75', '239', '314', '1258', '1361', '979', '29', '1257', '1271', '135', '806', '105', '1380', '800', '685', '87', '404', '1316', '738', '338', '1129', '654', '336', '24', '634', '35', '1076', '374', '637', '370', '1252', '620', '229', '376', '12']
		#the brute force NP solution for set cover is not possible to implemet
	#28 dps 2^28 subsets for each subsets, there are dpids inside the subsets and for those dpids, filter and count union areperformed on dfs
	#so, follow greedy approximate algorithm
	#initally included elements=I
	#keep adding subsets to it, and at any point the subset u pich should have max [SI-I] value, i.e max no.of new elements it ha to give
except :
	print("m")

try:
	print('edge cover starts')
	all_edges=spark.read.parquet(all_edges_path)	
	dp_req_edges=spark.read.parquet(path+'dp_req_edges_with_longs').select('dpid','src','dst').distinct()	
	# dps=
	dp_req_edges=dp_req_edges.select('dpid','src','dst').distinct()
	schema = StructType([
	  StructField('src', LongType(), False),
	  StructField('dst', LongType(), False),
	  ])
	included_edges=spark.sparkContext.parallelize([]).toDF(schema)
	n=len(dps)
	threshold=0.97
	total_cover=all_edges.count()
	# 
	seendpids={'738', '1361', '1258', '87'}
	for i in seendpids:
		included_edges=included_edges.union(dp_req_edges.filter(F.col('dpid')==i).select('src','dst').distinct()).distinct()
	print("total_cover=",total_cover,threshold*total_cover)
	# total_cover=1689391301 1638709561.97                                        
	while(included_edges.count()<threshold*total_cover):
		maxval=0
		maxdpid=-1
		for ind,dpid in enumerate(dps):
			if(dpid in seendpids):
				continue
			curr_edges=dp_req_edges.filter(F.col('dpid')==dpid).select('src','dst').distinct()
			diff=curr_edges.subtract(included_edges).distinct()
			curr_count=diff.count()
			if(curr_count>maxval):
					maxval=curr_count
					maxdpid=dpid
			print("here",ind)
		if(maxdpid==-1):
			print("ERRORRRR!!!!")
			break
		print(included_edges.count(),maxdpid,seendpids,maxval)
		included_edges=included_edges.union(dp_req_edges.filter(F.col('dpid')==maxdpid).select('src','dst').distinct()).distinct()
		seendpids.add(maxdpid)
		print("UPDATED",included_edges.count())
		print(seendpids)
	dp_score_coveredges=defaultdict(int)
	for i in seendpids:
		dp_score_coveredges[i]= "{:.8f}".format(float( ( dp_req_edges.filter(F.col('dpid')==i).distinct().count() / total_cover )))
	print(dp_score_coveredges)
except Exception as error:
	print('No',error)

print(dp_score_coveredges)


                                                 
UPDATED 1403872296                                                              
{'738', '1361', '1258', '87'}
UPDATED 393939893                                                               
seendpids={'678', '1361', '738', '307', '87', '1258'}
{'678': '0.06004700', '1361': '0.21746291', '738': '0.35352335', '307': '0.17460111', '87': '0.22022413', '1258': '0.13703610'}

seendpids- 
0.99*total_cover
included_edges.count()-

0.99*total_cover
#now the scoring shouldnt be in other of how the greedy algo chose the dpids
coz say a dpid1 has 99% data and other dpid2 has 99.1% , so dpid2 will be chosen with score 99.1 and the other dpid will then be scored only 0.1 around
so 



now again, the dps in seendpids are scored based on count of how much they seen/total count and other remaining are not given any score(not even a negative score)

since this score is very crucial may be it neeed to be scaled up by alpha 
alpha=1.5






