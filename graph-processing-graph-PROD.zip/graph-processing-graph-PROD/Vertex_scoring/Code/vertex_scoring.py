# gcloud beta compute ssh --zone "europe-west1-b" "dproc-datascience-dev-eu-m" --tunnel-through-iap --project "zeotap-dev-datascience"
# pyspark --packages org.apache.spark:spark-avro_2.11:2.4.4,graphframes:graphframes:0.6.0-spark2.3-s_2.11c
# pyspark --packages graphframes:graphframes:0.6.0-spark2.3-s_2.11 --executor-memory 30g --conf spark.sql.shuffle.partitions=10000

from pyspark.sql import SparkSession
from pyspark.sql import SQLContext  
from pyspark.sql import functions as F
from pyspark.sql.types import *

from graphframes import *

import community as community_louvain
import infomap

import networkx as nx
from networkx import algorithms
from networkx.generators import ego_graph
from networkx.drawing.nx_pylab import draw_networkx_labels

from scipy.stats.stats import pearsonr
import scipy.optimize as sciopt
from scipy.stats import norm,chisquare
import scipy.stats

from matplotlib import pyplot as plt
import pandas as pd

import numpy as np

import random
import time
from collections import deque,Counter
import math
import copy
import datetime
import statistics
import scipy.stats as st
#	METADATA FEATURE VALUES



data_with_metadata = spark.read.parquet("gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/kuldeep/data_with_metadata")

 # DATA SCHEMA:
 # |-- dpid: string (nullable = true)
 # |-- timestamp: long (nullable = true)
 # |-- component: long (nullable = true)
 # |-- long_id: long (nullable = true)

components = data_with_metadata.groupBy("component").count().orderBy("count").filter((F.col("count") == 14)).collect()
components = [x["component"] for x in components]
components = components[:100]
# Filtering some components for scoring vertices in them.

sample_data_with_metadata = data_with_metadata.filter(F.col("component").isin(components))
sample_data_with_metadata = data_with_metadata

sample_data_with_metadata = sample_data_with_metadata.select("dpid","timestamp","component","long_id")
sample_data_with_metadata = sample_data_with_metadata.groupBy("long_id").agg(F.collect_list("dpid").alias("all_dpid"),F.collect_list("timestamp").alias("all_timestamp"))
# Created sample_data for scoring vertices in them

sample_data_with_metadata.write.mode("overwrite").parquet("gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/kuldeep/sample_meatdata_preparation")
sample_data_with_metadata = spark.read.parquet("gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/kuldeep/sample_meatdata_preparation")

def dpid_counter(x):
	return dict(Counter(x))

dpid_counter_udf = F.udf(dpid_counter,MapType(StringType(), IntegerType()))
sample_data_with_metadata = sample_data_with_metadata.withColumn("dpid_map",dpid_counter_udf(F.col("all_dpid")))
# Adding dpid dictionary for later use. 

dp_weight_path = spark.read.parquet("gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/graph/cleanup/country=ALL/Prudhvi/DP_scoring/all_countries_dpid_scores_with_final_scores")
dp_weight_path = dp_weight_path.select("dpid","country","final_score_Scaled")

dp_weight = dp_weight_path.collect()


def create_dp_weights(dp_weight):
	dpid_dict = {}
	weight_max = -1
	weight_min = 1000
	for row in dp_weight:
		curr_dict = dpid_dict.get(int(row["dpid"]),{})
		curr_dict[row["country"]] = row["final_score_Scaled"]
		weight_min = min(weight_min,row["final_score_Scaled"])
		weight_max = max(weight_max,row["final_score_Scaled"])
		dpid_dict[int(row["dpid"])] = curr_dict
	return (dpid_dict,weight_max,weight_min)

DP_weight,maxi,mini = create_dp_weights(dp_weight)

def transform_dict(DP_weight,OldMax,OldMin):
	OldRange = OldMax - OldMin
	NewMax = 10
	NewMin = 1
	NewRange = (NewMax - NewMin) 
	for dpid,dpid_dict in DP_weight.items():
		for country,value in dpid_dict.items():
			DP_weight[dpid][country] = NewMin + (((value - OldMin) * NewRange) / OldRange) 
	return DP_weight

DP_weight = transform_dict(DP_weight,maxi,mini)
DPID_weight = sc.broadcast(DP_weight)

def bayesian_rating_products(n, wts,confidence=0.95):
	if sum(n)==0:
		return 0
	K = len(n)
	z = float(st.norm.ppf(1 - (1 - confidence) / 2))
	N = sum(n)
	first_part = 0.0
	second_part = 0.0
	for k, n_k in enumerate(n):
		first_part += (wts[k] + 1)*(n[k]+1)/(N+K)
		second_part += (wts[k] + 1)*(wts[k]+ 1)*(n[k]+1)/(N+K)
	try:
		score = first_part - z * math.sqrt((second_part - (first_part*first_part))/(N+K+1))
	except ValueError:
		score = first_part
	return score/10

def dpid_disparity(arr):
    maxi_count = max(arr)
    tot = len(arr)*maxi_count
    disparity_count = 0
    for i in range(len(arr)):
        disparity_count = disparity_count + (maxi_count - arr[i])    
    return (10 - (disparity_count/tot)*10)/10


def dpid_weight_score(count,weights):
    return bayesian_rating_products(count,weights)*dpid_disparity(count)

def dpid_score(x):
	dpid_dict = x["dpid_map"]
	cont = []
	weights = []
	for idd,ct in dpid_dict.items():
		cont.append(ct)
		try:
			curr_weight = DPID_weight.value[int(idd)]["GBR"]
		except KeyError:
			curr_weight = 0.4
		weights.append(curr_weight)
	return dpid_weight_score(cont,weights)


dpid_score_udf = F.udf(dpid_score,FloatType())
sample_data_with_metadata = sample_data_with_metadata.withColumn("dpid_score",dpid_score_udf(F.struct(F.col("dpid_map"))))
# Using Dp-weights for meta-data scoring. Here we use Bayersian-rating-variation.  


def timestamp_difference_mean(x):
	timestamps = sorted([int(i) for i in x])
	t0 = timestamps[0]
	difference = []
	for i,timestamp in enumerate(timestamps):
		difference.append(timestamp - t0)
		t0 = timestamp
	return int(statistics.mean(difference))


def timestamp_difference_median(x):
	timestamps = sorted([int(i) for i in x])
	t0 = timestamps[0]
	difference = []
	for i,timestamp in enumerate(timestamps):
		difference.append(timestamp - t0)
		t0 = timestamp
	return int(statistics.median(difference))

timestamp_difference_mean_udf = F.udf(timestamp_difference_mean,IntegerType())
sample_data_with_metadata = sample_data_with_metadata.withColumn("timestamp_difference_mean",timestamp_difference_mean_udf(F.col("all_timestamp")))

timestamp_difference_median_udf = F.udf(timestamp_difference_median,IntegerType())
sample_data_with_metadata = sample_data_with_metadata.withColumn("timestamp_difference_median",timestamp_difference_median_udf(F.col("all_timestamp")))
# Adding mean and median for time-stamps difference for each vertex.


def sigmoid(gamma):
 	if gamma < 0:
 		return 1 - 1/(1 + math.exp(gamma))
 	else:
 		return 1/(1 + math.exp(-gamma))

def timestamp_score(x):
	timestamps = sorted([int(float(i)) for i in x[0]],reverse = True)
	median_timestamp = datetime.datetime.utcfromtimestamp(int(x[1])) - datetime.datetime.utcfromtimestamp(0)
	current_timestamp = datetime.datetime.utcnow()
	try:
		recent_timestamp = datetime.datetime.utcfromtimestamp(timestamps[0])
	except ValueError:
		recent_timestamp = datetime.datetime.utcfromtimestamp(timestamps[0]/1000)
	difference = (current_timestamp - recent_timestamp).days
	median_days = median_timestamp.days 
	score_1= sigmoid((median_days -(difference)))
	if median_days == 0:
		median_days = 10
	score_2 = math.pow(0.5,((difference))/max(median_days,1))
	score_3 = math.pow(0.9,((difference))/max(median_days,1))
	if len(timestamps) < 3:
		score_3 = math.pow(0.9,((difference))/10)
	return score_3

timestamp_score_udf = F.udf(timestamp_score,FloatType())
sample_data_with_metadata = sample_data_with_metadata.withColumn("timestamp_score",timestamp_score_udf(F.struct(F.col("all_timestamp"),F.col("timestamp_difference_median"))))
# Adding time-stamp feature value for each vertex in the sample_data

sample_data_with_metadata.write.mode("overwrite").parquet("gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/kuldeep/sample_data_with_metadata_score")


def dpid_score(x):
	return score

dpid_score_udf = F.udf(dpid_score,FloatType())
sample_data_with_metadata = sample_data_with_metadata.withColumn("dpid_score",dpid_score_udf(F.struct(F.col("dpid_map"))))
# Adding dpid feature value for each vertex in the sample_data
# Final Sample_data SCHEMA:
 # |-- long_id: long (nullable = true)
 # |-- all_dpid: array (nullable = true)
 # |    |-- element: string (containsNull = true)
 # |-- all_timestamp: array (nullable = true)
 # |    |-- element: long (containsNull = true)
 # |-- dpid_map: map (nullable = true)
 # |    |-- key: string
 # |    |-- value: integer (valueContainsNull = true)
 # |-- timestamp_difference_mean: integer (nullable = true)
 # |-- timestamp_difference_median: integer (nullable = true)
 # |-- timestamp_score: float (nullable = true)



#	STRUCTURAL FEATURE VALUES:
path = "gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/graph/cleanup_new_timeline/country=GBR/data/final_graph/traversible_vertexes_with_types"
data = spark.read.parquet(path)
#components = data.groupBy("component").count().orderBy("count").filter((F.col("count") > 1000)).collect()
#components = [x["component"] for x in components]
#print(f"Number of components found: {len(components)}")


edge_path = "gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/graph/cleanup_new_timeline/country=GBR/data/final_graph/traversible_edges_with_cc"
edge = spark.read.parquet(edge_path)
#sample_edges = edge.filter(F.col("component").isin(components))


sample_edges = edge
comp_edges = sample_edges.groupBy("component").agg(F.collect_list("src_long_id").alias("src"),F.collect_list("dst_long_id").alias("dst"))
# preparing sample data using the component size to score all the vertices.
# DATA:
#  |-- component: long (nullable = true)
#  |-- src: array (nullable = true)
#  |    |-- element: long (containsNull = true)
#  |-- dst: array (nullable = true)
#  |    |-- element: long (containsNull = true)

def bfs_edges(G, source,dest=None, reverse=False, depth_limit=None, sort_neighbors=None):
	if reverse and G.is_directed():
		successors = G.predecessors
	else:
		successors = G.neighbors
	yield from generic_bfs_edges(G, source,dest, successors, depth_limit, sort_neighbors)

def find_common(a,b):
	a_set = set(a)
	b_set = set(b)
	return len(a_set & b_set)


def find_union(a,b):
	a_set = set(a)
	b_set = set(b)
	return len(a_set | b_set)


def ego_score(G,a,b,depth_lim=4):
	a_full = [v for k,v in list(bfs_edges(G,a,dest=b,depth_limit=depth_lim))]
	b_full = [v for k,v in list(bfs_edges(G,b,dest=a,depth_limit=depth_lim))]
	c_val = find_common(a_full,b_full)
	u_val = find_union(a_full,b_full)
	sc = u_val/(c_val + 1)
	return round(sc,3) 


def normalize_dict(dic):
	dic_ = dic
	tot = max([val for edge,val in dic_.items()])
	tot = max(tot,0.0001)
	dic_normal = {edge:round((val/tot),3) for edge,val in dic_.items()}
	return dic_normal

def generic_bfs_edges(G, source,dest=None, neighbors=None, depth_limit=None, sort_neighbors=None):
	if callable(sort_neighbors):
		_neighbors = neighbors
		neighbors = lambda node: iter(sort_neighbors(_neighbors(node)))
	visited = {source}
	if depth_limit is None:
		depth_limit = len(G)
	queue = deque([(source, depth_limit, neighbors(source))])
	while queue:
		parent, depth_now, children = queue[0]
		try:
			child = next(children)
			if child not in visited and child != dest:
				yield parent, child
				visited.add(child)
				if depth_now > 1:
					queue.append((child, depth_now - 1, neighbors(child)))
		except StopIteration:
			queue.popleft()

def LCC_DC(G):
	lcc = nx.clustering(G)
	lcc_deg = {}
	deg = dict(G.degree())
	maxi = -1
	for i, val in lcc.items():
		lcc_deg[i] = (lcc[i]+0.1)*deg[i]
		if lcc_deg[i] >= maxi:
			maxi = lcc_deg[i]
	lcc_deg = {key: round(val/maxi,4) for key,val in lcc_deg.items()}
	return lcc_deg

def Page_rank(G):
	try:
		pr = nx.pagerank(G, alpha=0.9,max_iter=1000)
	except:
		pr = {node:0.05 for node in list(G.nodes)}
	return pr

def Neighbour_Diversity(G,lcc_dc_score,pr_score,iou_aggregation_score):
	neighbours = Neighbours(G)
	neighbour_diversity_score = {}
	for i in list(G.nodes):
		nb= neighbours[i]
		nb_lcc_dc = 0
		nb_pr = 0
		nb_iou = 0
		if len(nb) >= 1:
		    nb_lcc_dc = statistics.mean([lcc_dc_score[it] for it in nb])
		    nb_pr = statistics.mean([pr_score[it] for it in nb])
		    nb_iou = statistics.mean([iou_aggregation_score[it] for it in nb])
		curr_lcc_dc = lcc_dc_score[i]
		curr_pr = pr_score[i]
		curr_iou = iou_aggregation_score[i]
		neighbour_diversity_score[i] = ((abs(nb_lcc_dc-curr_lcc_dc)/max(nb_lcc_dc,curr_lcc_dc,0.01)) + abs((nb_pr-curr_pr)/max(nb_pr,curr_pr,0.001)) + abs((nb_iou-curr_iou)/max(nb_iou,curr_iou,0.001)))*1/3.
	return neighbour_diversity_score

def IOU_Aggregation(G):
	neighbours = Neighbours(G)
	ego_coefficient = {}
	ego_aggregation = {node:0 for node in G.nodes}
	for i, edge in enumerate(list(nx.edges(G))):
		ego_coefficient[edge] = ego_score(G,edge[0],edge[1],depth_lim=3)
	ego_normal = normalize_dict(ego_coefficient)
	for i, edge in enumerate(list(nx.edges(G))):
		ego_aggregation[edge[0]] = ego_aggregation[edge[0]] + ego_normal[edge]
		ego_aggregation[edge[1]] = ego_aggregation[edge[1]] + ego_normal[edge]
	deg = dict(G.degree())
	ego_aggregation = {node:score/(deg[node]+0.1) for node,score in ego_aggregation.items()}
	return ego_aggregation

def Neighbours(G):
	neighbours = {}
	for i in list(G.nodes):
		edges = nx.bfs_edges(G, i,depth_limit = 3)
		nodes = [v for u, v in edges]
		neighbours[i] = nodes
	return neighbours

def density_bining(x):
	if x<0.5:
		return 1
	elif x>=0.5 and x<1:
		return 2
	elif x>=1 and x<1.5:
		return 3
	elif x>=1.5 and x<2:
		return 4
	elif x>=2 and x<2.5:
		return 5
	elif x>=2.5 and x<3:
		return 6
	elif x>=3 and x<3.5:
		return 7 
	elif x>=3.5 and x<4:
		return 8
	elif x>=4 and x<4.5:
		return 9
	else:
		return 10

def Component_Scoring(x):
	edge_src = x[1]
	edge_dst = x[2]
	vertices = set()
	edges = []
	G = nx.Graph()
	for i in range(len(edge_src)):
		vertices.add(edge_src[i])
		vertices.add(edge_dst[i])
		edges.append((edge_src[i],edge_dst[i]))
	G.add_nodes_from(vertices)
	G.add_edges_from(edges)
	lcc_dc_score = LCC_DC(G)
	nx.set_node_attributes(G,lcc_dc_score,"lcc_dc_score")
	pr_score = Page_rank(G)
	nx.set_node_attributes(G,pr_score,"pr_score")
	iou_aggregation_score = IOU_Aggregation(G)
	nx.set_node_attributes(G,iou_aggregation_score,"iou_aggregation_score")
	lcc_dc_src = []
	iou_aggregation_src = []
	pr_src = []
	lcc_dc_score = nx.get_node_attributes(G,"lcc_dc_score")
	iou_aggregation_score = nx.get_node_attributes(G,"iou_aggregation_score")
	pr_score = nx.get_node_attributes(G,"pr_score")
	vertices = list(vertices)
	for src in vertices:
		lcc_dc_src.append(lcc_dc_score[src])
		iou_aggregation_src.append(iou_aggregation_score[src])
		pr_src.append(pr_score[src])
	density = len(vertices)/len(edges) 
	density_bin = density_bining(density) 
	no_edges = len(edges)
	no_nodes = len(vertices)
	return (x[0],x[1],x[2],vertices,lcc_dc_src,iou_aggregation_src,pr_src,density_bin,no_edges,no_nodes)
#all helper functions to find structural feature values

Dataframe_with_score = comp_edges.rdd.map(Component_Scoring).toDF(["component","V1","V2","Vertices","lcc_dc_score","iou_aggregation_score","page-rank_score","density","no_edges","no_vertices"])

def average_score(x):
	iou_array = x["iou_aggregation_score"]
	lcc_array = x["lcc_dc_score"]
	page_rank_array = x["page-rank_score"]
	average_score_array = []
	for i in range(len(iou_array)):
		current_average = (lcc_array[i] + iou_array[i] + page_rank_array[i])/3
		average_score_array.append(current_average)
	return average_score_array

average_score_udf = F.udf(average_score,ArrayType(DoubleType()))
Dataframe_with_score = Dataframe_with_score.withColumn("average_structural_feature_score",average_score_udf(F.struct(F.col("iou_aggregation_score"),F.col("lcc_dc_score"),F.col("page-rank_score"))))
Dataframe_with_score.write.mode("overwrite").parquet("gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/kuldeep/sample_data_with_average_structural_feature_score_help")
Dataframe_with_score = spark.read.parquet("gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/kuldeep/sample_data_with_average_structural_feature_score_help")
# FINAL DATA with structural feature values
 # |-- Vertices: array (nullable = true)
 # |    |-- element: long (containsNull = true)
 # |-- lcc_dc_score: array (nullable = true)
 # |    |-- element: double (containsNull = true)
 # |-- iou_aggregation_score: array (nullable = true)
 # |    |-- element: double (containsNull = true)
 # |-- page-rank_score: array (nullable = true)
 # |    |-- element: double (containsNull = true)
 # |-- density: long (nullable = true)
 # |-- no_edges: long (nullable = true)
 # |-- no_vertices: long (nullable = true)
 # |-- average_structural_feature_score: array (nullable = true)
 # |    |-- element: double (containsNull = true)


def expand_it(x):
	average_score_array = x["average_structural_feature_score"]
	vertices = x["Vertices"]
	expansion = []
	for i in range(len(average_score_array)):
		expansion.append([vertices[i],average_score_array[i]])
	return expansion

schema = ArrayType(StructType([
	StructField("vertices", LongType(), False),
	StructField("average_score_structural", DoubleType(), False)
	]))
expand_it_udf = F.udf(expand_it,schema)
Dataframe_with_score = Dataframe_with_score.withColumn("expansion_help",expand_it_udf(F.struct(F.col("average_structural_feature_score"),F.col("Vertices"))))
Dataframe_with_score_test = Dataframe_with_score.select(F.explode(F.col("expansion_help")),F.col("*"))


def make_df(x):
	strct = x[0]
	return (strct[0],strct[1])


Df_with_score = Dataframe_with_score_test.rdd.map(make_df).toDF(["vertices","average_structural_feature_score"])
Df_with_score.printSchema()
# Final Data Scheme:
 # |-- vertices: long (nullable = true)
 # |-- average_structural_feature_score: double (nullable = true)


Df_with_score.write.mode("overwrite").parquet("gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/kuldeep/sample_data_with_average_structural_feature_score")



# Aggregating metadata feature values and structural feature values:
df_with_structural_score = spark.read.parquet("gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/kuldeep/sample_data_with_average_structural_feature_score")
df_with_metadata_score = spark.read.parquet("gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/kuldeep/sample_data_with_metadata_score")
df_with_structural_score.printSchema()
df_with_metadata_score.printSchema()
df_with_score = df_with_structural_score.join(df_with_metadata_score,df_with_metadata_score.long_id == df_with_structural_score.vertices,"inner").select("vertices","average_structural_feature_score","timestamp_score")
df_with_score.write.mode("overwrite").parquet("gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/kuldeep/sample_data_with_score_help")
df_with_score = spark.read.parquet("gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/kuldeep/sample_data_with_score_help")

def final_average(x):
	average_structural_feature_score = x["average_structural_feature_score"]
	timestamp_score = x["timestamp_score"]
	final_average_score = ((average_structural_feature_score*3) + timestamp_score)/4
	return final_average_score

final_average_score_udf = F.udf(final_average,DoubleType())
df_with_score = df_with_score.withColumn("final_average_score",final_average_score_udf(F.struct(F.col("average_structural_feature_score"),F.col("timestamp_score"))))

hist = df_with_score.groupBy().agg(F.collect_list("final_average_score").alias("all_scores"))
def final_average_histogram(x):
	final_average_score_list = [float(i) for i in x]
	final_average_hist, final_average_bin_edges = np.histogram(final_average_score_list,bins=10,range=(0,1))
	final_average_score_hist = [int(i) for i in final_average_hist]
	return final_average_score_hist

final_average_histogram_udf = F.udf(final_average_histogram)
hist = hist.withColumn("final_average_histogram",final_average_histogram_udf(F.col("all_scores")))
hist.select("final_average_histogram").show(50,False)






