from Helper._packages import *
from Metadata.metadata import metadata_scoring
from Structural.structural import structural_scoring
from Combination.final_average import final_average_score
from Helper.integrate_score import integrate_score
from Helper.utils import *

if __name__ == "__main__":
    spark = SparkSession.builder.appName("vertex scoring").getOrCreate()
    sc = spark.sparkContext
    input_base_path = spark.conf.get("spark.input.basePath") 
    traversible_vertices_path = input_base_path + "/reporting_input_processing/data/incremental_cleaning/traversible_vertexes_with_types"
    traversible_edges_path = input_base_path + "/reporting_input_processing/data/incremental_cleaning/traversible_edges_with_cc"
    long_mapper_path = input_base_path + "/reporting_input_processing/long_mapper_for_vertex"

    input_base_path = input_base_path + "/reporting_input_processing/vertexScoring/"
    non_tube_vertex_set_path = spark.conf.get("spark.input.nonTubeVertexSetPath") 
    non_tube_edge_set_path = spark.conf.get("spark.input.nontubeEdgeSetPath")
    final_output_path = spark.conf.get("spark.output.scoredPath") 

    structural_output_path = input_base_path + "/data_with_average_structural_feature_score" 
    metadata_output_path = input_base_path + "/data_with_metadata_score"  # "gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/kuldeep/code_run/vertex_scoring/output/data_with_metadata_score"
    dpid_scored_path = spark.conf.get("spark.input.dpidScoredPath")  # "gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/graph/cleanup/country=ALL/Prudhvi/DP_scoring/all_countries_dpid_scores_with_final_scores"
    # final input params	 ## "gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/kuldeep/code_run/vertex_scoring/output/data_with_final_score"
    metadata_scoring(input_base_path, long_mapper_path, non_tube_vertex_set_path, non_tube_edge_set_path, dpid_scored_path, metadata_output_path, spark, sc)
    structural_scoring(input_base_path, traversible_vertices_path, traversible_edges_path, structural_output_path, spark, sc)
    final_average_score(input_base_path, structural_output_path, metadata_output_path, spark, sc)
    integrate_score(input_base_path, final_output_path, long_mapper_path, spark, sc)
    
    