from Helper._packages import *

def Page_rank(G):
	try:
		pr = nx.pagerank(G, alpha=0.9,max_iter=1000)
	except:
		pr = {node:0.05 for node in list(G.nodes)}
	return pr