from Helper._packages import *

def Neighbour_Diversity(G,lcc_dc_score,pr_score,iou_aggregation_score):
	neighbours = Neighbours(G)
	neighbour_diversity_score = {}
	for i in list(G.nodes):
		nb= neighbours[i]
		nb_lcc_dc = 0
		nb_pr = 0
		nb_iou = 0
		if len(nb) >= 1:
		    nb_lcc_dc = statistics.mean([lcc_dc_score[it] for it in nb])
		    nb_pr = statistics.mean([pr_score[it] for it in nb])
		    nb_iou = statistics.mean([iou_aggregation_score[it] for it in nb])
		curr_lcc_dc = lcc_dc_score[i]
		curr_pr = pr_score[i]
		curr_iou = iou_aggregation_score[i]
		neighbour_diversity_score[i] = ((abs(nb_lcc_dc-curr_lcc_dc)/max(nb_lcc_dc,curr_lcc_dc,0.01)) + abs((nb_pr-curr_pr)/max(nb_pr,curr_pr,0.001)) + abs((nb_iou-curr_iou)/max(nb_iou,curr_iou,0.001)))*1/3.
	return neighbour_diversity_score