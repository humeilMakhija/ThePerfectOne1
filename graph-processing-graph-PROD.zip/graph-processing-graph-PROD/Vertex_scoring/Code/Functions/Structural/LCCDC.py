from Helper._packages import *

def LCC_DC(G):
	lcc = nx.clustering(G)
	lcc_deg = {}
	deg = dict(G.degree())
	maxi = -1
	for i, val in lcc.items():
		lcc_deg[i] = (lcc[i]+0.1)*deg[i]
		if lcc_deg[i] >= maxi:
			maxi = lcc_deg[i]
	lcc_deg = {key: round(val/maxi,4) for key,val in lcc_deg.items()}
	return lcc_deg

	