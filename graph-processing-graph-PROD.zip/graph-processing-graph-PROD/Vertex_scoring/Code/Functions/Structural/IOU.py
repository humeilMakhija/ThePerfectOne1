from Helper._packages import *

def bfs_edges(G, source,dest=None, reverse=False, depth_limit=None, sort_neighbors=None):
	if reverse and G.is_directed():
		successors = G.predecessors
	else:
		successors = G.neighbors
	yield from generic_bfs_edges(G, source,dest, successors, depth_limit, sort_neighbors)


def find_common(a,b):
	a_set = set(a)
	b_set = set(b)
	return len(a_set & b_set)


def find_union(a,b):
	a_set = set(a)
	b_set = set(b)
	return len(a_set | b_set)


def ego_score(G,a,b,depth_lim=4):
	a_full = [v for k,v in list(bfs_edges(G,a,dest=b,depth_limit=depth_lim))]
	b_full = [v for k,v in list(bfs_edges(G,b,dest=a,depth_limit=depth_lim))]
	c_val = find_common(a_full,b_full)
	u_val = find_union(a_full,b_full)
	sc = u_val/(c_val + 1)
	return round(sc,3) 


def normalize_dict(dic):
	dic_ = dic
	tot = max([val for edge,val in dic_.items()])
	tot = max(tot,0.0001)
	dic_normal = {edge:round((val/tot),3) for edge,val in dic_.items()}
	return dic_normal


def generic_bfs_edges(G, source,dest=None, neighbors=None, depth_limit=None, sort_neighbors=None):
	if callable(sort_neighbors):
		_neighbors = neighbors
		neighbors = lambda node: iter(sort_neighbors(_neighbors(node)))
	visited = {source}
	if depth_limit is None:
		depth_limit = len(G)
	queue = deque([(source, depth_limit, neighbors(source))])
	while queue:
		parent, depth_now, children = queue[0]
		try:
			child = next(children)
			if child not in visited and child != dest:
				yield parent, child
				visited.add(child)
				if depth_now > 1:
					queue.append((child, depth_now - 1, neighbors(child)))
		except StopIteration:
			queue.popleft()


def Neighbours(G):
	neighbours = {}
	for i in list(G.nodes):
		edges = bfs_edges(G, i,depth_limit = 3)
		nodes = [v for u, v in edges]
		neighbours[i] = nodes
	return neighbours

				
def IOU_Aggregation(G):
	neighbours = Neighbours(G)
	ego_coefficient = {}
	ego_aggregation = {node:0 for node in G.nodes}
	for i, edge in enumerate(list(nx.edges(G))):
		ego_coefficient[edge] = ego_score(G,edge[0],edge[1],depth_lim=3)
	ego_normal = normalize_dict(ego_coefficient)
	for i, edge in enumerate(list(nx.edges(G))):
		ego_aggregation[edge[0]] = ego_aggregation[edge[0]] + ego_normal[edge]
		ego_aggregation[edge[1]] = ego_aggregation[edge[1]] + ego_normal[edge]
	deg = dict(G.degree())
	ego_aggregation = {node:score/(deg[node]+0.1) for node,score in ego_aggregation.items()}
	return ego_aggregation