from Structural.LCCDC import *
from Structural.IOU import *
from Structural.Neighbour_diversity import *
from Structural.Pagerank import *
from Helper._packages import *

def Component_Scoring(x):
	edge_src = x[1]
	edge_dst = x[2]
	vertices = set()
	edges = []
	G = nx.Graph()
	for i in range(len(edge_src)):
		vertices.add(edge_src[i])
		vertices.add(edge_dst[i])
		edges.append((edge_src[i],edge_dst[i]))
	G.add_nodes_from(vertices)
	G.add_edges_from(edges)
	lcc_dc_score = LCC_DC(G)
	nx.set_node_attributes(G,lcc_dc_score,"lcc_dc_score")
	pr_score = Page_rank(G)
	nx.set_node_attributes(G,pr_score,"pr_score")
	iou_aggregation_score = IOU_Aggregation(G)
	nx.set_node_attributes(G,iou_aggregation_score,"iou_aggregation_score")
	lcc_dc_src = []
	iou_aggregation_src = []
	pr_src = []
	lcc_dc_score = nx.get_node_attributes(G,"lcc_dc_score")
	iou_aggregation_score = nx.get_node_attributes(G,"iou_aggregation_score")
	pr_score = nx.get_node_attributes(G,"pr_score")
	vertices = list(vertices)
	for src in vertices:
		lcc_dc_src.append(lcc_dc_score[src])
		iou_aggregation_src.append(iou_aggregation_score[src])
		pr_src.append(pr_score[src])
	density = len(vertices)/len(edges) 
	no_edges = len(edges)
	no_nodes = len(vertices)
	return (x[0],x[1],x[2],vertices,lcc_dc_src,iou_aggregation_src,pr_src,no_edges,no_nodes)