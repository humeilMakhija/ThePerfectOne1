from Helper._packages import *
from Structural.Component_scoring import *
from Helper.Structural_help import *

def structural_scoring(input_base_path ,  traversible_vertices_path , traversible_edges_path , structural_output_path  , spark , sc ):
	traversible_vertexes_with_types = spark.read.parquet(traversible_vertices_path)
	# if wflow_type == "Incremental" : 
	traversible_edges = spark.read.parquet(traversible_edges_path).withColumnRenamed("src" , "src_long_id").withColumnRenamed("dst" , "dst_long_id")
	# else:
		# traversible_edges = spark.read.parquet(traversible_edges_path)
		
	comp_edges = traversible_edges.groupBy("component").agg(F.collect_list("src_long_id").alias("src"),F.collect_list("dst_long_id").alias("dst"))
	comp_edges.write.mode("overwrite").parquet(input_base_path + "/traversible_edges_groupby_with_cc")

	comp_edges = spark.read.parquet(input_base_path + "/traversible_edges_groupby_with_cc")
	comp_edges.rdd.map(Component_Scoring).toDF(["component","V1","V2","Vertices","lcc_dc_score","iou_aggregation_score","page-rank_score","no_edges","no_vertices"]).write.mode("overwrite").parquet(input_base_path +  "/df_with_score_path")
	Dataframe_with_score = spark.read.parquet(input_base_path + "/df_with_score_path")
	structural_average_score_udf = F.udf(structural_average_score,ArrayType(DoubleType()))
	Dataframe_with_score = Dataframe_with_score.withColumn("average_structural_feature_score",structural_average_score_udf(F.struct(F.col("iou_aggregation_score"),F.col("lcc_dc_score"),F.col("page-rank_score"))))
	Dataframe_with_score.write.mode("overwrite").parquet(input_base_path + "/data_with_average_structural_feature_score_help")
	Dataframe_with_score = spark.read.parquet(input_base_path + "/data_with_average_structural_feature_score_help")

	schema = ArrayType(StructType([
	StructField("vertices", LongType(), False),
	StructField("average_score_structural", DoubleType(), False)
	]))

	expand_it_udf = F.udf(expand_it,schema)
	Dataframe_with_score = Dataframe_with_score.withColumn("expansion_help",expand_it_udf(F.struct(F.col("average_structural_feature_score"),F.col("Vertices"))))
	Dataframe_with_score.select(F.explode(F.col("expansion_help")),F.col("*")).write.mode("overwrite").parquet(input_base_path + "/data_with_average_structural_feature_score_help_exploded")
	Dataframe_with_score = spark.read.parquet(input_base_path + "/data_with_average_structural_feature_score_help_exploded") 

	Dataframe_with_score.rdd.map(make_df).toDF(["vertices","average_structural_feature_score"]).write.mode("overwrite").parquet(structural_output_path)
	# Final Data Scheme:
	 # |-- vertices: long (nullable = true)
	 # |-- average_structural_feature_score: double (nullable = true)
	print(f"Structural Scoring is done")




