from Helper._packages import *
def integrate_score(input_base_path, final_output_path ,long_mapper_path ,spark, sc):
	df_to_be_scored = spark.read.parquet(final_output_path).drop("quality")
	scored_data = spark.read.parquet(input_base_path + "/final_output_score")
	long_mapper = spark.read.parquet(long_mapper_path).withColumnRenamed("long_id","vertices").withColumnRenamed("vertex" , "string_id").withColumnRenamed("vertexType" , "type")
	scored_data.join(long_mapper,on =["vertices"], how= "inner").write.mode("overwrite").parquet(input_base_path + "/data_with_final_score_with_string_id_type")
	scored_data = spark.read.parquet(input_base_path +  "/data_with_final_score_with_string_id_type").select("string_id" , "type" , F.col("final_average_score").alias("quality"))
	df_to_be_scored.join(scored_data , [scored_data.string_id == df_to_be_scored.vertex , scored_data.type == df_to_be_scored.vertexType] ).drop("string_id" , "type").write.mode("overwrite").parquet(input_base_path + "/final_integrated_score")
	spark.read.parquet(input_base_path + "/final_integrated_score").write.mode("overwrite").parquet(final_output_path)
	integration_count = spark.read.parquet(input_base_path + "/final_integrated_score").count()
	initial_count = spark.read.parquet(final_output_path).count()
	if integration_count != initial_count:
		raise Exception("All scores not found in final integration")



