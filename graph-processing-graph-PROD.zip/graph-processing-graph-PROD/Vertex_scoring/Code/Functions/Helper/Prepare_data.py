def Prepare_data(metadata_path,structural_path):
	return (metadata_path,structural_path)