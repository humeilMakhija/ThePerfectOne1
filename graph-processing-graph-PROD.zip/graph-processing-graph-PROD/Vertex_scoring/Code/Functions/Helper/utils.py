def pathExistsCheck(path , spark , sc):
	fs = sc._jvm.org.apache.hadoop.fs.FileSystem.get(
		sc._jvm.java.net.URI.create("gs://" + path.split("/")[2]),
		sc._jsc.hadoopConfiguration(),
		)
	return fs.isDirectory(sc._jvm.org.apache.hadoop.fs.Path(path))