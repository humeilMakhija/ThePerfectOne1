#!/bin/bash
sudo /opt/conda/default/bin/pip install cdlib;
sudo /opt/conda/default/bin/pip install lifelines;
sudo /opt/conda/default/bin/pip install -U numpy;
sudo /opt/conda/default/bin/pip install matplotlib;
sudo /opt/conda/default/bin/pip install networkx;
sudo /opt/conda/default/bin/pip install infomap;
sudo /opt/conda/default/bin/pip install jenkspy;
sudo /opt/conda/default/bin/pip install scipy;
sudo /opt/conda/default/bin/pip install statistics;
sudo /opt/conda/default/bin/pip install pandas;
sudo /opt/conda/default/bin/pip install copy;




