def all_average(x):
	average_structural_feature_score = x["average_structural_feature_score"]
	meta_data_average_score = x["meta-data_average_score"]
	final_average_score = ((average_structural_feature_score*3) + (meta_data_average_score*2))/5
	return final_average_score


def sanity_check_final_average(metadata_null_count,structural_null_count,metadata_anomaly_count,structural_anomaly_count):
	if metadata_null_count > 0:
		raise Exception("null values found in Metadata scoring")
	if structural_null_count > 0:
		raise Exception("null values found in Structural scoring")
	if metadata_anomaly_count > 0:
		raise Exception("anomalous scoring found in Metadata scoring")
	if structural_anomaly_count > 0:
		raise Exception("anomalous scoring found in Structural scoring")