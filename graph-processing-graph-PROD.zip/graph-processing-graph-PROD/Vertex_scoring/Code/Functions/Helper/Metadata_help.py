def metadata_average(x):
	dpid_score = x["timestamp_score"]
	timestamp_score = x["dpid_score"]
	average = (dpid_score + timestamp_score)/2
	return average
