def structural_average_score(x):
	iou_array = x["iou_aggregation_score"]
	lcc_array = x["lcc_dc_score"]
	page_rank_array = x["page-rank_score"]
	average_score_array = []
	for i in range(len(iou_array)):
		current_average = (lcc_array[i] + iou_array[i] + page_rank_array[i])/3
		average_score_array.append(current_average)
	return average_score_array


def expand_it(x):
	average_score_array = x["average_structural_feature_score"]
	vertices = x["Vertices"]
	expansion = []
	for i in range(len(average_score_array)):
		expansion.append([vertices[i],average_score_array[i]])
	return expansion


def make_df(x):
	strct = x[0]
	return (strct[0],strct[1])