from Helper.all_average import *
from Helper._packages import *

def final_average_score(input_base_path , path_to_structural_score , path_to_metadata_score , spark , sc):
	df_with_structural_score = spark.read.parquet(path_to_structural_score)
	df_with_metadata_score = spark.read.parquet(path_to_metadata_score)
	structural_null_count = df_with_structural_score.filter(F.col("average_structural_feature_score").isNull()).count()
	metadata_null_count = df_with_metadata_score.filter(F.col("meta-data_average_score").isNull()).count()
	structural_anomaly_count = df_with_structural_score.filter((F.col("average_structural_feature_score") > 1) | (F.col("average_structural_feature_score") < 0)).count()
	metadata_anomaly_count = df_with_metadata_score.filter((F.col("meta-data_average_score") > 1) | (F.col("meta-data_average_score") < 0)).count()
	sanity_check_final_average(metadata_null_count,structural_null_count,metadata_anomaly_count,structural_anomaly_count)
	df_with_score = df_with_structural_score.join(df_with_metadata_score,df_with_metadata_score.long_id == df_with_structural_score.vertices,"inner").select("vertices","average_structural_feature_score","timestamp_score","dpid_score","meta-data_average_score")
	df_with_score.write.mode("overwrite").parquet(input_base_path + "/data_with_score_help")
	df_with_score = spark.read.parquet(input_base_path + "/data_with_score_help")
	all_average_score_udf = F.udf(all_average,DoubleType())
	df_with_score.withColumn("final_average_score",all_average_score_udf(F.struct(F.col("average_structural_feature_score"),F.col("meta-data_average_score")))).write.mode("overwrite").parquet(input_base_path + "/final_output_score")
	print("Scoring is done.")
