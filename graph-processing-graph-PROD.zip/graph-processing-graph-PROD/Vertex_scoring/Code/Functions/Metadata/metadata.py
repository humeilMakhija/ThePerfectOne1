from Helper._packages import *
from Metadata.DPID_functions import *
from Metadata.Timestamp_functions import *
from Helper.Metadata_help import *

def metadata_scoring(input_base_path , long_mapper_path  , non_tube_vertex_set_path ,non_tube_edge_set, dpid_scored_path , metadata_output_path,  spark , sc):
	long_mapper_df = spark.read.parquet(long_mapper_path).withColumnRenamed("string_id" , "vertex").withColumnRenamed("type" , "vertexType")
	# tube_edges = spark.read.parquet(tube_edge_set)
	non_tube_edges = spark.read.parquet(non_tube_edge_set)
	# tube_vertex1 = tube_edges.select(F.col("vertex1").alias("vertex"),F.col("vertex1Type").alias("vertexType"),"dpid","timestamp").distinct()
	# tube_vertex2 = tube_edges.select(F.col("vertex2").alias("vertex"),F.col("vertex2Type").alias("vertexType"),"dpid","timestamp").distinct()
	non_tube_vertex1 = non_tube_edges.select(F.col("vertex1").alias("vertex"),F.col("vertex1Type").alias("vertexType"),"dpid","timestamp").distinct()
	non_tube_vertex2 = non_tube_edges.select(F.col("vertex2").alias("vertex"),F.col("vertex2Type").alias("vertexType"),"dpid","timestamp").distinct()
	# tube_vertex_set_path_from_edges = input_base_path + "/tube_vertices_from_edges"
	non_tube_vertex_set_path_from_edges = input_base_path + "/non_tube_vertices_from_edges"
	# tube_vertex1.union(tube_vertex2).write.mode("overwrite").parquet(tube_vertex_set_path_from_edges)
	non_tube_vertex1.union(non_tube_vertex2).distinct().write.mode("overwrite").parquet(non_tube_vertex_set_path_from_edges)
	# tube_vertex_from_edges = spark.read.parquet(tube_vertex_set_path_from_edges)
	# non_tube_vertex_from_edges = spark.read.parquet(non_tube_vertex_set_path_from_edges)
	# tube_vertex_from_edges.union(non_tube_vertex_from_edges).distinct().write.mode("overwrite").parquet(input_base_path +  "/vertices_from_edges")
	vertex_from_edges = spark.read.parquet(non_tube_vertex_set_path_from_edges)
	# tube_vertex_df = spark.read.parquet(tube_vertex_set_path).select("vertex" , "vertexType" , "dpid" , "timestamp")
	non_tube_vertex_df = spark.read.parquet(non_tube_vertex_set_path).select("vertex" , "vertexType" , "dpid" , "timestamp")
	# tube_vertex_df.union(non_tube_vertex_df).distinct().write.mode("overwrite").parquet(input_base_path +  "/tube_and_non_tube_distinct_string")
	# unioned_df = spark.read.parquet(input_base_path +  "/tube_and_non_tube_distinct_string")
	non_tube_vertex_df.union(vertex_from_edges).write.mode("overwrite").parquet(input_base_path + "/non_tube_distinct_with_vertices_from_edges")
	unioned_df = spark.read.parquet(input_base_path +  "/non_tube_distinct_with_vertices_from_edges")
	unioned_df.join(long_mapper_df , on = ["vertex" , "vertexType"]).select("dpid","timestamp","long_id").write.mode("overwrite").parquet(input_base_path + "/non_tube_ids_long_and_props")
	data_with_metadata = spark.read.parquet(input_base_path +  "/non_tube_ids_long_and_props")
	data_with_metadata = data_with_metadata.groupBy("long_id").agg(F.collect_list("dpid").alias("all_dpid"),F.collect_list("timestamp").alias("all_timestamp"))
	data_with_metadata.write.mode("overwrite").parquet(input_base_path +"/metadata_preparation")
	data_with_metadata = spark.read.parquet(input_base_path + "/metadata_preparation")
	dpid_counter_udf = F.udf(dpid_counter,MapType(StringType(), IntegerType()))
	data_with_metadata = data_with_metadata.withColumn("dpid_map",dpid_counter_udf(F.col("all_dpid")))
	dp_weight_path = spark.read.parquet(dpid_scored_path)
	dp_weight_path = dp_weight_path.select("dpid" , "final_score_Scaled")
	dp_weight = dp_weight_path.collect()
	DP_weight,maxi,mini = create_dp_weights(dp_weight)
	DP_weight = transform_dict(DP_weight,maxi,mini)
	DPID_weight = sc.broadcast(DP_weight)
	timestamp_difference_mean_udf = F.udf(timestamp_difference_mean,IntegerType())
	data_with_metadata.withColumn("timestamp_difference_mean",timestamp_difference_mean_udf(F.col("all_timestamp"))).write.mode("overwrite").parquet(input_base_path +  "/timestamp_difference_mean_path")
	data_with_metadata =  spark.read.parquet(input_base_path +  "/timestamp_difference_mean_path")
	timestamp_difference_median_udf = F.udf(timestamp_difference_median,IntegerType())
	data_with_metadata.withColumn("timestamp_difference_median",timestamp_difference_median_udf(F.col("all_timestamp"))).write.mode("overwrite").parquet(input_base_path +  "/timestamp_difference_median_path")
	data_with_metadata =  spark.read.parquet(input_base_path +  "/timestamp_difference_median_path")
	timestamp_score_udf = F.udf(timestamp_score,FloatType())
	data_with_metadata.withColumn("timestamp_score",timestamp_score_udf(F.struct(F.col("all_timestamp"),F.col("timestamp_difference_median")))).write.mode("overwrite").parquet(input_base_path +  "/timestamp_score_path")
	data_with_metadata = spark.read.parquet(input_base_path +  "/timestamp_score_path")
	dpid_score_udf = F.udf(lambda x: dpid_score(x , DPID_weight) , FloatType())
	data_with_metadata.withColumn("dpid_score",dpid_score_udf(F.struct(F.col("dpid_map")))).write.mode("overwrite").parquet(input_base_path + "/dpid_score_path")
	data_with_metadata = spark.read.parquet(input_base_path +  "/dpid_score_path")
	metadata_average_udf = F.udf(metadata_average,FloatType())
	data_with_metadata.withColumn("meta-data_average_score",metadata_average(F.struct(F.col("timestamp_score"),F.col("dpid_score")))).write.mode("overwrite").parquet(metadata_output_path)
	print(f"Metadata Scoring is done")




