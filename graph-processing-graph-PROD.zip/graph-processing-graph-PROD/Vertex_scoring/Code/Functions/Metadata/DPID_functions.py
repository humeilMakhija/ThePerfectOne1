from Helper._packages import *

def dpid_counter(x):
	return dict(Counter(x))


def create_dp_weights(dp_weight):
	dpid_dict = {}
	weight_max = -1
	weight_min = 1000
	for row in dp_weight:
		curr_dict = dpid_dict.get(int(row["dpid"]),{})
		# curr_dict[row["country"]] = row["final_score_Scaled"]
		weight_min = min(weight_min,row["final_score_Scaled"])
		weight_max = max(weight_max,row["final_score_Scaled"])
		dpid_dict[int(row["dpid"])] = row["final_score_Scaled"]## curr_dict
	return (dpid_dict,weight_max,weight_min)


def transform_dict(DP_weight,OldMax,OldMin):
	OldRange = OldMax - OldMin
	NewMax = 10
	NewMin = 1
	NewRange = (NewMax - NewMin) 
	for dpid,score_ in DP_weight.items():
		# for country,value in dpid_dict.items():
		DP_weight[dpid] = NewMin + (((score_ - OldMin) * NewRange) / OldRange) 
	return DP_weight


def bayesian_rating_products(n, wts,confidence=0.95):
	if sum(n)==0:
		return 0
	K = len(n)
	z = float(st.norm.ppf(1 - (1 - confidence) / 2))
	N = sum(n)
	first_part = 0.0
	second_part = 0.0
	for k, n_k in enumerate(n):
		first_part += (wts[k])*(n[k]+1)/(N+K)
		second_part += (wts[k])*(wts[k])*(n[k]+1)/(N+K)
	try:
		score = first_part - z * math.sqrt((second_part - (first_part*first_part))/(N+K+1))
	except ValueError:
		score = first_part
	return score/10


def dpid_disparity(arr):
    maxi_count = max(arr)
    tot = len(arr)*maxi_count
    disparity_count = 0
    for i in range(len(arr)):
        disparity_count = disparity_count + (maxi_count - arr[i])    
    return (10 - (disparity_count/tot)*10)/10


def dpid_weight_score(count,weights):
    return bayesian_rating_products(count,weights)*dpid_disparity(count)


def dpid_score(x , DPID_weight):
	dpid_dict = x["dpid_map"]
	cont = []
	weights = []
	for idd,ct in dpid_dict.items():
		cont.append(ct)
		try:
			curr_weight = DPID_weight.value[int(idd)]
		except KeyError:
			curr_weight = 0.4
		weights.append(curr_weight)
	return dpid_weight_score(cont,weights)
