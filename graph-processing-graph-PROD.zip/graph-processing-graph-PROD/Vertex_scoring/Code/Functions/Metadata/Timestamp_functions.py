from Helper._packages import *
def timestamp_difference_mean(x):
	timestamps = sorted([int(i) for i in x])
	t0 = timestamps[0]
	difference = []
	for i,timestamp in enumerate(timestamps):
		difference.append(timestamp - t0)
		t0 = timestamp
	return int(statistics.mean(difference))


def timestamp_difference_median(x):
	timestamps = sorted([int(i) for i in x])
	t0 = timestamps[0]
	difference = []
	for i,timestamp in enumerate(timestamps):
		difference.append(timestamp - t0)
		t0 = timestamp
	return int(statistics.median(difference))


def sigmoid(gamma):
 	if gamma < 0:
 		return 1 - 1/(1 + math.exp(gamma))
 	else:
 		return 1/(1 + math.exp(-gamma))


def timestamp_score(x):
	timestamps = sorted([int(float(i)) for i in x[0]],reverse = True)
	median_timestamp = datetime.datetime.utcfromtimestamp(int(x[1])) - datetime.datetime.utcfromtimestamp(0)
	current_timestamp = datetime.datetime.utcnow()
	try:
		recent_timestamp = datetime.datetime.utcfromtimestamp(timestamps[0])
	except ValueError:
		recent_timestamp = datetime.datetime.utcfromtimestamp(timestamps[0]/1000)
	difference = (current_timestamp - recent_timestamp).days
	median_days = median_timestamp.days 
	if median_days == 0:
		median_days = 10
	score_1= sigmoid((median_days -(difference)))
	score_2 = math.pow(0.5,((difference))/max(median_days,1))
	score_3 = math.pow(0.9,((difference))/max(median_days,1))
	if len(timestamps) < 3:
		score_3 = math.pow(0.9,((difference))/10)
	return score_3