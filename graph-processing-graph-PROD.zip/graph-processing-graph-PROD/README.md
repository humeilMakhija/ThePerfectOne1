Graph Processing Project is devided in to 3 components. 
1. Graph Reporting 
2. Graph Cleaning 
3. Graph Anomaly Detection
