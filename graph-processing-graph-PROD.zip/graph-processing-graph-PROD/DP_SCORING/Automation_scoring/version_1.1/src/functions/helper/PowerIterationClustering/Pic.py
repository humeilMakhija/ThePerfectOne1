from helper.packages_ import *
def create_Inter_cluster_edges(path , e_set , cluster_number , iterations , group , spark , sc):
	inter_cluster_path = path+"/Prudhvi/groups="+group+"/PIC_comps/PIC_model="+cluster_number+"/iterations="+iterations+"/inter_cluster_edges/"
	inter = e_set.filter(F.col("src_cluster") != F.col("dst_cluster"))
	inter.select("src").union(inter.select("dst")).distinct().count()
	inter.write.mode("overwrite").parquet(inter_cluster_path)
	return inter_cluster_path


def create_Intra_cluster_edges(path , e_set , cluster_number , iterations , group , spark , sc):
	intra_cluster_path = path+"/Prudhvi/groups="+group+"/PIC_comps/PIC_model="+cluster_number+"/iterations="+iterations+"/intra_cluster_edges/"
	intra = e_set.filter(F.col("src_cluster") == F.col("dst_cluster"))
	v_set = intra.select("src").union(intra.select("dst")).distinct().withColumnRenamed("src" , "id")
	v_set.count()
	intra.write.mode("overwrite").parquet(intra_cluster_path)
	return intra_cluster_path , v_set


def graph_cc_intra(path , intra_cluster_path , cluster_number , iterations , group , spark , sc):
	cc_intra_path = path+"/Prudhvi/groups="+group+"/PIC_comps/PIC_model="+cluster_number+"/iterations="+iterations+"/intra_cluster_components"
	edges_set_intra = spark.read.parquet(intra_cluster_path)
	vertex_set_intra = edges_set_intra.select("src").union(edges_set_intra.select("dst")).distinct().withColumnRenamed("src" , "id")
	graph_intra = GraphFrame(vertex_set_intra , edges_set_intra)
	sc.setCheckpointDir(path+"/Prudhvi/checkpoint_dir")
	print("hiii")
	graph_intra_cc = graph_intra.connectedComponents(algorithm = "graphframes", checkpointInterval = 2, broadcastThreshold = 100000)
	graph_intra_cc.groupby("component").count().sort(F.col("count").desc()).show()
	graph_intra_cc.write.mode("overwrite").parquet(cc_intra_path)
	return True , cc_intra_path


def graph_cc_inter(path , inter_cluster_path , intra_cluster_vertices , cluster_number , iterations , group , spark , sc):
	cc_inter_path = path+"/Prudhvi/groups="+group+"/PIC_comps/PIC_model="+cluster_number+"/iterations="+iterations+"/inter_cluster_components"
	isolated_vertices_path = path+"/Prudhvi/groups="+group+"/PIC_comps/PIC_model="+cluster_number+"/iterations="+iterations+"/isolated_vertices"
	edges_set_inter = spark.read.parquet(inter_cluster_path)
	vertex_set_inter = edges_set_inter.select("src").union(edges_set_inter.select("dst")).distinct().withColumnRenamed("src" , "id")
	inter_cluster_vertices_with_alone_vertices = vertex_set_inter.subtract(intra_cluster_vertices)
	inter_cluster_vertices_with_alone_vertices.join(edges_set_inter , [inter_cluster_vertices_with_alone_vertices.id == edges_set_inter.src]).drop("id").write.mode("overwrite").parquet(path+"/Prudhvi/groups="+group+"/PIC_comps/PIC_model="+cluster_number+"/iterations="+iterations+"/inter_cluster_edges_with_alone_vertices_intermediate")
	intermediate_inter_cluster_edges = spark.read.parquet(path+"/Prudhvi/groups="+group+"/PIC_comps/PIC_model="+cluster_number+"/iterations="+iterations+"/inter_cluster_edges_with_alone_vertices_intermediate")
	inter_cluster_vertices_with_alone_vertices.join(intermediate_inter_cluster_edges , [inter_cluster_vertices_with_alone_vertices.id == intermediate_inter_cluster_edges.dst]).drop("id").write.mode("overwrite").parquet(path+"/Prudhvi/groups="+group+"/PIC_comps/PIC_model="+cluster_number+"/iterations="+iterations+"/inter_cluster_edges_with_alone_vertices")
	inter_cluster_edges = spark.read.parquet(path+"/Prudhvi/groups="+group+"/PIC_comps/PIC_model="+cluster_number+"/iterations="+iterations+"/inter_cluster_edges_with_alone_vertices")
	inter_cluster_vertices_final = inter_cluster_edges.select("src").union(inter_cluster_edges.select("dst")).distinct().withColumnRenamed("src" , "id")
	inter_cluster_vertices_with_alone_vertices.subtract(inter_cluster_vertices_final).write.mode("overwrite").parquet(isolated_vertices_path)
	isolated_vertices = spark.read.parquet(isolated_vertices_path)
	graph_inter = GraphFrame(inter_cluster_vertices_final , inter_cluster_edges)
	sc.setCheckpointDir(path+"/Prudhvi/checkpoint_dir")
	graph_inter_cc = graph_inter.connectedComponents(algorithm = "graphframes", checkpointInterval = 2, broadcastThreshold = 100000)
	graph_inter_cc.groupby("component").count().sort(F.col("count").desc()).show()
	graph_inter_cc = graph_inter_cc.select("id" , "component").union(isolated_vertices.withColumn("component" , F.col("id")).select("id" , "component"))
	graph_inter_cc.write.mode("overwrite").parquet(cc_inter_path)
	return True , cc_inter_path 