from helper.packages_ import *


def sanityCheck(source_, target_, condition_):
    if(source_.count() != target_.count()):
        print("sanity check failed for" + condition_ + "mismatched")
        # exit()
    else:
        print("sanity check passed for" + condition_)
