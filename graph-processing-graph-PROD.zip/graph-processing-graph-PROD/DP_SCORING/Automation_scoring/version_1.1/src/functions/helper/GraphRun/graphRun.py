## helper functions
from helper.gettraversibleedges_c import *
from helper.PowerIterationClustering.PICDriver import *
from helper.communityDetection.communityDetectionDriver import *
from helper.packages_ import *

def GraphFrameCreation(path , edges_mapped , vertex_mapped , dp , spark , sc):
	graph = GraphFrame(vertex_mapped , edges_mapped)
	print(graph)
	sc.setCheckpointDir(path + "graphFrameCreation/dp=" + str(dp) + "/setCheckpointDir")
	conn_comp = graph.connectedComponents(algorithm="graphframes", checkpointInterval=2, broadcastThreshold=100000)
	conn_comp.write.mode("overwrite").parquet(path + "graphFrameCreation/dp=" + str(dp) + "/cc")
	return path + "graphFrameCreation/dp=" + str(dp) + "/cc"

## helper function 
def dpGraphCreation(path , dp_long_edges , spark , sc):
	dps = dp_long_edges.select('dpid').distinct().collect()
	dps = list(map(lambda x:x[0],dps))
	for ind in range(len(dps)): 
		dp = dps[ind]
		curr_df = dp_long_edges.filter(F.col('dpid') == dp)
		curr_df.select('src','dst').distinct().write.mode("overwrite").parquet(path + "graphFrameCreation/dp=" + str(dp) + "/edges")
		edge_df = spark.read.parquet(path + "graphFrameCreation/dp=" + str(dp) + "/edges")
		edge_df.select('src').withColumnRenamed('src','id').union(edge_df.select('dst').withColumnRenamed("dst","id")).distinct().write.mode("overwrite").parquet(path + "graphFrameCreation/dp=" + str(dp) + "/vertices")
		vertex_df = spark.read.parquet(path + "graphFrameCreation/dp=" + str(dp) + "/vertices")
		returned_df_path = GraphFrameCreation(path , edge_df , vertex_df  , dp , spark , sc)
		returned_df = spark.read.parquet(returned_df_path).withColumn('dpid' , F.lit(dp))
		returned_df.select("component" , "id" , "dpid").write.mode("overwrite").parquet(path + "graphFrameCreation/dp=" + str(dp) + "/final_df")
		print("dp scoring done")
	#############################
	dpidccs = spark.read.parquet(path + "graphFrameCreation/dp=*/final_df")
	dpid_ccedges = gettraversibleedges_c(path , dpidccs , dp_long_edges , spark , sc) 
	# sanityCheck(dp_long_edges , dpid_ccedges , " dp edge count before and after traversible join ")
	# sanityCheck(dp_long_edges.select('src','dst').distinct() , dpid_ccedges.select('src','dst').distinct() , " distinct edge count before and after traversible join ")
	maxcount = dpid_ccedges.groupby('dpid','component').count().sort(F.col('count').desc()).agg({"count": "max"}).collect()[0]['max(count)']
	dpidccs.groupby('dpid','component').count().filter(F.col("count") <= 70000).write.mode("overwrite").parquet(path+'dpids_with_ccs_less_than_threshold')
	final_cc = spark.read.parquet(path+'dpids_with_ccs_less_than_threshold').drop("count")
	final_cc.join(dpid_ccedges , on = ["dpid" , "component"]).write.mode("overwrite").parquet(path+'dpids_with_ccs_edges')
	final_edges = spark.read.parquet(path+'dpids_with_ccs_edges')
	final_cc.join(dpidccs , on = ["dpid" , "component"]).write.mode("overwrite").parquet(path+'dpids_with_ccs_vertices')
	dpidccs.groupby('dpid','component').count().filter(F.col("count") > 70000).write.mode("overwrite").parquet(path+'final_cc_to_output_with_dp_which_are_not_processed')
	final_cc_excluded = spark.read.parquet(path+'final_cc_to_output_with_dp_which_are_not_processed')
	final_cc_excluded.join(dpidccs , on = ["dpid" , "component"]).write.mode("overwrite").parquet(path+'final_cc_with_ids_to_output_with_dp_which_are_not_processed')
	spark.read.parquet(path+'final_cc_with_ids_to_output_with_dp_which_are_not_processed').select("dpid" , "component").distinct().groupby("dpid").count().write.mode("overwrite").parquet(path+'rejected_cc_count_per_dpid')
	final_edges.groupby('dpid','component').agg(F.collect_list( F.struct(F.col('src'),F.col('dst'))).alias('edges')).write.mode('overwrite').parquet(path+'dpids_with_ccs_final_edges_groupby')
	allccs = spark.read.parquet(path+'dpids_with_ccs_final_edges_groupby').count()
	return path+'dpids_with_ccs_final_edges_groupby' , allccs

