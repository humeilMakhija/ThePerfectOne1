from helper.packages_ import *
def gettraversibleedges_dp(path , comps_final,final_edges_to_apply_cc,data=""):
	comps_final=comps_final.withColumnRenamed('dpid','dpid_')
	max_comp_intermediate_edges=comps_final.join(final_edges_to_apply_cc, [comps_final.id == final_edges_to_apply_cc.src,comps_final.dpid_==final_edges_to_apply_cc.dpid]).drop("id",'dpid_')
	max_comp_intermediate_edges=max_comp_intermediate_edges.withColumnRenamed("component","src_component")
	max_comp_edges=max_comp_intermediate_edges.join(comps_final , [comps_final.id == max_comp_intermediate_edges.dst,comps_final.dpid_==max_comp_intermediate_edges.dpid]).drop("id",'dpid_').withColumnRenamed("component","dst_component")
	comps_final=comps_final.withColumnRenamed('dpid_','dpid')
	return max_comp_edges.filter(F.col("src_component") == F.col("dst_component")).drop("dst_component").withColumnRenamed("src_component" , "component")
