from helper.packages_ import *
def gettraversibleedges(path , comps_final , final_edges_to_apply_cc,data=""):
	max_comp_intermediate_edges=comps_final.join(final_edges_to_apply_cc, [comps_final.id == final_edges_to_apply_cc.src]).drop("id")
	max_comp_intermediate_edges=max_comp_intermediate_edges.withColumnRenamed("component","src_component")
	max_comp_edges=max_comp_intermediate_edges.join(comps_final , [comps_final.id == max_comp_intermediate_edges.dst]).drop("id").withColumnRenamed("component","dst_component")
	return max_comp_edges.filter(F.col("src_component") == F.col("dst_component")).drop("dst_component").withColumnRenamed("src_component" , "component")
