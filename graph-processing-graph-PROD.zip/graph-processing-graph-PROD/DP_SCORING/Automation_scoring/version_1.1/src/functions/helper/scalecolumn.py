from helper.packages_ import *
def scalecolumn(df,col):
	# UDF for converting column type from vector to double type
	unlist = F.udf(lambda x: round(float(list(x)[0]),3), DoubleType())
	assembler = VectorAssembler(inputCols=[col],outputCol=col+"_Vect")
	# MinMaxScaler Transformation
	scaler = MinMaxScaler(inputCol=col+"_Vect", outputCol=col+"_Scaled")
	# Pipeline of VectorAssembler and MinMaxScaler
	pipeline = Pipeline(stages=[assembler, scaler])
	# Fitting pipeline on dataframe
	returndf= pipeline.fit(df).transform(df).withColumn(col+"_Scaled", unlist(col+"_Scaled")).drop(col+"_Vect")
	return returndf
