from helper.packages_ import *
def gettraversibleedges_c(path , comps_final , final_edges_to_apply_cc , spark , sc):
	comps_final = comps_final.withColumnRenamed('dpid','dpid_')
	comps_final.join(final_edges_to_apply_cc, [comps_final.id == final_edges_to_apply_cc.src,comps_final.dpid_==final_edges_to_apply_cc.dpid]).drop("id","dpid_").withColumnRenamed("component","src_component").write.mode("overwrite").parquet(path + "traversible_edges/intermediate")
	max_comp_intermediate_edges = spark.read.parquet(path + "traversible_edges/intermediate")
	max_comp_intermediate_edges.join(comps_final , [comps_final.id == max_comp_intermediate_edges.dst,comps_final.dpid_==max_comp_intermediate_edges.dpid]).drop("id","dpid_").withColumnRenamed("component","dst_component").drop('src_component').withColumnRenamed('dst_component','component').write.mode("overwrite").parquet(path + "traversible_edges/final")
	return spark.read.parquet(path + "traversible_edges/final")
