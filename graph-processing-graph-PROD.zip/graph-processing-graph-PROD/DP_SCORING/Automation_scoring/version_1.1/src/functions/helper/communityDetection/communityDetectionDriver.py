#now apply infomap on cleaned after pic(which are of size ~6lakh)
from helper.gettraversibleedges_dp import *
from helper.packages_ import *
def InfoMap(x):
	d = defaultdict(list)
	community_dict = dict()
	data = x['edges']
	im = infomap.Infomap()
	for i in data:
		im.add_link(int(list(i.keys())[0]), int(list(i.values())[0]))
	im.run()
	for node_id, module_id in im.modules:d[module_id].append(node_id)
	return x['dpid'] , {min(j):j for i,j in dict(d).items()}


def break_ccs(path , comp_edges, spark , sc , limit=60000): #dpid,component,src,dst
	comp_edges=comp_edges.distinct()
	ind=0
	flag=True
	schema = StructType([
	  StructField('dpid', StringType(), False),
	  StructField('component', LongType(), False),
	  StructField('src', LongType(), False),
	  StructField('dst', LongType(), False),
	  ])
	final_df=spark.sparkContext.parallelize([]).toDF(schema)
	while(flag):
		comp_edges=comp_edges.select('dpid','component','src','dst')
		comp_count=comp_edges.groupby('dpid','component').count()
		maxcount= comp_count.agg({"count": "max"}).collect()[0]['max(count)']
		ideals=comp_count.filter(F.col('count')<limit).select('dpid','component').distinct().withColumnRenamed('component','component_').withColumnRenamed('dpid','dpid_')
		final_df=final_df.union(comp_edges.join(ideals,[ideals.component_==comp_edges.component,ideals.dpid_==comp_edges.dpid]).drop('component_','dpid_'))
		final_df.write.mode('overwrite').parquet(path+'/final_df_'+str(ind))
		final_df=spark.read.parquet(path+'/final_df_'+str(ind))
		ideals=ideals.withColumnRenamed('component_','component').withColumnRenamed('dpid_','dpid')
		tobecleaned=comp_edges.join(ideals,on=['dpid','component'],how='left_anti')
		tobecleaned.select('dpid','component','src','dst').write.mode('overwrite').parquet(path+'/tobecleaned_comp_'+str(ind))
		tobecleaned=spark.read.parquet(path+'/tobecleaned_comp_'+str(ind))
		print("here",ind,maxcount)
		if((not maxcount) or (maxcount>=limit)):
			max_comp_edges_as_dict=tobecleaned.groupby('dpid','component').agg(F.collect_list(F.create_map(F.col("src") , F.col("dst"))).alias("edges"))
			max_comp_edges_as_dict.rdd.map(lambda x: InfoMap(x)).toDF([ "dpid","community_dict"]).write.mode("overwrite").parquet(path+"/comp_communities_detected/"+str(ind))
			y=spark.read.parquet(path+"/comp_communities_detected/"+str(ind))
			df=y.select('dpid',F.explode("community_dict").alias("component" , "id"))
			df2=df.select('dpid',"component" , F.explode("id").alias("id"))
			df2.write.mode("overwrite").parquet(path+"/communitie_with_ids/"+str(ind))
			df2=spark.read.parquet(path+"/communitie_with_ids/"+str(ind))
			print("here2",df2)
			comp_edges=gettraversibleedges_dp(path , df2,tobecleaned.select('dpid','src','dst'))
			print('here3',comp_edges)
			comp_edges.write.mode('overwrite').parquet(path+'/comp_edges_at_itr/'+str(ind))
			comp_edges=spark.read.parquet(path+'/comp_edges_at_itr/'+str(ind))
			ind+=1
		else:
			flag=False 
	return final_df 