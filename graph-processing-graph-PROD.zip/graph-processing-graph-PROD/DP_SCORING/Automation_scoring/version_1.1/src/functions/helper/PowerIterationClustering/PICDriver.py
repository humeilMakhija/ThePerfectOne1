from helper.PowerIterationClustering.Pic import *
from helper.gettraversibleedges import *
from helper.packages_ import *


def runPIC(path , edge_set , cluster_number , iterations  , spark , sc ,group=""):
	try:
		similarities = edge_set.rdd.map(lambda x: tuple((x["src"] , x["dst"] , float(1.0))))
		print(similarities)
		model1 = PowerIterationClustering.train(similarities , int(cluster_number) , int(iterations))
		sav2 = model1.assignments().toDF(["id" , "cluster"])   
		print("I am here")
		sav2.write.mode("overwrite").parquet(path+group+'ccs_cleaned_by_PIC')
		sav2 = spark.read.parquet(path+group+'ccs_cleaned_by_PIC')
		sav2.groupby("cluster").count().sort(F.col("count").desc()).show()
		join1 = edge_set.join(sav2 , [edge_set.src == sav2.id]).withColumnRenamed("cluster" , "src_cluster").drop("id")
		join2 = join1.join(sav2 , [join1.dst == sav2.id]).withColumnRenamed("cluster" , "dst_cluster").drop("id")
		intra_cluster_path ,intra_cluster_vertices = create_Intra_cluster_edges(path , join2 , cluster_number , iterations , group , spark , sc)
		inter_cluster_path = create_Inter_cluster_edges(path , join2 , cluster_number , iterations , group , spark , sc)
		## create intra cluster graphframes and cc
		Flag , cc_intra_path = graph_cc_intra(path , intra_cluster_path , cluster_number , iterations , group , spark , sc)
		Flag , cc_inter_path = graph_cc_inter(path , inter_cluster_path , intra_cluster_vertices , cluster_number , iterations , group , spark , sc)
		if cc_inter_path == "no path" or cc_intra_path == "no path" : 
			print("components not created , size explosion above 30000")
			return False , "no_intra_component_generation" , "no_inter_component_generation"
		else:
			return True , cc_intra_path , cc_inter_path
	except:
		print("PIC not completed , please try again")
		return False ,"",""


def break_with_PIC(path , dpid_ccedges , spark , sc):
	itr=0
	while(True):
		itr+=1
		ccs_with_sizes=dpid_ccedges.groupby('dpid','component').count().sort(F.col('count').desc()).filter(F.col('count')>600000).collect()
		ccs_with_sizes=list(map(lambda x:[x[0],x[1],x[2]],ccs_with_sizes))
		smallones=dpid_ccedges.groupby('dpid','component').count().filter(F.col('count')<=600000).select('dpid','component')
		final_df=dpid_ccedges.join(smallones,on=['dpid','component'])
		schema = StructType([
		  StructField('dpid', StringType(), False),
		  StructField('component', LongType(), False),
		  StructField('src', LongType(), False),
		  StructField('dst', LongType(), False),
		  ])
		cleaned_df=spark.sparkContext.parallelize([]).toDF(schema)
		for ind,i in enumerate(ccs_with_sizes):
			group='G_'+str(ind)+'itr_'+str(itr)
			edgeset=dpid_ccedges.filter( (F.col('dpid')==i[0]) & (F.col('component')==i[1])).select('src','dst')
			size=i[2]
			clusters=str(size//400000)
			flag , cc_intra_path , cc_inter_path= runPIC(path , edgeset ,clusters , 25 , spark , sc ,group)
			spark.read.parquet(cc_intra_path).select("component" , "id").union(spark.read.parquet(cc_inter_path).select("component" , "id")).write.mode("overwrite").parquet(path+group+'ccs_cleaned_by_PIC')
			cleaned_PIC=spark.read.parquet(path+group+'ccs_cleaned_by_PIC')
			cleaned_edges=gettraversibleedges(path , cleaned_PIC,edgeset)
			cleaned_edges.write.mode('overwrite').parquet(path+group+'cleaned_pic_edges_')
			cleaned_edges=spark.read.parquet(path+group+'cleaned_pic_edges_').withColumn('dpid',i[0])
			cleaned_df=cleaned_df.select('src','dst','dpid','component').union(cleaned_edges.select('src','dst','dpid','component'))
		final_df=final_df.select('src','dst','dpid','component').union(cleaned_df.select('src','dst','dpid','component'))
		final_df.write.mode('overwrite').parquet(path+'cleaned_df_after_pic_'+str(itr))
		dpid_ccedges=spark.read.parquet(path+'cleaned_df_after_pic_'+str(itr))
		if(len(ccs_with_sizes)==0):
			return dpid_ccedges,itr
