from helper.packages_ import *
def createBuckets(path , corr_features , dpids_with_all_comp_cc_features_path , spark , sc):
	# now we need to group dp into three categories, high dense, mid dense, low dense 
	all_fetus=spark.read.parquet(dpids_with_all_comp_cc_features_path)
	cc_sizes=all_fetus.select('size_of_cc')
	sizes=cc_sizes.summary().collect()
	mean=float(sizes[1][1])
	std=float(sizes[2][1])
	#so the buckets 
	try:
		total_dps=all_fetus.select('dpid').distinct().count()
		#60
		all_fetus=all_fetus.drop('edges','component')
		for i in corr_features:	
			all_fetus=all_fetus.drop(i)
		all_fetus.filter(F.col('size_of_cc')<=2).write.mode("overwrite").parquet(path + 'bucket1_data')
		all_fetus.filter( (F.col('size_of_cc')>2) & (F.col('size_of_cc')<=int(mean+std))).write.mode("overwrite").parquet(path + 'bucket2_data')
		all_fetus.filter(F.col('size_of_cc')>int(mean+std)).write.mode("overwrite").parquet(path + 'bucket3_data')
		bucket1 = spark.read.parquet(path + 'bucket1_data')
		bucket2 = spark.read.parquet(path + 'bucket2_data')
		bucket3 = spark.read.parquet(path + 'bucket3_data')
		b1_c=bucket1.count()                                                                       
		b2_c=bucket2.count()  
		b3_c=bucket3.count()
		if(b1_c+b2_c+b3_c != all_fetus.count()):
			print('ERROR, b1_c+b2_c+b3_c!=all_fetus.count()')
			exit()
	except:
		print('error')
	return path + 'bucket1_data' , path + 'bucket2_data' , path + 'bucket3_data'
