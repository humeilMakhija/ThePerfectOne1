from ComponentLevelFeatures.scoredpids_intra import *
from helper.packages_ import *
def intraBucketDpScoring(path , dpids_with_all_comp_cc_features_path , bucket1_path , bucket2_path , bucket3_path , componentFeatureOutputPath , spark , sc):
	try:
		all_fetus = spark.read.parquet(dpids_with_all_comp_cc_features_path)
		bucket1 = spark.read.parquet(bucket1_path)
		rem_cols=bucket1.columns
		base='F.sum(bucket1.'
		b='bucket1.size_of_cc'
		x='bucket1.groupby("dpid").agg('
		for i in range(1,len(rem_cols)):
			col=rem_cols[i]
			x+='('+base+col +'*'+b+')/'+base+'size_of_cc)).alias("'+'mean_'+col+'")'+','	
		x=x[:-1]
		x+=')'
		meaned_bucket1= eval(x)
		mb1c=meaned_bucket1.count()
		#  means, the remaining dps have no dps in this bukcet
		bucket2 = spark.read.parquet(bucket2_path)
		base='F.sum(bucket2.'
		b='bucket2.size_of_cc'
		x='bucket2.groupby("dpid").agg('
		for i in range(1,len(rem_cols)):
			col=rem_cols[i]
			x+='('+base+col +'*'+b+')/'+base+'size_of_cc)).alias("'+'mean_'+col+'")'+','
		x=x[:-1]
		x+=')'
		meaned_bucket2=eval(x)
		mb2c=meaned_bucket2.count()
		bucket3 = spark.read.parquet(bucket3_path)
		base='F.sum(bucket3.'
		b='bucket3.size_of_cc'
		x='bucket3.groupby("dpid").agg('
		for i in range(1,len(rem_cols)):
			col=rem_cols[i]
			x+='('+base+col +'*'+b+')/'+base+'size_of_cc)).alias("'+'mean_'+col+'")'+','
		x=x[:-1]
		x+=')'
		meaned_bucket3=eval(x)
		mb3c=meaned_bucket3.count()
		#just check if all union buckets have all dpids 
		t=meaned_bucket1.select('dpid').distinct().union(meaned_bucket2.select('dpid').distinct().union(meaned_bucket3.select('dpid').distinct())).distinct().count()
		meaned_bucket1.write.mode('overwrite').parquet(path+'meaned_bucket1_comp_features')
		meaned_bucket2.write.mode('overwrite').parquet(path+'meaned_bucket2_comp_features')
		meaned_bucket3.write.mode('overwrite').parquet(path+'meaned_bucket3_comp_features')
		if(t!=total_dps):
			print('ERROR, t!=total_dps')
			exit()
	except :
		print('error')
	try:
		bucket1=spark.read.parquet(path+'meaned_bucket1_comp_features')
		bucket2=spark.read.parquet(path+'meaned_bucket2_comp_features')
		bucket3=spark.read.parquet(path+'meaned_bucket3_comp_features')
		# bucket1 already has dpid as first column 
		#funcs
		bucket1_scoreslist=scoredpids_intra(bucket1)
		dpid_with_scores1=spark.createDataFrame(bucket1_scoreslist,['dpid','b1_scores_wrto_b1'])
		dpid_with_scores1.write.mode('overwrite').parquet(componentFeatureOutputPath + '/dpids_with_comparitive_b1_scores_wrto_b1')
		# sanityCheck( dpid_with_scores1 , meaned_bucket1 ,  " meaned_bucket1_ count ")
		bucket2_scoreslist=scoredpids_intra(bucket2)
		dpid_with_scores2=spark.createDataFrame(bucket2_scoreslist,['dpid','b2_scores_wrto_b2'])
		dpid_with_scores2.write.mode('overwrite').parquet(componentFeatureOutputPath + '/dpids_with_comparitive_b2_scores_wrto_b2')
		# sanityCheck( dpid_with_scores2 , meaned_bucket2 ,  " meaned_bucket2_ count ")
		bucket3_scoreslist=scoredpids_intra(bucket3)
		dpid_with_scores3=spark.createDataFrame(bucket3_scoreslist,['dpid','b3_scores_wrto_b3'])
		dpid_with_scores3.write.mode('overwrite').parquet(componentFeatureOutputPath + '/dpids_with_comparitive_b3_scores_wrto_b3')
		# sanityCheck( dpid_with_scores3 , meaned_bucket3 ,  " meaned_bucket3_ count ")
		#now score inter buckets 
		#now call for 1,2-1,3-2,3
		# b1_scores_wrto_b2,b2_scores_wrto_b1=scoredpids_inter(bucket1,bucket2)
		# b1_scores_wrto_b3,b3_scores_wrto_b1=scoredpids_inter(bucket1,bucket3)
		# b2_scores_wrto_b3,b3_scores_wrto_b2=scoredpids_inter(bucket2,bucket3)
		# b1b2=spark.createDataFrame(b1_scores_wrto_b2,['dpid','b1_scores_wrto_b2'])
		# b1b2.write.mode('overwrite').parquet(path+'dpids_with_comparitive_b1_scores_wrto_b2')
		# b1b3=spark.createDataFrame(b1_scores_wrto_b3,['dpid','b1_scores_wrto_b3'])
		# b1b3.write.mode('overwrite').parquet(path+'dpids_with_comparitive_b1_scores_wrto_b3')
		# #join with b1b1
		# b1b2=b1b2.withColumnRenamed('dpid','dpid_')
		# join1=b1b2.join(b1b3,b1b2.dpid_==b1b3.dpid).drop('dpid_')
		# b1b1=spark.read.parquet(path+'dpids_with_comparitive_b1_scores_wrto_b1').withColumnRenamed('dpid','dpid_')
		# join1.join(b1b1,b1b1.dpid_==join1.dpid).drop('dpid_').select('dpid','b1_scores_wrto_b1','b1_scores_wrto_b2','b1_scores_wrto_b3').write.mode('overwrite').parquet(path+'bucket1_dpids_with_intra_inter_scores')
		# bucket1_scores=spark.read.parquet(path+'dpids_with_comparitive_b1_scores_wrto_b1')
		# b2b3=spark.createDataFrame(b2_scores_wrto_b3,['dpid','b2_scores_wrto_b3'])
		# b2b3.write.mode('overwrite').parquet(path+'dpids_with_comparitive_b2_scores_wrto_b3')
		# b2b1=spark.createDataFrame(b2_scores_wrto_b1,['dpid','b2_scores_wrto_b1'])
		# b2b1.write.mode('overwrite').parquet(path+'dpids_with_comparitive_b2_scores_wrto_b1')
		# #join with b2b2
		# b2b3=b2b3.withColumnRenamed('dpid','dpid_')
		# join2=b2b3.join(b2b1,b2b3.dpid_==b2b1.dpid).drop('dpid_')
		# b2b2=spark.read.parquet(path+'dpids_with_comparitive_b2_scores_wrto_b2').withColumnRenamed('dpid','dpid_')
		# join2.join(b2b2,b2b2.dpid_==join2.dpid).drop('dpid_').select('dpid','b2_scores_wrto_b2','b2_scores_wrto_b1','b2_scores_wrto_b3').write.mode('overwrite').parquet(path+'bucket2_dpids_with_intra_inter_scores')
		# bucket2_scores=spark.read.parquet(path+'dpids_with_comparitive_b2_scores_wrto_b2')
		# b3b1=spark.createDataFrame(b3_scores_wrto_b1,['dpid','b3_scores_wrto_b1'])
		# b3b1.write.mode('overwrite').parquet(path+'dpids_with_comparitive_b3_scores_wrto_b1')
		# b3b2=spark.createDataFrame(b3_scores_wrto_b2,['dpid','b3_scores_wrto_b2'])
		# b3b2.write.mode('overwrite').parquet(path+'dpids_with_comparitive_b3_scores_wrto_b2')
		# #join with b3b3
		# b3b2=b3b2.withColumnRenamed('dpid','dpid_')
		# join3=b3b2.join(b3b1,b3b2.dpid_==b3b1.dpid).drop('dpid_')
		# b3b3=spark.read.parquet(path+'dpids_with_comparitive_b3_scores_wrto_b3').withColumnRenamed('dpid','dpid_')
		# join3.join(b3b3,b3b3.dpid_==join3.dpid).drop('dpid_').select('dpid','b3_scores_wrto_b3','b3_scores_wrto_b1','b3_scores_wrto_b2').write.mode('overwrite').parquet(path+'bucket3_dpids_with_intra_inter_scores')
		# bucket3_scores=spark.read.parquet(path+'dpids_with_comparitive_b3_scores_wrto_b3')
	except Exception as error:
		print(error)
