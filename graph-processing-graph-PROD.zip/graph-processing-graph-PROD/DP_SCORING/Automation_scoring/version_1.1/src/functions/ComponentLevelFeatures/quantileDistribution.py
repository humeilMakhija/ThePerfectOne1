from helper.packages_ import *
def quantileDistribution(path , dpids_with_ccs_edges_path , allccs , cc_edges_dps_with_structural_features_path , spark , sc):
	try:
		def vertex_dist(x):
			edges=list(map(lambda x:tuple(x),x['edges']))
			graph_nx=nx.from_edgelist(edges)
			degrees=list(map(lambda x: x[1],list(graph_nx.degree(list(graph_nx.nodes())))))
			quant=[0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,0.95,0.98,0.99,1.0]
			res=list(map(int,list(np.quantile(degrees,quant))))
			return x['dpid'],x['component'],x['edges'],res
		dpids_with_ccs=spark.read.parquet(dpids_with_ccs_edges_path)
		dpids_with_ccs.rdd.map(lambda x: vertex_dist(x)).toDF(["dpid","component","edges","vertex_distribution"]).write.mode('overwrite').parquet(path+'dpids_with_ccs_with_degree_dist')
		degree_dpids=spark.read.parquet(path+'dpids_with_ccs_with_degree_dist')
		degree_dpids=degree_dpids.select("dpid","component","edges",F.col("vertex_distribution")[0],F.col("vertex_distribution")[1],F.col("vertex_distribution")[2],F.col("vertex_distribution")[3],F.col("vertex_distribution")[4],F.col("vertex_distribution")[5],F.col("vertex_distribution")[6],F.col("vertex_distribution")[7],F.col("vertex_distribution")[8],F.col("vertex_distribution")[9],F.col("vertex_distribution")[10],F.col("vertex_distribution")[11],F.col("vertex_distribution")[12])
		quant=[0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,0.95,0.98,0.99,1.0]
		for i in range(13):
			name='vertex_distribution['+str(i)+']'
			to='degree_quantile_'+str(int(100*quant[i]))
			degree_dpids=degree_dpids.withColumnRenamed(name,to) 
		degree_dpids.write.mode('overwrite').parquet(path+'dpids_with_ccs_with_degree_distribution')
		#join with structures
		structures = spark.read.parquet(cc_edges_dps_with_structural_features_path)
		degree_dpids=spark.read.parquet(path+'dpids_with_ccs_with_degree_distribution')
		degree_dpids=degree_dpids.withColumnRenamed('dpid','dpid_').withColumnRenamed('component','component_').withColumnRenamed('edges','edges_')
		structures.join(degree_dpids,[degree_dpids.dpid_==structures.dpid,structures.component==degree_dpids.component_]).drop('dpid_','component_','edges_').write.mode('overwrite').parquet(path+'dpids_with_all_comp_cc_features')
		# if(all_fetus.count()!=allccs):
		# 	print('ERROR, all_fetus.count()!=allccs')
		# 	exit()
		# # True
	except Exception as error:
		print("No",error)
	return path+'dpids_with_all_comp_cc_features'
