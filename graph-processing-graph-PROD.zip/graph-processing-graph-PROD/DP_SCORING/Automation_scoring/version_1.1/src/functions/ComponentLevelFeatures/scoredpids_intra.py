from helper.packages_ import *
def scoredpids_intra(dpids_features):
	#NOW GET WEIGHTS (THE EUCLEDIAN DISTANCE WITHIN THE ROW VECTORS)
	def scoredps(weights,iterations=20):
		numdps=len(weights)
		score_dps=[1/numdps]*numdps #intial score 
		damp=0.85
		newscoredps=[0]*numdps 
		while(iterations):
			iterations-=1
			for i in range(numdps):
				score=0
				for j in range(numdps):
					score+=(weights[i][j]*score_dps[j])
				newscoredps[i]=(1-damp)/numdps + damp*score
			for i in range(numdps):
				score_dps[i]=newscoredps[i]
		ab=score_dps
		if(max(ab)==min(ab)):
			norm=[1 for i in ab]
		else:
			norm = [(float(i)-min(ab))/(max(ab)-min(ab)) for i in ab]
		return score_dps,norm
	def custom_normalize(weights):
		normalized=[]
		for w in weights:
			curr=w[:]
			curr.sort()
			second_max=curr[-2]
			chosen_min=curr[0]
			chosen_max=1.5*second_max
			curr_normalized=[]
			ranged=chosen_max-chosen_min
			for i in w:
				if(i==float('inf')):
					curr_normalized.append(1)
				else:
					curr_normalized.append((i-chosen_min)/ranged)
			normalized.append(curr_normalized)
		return normalized
	def pairwise_distances_weights(features):
		result=[]
		n=len(features)
		for i in range(n):
			result_for_i=[]
			for j in range(n):
				vectora=features[i]
				vectorb=features[j]
				distance=0
				m=len(vectorb)
				for k in range(m):
					if(vectorb[k]==-1 or vectora[k]==-1):
						continue
					distance+=(vectora[k]-vectorb[k])**2
				if(distance==0):
					result_for_i.append(float('inf'))
				else:
					result_for_i.append(1/(distance**0.5))
			result.append(result_for_i)
		return result
	#expects a df with n rows (n=no.of dps)
	#note that the df should have dpid as its first columns
	#get features into a array
	#dpids_features=bucket1
	cols=dpids_features.columns
	if(cols[0]!='dpid'):
		print('ERRORR')
		print('Make the first column as dpid')
		return
	features=dpids_features.rdd.map(lambda row : row).collect()
	dpids=[]
	all_features=[]
	for i in features:
		currf=[]
		for ind,fs in enumerate(i):
			if(ind==0):
				dpids.append(fs)
			else:
				currf.append(fs)
		all_features.append(currf)
	pairwise_dist=pairwise_distances_weights(all_features)
	normalized=custom_normalize(pairwise_dist)
	normalized=list(map(lambda x:(list(map(lambda y:float(y),x))),normalized))
	#NOW JUST SCORE 
	dp_scores,normal_dp_scores=scoredps(normalized,100)
	dpscores_id={}
	for ind,i in enumerate(dpids):
		dpscores_id[i]=normal_dp_scores[ind]
	dpscores_list=list(map(lambda x:[x,dpscores_id[x]],dpscores_id))
	return dpscores_list
