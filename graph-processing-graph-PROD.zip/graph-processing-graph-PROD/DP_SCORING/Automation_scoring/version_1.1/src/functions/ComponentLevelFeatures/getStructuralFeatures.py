from helper.packages_ import *
def find_distancemeasures(G,e=None):
    if e is None:
        e=nx.eccentricity(G)
    diameter=max(e.values())
    radius=min(e.values())
    p=[v for v in e if e[v]==diameter]
    c=[v for v in e if e[v]==radius]
    return radius,diameter,p,c




def getStructuralFeatures(path , dpids_with_ccs_edges_path , allccs , spark , sc):
	try:
		def getClusteringCoeffAndNodeCutMapper(x):
			edges=list(map(lambda x:tuple(x),x['edges']))
			graph_nx=nx.from_edgelist(edges)
			avg_clustering_coef=nx.average_clustering(graph_nx)
			# node_cutset=len(nx.minimum_node_cut(graph_nx))
			return x['dpid'],x['edges'],x['component'],avg_clustering_coef
		######
		def getDistanceMeasureMapper(x):
			edges=list(map(lambda x:tuple(x),x['edges']))
			graph_nx=nx.from_edgelist(edges)
			radius,diameter,periphery_length,centre=find_distancemeasures(graph_nx)
			return x['dpid'],x['edges'],x['component'],x['avg_clustering_coef'],radius,diameter,len(periphery_length),len(centre)
		######
		def getNodeCliqueNumMapper(x):
			edges=list(map(lambda x:tuple(x),x['edges']))
			graph_nx=nx.from_edgelist(edges)
			size_of_cc=len(graph_nx.nodes())
			max_cliq=max((nx.node_clique_number(graph_nx)).values()) #called omega(G)
			return x['dpid'],x['edges'],x['component'],x['avg_clustering_coef'],x['radius'],x['diameter'],x['periphery_length'],x['centre_length'],size_of_cc,max_cliq
		######
		dpids_with_ccs = spark.read.parquet(dpids_with_ccs_edges_path)
		dpids_with_ccs.rdd.map(lambda x: getClusteringCoeffAndNodeCutMapper(x)).toDF(["dpid","edges","component","avg_clustering_coef"]).write.mode('overwrite').parquet(path+'cc_edges_dps_with_avg_cluster_nodecut')
		spark.read.parquet(path+'cc_edges_dps_with_avg_cluster_nodecut').rdd.map(lambda x: getDistanceMeasureMapper(x)).toDF(["dpid","edges","component","avg_clustering_coef","radius","diameter","periphery_length","centre_length"]).write.mode('overwrite').parquet(path+'cc_edges_dps_with_avg_cluster_nodecut_rad_dia_peri_centr')
		spark.read.parquet(path+'cc_edges_dps_with_avg_cluster_nodecut_rad_dia_peri_centr').rdd.map(lambda x: getNodeCliqueNumMapper(x)).toDF([ "dpid","edges","component","avg_clustering_coef","radius","diameter","periphery_length","centre_length","size_of_cc","max_clique"]).write.mode('overwrite').parquet(path+'cc_edges_dps_with_structural_features')
		structures = spark.read.parquet(path+'cc_edges_dps_with_structural_features')
		if(structures.count()!=allccs):
			print("ERROR, structures.count()!=allccs")
			exit()                                                                                      
	except Exception as error:
		print(error)
	return path+'cc_edges_dps_with_structural_features'