from helper.packages_ import *
def getCorrelation(path , dpids_with_all_comp_cc_features_path , spark , sc):
	#before dng the scoring for cc based features
	#find correlation among columns and drop high corrleated columns
	all_fetus=spark.read.parquet(dpids_with_all_comp_cc_features_path)
	all_fetus=all_fetus.drop('edges','component','dpid','size_of_cc')
	# convert to vector column first
	vector_col = "corr_features"
	assembler = VectorAssembler(inputCols=all_fetus.columns, outputCol=vector_col)
	df_vector = assembler.transform(all_fetus).select(vector_col)
	# get correlation matrix
	matrix = Correlation.corr(df_vector, vector_col)
	corr_matrix=matrix.collect()[0]["pearson({})".format(vector_col)].values
	corr_matrix=np.reshape(corr_matrix,(19,19))
	#get correlatiom among columns 
	corr_features=set()
	for i in range(len(all_fetus.columns)):
		for j in range(i): #i not i+1, becoz, if(i+1, then j=i and corr[i][i]is always 1)
			if abs(corr_matrix[i][j]) > 0.97:
				if(all_fetus.columns[j] not in corr_features):
					colname = all_fetus.columns[i]
					corr_features.add(colname)
	return corr_features