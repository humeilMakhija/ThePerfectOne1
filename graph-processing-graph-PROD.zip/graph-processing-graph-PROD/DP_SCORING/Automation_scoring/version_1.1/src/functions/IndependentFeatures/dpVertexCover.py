from helper.packages_ import *


def dpVertexCover(path, dpids_with_its_vertices_long_mapped_path, all_vertices_path, dpids_with_its_final_vertices_path, spark, sc):
    dp_reqids = spark.read.parquet(dpids_with_its_final_vertices_path)
    dps = dp_reqids.select('dpid').distinct().collect()
    dps = list(map(lambda x: x[0], dps))
    schema = StructType([
        StructField('long_id', LongType(), False),
    ])
    included_ids = spark.sparkContext.parallelize([]).toDF(schema)
    n = len(dps)
    threshold = 0.97
    all_vertices = spark.read.parquet(all_vertices_path).select("long_id")
    total_cover = all_vertices.count()
    seendpids = set()
    counter_ = 0
    for i in dps:
        dp_reqids.filter(F.col('dpid') == i).select('long_id').distinct().write.mode('overwrite').parquet(path + "/node_dp_cover/dpid=" + str(i) + "/current_ids")
    while(included_ids.count() < threshold * total_cover):
        maxval = 0
        maxdpid = -1
        for ind, dpid in enumerate(dps):
            if(dpid in seendpids):
                continue
            # dp_reqids.filter(F.col('dpid') == dpid).select('long_id').distinct().write.mode('overwrite').parquet(path + "/node_dp_cover/dpid=" + str(dpid) + "/current_ids")
            curr_ids = spark.read.parquet(path + "/node_dp_cover/dpid=" + str(dpid) + "/current_ids")
            diff = curr_ids.subtract(included_ids).distinct()
            curr_count = diff.count()
            if curr_count > maxval:
                maxval = curr_count
                maxdpid = dpid
        if maxdpid == -1:
            print("ERRORRRR no dpid is selected !!!!")
            break
        print('dpid selected is : ' + str(maxdpid))
        spark.read.parquet(path + "/node_dp_cover/dpid=" + str(maxdpid) + "/current_ids").write.mode("append").parquet(path + "/node_dp_cover_included_dps_ids/")
        included_ids = spark.read.parquet(path + "/node_dp_cover_included_dps_ids/").distinct()
        seendpids.add(maxdpid)
    spark.createDataFrame([[list(seendpids)]] , ["dp"]).write.mode("append").parquet(path + "/all_selected_dps_for_vertex_cover/")
    seendpids = spark.read.parquet(path + "/all_selected_dps_for_vertex_cover/").collect()[0]["dp"]
    dp_score_vertex_cover = defaultdict(int)
    for i in seendpids:
        dp_score_vertex_cover[i] = "{:.8f}".format(float(spark.read.parquet(path + "/node_dp_cover/dpid=" + str(i) + "/current_ids").count()/ total_cover))
    return dp_score_vertex_cover
