from helper.scalecolumn import *
from helper.packages_ import *


def dpScoringAlonenessEdge(path, dp_req_edges_with_longs_path, traversible_edges_groupby, spark, sc):
    dp_req_edges = spark.read.parquet(dp_req_edges_with_longs_path).select('dpid', 'src', 'dst', 'timestamp')
    dp_req_edges.select('dpid', 'src', 'dst').distinct().groupby('src', 'dst').count().filter(F.col('count') == 1).select("src", "dst").write.mode("overwrite").parquet(path + "/edges_seen_by_only_unique_dp")
    edges_seen_by_only_unique_dp = spark.read.parquet(path + "/edges_seen_by_only_unique_dp")
    edges_seen_by_only_unique_dp.join(dp_req_edges, on = ['src', 'dst']).distinct().write.mode('overwrite').parquet(path + "/dp_for_unique_edges")
    dp_for_unique_edges = spark.read.parquet(path + "/dp_for_unique_edges")
    dp_edge_only = dp_for_unique_edges.select('src', 'dst', 'dpid').distinct()
    sanityCheck(dp_edge_only, edges_seen_by_only_unique_dp, " edges seen by unique dp count ")
    dp_alones = dp_edge_only.select('dpid').distinct().collect()
    dp_alones = list(map(lambda x: x[0], dp_alones))
    dp_edge_score_aloness = defaultdict(int)
    total_edges = dp_req_edges.select('src', 'dst').distinct().count()
    for dp in dp_alones:
        alone_count = dp_edge_only.filter(F.col('dpid') == dp).distinct().count()
        dp_edge_score_aloness[dp] = "{:.8f}".format(float((alone_count / total_edges)))
    dp_edge_score_aloness = betweenessCentralityEdgeScoring(path, traversible_edges_groupby, dp_edge_only, dp_edge_score_aloness, spark, sc) 
    spark.createDataFrame(list(dp_edge_score_aloness.items()), ['dp', 'score']).write.mode("overwrite").parquet(path + '/dpScoringAlonenessEdge')
    dp_edge_score_aloness = {i['dp']: float(i['score']) for i in spark.read.parquet(path + '/dpScoringAlonenessEdge').collect()}
    return dp_edge_score_aloness




def betweenessCentralityEdge(path, df, spark, sc):
    def bc_edge(x):
        edges = list(map(lambda x: tuple(x), x['edges']))
        graph_nx = nx.from_edgelist(edges)
        edge_bcs = nx.edge_betweenness_centrality(graph_nx)
        return x['component'], edge_bcs
    print("bc_for_edge starts")
    df.rdd.map(lambda x: bc_edge(x)).toDF(["component", "edges_with_bcs"]).write.mode('overwrite').parquet(path + "/edges_betweeness_centrality")
    edges_betweeness_centrality = spark.read.parquet(path + "/edges_betweeness_centrality")
    sanityCheck(df.select("component"), edges_betweeness_centrality.select("component"), " betweeness centrality for all traversible edges ")
    edges_betweeness_centrality_ = edges_betweeness_centrality.select("component", F.explode("edges_with_bcs"))
    edges_betweeness_centrality_.select('component', 'key.*', 'value').withColumnRenamed('_1', 'src').withColumnRenamed('_2', 'dst').withColumnRenamed('value', 'edge_bc').write.mode('overwrite').parquet(path + "/edges_betweeness_centrality_exploded")
    edges_betweeness_centrality_exploded = spark.read.parquet(path + "/edges_betweeness_centrality_exploded")
    return edges_betweeness_centrality_exploded




def betweenessCentralityEdgeScoring(path, traversible_edges_groupby, dp_edge_only, dp_edge_score_aloness, spark, sc):
    edges_betweeness_centrality_exploded = betweenessCentralityEdge(path, traversible_edges_groupby, spark, sc)
    # here edge_bcs_count may be less than total coz the nx.bc counted all undirected edges only and in the dataset there are b0th a-b and b-a edges
    # now use the dp_edgeonly df here 
    dp_edge_only.join(edges_betweeness_centrality_exploded, on = ["src", "dst"]).select('src', 'dst', 'dpid', 'edge_bc').write.mode('overwrite').parquet(path + "/unique_edges_betweeness_centrality_on_src_and_dst")
    dp_edge_only.join(edges_betweeness_centrality_exploded, [dp_edge_only.src == edges_betweeness_centrality_exploded.dst, dp_edge_only.dst == edges_betweeness_centrality_exploded.src]).drop(dp_edge_only.src).drop(dp_edge_only.dst).select('src', 'dst', 'dpid', 'edge_bc').write.mode('overwrite').parquet(path + "/unique_edges_betweeness_centrality_on_dst_and_src")
#    remaining are revrse direction edges
    spark.read.parquet(path + "/unique_edges_betweeness_centrality_on_src_and_dst").union(spark.read.parquet(path + "/unique_edges_betweeness_centrality_on_dst_and_src")).write.mode('overwrite').parquet(path + "/alone_edges_with_edgebc")
    aloneedges = spark.read.parquet(path + "/alone_edges_with_edgebc").withColumn('edge_score', 1 / F.col('edge_bc'))
    sanityCheck(aloneedges, dp_edge_only, " betweeness centrality for unique dp edges and after join with bet calculation mapper ")
    aloneedges.groupby('dpid').agg(F.avg(F.col('edge_score')).alias('avg_edgescore')).write.mode('overwrite').parquet(path + "/dpid_with_edge_score")
    dpid_with_edge_score = spark.read.parquet(path + "/dpid_with_edge_score")
    # now get avg edge_score for a dpid 
    dpid_with_edge_score_scaled = scalecolumn(dpid_with_edge_score, 'avg_edgescore')
    dpid_with_edge_score_scaled.write.mode('overwrite').parquet(path + '/dpid_with_avg_edge_score_scaled')
    dpids_edge_score = spark.read.parquet(path + '/dpid_with_avg_edge_score_scaled')
    dpids_edge_score = dpids_edge_score.collect()
    # DEFINE DP_SCORE_ALONESS 
    for i in dpids_edge_score:
        dp_edge_score_aloness[i['dpid']] = i['avg_edgescore_Scaled'] * float(dp_edge_score_aloness[i['dpid']])
    return dp_edge_score_aloness
