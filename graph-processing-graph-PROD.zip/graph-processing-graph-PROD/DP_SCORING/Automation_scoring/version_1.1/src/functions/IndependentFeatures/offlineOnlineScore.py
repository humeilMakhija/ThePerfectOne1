from helper.packages_ import *


def offlineOnlineScore(path, dp_req_edges, spark, sc):
    dp_req_edges = dp_req_edges.select("vertex1" , "vertex1Type" , "vertex2" , "vertex2Type" , "dpid")
    dps = dp_req_edges.select('dpid').distinct().collect()
    dp_score_off_on = defaultdict(int)
    dps = list(map(lambda x: x[0], dps))
    for dp in dps:
        dp_score_off_on[dp] = "{:.8f}".format(float(((dp_req_edges.filter(F.col('dpid') == dp).filter(F.col("vertex1Type").contains("id_mid")).filter(~F.col("vertex2Type").contains("id_mid")).count() + dp_req_edges.filter(F.col('dpid') == dp).filter(F.col("vertex2type").contains("id_mid")).filter(F.col("vertex1type").contains("id_mid")).count()) / dp_req_edges.filter(F.col('dpid') == dp).distinct().count())))
    spark.createDataFrame(list(dp_score_off_on.items()), ['dp', 'score']).write.mode("overwrite").parquet(path + 'offlineOnlineScore')
    dp_score_off_on = {i['dp']: float(i['score']) for i in spark.read.parquet(path + '/offlineOnlineScore').collect()}
    return dp_score_off_on
