from helper.packages_ import *


def dpEdgeCover(path, all_edges_path, dp_req_edges_with_longs_path, spark, sc):
    all_edges = spark.read.parquet(all_edges_path)	
    dp_req_edges = spark.read.parquet(dp_req_edges_with_longs_path).select('dpid', 'src', 'dst').distinct()		
    dps = dp_req_edges.select('dpid').distinct().collect()
    dps = list(map(lambda x: x[0], dps))
    schema = StructType([
        StructField('src', LongType(), False),
        StructField('dst', LongType(), False),
    ])
    included_edges = spark.sparkContext.parallelize([]).toDF(schema)
    n = len(dps)
    threshold = 0.97
    total_cover = all_edges.count()
    seendpids = set()
    for i in dps:
        dp_req_edges.filter(F.col('dpid') == i).select('src' , 'dst').distinct().write.mode('overwrite').parquet(path + "/edge_dp_cover/dpid=" + str(i) + "/current_edges")
    while(included_edges.count() < threshold * total_cover):
        maxval = 0
        maxdpid = -1
        for ind, dpid in enumerate(dps):
            if(dpid in seendpids):
                continue
            curr_edges = spark.read.parquet(path + "/edge_dp_cover/dpid=" + str(dpid) + "/current_edges")
            diff = curr_edges.subtract(included_edges).distinct()
            curr_count = diff.count()
            if(curr_count > maxval):
                maxval = curr_count
                maxdpid = dpid
        if(maxdpid == -1):
            print("ERRORRRR no dpid is selected !!!!")
            break
        print("final selected " + str(maxdpid))
        spark.read.parquet(path + "/edge_dp_cover/dpid=" + str(maxdpid) + "/current_edges").select("src" , "dst").write.mode("append").parquet(path + "/edge_dp_cover_included_dps_ids/")
        included_edges = spark.read.parquet(path + "/edge_dp_cover_included_dps_ids/").distinct()
        seendpids.add(maxdpid)
    spark.createDataFrame([[list(seendpids)]] , ["dp"]).write.mode("append").parquet(path + "/all_selected_dps_for_edge_cover/")
    seendpids = spark.read.parquet(path + "/all_selected_dps_for_edge_cover/").collect()[0]["dp"]
    dp_score_cover_edges = defaultdict(int)
    for i in seendpids:
        dp_score_cover_edges[i] = "{:.8f}".format(float( spark.read.parquet(path + "/edge_dp_cover/dpid=" + str(i) + "/current_edges").count()/ total_cover))
    return dp_score_cover_edges

