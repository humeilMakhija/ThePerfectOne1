from helper.packages_ import *


def ingestionPercentScore(path, dp_req_edges, spark, sc):
    dps = dp_req_edges.select('dpid').distinct().collect()
    dps = list(map(lambda x: x[0], dps))
    dp_req_edges = dp_req_edges.select("src" , "dst" , "dpid" , "datetime")
    dp_score_inges = defaultdict(int)
    for dp in dps:
        dp_score_inges[dp] = "{:.8f}".format(float(-(dp_req_edges.filter(F.col('dpid') == dp).where(F.col('datetime').like("%00:00:00")).distinct().count() / dp_req_edges.filter(F.col('dpid') == dp).distinct().count())))
    # now the actual score based on ingestion percent shouldnt be very high so scale it down by alpha 
    spark.createDataFrame(list(dp_score_inges.items()), ['dp', 'score']).write.mode("overwrite").parquet(path + '/ingestionPercentScore')
    alpha = 0.05
    for i in  spark.read.parquet(path + '/ingestionPercentScore').collect():
        if float(i["score"]) != 0:
            dp_score_inges[i["dp"]] = alpha * float(i["score"])
        else:
            dp_score_inges[i["dp"]] = float(i["score"])
    # for i in dp_score_inges.keys():
    #     if(float(dp_score_inges[i]) != 0):
    #         dp_score_inges[i] = alpha * float(dp_score_inges[i])
    return dp_score_inges
