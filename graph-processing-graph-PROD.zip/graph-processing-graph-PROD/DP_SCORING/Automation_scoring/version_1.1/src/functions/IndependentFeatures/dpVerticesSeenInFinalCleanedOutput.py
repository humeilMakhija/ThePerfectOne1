from helper.packages_ import *


def dpVerticesSeenInFinalCleanedOutput(path, dp_vertices_path, dpids_with_its_vertices_long_mapped_path, dpids_with_its_final_vertices_path, spark, sc):
    dp_vertices = spark.read.parquet(dp_vertices_path)
    # the count of all vertices seen by dps( more than actual count coz one vertex can be seen by more than one dp) 
    dp_with_long_ids = spark.read.parquet(dpids_with_its_vertices_long_mapped_path).select('dpid', 'long_id')
    # all_vertices = spark.read.parquet(all_vertices_path)
    # # DataFrame[id: bigint]
    dp_reqids = spark.read.parquet(dpids_with_its_final_vertices_path)
    # this df contains dpid and only those ids which are present in final all vertices 
    # NOW DO THE STEP 1 
    # COLLECT ALL DPIDS 
    dps = dp_with_long_ids.select('dpid').distinct().collect()
    dp_score_vertices = defaultdict(int)
    total = 0
    usefuls = 0
    for i in dps:
        curr_dp = i[0]
        total_seen_ids = dp_with_long_ids.filter(F.col('dpid') == curr_dp).select('long_id').distinct().count()
        useful_ids = dp_reqids.filter(F.col('dpid') == curr_dp).select('long_id').distinct().count()
        dp_score_vertices[curr_dp] = useful_ids / total_seen_ids
        usefuls += useful_ids
        total += total_seen_ids 
    for i in dp_score_vertices.keys():
        dp_score_vertices[i] = "{:.8f}".format(float((dp_score_vertices[i])))
    spark.createDataFrame(list(dp_score_vertices.items()), ['dp', 'score']).write.mode("overwrite").parquet(path + '/dpVerticesSeenInFinalCleanedOutput')
    dp_score_vertices = {i['dp']: float(i['score']) for i in spark.read.parquet(path + '/dpVerticesSeenInFinalCleanedOutput').collect()}
    return dp_score_vertices
