from helper.packages_ import *


def dpEdgesSeenInFinalCleanedOutput(path, dp_edges_mapped_to_long_path, dp_req_edges_with_longs_path, spark, sc):
    dp_long_edges = spark.read.parquet(dp_edges_mapped_to_long_path)
    #  (along with timestamps and multiple dpids) 
    dp_req_edges = spark.read.parquet(dp_req_edges_with_longs_path).select('dpid', 'src', 'dst').distinct()		
    # since an edge is seen by multiple dps
    dps = dp_long_edges.select('dpid').distinct().collect()
    dp_score_edges = defaultdict(int)
    for i in dps:
        curr_dp = i[0]
        total_seen_edges = dp_long_edges.filter(F.col('dpid') == curr_dp).select('src', 'dst').distinct().count()
        useful_edges = dp_req_edges.filter(F.col('dpid') == curr_dp).select('src', 'dst').distinct().count()
        dp_score_edges[curr_dp] = "{:.8f}".format(float((useful_edges / total_seen_edges)))
    spark.createDataFrame(list(dp_score_edges.items()), ['dp', 'score']).write.mode("overwrite").parquet(path + '/dpEdgesSeenInFinalCleanedOutput')
    dp_score_edges = {i['dp']: float(i['score']) for i in spark.read.parquet(path + '/dpEdgesSeenInFinalCleanedOutput').collect()}
    return dp_score_edges
