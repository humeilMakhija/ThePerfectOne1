from helper.scalecolumn import *
from helper.packages_ import *


def dpScoringAlonenessNode(path, edges_path_nontube, all_vertices_path, long_mapped_ids, traversible_edges_groupby, spark, sc):
    # edges_tube = spark.read.parquet(edges_path_tube)
    edges_nontube = spark.read.parquet(edges_path_nontube)
    # edges_tube.select('dpid', 'vertex1', 'vertex1type').select("dpid", F.col("vertex1").alias("vertex"), F.col("vertex1type").alias("vertexType")).union(edges_tube.select('dpid', 'vertex2', 'vertex2type').select("dpid", F.col("vertex2").alias("vertex"), F.col("vertex2type").alias("vertexType"))).distinct().write.mode('overwrite').parquet(path + "/dp_tube_vertices")
    edges_nontube.select('dpid', F.col("vertex1").alias("vertex"), F.col("vertex1Type").alias("vertexType")).union(edges_nontube.select('dpid', F.col("vertex2").alias("vertex"), F.col("vertex2Type").alias("vertexType"))).distinct().write.mode('overwrite').parquet(path + "/dp_nontube_vertices")
    # spark.read.parquet(path + "/dp_tube_vertices").select("dpid", "vertex", "vertexType").union(spark.read.parquet(path + "/dp_nontube_vertices").select("dpid", "vertex", "vertexType")).distinct().write.mode('overwrite').parquet(path + "/dpids_with_its_vertices")
    dp_vertices = spark.read.parquet(path + '/dp_nontube_vertices')
    # now join with long mapped ids 
    dp_vertices.join(long_mapped_ids, on = ["vertex" , "vertexType"]).write.mode('overwrite').parquet(path + '/dpids_with_its_vertices_long_mapped')
    dp_with_long_id = spark.read.parquet(path + '/dpids_with_its_vertices_long_mapped').select('dpid', 'long_id')
    all_vertices = spark.read.parquet(all_vertices_path).select("long_id")
    # DataFrame[id: bigint]
    dp_with_long_id.join(all_vertices, on = "long_id").write.mode('overwrite').parquet(path + '/dpids_with_its_final_vertices')
    dp_reqids = spark.read.parquet(path + '/dpids_with_its_final_vertices')
    sanityCheck(all_vertices, dp_reqids.select('long_id').distinct(), " traversible id count and distinct id count from dp long df ")
    alone_ids = dp_reqids.groupby('long_id').count().filter(F.col('count') == 1).select("long_id")
    # alones are the ids which are seen by only one dp
    alone_ids.join(dp_reqids, on = 'long_id').drop('long_id_').write.mode('overwrite').parquet(path + '/only_me_ids_dpids')
    alone_id_dps = spark.read.parquet(path + '/only_me_ids_dpids')
    sanityCheck(alone_id_dps, alone_ids, " ids seen by single dp coming from groupby and ids seen by single dp after groupby join ")
    alone_dps = alone_id_dps.select('dpid').distinct().collect()
    alone_dps = list(map(lambda x: x[0], alone_dps))
    dp_id_score_aloness = defaultdict(int)
    total_ids = dp_reqids.select('long_id').distinct().count()
    # now score
    for dp in alone_dps:
        alone_count = alone_id_dps.filter(F.col('dpid') == dp).distinct().count()
        # print(alone_count , total_ids)
        dp_id_score_aloness[dp] = "{:.8f}".format(float((alone_count / total_ids)))
    dp_id_score_aloness = betweenessCentralityVertexScoring(path, traversible_edges_groupby, alone_id_dps, dp_id_score_aloness, spark, sc)
    spark.createDataFrame(list(dp_id_score_aloness.items()), ['dp', 'score']).write.mode("overwrite").parquet(path + '/dpScoringAlonenessNode')
    dp_id_score_aloness = {i['dp']: float(i['score']) for i in spark.read.parquet(path + '/dpScoringAlonenessNode').collect()}
    return dp_id_score_aloness, path + '/dp_nontube_vertices', path + '/dpids_with_its_vertices_long_mapped', path + '/dpids_with_its_final_vertices'  

 # now same as before, the ids have to scored based on anaomaly
# so node bc can be used in a similar way 


def betweenessCentralityVertex(path, df, spark, sc):
    def bc_node(x):
        edges = list(map(lambda x: tuple(x), x['edges']))
        graph_nx = nx.from_edgelist(edges)
        node_bcs = nx.betweenness_centrality(graph_nx)
        return x['component'], node_bcs
    df.rdd.map(lambda x: bc_node(x)).toDF(["component", "nodes_with_bcs"]).write.mode('overwrite').parquet(path + "/node_betweeness_centrality")
    interm_ = spark.read.parquet(path + "/node_betweeness_centrality").select("component", F.explode("nodes_with_bcs"))
    interm_.withColumnRenamed('key', 'id').withColumnRenamed('value', 'node_bc').write.mode('overwrite').parquet(path + '/nodes_with_bc_exploded')
    nodebcs = spark.read.parquet(path + '/nodes_with_bc_exploded')
    return nodebcs


def betweenessCentralityVertexScoring(path, traversible_edges_groupby, alone_id_dps, dp_id_score_aloness, spark, sc):
    nodebcs = betweenessCentralityVertex(path, traversible_edges_groupby, spark, sc)
    alone_id_dps.join(nodebcs, nodebcs.id == alone_id_dps.long_id).drop('long_id').write.mode('overwrite').parquet(path + '/alone_ids_with_nodebc')
    alone_ids_with_nodebc = spark.read.parquet(path + '/alone_ids_with_nodebc')
    node_scores = alone_ids_with_nodebc.withColumn('node_score', 1 / F.col('node_bc'))
    # #scale the score between 0 -1
    node_scores.groupby('dpid').agg(F.avg(F.col('node_score')).alias('avg_nodescore')).write.mode('overwrite').parquet(path + '/dpid_with_node_score')
    dpid_with_node_score = spark.read.parquet(path + '/dpid_with_node_score').fillna({'avg_nodescore': 1})
    # now get avg node_score for a dpid 
    # dpid_with_nodescore = dpid_with_nodescore.fillna({'avg_nodescore':1})
    dpid_with_avg_node_score_scaled = scalecolumn(dpid_with_node_score, 'avg_nodescore')
    dpid_with_avg_node_score_scaled.write.mode('overwrite').parquet(path + '/dpid_with_avg_node_score_scaled')
    dpids_node_score = spark.read.parquet(path + '/dpid_with_avg_node_score_scaled')
    dpids_node_score = dpids_node_score.collect()
    for i in dpids_node_score:
        dp_id_score_aloness[i['dpid']] = i['avg_nodescore_Scaled'] * float(dp_id_score_aloness[i['dpid']])
    return dp_id_score_aloness
