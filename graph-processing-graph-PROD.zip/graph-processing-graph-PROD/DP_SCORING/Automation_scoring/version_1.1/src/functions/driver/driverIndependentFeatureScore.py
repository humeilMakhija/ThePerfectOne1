from IndependentFeatures.dpEdgeCover import *
from IndependentFeatures.dpEdgesSeenInFinalCleanedOutput import *
from IndependentFeatures.dpScoringAlonenessEdge import *
from IndependentFeatures.dpScoringAlonenessNode import *
from IndependentFeatures.dpVertexCover import *
from IndependentFeatures.dpVerticesSeenInFinalCleanedOutput import *
from IndependentFeatures.ingestionPercentScore import *
from IndependentFeatures.offlineOnlineScore import *
from helper.packages_ import *


def dpScoringIndependentFeatureDriver(path, edges_path_nontube, long_mapped_ids_path, all_traversible_vertices_path, all_traversible_edges_path, independentFeatureOutputPath, spark, sc):
    edges_nontube = spark.read.parquet(edges_path_nontube)
    dp_edges = edges_nontube.select('dpid', 'vertex1', "vertex1Type", 'vertex2', "vertex2Type" , 'timestamp')
    dp_edges_mapped_to_long_path = path + "/dp_edges_mapped_to_long"
    long_mapped_ids = spark.read.parquet(long_mapped_ids_path)
    long_mapped_ids.join(dp_edges, [long_mapped_ids.vertex == dp_edges.vertex1, long_mapped_ids.vertexType == dp_edges.vertex1Type]).drop("vertex", "vertexType").withColumnRenamed("long_id", "src").write.mode("overwrite").parquet(path + "/dp_edges_mapped_to_long_intermediate")
    intermediate_edges = spark.read.parquet(path + "/dp_edges_mapped_to_long_intermediate")
    long_mapped_ids.join(intermediate_edges, [long_mapped_ids.vertex == intermediate_edges.vertex2, long_mapped_ids.vertexType == intermediate_edges.vertex2Type]).drop("vertex", "vertexType").withColumnRenamed("long_id", "dst").write.mode("overwrite").parquet(dp_edges_mapped_to_long_path)
    dp_longedges = spark.read.parquet(dp_edges_mapped_to_long_path)
    
    dp_req_edges_with_longs_path = path + '/dp_req_edges_with_longs_distinct'
    traversible_edges = spark.read.parquet(all_traversible_edges_path)  # all edges path is the merged edges of tube and nontube
    dp_longedges.join(traversible_edges, on = ["src", "dst"]).drop("src_string_id" , "dst_string_id" , "src_type" , "dst_type").write.mode('overwrite').parquet(dp_req_edges_with_longs_path)
    dp_req_edges = spark.read.parquet(dp_req_edges_with_longs_path)     
    dp_req_edges = dp_req_edges.withColumn("datetime", F.from_unixtime(F.col("timestamp")))
   
    traversible_edges.groupby('component').agg(F.collect_list(F.struct(F.col('src'), F.col('dst'))).alias('edges')).write.mode('overwrite').parquet(path + "/traversible_edges_groupby")
    traversible_edges_groupby = spark.read.parquet(path + "/traversible_edges_groupby")
    # this dps count may be < the total dps(since we took only the merged edges tube-nontube)  
    # now give score to these dps ,(the remaining dps are given a negative score in dpcover section)

    dp_score_inges = ingestionPercentScore(path, dp_req_edges, spark, sc)
    dp_score_off_on = offlineOnlineScore(path, dp_req_edges, spark, sc)
    dp_edge_score_aloness = dpScoringAlonenessEdge(path, dp_req_edges_with_longs_path, traversible_edges_groupby, spark, sc)
    dp_id_score_aloness, dp_vertices_path, dpids_with_its_vertices_long_mapped_path, dpids_with_its_final_vertices_path = dpScoringAlonenessNode(path, edges_path_nontube, all_traversible_vertices_path, long_mapped_ids, traversible_edges_groupby, spark, sc)
    dp_score_vertices = dpVerticesSeenInFinalCleanedOutput(path, dp_vertices_path, dpids_with_its_vertices_long_mapped_path, dpids_with_its_final_vertices_path, spark, sc)
    dp_score_vertex_cover = dpVertexCover(path, dpids_with_its_vertices_long_mapped_path, all_traversible_vertices_path, dpids_with_its_final_vertices_path, spark, sc)
    dp_score_edges = dpEdgesSeenInFinalCleanedOutput(path, dp_edges_mapped_to_long_path, dp_req_edges_with_longs_path, spark, sc)
    dp_score_cover_edges = dpEdgeCover(path, all_traversible_edges_path, dp_req_edges_with_longs_path, spark, sc)
    # make a df from above scores
    dp_long_edges = spark.read.parquet(dp_edges_mapped_to_long_path).withColumnRenamed('src', 'src_long_id').withColumnRenamed('dst', 'dst_long_id')
    all_dps_from_vertices = dp_long_edges.select('dpid').distinct().collect()
    all_dps_from_vertices = list(map(lambda x: x[0], all_dps_from_vertices))
    dp_map = defaultdict(list)
    try:
        # 8 different scores-
        for dp in all_dps_from_vertices:
            if(dp in dp_score_inges and float(dp_score_inges[dp]) != 0):
                dp_map[dp].append(float(dp_score_inges[dp]))
            else:
                dp_map[dp].append(0.0)  # the nonexisent dps here are given negative score in requires_score
            if(dp in dp_score_off_on):
                dp_map[dp].append(float(dp_score_off_on[dp]))
            else:
                dp_map[dp].append(0.0)
            if(dp in dp_edge_score_aloness):
                dp_map[dp].append(float(dp_edge_score_aloness[dp]))
            else:
                dp_map[dp].append(0.0)
            if(dp in dp_id_score_aloness):
                dp_map[dp].append(float(dp_id_score_aloness[dp]))
            else:
                dp_map[dp].append(0.0)
            if(dp_score_vertices[dp] != 0):
                dp_map[dp].append(float(dp_score_vertices[dp]))
            else:
                dp_map[dp].append(-0.3)
            if(dp in dp_score_vertex_cover):
                dp_map[dp].append(float(dp_score_vertex_cover[dp]))
            else:
                dp_map[dp].append(0.0)
            if(dp_score_edges[dp] != 0):
                dp_map[dp].append(float(dp_score_edges[dp]))
            else:
                dp_map[dp].append(-0.3)
            if(dp in dp_score_cover_edges):
                dp_map[dp].append(float(dp_score_cover_edges[dp]))
            else:
                dp_map[dp].append(0.0)
        dp_scores = []
        for dp in dp_map.keys():
            curr = [dp]
            curr.extend(dp_map[dp])
            dp_scores.append(curr)  
        Columns = ["dpid", "dp_score_inges", "dp_score_off_on", "dp_edge_score_aloness", "dp_id_score_aloness", "dp_score_vertices", "dp_score_vertex_cover", "dp_score_edges", "dp_score_cover_edges"]
        scores_df = spark.createDataFrame(data=dp_scores, schema = Columns)
        scores_df.show()
        scores_df.write.mode('overwrite').parquet(independentFeatureOutputPath )
        scores_df = spark.read.parquet(independentFeatureOutputPath )
    except:
        print("error please check")
    return dp_edges_mapped_to_long_path, dpids_with_its_vertices_long_mapped_path
