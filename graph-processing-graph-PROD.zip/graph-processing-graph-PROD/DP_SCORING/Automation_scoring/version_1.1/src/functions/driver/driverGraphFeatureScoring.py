from GraphLevelFeatures.getGraphLevelFeatures import *
from helper.GraphRun.graphRun import *
from GraphLevelFeatures.pageRankCalculation import *
from helper.packages_ import *


def dpScoringGraphFeatureDriver(path, dp_edges_mapped_to_long_path, nonTubeEdgePath, dpids_with_its_vertices_long_mapped_path, graphFeatureOutputPath, spark, sc):
    # path += "/data/graph_feature/"
    dp_long_edges = spark.read.parquet(dp_edges_mapped_to_long_path)
    # need to apply cc on each dp graph 
    dp_long_edges = dp_long_edges.select('src', 'dst', "dpid").distinct()
    dps_edges_count = dp_long_edges.count()
    dpids_with_ccs_edges_path, allccs = dpGraphCreation(path, dp_long_edges, spark, sc)
    dpid_with_comp_independent_features_path = getGraphLevelFeatures(path, dpids_with_ccs_edges_path, nonTubeEdgePath, dpids_with_its_vertices_long_mapped_path, spark, sc)
    pageRankForGraphLevelFeatures(path, dpid_with_comp_independent_features_path, graphFeatureOutputPath, spark, sc)
    ##### end of graph level features #######################################################
    return dpids_with_ccs_edges_path, allccs
