from ComponentLevelFeatures.getStructuralFeatures import *
from ComponentLevelFeatures.quantileDistribution import *
from ComponentLevelFeatures.getCorrelation import *
from ComponentLevelFeatures.createBuckets import *
from ComponentLevelFeatures.intraBucketDpScoring import *
from helper.packages_ import *

def dpScoringComponentFeatureDriver(path , dpids_with_ccs_edges_path , allccs , componentFeatureOutputPath , spark , sc):
	cc_edges_dps_with_structural_features_path = getStructuralFeatures(path , dpids_with_ccs_edges_path , allccs , spark , sc)
	dpids_with_all_comp_cc_features_path = quantileDistribution(path , dpids_with_ccs_edges_path , allccs , cc_edges_dps_with_structural_features_path , spark , sc)#now independent features(no components)
	corr_features = getCorrelation(path , dpids_with_all_comp_cc_features_path , spark , sc)
	bucket1_path , bucket2_path , bucket3_path = createBuckets(path , corr_features , dpids_with_all_comp_cc_features_path , spark , sc)
	intraBucketDpScoring(path , dpids_with_all_comp_cc_features_path , bucket1_path , bucket2_path , bucket3_path ,componentFeatureOutputPath  , spark , sc)
	
