from helper.packages_ import *
from helper.scalecolumn import *
def aggregatedDpScoringDriver(path  , dpids_with_its_edges_path , output_path ,  independentFeatureOutputPath , componentFeatureOutputPath , graphFeatureOutputPath , spark , sc ):
	# path += "/data/output/"
	dp_longedges= spark.read.parquet(dpids_with_its_edges_path).withColumnRenamed('src','src_long_id').withColumnRenamed('dst','dst_long_id')
	all_dps=(dp_longedges.select('dpid').distinct().collect())
	all_dps=list(map(lambda x:x[0],all_dps))
	comparitive_ind_scores = spark.read.parquet(graphFeatureOutputPath )
	bucket1_scores = spark.read.parquet(componentFeatureOutputPath + '/dpids_with_comparitive_b1_scores_wrto_b1')
	bucket2_scores = spark.read.parquet(componentFeatureOutputPath + '/dpids_with_comparitive_b2_scores_wrto_b2')
	bucket3_scores = spark.read.parquet(componentFeatureOutputPath + '/dpids_with_comparitive_b3_scores_wrto_b3')
	#union the remaining dps in every bucket
	bucket1_rem = list(set(all_dps)-set(list(map(lambda x:x[0],bucket1_scores.select('dpid').collect()))))
	bucket2_rem = list(set(all_dps)-set(list(map(lambda x:x[0],bucket2_scores.select('dpid').collect()))))
	bucket3_rem = list(set(all_dps)-set(list(map(lambda x:x[0],bucket3_scores.select('dpid').collect()))))
	bucket1_rem_list=[]
	for dp in bucket1_rem:
		bucket1_rem_list.append([dp,0.0])
	bucket2_rem_list=[]
	for dp in bucket2_rem:
		bucket2_rem_list.append([dp,0.0])
	bucket3_rem_list=[]
	for dp in bucket3_rem:
		bucket3_rem_list.append([dp,0.0])
	if(len(bucket1_rem_list)):
		bucket1_rem_df=spark.createDataFrame(data=bucket1_rem_list,schema=bucket1_scores.columns)
	if(len(bucket2_rem_list)):
		bucket2_rem_df=spark.createDataFrame(data=bucket2_rem_list,schema=bucket2_scores.columns)
	if(len(bucket3_rem_list)):
		bucket3_rem_df=spark.createDataFrame(data=bucket3_rem_list,schema=bucket3_scores.columns)
	if(len(bucket1_rem_list)):
		bucket1_scores=bucket1_scores.union(bucket1_rem_df)
	if(len(bucket2_rem_list)):
		bucket2_scores=bucket2_scores.union(bucket2_rem_df)
	if(len(bucket3_rem_list)):
		bucket3_scores=bucket3_scores.union(bucket3_rem_df)
	all_scores=bucket1_scores.join(bucket2_scores,on=['dpid'])
	all_scores=all_scores.join(bucket3_scores,on=['dpid'])
	final_comp_scores=all_scores.join(comparitive_ind_scores,on=['dpid'])
	final_comp_scores.write.mode('overwrite').parquet(path+'/all_comp_final_scores')
	final_comp_scores=spark.read.parquet(path+'/all_comp_final_scores')
	scores_df = spark.read.parquet(independentFeatureOutputPath)
	final_all_scores_df=scores_df.join(final_comp_scores,on=['dpid'])
	final_all_scores_df.write.mode('overwrite').parquet(path+'/all_final_comp_ind_scores')
	# scores_df.write.mode('overwrite').parquet(path + '/all_final_comp_ind_scores')
	final_all_scores_df = spark.read.parquet(path + '/all_final_comp_ind_scores')
	final_all_scores_df=final_all_scores_df.drop('b1_scores_wrto_b2', 'b1_scores_wrto_b3','b2_scores_wrto_b1', 'b2_scores_wrto_b3','b3_scores_wrto_b2', 'b3_scores_wrto_b1').withColumnRenamed('b1_scores_wrto_b1','bucket1_score').withColumnRenamed('b2_scores_wrto_b2','bucket2_score').withColumnRenamed('b3_scores_wrto_b3','bucket3_score')
	final_all_scores_df = final_all_scores_df.withColumn('final_score',F.col('dp_score_inges')+F.col('dp_score_off_on')+F.col('dp_edge_score_aloness')+F.col('dp_id_score_aloness')+F.col('dp_score_vertices')+F.col('dp_score_vertex_cover')+F.col('dp_score_edges')+F.col('dp_score_cover_edges')+F.col('bucket1_score')+F.col('bucket2_score')+F.col('bucket3_score')+F.col('comparitive_ind_score'))
	# final_all_scores_df = final_all_scores_df.withColumn('final_score',F.col('dp_score_inges')+F.col('dp_score_off_on')+F.col('dp_edge_score_aloness')+F.col('dp_id_score_aloness')+F.col('dp_score_vertices')+F.col('dp_score_vertex_cover')+F.col('dp_score_edges')+F.col('dp_score_cover_edges'))
	scaled = scalecolumn(final_all_scores_df , 'final_score')
	scaled = scaled.select('dpid' , 'final_score_Scaled')
	scaled.write.mode('overwrite').parquet(output_path)







