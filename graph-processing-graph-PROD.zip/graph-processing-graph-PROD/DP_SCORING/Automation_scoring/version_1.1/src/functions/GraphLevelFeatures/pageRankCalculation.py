from helper.packages_ import *
def pageRankForGraphLevelFeatures(path , dpid_with_comp_independent_features_path , graphFeatureOutputPath , spark , sc):
	try:
		def pairwise_distances_weights(features):
			result=[]
			n=len(features)
			for i in range(n):
				result_for_i=[]
				for j in range(n):
					vectora=features[i]
					vectorb=features[j]
					distance=0
					m=len(vectorb)
					for k in range(m):
						if(vectorb[k]==-1 or vectora[k]==-1):
							continue
						distance+=(vectora[k]-vectorb[k])**2
					if(distance==0):
						result_for_i.append(float('inf'))
					else:
						result_for_i.append(1/(distance**0.5))
				result.append(result_for_i)
			return result
		def custom_normalize(weights):
			normalized=[]
			for w in weights:
				curr=w[:]
				curr.sort()
				second_max=curr[-2]
				chosen_min=curr[0]
				chosen_max=1.5*second_max
				curr_normalized=[]
				ranged=chosen_max-chosen_min
				for i in w:
					if(i==float('inf')):
						curr_normalized.append(1)
					else:
						curr_normalized.append((i-chosen_min)/ranged)
				normalized.append(curr_normalized)
			return normalized
		def scoredps(weights,iterations=20):
			numdps=len(weights)
			damp=0.85
			score_dps=[1/numdps]*numdps #intial score 
			newscoredps=[0]*numdps 
			while(iterations):
				iterations-=1
				for i in range(numdps):
					score=0
					for j in range(numdps):
						score+=(weights[i][j]*score_dps[j])
					newscoredps[i]= (1-damp)/numdps + damp*score 
				for i in range(numdps):
					score_dps[i]=newscoredps[i]
			a=score_dps
			norm = [(float(i)-min(a))/(max(a)-min(a)) for i in a]
			return score_dps,norm
		dps_ind_fetus=spark.read.parquet(dpid_with_comp_independent_features_path)
		dps_ind_fetus=dps_ind_fetus.drop('total_ccs')
		# the avg_datetime is the string but we need integer which is avg timestamp, basically it is the number of milliseconds from a prefixed time(jan1 1970)
		dps_ind_fetus=dps_ind_fetus.drop('avg_datetime')
		dps_ind_fetus=dps_ind_fetus.select('dpid','mean_cc_size', 'online_percent', 'offline_percent', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'avg_timestamp', 'percent_of_ccs_seen', 'online_skewed_percent', 'offline_skewed_percent', 'not_skewed_percent')
		features=dps_ind_fetus.rdd.map(lambda row : row).collect()
		dpids=[]
		all_features=[]
		for i in features:
			currf=[]
			for ind,fs in enumerate(i):
				if(ind==0):
					dpids.append(fs)
				else:
					currf.append(fs)
			all_features.append(currf)
		#while taking eucledian distance the -1 values are ignored in the sum
		#the value returned is 1/distance, sicne we are using them as weights
		pairwise_dist=pairwise_distances_weights(all_features)
		score_df=spark.createDataFrame(pairwise_dist)
		score_df.write.mode('overwrite').parquet(path+'euclidian_distances_comp_independent')
		score_df=spark.read.parquet(path+'euclidian_distances_comp_independent')
		# 57*57
		#now we got distances, need to convert them to weights
		#so less the distance, more the weight, so 1/ distance 
		# normalize the weights row wise (since each row are the weights for each dp)
		#while normalising, the inf will become 1 and the maxchosen can be 1.5*(max of remaining values)
		normalized=custom_normalize(pairwise_dist)
		normalized=list(map(lambda x:(list(map(lambda y:float(y),x))),normalized))
		normalweights_df=spark.createDataFrame(normalized)
		normalweights_df.write.mode('overwrite').parquet(path+'normalized_euclidian_weights_comp_indfeatures')
		#u got the weights of each dp to every other d
		# now score them using pagerank similar algo 
		# initial scores=1/n for all dps 
		dp_scores,normal_dp_scores=scoredps(normalized,100)
		dpscores_id={}
		for ind,i in enumerate(dpids):
			dpscores_id[i]=normal_dp_scores[ind]
		dpscores_list=list(map(lambda x:[x,dpscores_id[x]],dpscores_id))
		dpid_with_scores=spark.createDataFrame(dpscores_list,['dpid','comparitive_ind_score'])
		dpid_with_scores.write.mode('overwrite').parquet(graphFeatureOutputPath)
	except Exception as error:
		print(error)

	