from helper.packages_ import *


def getGraphLevelFeatures(path, dpids_with_ccs_edges_path, edges_path_nontube, dpids_with_its_vertices_long_mapped, spark, sc):
    try:
        dpids_with_ccs = spark.read.parquet(dpids_with_ccs_edges_path)
        distinct_dps = dpids_with_ccs.select('dpid').distinct()
        required_dps = dpids_with_ccs.select('dpid').distinct()
        # find dpid- days seen
        edges_nontube = spark.read.parquet(edges_path_nontube).select("vertex1", "vertex2", "vertex1Type", "vertex2Type", "dpid", "timestamp")
        # DataFrame[vertex1: string, vertex1type: string, vertex2: string, vertex2type: string, dpid: string, timestamp: string, recordType: string]
        # edges_nontube.union(edges_tube).write.mode('overwrite').parquet(path+'tube_and_non_tube_edges_dup')#.distinct()->dont do distinct()
        all_edges_with_ts_changed = edges_nontube.withColumn('timestamp', F.col('timestamp')[0:10])
        # now get vertices from these edges

        def findDay(datedtime):
            date = datedtime[:10]
            time = datedtime[10:]
            year, month, day = (int(i) for i in date.split('-'))     
            born = datetime.date(year, month, day) 
            return born.strftime("%A")
        all_edges_with_ts_changed = all_edges_with_ts_changed.withColumn("datetime", F.from_unixtime(F.col("timestamp")))
        # remove all ingested
        all_edges_with_ts_changed = all_edges_with_ts_changed.filter(~ F.col('datetime').like("%00:00:00"))
        findday = F.udf(lambda x: findDay(x))
        all_edges_with_ts_changed = all_edges_with_ts_changed.withColumnRenamed("datetime", "datedtime")
        all_edges_day = all_edges_with_ts_changed.withColumn("day", F.lit(findday(F.col("datedtime"))))
        # all non ingested edges with dpids and days
        all_edges_day.write.mode('overwrite').parquet(path + 'edges_with_dpids_days')
        all_edges_day = spark.read.parquet(path + 'edges_with_dpids_days')
        all_edges_day.groupby('dpid', "day").count().write.mode("overwrite").parquet(path + 'edges_with_dpids_days_count')
        df1 = spark.read.parquet(path + 'edges_with_dpids_days_count')
        df1.groupby("dpid").agg(F.map_from_entries(F.collect_list(F.struct("day", "count"))).alias("day_counts")).write.mode("overwrite").parquet(path + 'dpid_with_days_dict')
        df2 = spark.read.parquet(path + 'dpid_with_days_dict')
        # #-remaining are ingested

        def countdays(x):
            days = x['day_counts']
            daydict = defaultdict(int)
            daydict['Sunday'] = 0
            daydict['Monday'] = 0
            daydict['Tuesday'] = 0
            daydict['Wednesday'] = 0
            daydict['Thursday'] = 0
            daydict['Friday'] = 0
            daydict['Saturday'] = 0
            for i in days.keys():
                daydict[i] += days[i]
            total = sum(daydict.values())
            return x['dpid'], daydict['Sunday'] / total, daydict['Monday'] / total, daydict['Tuesday'] / total, daydict['Wednesday'] / total, daydict['Thursday'] / total, daydict['Friday'] / total, daydict['Saturday'] / total, total
        df2.rdd.map(lambda x: countdays(x)).toDF(['dpid', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'total_days']).write.mode('overwrite').parquet(path + 'dpid_with_day_frequencies')
        day_freq = spark.read.parquet(path + 'dpid_with_day_frequencies')
        # find mean time on day
        all_edges_day = spark.read.parquet(path + 'edges_with_dpids_days')
        dpid_time = all_edges_day.select('dpid', 'timestamp')
        dpid_time = dpid_time.groupby('dpid').agg(F.mean('timestamp')).withColumnRenamed('avg(timestamp)', 'avg_timestamp')
        dpid_time = dpid_time.withColumn("avg_datetime", F.from_unixtime(F.col("avg_timestamp")))
        dpid_time.write.mode('overwrite').parquet(path + 'dpid_with_avg_timestamp')
        dpid_time = spark.read.parquet(path + 'dpid_with_avg_timestamp')
        dpid_time = dpid_time.withColumnRenamed('dpid', 'dpid_')
        # join with day_freq
        join1 = dpid_time.join(day_freq, day_freq.dpid == dpid_time.dpid_).drop('dpid_', 'total_days').distinct()
        join1.write.mode('overwrite').parquet(path + '/join1')
        join1 = spark.read.parquet(path + '/join1')
        # sanityCheck(join1, all_edges_day.select('dpid').distinct(), " dpid count before and after day freq creation ")
        # True get remaining dps
        rem_dps = dpids_with_ccs.select('dpid').distinct().subtract(dpid_time.select('dpid_').distinct()).collect()
        rem_dps_df = []
        for i in rem_dps:
            curr = [i[0]]
            for j in range(9):
                curr.append(-1)
            rem_dps_df.append(curr)
        dummy_df = spark.createDataFrame(rem_dps_df, ['dpid', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'avg_timestamp', 'avg_datetime'])
        join2 = join1.select('dpid', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'avg_timestamp', 'avg_datetime').union(dummy_df)
        join2.write.mode('overwrite').parquet(path + '/join2')
        join2 = spark.read.parquet(path + '/join2')
        # sanityCheck(distinct_dps, join2, " total dp count before and after ")
        # True find offline online count
        # now get vertices from these edges
        edges_nontube.select(F.col('vertex1').alias("string_id"), F.col('vertex1Type').alias("type"), 'timestamp', 'dpid').union(edges_nontube.select(F.col('vertex2').alias("string_id"), F.col('vertex2Type').alias("type"), 'timestamp', 'dpid')).write.mode('overwrite').parquet(path + 'embed_trails' + '/vertices_with_dpids')
        # find offline online count
        vertices_with_dpids = spark.read.parquet(path + 'embed_trails' + '/vertices_with_dpids')
        df = vertices_with_dpids.withColumn('id_type', F.when(F.col('type').like("id_mid%"), 'on').otherwise('off'))
        # off_on=df.groupby('dpid').agg(F.collect_list('id_type'))
        df1 = df.groupby('dpid', "id_type").count()
        off_on = df1.groupby("dpid").agg(F.map_from_entries(F.collect_list(F.struct("id_type", "count"))).alias("id_type_counts"))

        def countoff_on(x):
            types = x['id_type_counts']
            on = 0
            off = 0
            for i in types.keys():
                if(i == 'on'):
                    on += types[i]
                else:
                    off += types[i]
            return x['dpid'], on / (on + off), off / (on + off)
        off_on.rdd.map(lambda x: countoff_on(x)).toDF(['dpid', 'online_percent', 'offline_percent']).write.mode('overwrite').parquet(path + 'dpids_with_off_on_percent')
        df = spark.read.parquet(path + 'dpids_with_off_on_percent')
        df = df.withColumnRenamed('dpid', 'dpid_')
        join3 = df.join(join2, df.dpid_ == join2.dpid).drop('dpid_')
        join3.write.mode('overwrite').parquet(path + '/join3')
        join3 = spark.read.parquet(path + '/join3')
        # get mean cc size

        def getsize(x):
            return x['dpid'], x['component'], len(x['edges'])
        structures = dpids_with_ccs.rdd.map(lambda x: getsize(x)).toDF(['dpid', 'component', 'size_of_cc'])
        mean_cc = structures.groupby('dpid').agg(F.mean('size_of_cc')).alias('mean_cc_size')
        mean_cc = mean_cc.withColumnRenamed('avg(size_of_cc)', 'mean_cc_size')
        mean_cc.write.mode("overwrite").parquet(path + 'dpids_with_mean_cc_size')
        mean_cc = spark.read.parquet(path + 'dpids_with_mean_cc_size')
        mean_cc = mean_cc.withColumnRenamed('dpid', 'dpid_')
        join4 = mean_cc.join(join3, mean_cc.dpid_ == join3.dpid).drop('dpid_')
        join4.write.mode('overwrite').parquet(path + '/join4')
        join4 = spark.read.parquet(path + '/join4')
        # no.of cc / total c.c in graph
        dpid_noccs = structures.groupby('dpid').count().withColumnRenamed('count', 'count_of_ccs')
        total_ccs = structures.count()
        dpid_p_ccs = dpid_noccs.withColumn('count_of_ccs', F.col('count_of_ccs') / total_ccs).withColumnRenamed('count_of_ccs', 'percent_of_ccs_seen')
        dpid_p_ccs.write.mode('overwrite').parquet(path + 'dpids_with_percent_of_ccs')
        dpid_p_ccs = spark.read.parquet(path + 'dpids_with_percent_of_ccs').withColumnRenamed('dpid', 'dpid_')
        join5 = join4.join(dpid_p_ccs, dpid_p_ccs.dpid_ == join4.dpid).drop('dpid_')
        # no.of skewed cc (online and offline) - an indepenedent feature
        dpid_edges = dpids_with_ccs.select('dpid', 'edges')
        dp_ids = spark.read.parquet(dpids_with_its_vertices_long_mapped)

        def breakedges(x):
            t = x['edges']
            flat_list = [item for sublist in t for item in sublist]
            flat_list = list(set(flat_list))
            return x['dpid'], min(flat_list), flat_list
        dpid_edges.rdd.map(lambda x: breakedges(x)).toDF(['dpid', 'cc_id', 'ids']).write.mode('overwrite').parquet(path + 'dpids_with_cc_id_ids')
        x = spark.read.parquet(path + 'dpids_with_cc_id_ids')
        explo = x.select('dpid', 'cc_id', F.explode('ids'))
        dp_ids = dp_ids.select(F.col('vertex').alias("id"), F.col('vertexType').alias("type"), 'long_id').distinct()
        df = explo.join(dp_ids, [dp_ids.long_id == explo.col]).drop('col')
        df.write.mode('overwrite').parquet(path + 'dpid_cc_ids_with_type')
        df = spark.read.parquet(path + 'dpid_cc_ids_with_type')
        # dpid_types=df.groupby('dpid','cc_id').agg(F.collect_list('type').alias('types'))
        df1 = df.groupby('dpid', "cc_id", "type").count()
        dpid_types = df1.groupby("dpid", "cc_id").agg(F.map_from_entries(F.collect_list(F.struct("type", "count"))).alias("type_counts"))
        # DataFrame[dpid: string, cc_id: bigint, types: array<string>]

        def flagskewed(x):
            types = x['type_counts']
            onlines = 0
            offlines = 0
            for i in types.keys():
                if(i[0:3] == 'id_'):
                    onlines += types[i]
                else:
                    offlines += types[i] 
            flag = ""
            if(onlines != 0 and offlines != 0):
                flag = 'not_skewed'
            elif(onlines == 0):
                flag = 'offline_skewed'
            else:
                flag = 'online_skewed'
            return x['dpid'], x['cc_id'], flag 
        dpid_types.rdd.map(lambda x: flagskewed(x)).toDF(['dpid', 'cc_id', 'Skew_Flag']).write.mode('overwrite').parquet(path + 'dpid_ccids_skewflag')
        dpid_skewflag = spark.read.parquet(path + 'dpid_ccids_skewflag')
        df1 = dpid_skewflag.groupby('dpid', "Skew_Flag").count()
        df = df1.groupby("dpid").agg(F.map_from_entries(F.collect_list(F.struct("Skew_Flag", "count"))).alias("flag_counts"))

        def flagskews(x):
            totalskews = x['flag_counts']
            total_ccs = 0
            online_skew = 0
            offline_skew = 0
            not_skew = 0
            for i in totalskews.keys():
                if(i == 'online_skewed'):
                    online_skew += totalskews[i]
                elif(i == 'not_skewed'):
                    not_skew += totalskews[i]
                else:
                    offline_skew += totalskews[i]
                total_ccs += totalskews[i]
            return x['dpid'], (online_skew / total_ccs), (offline_skew / total_ccs), (not_skew / total_ccs), (total_ccs)
        df.rdd.map(lambda x: flagskews(x)).toDF(['dpid', 'online_skewed_percent', 'offline_skewed_percent', 'not_skewed_percent', 'total_ccs']).write.mode('overwrite').parquet(path + 'dpids_with_skew_ratios')
        dpid_with_skews = spark.read.parquet(path + 'dpids_with_skew_ratios').withColumnRenamed('dpid', 'dpid_')
        join5.join(dpid_with_skews, dpid_with_skews.dpid_ == join5.dpid).drop('dpid_').write.mode('overwrite').parquet(path + 'dpid_with_comp_independent_features')
        dps_ind_fetus = spark.read.parquet(path + 'dpid_with_comp_independent_features')
        # sanityCheck(dps_ind_fetus, distinct_dps, " dp count from source and from final graph level feature df ")
    except Exception as error:
        print("No", error)
    return path + 'dpid_with_comp_independent_features'
