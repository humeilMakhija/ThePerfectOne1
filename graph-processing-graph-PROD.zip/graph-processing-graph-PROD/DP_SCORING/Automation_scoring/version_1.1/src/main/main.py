from driver.aggregatedDpScoringDriver import *
from driver.driverGraphFeatureScoring import *
from driver.driverIndependentFeatureScore import *
from driver.driverComponentFeatureScoring import *
from helper.packages_ import *
from helper.pathChecker import *

if __name__ == "__main__":
    spark = SparkSession.builder.appName("Dp scoring Driver").getOrCreate()
    sc = spark.sparkContext
    base_path = spark.conf.get("spark.input.basePath") # 
    output_path = spark.conf.get("spark.output.scoredPath")
    base_path = base_path + "/reporting_input_processing"

    nonTubeEdgePath = spark.conf.get("spark.input.nonTubeEdgePath") 
    ## lq graph created path in previous reporting stage
    long_mapped_ids_path = f'{base_path}/long_mapper_for_vertex'  # + "/country="+country+"/Prudhvi/"+country+"_Graph_cleaning_newdata/all_ids_with_long_mapping" ## long_mapped_ids_path_per_country = "gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/graph/cleanup/country=NLD/Prudhvi/NLD_Graph_cleaning_newdata/all_ids_with_long_mapping"
    all_traversible_vertices = f'{base_path}/data/incremental_cleaning/traversible_vertexes_with_types'  # + "/country="+country+"/Prudhvi/"+country+"_Graph_cleaning_new/final_vertices_to_apply_cc" ## all_vertices_path_per_country = "gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/graph/cleanup/country=NLD/Prudhvi/NLD_Graph_cleaning_new/final_vertices_to_apply_cc"
    all_traversible_edges = f'{base_path}/data/incremental_cleaning/traversible_edges_with_cc'  # + "/country="+country+"/Prudhvi/"+country+"_Graph_cleaning_new/Prudhvi/component_traversible_edge_set"  ## all_edges_path_per_country = "gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/graph/cleanup/country=NLD/Prudhvi/NLD_Graph_cleaning_new/Prudhvi/component_traversible_edge_set"
    # cc_path_per_country = f'{cleaningBasePath}/country={country}/data/final_graph/traversible_vertexes_with_types' ##+ "/country="+country+"/Prudhvi/"+country+"_Graph_cleaning_newcc_merged_with_edges"  ## cc_path_per_country = "gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/graph/cleanup/country=NLD/Prudhvi/NLD_Graph_cleaning_newcc_merged_with_edges"

    independentFeatureOutputPath = f'{base_path}/dp_scoring/output_path/independentFeatureOutputPath/'  # independentFeatureOutputPathPerCountry = "gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/graph/DP_scoring/output/independent_feature_path"
    componentFeatureOutputPath = f'{base_path}/dp_scoring/output_path/componentFeatureOutputPath/'  # componentFeatureOutputPathPerCountry = "gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/graph/DP_scoring/output/component_feature_path"
    graphFeatureOutputPath = f'{base_path}/dp_scoring/output_path/graphFeatureOutputPath/'  # graphFeatureOutputPathPerCountry = "gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/graph/DP_scoring/output/graph_feature_path"
    # aggregatedFeatureOutputPath = f'{base_path}/dp_scoring/output_path/finalScoredPath'  # aggregatedFeatureOutputPathPerCountry = "gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/graph/DP_scoring/output/aggregated_feature_path"

    dp_edges_mapped_to_long_path, dpids_with_its_vertices_long_mapped_path = dpScoringIndependentFeatureDriver(base_path + "/dp_scoring/input_processing/", nonTubeEdgePath, long_mapped_ids_path, all_traversible_vertices , all_traversible_edges, independentFeatureOutputPath, spark, sc)
    print("dpScoringIndependentFeatureDriver completed")
    dpids_with_ccs_edges_path, allccs = dpScoringGraphFeatureDriver(base_path + "/dp_scoring/input_processing/" , dp_edges_mapped_to_long_path, nonTubeEdgePath, dpids_with_its_vertices_long_mapped_path, graphFeatureOutputPath, spark, sc)
    print("dpScoringGraphFeatureDriver completed")
    dpScoringComponentFeatureDriver(base_path + "/dp_scoring/input_processing/" , dpids_with_ccs_edges_path, allccs, componentFeatureOutputPath, spark, sc)
    print("dpScoringGraphFeatureDriver completed")
    aggregatedDpScoringDriver(base_path + "/dp_scoring/input_processing/" , dp_edges_mapped_to_long_path, output_path, independentFeatureOutputPath, componentFeatureOutputPath, graphFeatureOutputPath, spark, sc)
