from driver.reportingFunction import *
from helper.packages_ import *
if __name__ == '__main__':
	spark = SparkSession.builder.appName("cleaning pipeline").getOrCreate()
	sc = spark.sparkContext
	base_path = spark.conf.get("spark.input.basePath") ## base_path = "gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/graph/incremental_testing/"
	output_edge_path = spark.conf.get("spark.output.EdgePath") ## output_edge_path = "gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/graph/incremental_testing/reporting_output/edge"
	output_vertex_path = spark.conf.get("spark.output.vertexPath")  ## output_vertex_path = "gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/graph/incremental_testing/reporting_output/vertex"
	idGraphEdgePath = spark.conf.get("spark.input.idGraphEdgePath") ## used later
	idGraphVertexPath = spark.conf.get("spark.input.idGraphVertexPath") ## used later
	input_vertex_set_path = spark.conf.get("spark.input.inputVertexPath") 
	input_edge_set_path = spark.conf.get("spark.input.inputEdgePath") 
	# processedCountriesPath = spark.conf.get("spark.processedCountriesPath")
	threshold_for_cc = int(spark.conf.get("spark.output.thresholdForCc")) ## 70
	flag = reportingFunction(base_path , threshold_for_cc , output_edge_path , output_vertex_path , idGraphEdgePath , idGraphVertexPath  , input_vertex_set_path , input_edge_set_path , spark , sc)

# spark.input.basePath=gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/graph/incremental_testing_
# spark.output.EdgePath=gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/graph/incremental_testing/reporting_output_/edge
# spark.output.vertexPath=gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/graph/incremental_testing/reporting_output_/vertex
# spark.input.idGraphEdgePath=gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/graph/incremental_testing/lqGraph/edge
# spark.input.idGraphVertexPath=gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/graph/incremental_testing/lqGraph/vertex
# spark.input.inputVertexPath=gs://gcs-ireland-all-eu-idu-lqsnapshot-zt/LQSnapshotGenerator/LQSnapshot/vertex/version=1629997951
# spark.input.inputEdgePath=gs://gcs-ireland-all-eu-idu-lqsnapshot-zt/LQSnapshotGenerator/LQSnapshot/edge/version=1629997951
# spark.output.thresholdForCc=2000

