import pyspark.sql.functions as F
from pyspark.sql.types import ArrayType , StructField , StructType , DoubleType , FloatType , IntegerType
from pyspark.sql import SparkSession
from pyspark import SparkContext,SparkConf
if __name__ == '__main__':
	spark = SparkSession.builder.appName("pre cleaning pipeline").getOrCreate()
	sc = spark.sparkContext
	base_path = spark.conf.get("spark.input.basePath") ## base_path = "gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/graph/incremental_testing"
	vertices_path = spark.conf.get("spark.input.lqSnapshot.verticesPath") ## "gs://gcs-ireland-all-eu-daap-connect-internal-zeotap-com-qa/lq_snapshot/test/LQSnapshotGenerator/LQSnapshot/vertex/version=1616439519"
	edges_path = spark.conf.get("spark.input.lqSnapshot.edgesPath") ## "gs://gcs-ireland-all-eu-daap-connect-internal-zeotap-com-qa/lq_snapshot/test/LQSnapshotGenerator/LQSnapshot/edge/version=1616439519"
	idGraphEdgePath = spark.conf.get("spark.input.idGraphEdgePath") ## used later
	idGraphVertexPath = spark.conf.get("spark.input.idGraphVertexPath") ## used later
	
	# output_vertices_exploded_path = base_path + "/reporting_input/data/output_vertices_exploded"
	# output_edges_exploded_path = base_path + "/reporting_input/data/output_edges_exploded"
	# output_scored_vertex = spark.read.parquet(vertices_path).select("vertex","vertex_type" , F.explode("country_ds_metadata").alias("country" , "vertexScores")).select("country" , F.col("vertex").alias("string_id") ,F.col("vertex_type").alias("type") , "vertexScores.hops_mr_3" , "vertexScores.hops_mr_5" , "vertexScores.max_len_clique" , F.col("vertexScores.quality").alias("vertex_quality")).withColumn("graph_type_flag" , F.lit("zeoGraph"))
	# output_scored_edges = spark.read.parquet(edges_path).select("vertex1" , "vertex1_type" , "vertex2" , "vertex2_type" , F.explode("country_ds_metadata").alias("country" , "edge_scores")).select(F.col("vertex1").alias("src_string_id") , F.col("vertex1_type").alias("src_type") , F.col("vertex2").alias("dst_string_id") , F.col("vertex2_type").alias("dst_type") , "country" , F.col("edge_scores.quality").alias("edge_quality") , "edge_scores.edge_category").drop("ts" , "version").withColumn("graph_type_flag" , F.lit("zeoGraph"))
	# output_scored_vertex.write.partitionBy("country").mode("overwrite").parquet(output_vertices_exploded_path)
	# output_scored_edges.write.partitionBy("country").mode("overwrite").parquet(output_edges_exploded_path)

	non_tube_data_vertex = spark.read.parquet(vertices_path).withColumnRenamed("vertexType" , "vertex_type").select("vertex" , "vertex_type" , F.explode("dp_country").alias("dpid" , "meta")).select("vertex" , "vertex_type" , "dpid" , F.explode("meta").alias("meta")).select("vertex" , F.col("vertex_type").alias("vertexType") , "dpid" , F.col("meta.ts").alias("timestamp")).distinct()
	non_tube_data_edge = spark.read.parquet(edges_path).withColumnRenamed("vertex1Type" , "vertex1_type").withColumnRenamed("vertex2Type" , "vertex2_type").select("vertex1" ,  "vertex1_type" , "vertex2" , "vertex2_type" , F.explode("dp_country").alias("dpid" , "meta")).select("vertex1" ,  "vertex1_type" , "vertex2" , "vertex2_type" , "dpid" , F.explode("meta").alias("meta")).select("vertex1" ,  F.col("vertex1_type").alias("vertex1Type") , "vertex2" , F.col("vertex2_type").alias("vertex2Type") , "dpid" , F.col("meta.ts").alias("timestamp")).distinct()
	non_tube_data_edge.select(F.col("vertex1").alias("vertex") , F.col("vertex1Type").alias("vertexType") , "dpid" , "timestamp" ).union(non_tube_data_edge.select(F.col("vertex2").alias("vertex") , F.col("vertex2Type").alias("vertexType") ,"dpid" , "timestamp")).distinct().write.mode("overwrite").parquet(base_path + "/reporting_input/data/all_vertices_from_edges")
	spark.read.parquet(base_path + "/reporting_input/data/all_vertices_from_edges").select("vertex" , "vertexType" , "dpid" , "timestamp").subtract(non_tube_data_vertex.select("vertex" , "vertexType" , "dpid" , "timestamp")).write.mode("overwrite").parquet(base_path + "/reporting_input/data/extra_vertices_from_edges")
	spark.read.parquet(base_path + "/reporting_input/data/extra_vertices_from_edges").select("vertex" , "vertexType" , "dpid" , "timestamp").union(non_tube_data_vertex.select("vertex" , "vertexType" , "dpid" , "timestamp")).distinct().write.mode("overwrite").parquet(idGraphVertexPath)
	non_tube_data_edge.write.mode("overwrite").parquet(idGraphEdgePath)


# spark.input.basePath=gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/graph/incremental_testing
# spark.input.lqSnapshot.verticesPath=gs://gcs-ireland-all-eu-idu-lqsnapshot-zt/LQSnapshotGenerator/LQSnapshot/vertex/version=1629997951
# spark.input.lqSnapshot.edgesPath=gs://gcs-ireland-all-eu-idu-lqsnapshot-zt/LQSnapshotGenerator/LQSnapshot/edge/version=1629997951
# spark.input.idGraphEdgePath=gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/graph/incremental_testing/lqGraph/edge
# spark.input.idGraphVertexPath=gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/graph/incremental_testing/lqGraph/vertex