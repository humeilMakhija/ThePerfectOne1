from helper.packages_ import *
def sanityCheck(output_vertex_path , output_edge_path , input_edge , input_vertex , spark , sc):
	vertex_check_flag , edge_check_flag = False , False
	if spark.read.parquet(output_vertex_path).count() == spark.read.parquet(input_vertex).count():
		vertex_check_flag = True
	if spark.read.parquet(output_edge_path).count() == spark.read.parquet(input_edge).count():
		edge_check_flag = True
	return vertex_check_flag and edge_check_flag