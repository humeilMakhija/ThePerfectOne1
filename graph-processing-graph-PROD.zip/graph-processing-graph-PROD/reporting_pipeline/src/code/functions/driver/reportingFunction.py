from driver.incrementalCleaning import *
from helper.sanityCheck import *
from helper.packages_ import *
from helper.utils import *
def reportingFunction(base_path ,  threshold_for_cc , output_edge_path , output_vertex_path , idGraphEdgePath , idGraphVertexPath , input_vertex_set_path , input_edge_set_path , spark , sc):
	# print(output_vertex_path)
	def longMapper( vertex , long_mapper_path ):
		if vertex.count() == 0:
			print("long mapping not done")
		else:
			pass
		zipped_df = vertex.select("vertex" , "vertexType").rdd.zipWithIndex().toDF()
		try :
			zipped_df.select(zipped_df._1.vertex.alias("vertex") , zipped_df._1.vertexType.alias("vertexType")  , zipped_df._2.alias("long_id")).write.mode('overwrite').parquet(long_mapper_path)
			print("long mapping done and file written to : " + long_mapper_path)
		except:
			print("long mapping not done")
	#############
	base_path = base_path + "/reporting_input_processing"
	non_tube_data_edge = spark.read.parquet(idGraphEdgePath).select("vertex1" , "vertex1Type" , "vertex2" , "vertex2Type").distinct()
	non_tube_data_vertex = spark.read.parquet(idGraphVertexPath).select("vertex" , "vertexType").distinct()
	# non_tube_data_vertex.subtract(spark.read.parquet(base_path + "/reporting_input/data/all_vertices_from_edges").select("vertex" , "vertexType"))
	long_mapper_path = base_path + "/long_mapper_for_vertex"
	longMapper(non_tube_data_vertex , long_mapper_path)
	df = spark.read.parquet(long_mapper_path)
	src_graph_edges_mapped_to_long_path = base_path + "/src_graph_edges_mapped_to_long_path"
	dst_graph_edges_mapped_to_long_path = base_path + "/dst_graph_edges_mapped_to_long_path"
	df.join(non_tube_data_edge , [df.vertex ==non_tube_data_edge.vertex1 , df.vertexType ==non_tube_data_edge.vertex1Type]).drop("vertex" , "vertexType" ).withColumnRenamed("long_id" , "src_long_id").write.mode("overwrite").parquet(src_graph_edges_mapped_to_long_path)
	intermediate = spark.read.parquet(src_graph_edges_mapped_to_long_path)
	df.join(intermediate , [df.vertex ==intermediate.vertex2 , df.vertexType ==intermediate.vertex2Type]).drop("vertex" , "vertexType").withColumnRenamed("long_id" , "dst_long_id").write.mode("overwrite").parquet(dst_graph_edges_mapped_to_long_path)
	edges_long = spark.read.parquet(dst_graph_edges_mapped_to_long_path).select(F.col("src_long_id").alias("src") , F.col("dst_long_id").alias("dst"))
	vertices_long = df.select(F.col("long_id").alias("id"))
	cc_path = base_path + "/cc_path"
	graph = GraphFrame(vertices_long , edges_long)
	sc.setCheckpointDir(base_path + "/checkpoint_dir_path")
	print("cc starting..")
	cc = graph.connectedComponents(algorithm = "graphframes", checkpointInterval = 2, broadcastThreshold = 10000)
	print("cc writing on cc_path...")
	cc.write.mode("overwrite").parquet(cc_path)
	cc = spark.read.parquet(cc_path)
	cc.groupby("component").count().sort(F.col("count").desc()).show()
	# max_sized_cc = cc.groupby("component").count().sort(F.col("count").desc()).take(1)[0][1]
	cc.groupby("component").count().filter(F.col("count") <= threshold_for_cc ).drop("count").write.mode("overwrite").parquet(base_path + "/non_cleaned_cc")
	non_cleaned_cc = spark.read.parquet(base_path + "/non_cleaned_cc")
	non_cleaned_cc.join(cc , on = "component").write.mode("overwrite").parquet(base_path + "/non_cleaned_ids")
	cc.groupby("component").count().filter(F.col("count") == 1 ).drop("count").write.mode("overwrite").parquet(base_path + "/isolated_cc")
	isolated_cc = spark.read.parquet(base_path + "/isolated_cc")
	isolated_cc.join(cc , on = "component").write.mode("overwrite").parquet(base_path + "/isolated_ids")
	cc.join(edges_long , cc.id == edges_long.src).drop("id").write.mode("overwrite").parquet(base_path + "/cc_with_edges")
	cc_with_edges = spark.read.parquet(base_path + "/cc_with_edges")
	community_threshold = threshold_for_cc
	PIC_threshold = 70000
	# cc_with_info.filter(F.col("vertex_count") > threshold_for_cc).select("component").write.mode("overwrite").parquet(base_path + "/reporting_input_processing/country="+country+"/cc_to_be_scored_again")
	cc.groupby("component").count().filter(F.col("count") > threshold_for_cc ).drop("count").write.mode("overwrite").parquet(base_path + "/component_to_be_cleaned")
	component_to_be_cleaned = spark.read.parquet(base_path + "/component_to_be_cleaned")
	component_to_be_cleaned.join(cc , on = "component").write.mode("overwrite").parquet(base_path + "/ids_to_be_cleaned")
	ids_to_be_cleaned = spark.read.parquet(base_path + "/ids_to_be_cleaned")
	component_to_be_cleaned.join(cc_with_edges , on = "component").write.mode("overwrite").parquet(base_path + "/edges_to_be_cleaned")
	edges_need_to_be_cleaned_long = spark.read.parquet(base_path + "/edges_to_be_cleaned")
	incrementalCleaning( base_path + "/", long_mapper_path , base_path + "/edges_to_be_cleaned" , base_path + "/ids_to_be_cleaned" , PIC_threshold , community_threshold , dst_graph_edges_mapped_to_long_path   ,  output_edge_path + "/" , output_vertex_path + "/" , input_vertex_set_path , input_edge_set_path , spark , sc)

