from IncrementalCleaning.Relinking.IsolatedIdRelinking import *
from IncrementalCleaning.communityDetection.Infomap.communityDetection import *
from IncrementalCleaning.communityDetection.PowerIterationClustering.PICdriver import *
from IncrementalCleaning.Relinking.relinking import *
from IncrementalCleaning.Scoring.scoring import *
from IncrementalCleaning.communityDetection.spectralAnalysis.spectraCommunityAlgo import *
from helper.packages_ import *


def incrementalCleaning(base_path, long_mapper_path, edge_set_path, vertex_set_path, PIC_threshold, community_threshold, all_edges_path, output_edge_path, output_vertex_path, input_vertex_set_path , input_edge_set_path, spark, sc):
    cc_lq_graph_path = vertex_set_path
    edges = spark.read.parquet(edge_set_path)
    vertices = spark.read.parquet(cc_lq_graph_path)
    PIC_flag = False
    community_flag = False
    if vertices.groupby("component").count().filter(F.col("count") > PIC_threshold).count() > 0:
        vertices.groupby("component").count().filter(F.col("count") <= PIC_threshold).select("component").write.mode("overwrite").parquet(base_path + "components_not_for_PIC_path")
        components_not_for_PIC = spark.read.parquet(base_path + "components_not_for_PIC_path")
        components_not_for_PIC.join(vertices, on = "component").write.mode("overwrite").parquet(base_path + "vertices_not_for_PIC_path")
        cc_lq_graph_path = base_path + "vertices_after_PIC"
        cleaned_path = cleaningComponentsUsingPIC(base_path, vertices, edges, PIC_threshold, "incremental_cleaning", spark, sc)
        spark.read.parquet(cleaned_path).select("component", "id").union(spark.read.parquet(base_path + "vertices_not_for_PIC_path").select("component", "id")).write.mode("overwrite").parquet(cc_lq_graph_path)
        vertices = spark.read.parquet(cc_lq_graph_path)
        print("count of vertices after PIC " + str(vertices.count()))
        PIC_flag = True
    if vertices.groupby("component").count().filter(F.col("count") > community_threshold).count() > 0:
        cc_lq_graph_path = base_path + "vertices_after_community_detection"
        cleaned_path = cleaningGraphBigComponentsUsingCommunityDetection(base_path, vertices, edges, community_threshold, "incremental_cleaning", spark, sc)
        #cleaned_path = spectralAlgo(base_path , vertices , edges ,community_threshold , "incremental_cleaning" , spark , sc)
        spark.read.parquet(cleaned_path).select("component", "id").write.mode("overwrite").parquet(cc_lq_graph_path)
        vertices = spark.read.parquet(cc_lq_graph_path)
        print("count of vertices after community " + str(vertices.count()))
        community_flag = True
    if PIC_flag == True or community_flag == True:
        if vertices.groupby("component").count().filter(F.col("count") == 1).count() > 0:
            isolated_relinking_path = relinkingIsolatedID(base_path, vertices, edges, "incremental_cleaning", spark, sc)
            vertices = spark.read.parquet(isolated_relinking_path)
        cc_lq_graph_path = base_path + "final_cc_after_relinking_and_union"
        cc_skewness_removed_path, skew_check_flag = relinkingSkewedId(base_path, vertices, edges, "incremental_cleaning", long_mapper_path, spark, sc)
        if skew_check_flag == 0:
            vertices.write.mode("overwrite").parquet(cc_lq_graph_path)
        else:
            cc_skewness_removed = spark.read.parquet(cc_skewness_removed_path)
            cc_skewness_removed.select("component", "id").write.mode("overwrite").parquet(cc_lq_graph_path)
            print("count of vertices after skewed relilnking " + str(spark.read.parquet(cc_lq_graph_path).count()))
    else:
        pass
    scoringVertexAndEdges(base_path , cc_lq_graph_path, all_edges_path, long_mapper_path, "incremental_cleaning", output_vertex_path, output_edge_path, input_vertex_set_path , input_edge_set_path , spark, sc)
