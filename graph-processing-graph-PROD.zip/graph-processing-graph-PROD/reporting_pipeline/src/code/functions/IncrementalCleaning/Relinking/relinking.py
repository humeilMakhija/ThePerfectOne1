from helper.packages_ import *
def getNeighbors(base_path , edges  , type_ ):
	neighbor_path = base_path + "data/"+type_+"/neighbor_path"
	edges.select(F.col("src").alias("id") , F.col("dst").alias("neighbor")).union(edges.select(F.col("dst").alias("id") , F.col("src").alias("neighbor"))).distinct().write.mode("overwrite").parquet(neighbor_path)
	return neighbor_path
#####################



def getComponentData(base_path , component  , cc_type , type_ , long_mapper_path , spark , sc):
	def getComponentDistributionInfo(x):
		online_count , offline_count , skewness_flag = 0 , 0 , False
		for type_ in x["type"]:
			if "id_mid" in type_:
				online_count += 1
			else:
				offline_count += 1
		if online_count == 0 or offline_count == 0 : 
			skewness_flag = True
		return x["component"] , x["long_id"] , offline_count , online_count , skewness_flag
		##################
	cc_data_path = base_path + "data/"+type_+"/"+cc_type+"/cc_data_path"
	cc_data_groupby_path = base_path + "data/"+type_+"/"+cc_type+"/cc_data_groupby_path"
	cc_data_groupby_mapped_to_distribution_path = base_path + "data/"+type_+"/"+cc_type+"/cc_data_groupby_mapped_to_distribution_path"
	cc_data_groupby_mapped_to_distribution_exploded_path = base_path + "data/"+type_+"/"+cc_type+"/cc_data_groupby_mapped_to_distribution_exploded_path"
	vertex_set = spark.read.parquet(long_mapper_path).withColumnRenamed("vertex" , "string_id").withColumnRenamed("vertexType" , "type")
	component.join(vertex_set , [component.id == vertex_set.long_id]).drop("id" , "string_id").write.mode("overwrite").parquet(cc_data_path)
	spark.read.parquet(cc_data_path).groupby("component").agg(F.collect_list(F.col("long_id")).alias("long_id") , F.collect_list(F.col("type")).alias("type")).write.mode("overwrite").parquet(cc_data_groupby_path)
	spark.read.parquet(cc_data_groupby_path).rdd.map(lambda x: getComponentDistributionInfo(x)).toDF(["component" , "long_id" , "offline_id_count" , "online_id_count" , "skewed_or_not"]).write.mode("overwrite").parquet(cc_data_groupby_mapped_to_distribution_path)
	spark.read.parquet(cc_data_groupby_mapped_to_distribution_path).select("component" , "offline_id_count" , "online_id_count" , "skewed_or_not" , F.explode("long_id").alias("long_id")).write.mode("overwrite").parquet(cc_data_groupby_mapped_to_distribution_exploded_path)
	return cc_data_groupby_mapped_to_distribution_exploded_path
## all edges need to be changed after every run , initially it is all edges befor component , think of somme strategy of appending soe new neighbors always
#####################




def relinkingSkewedId(base_path , vertices  , edges , type_ , long_mapper_path , spark , sc):		
	def RelinkingMapper(x):
		cc_set = set([])
		skewed_cc_list = []
		non_skewed_cc_list = []
		dst_comp = -1
		for i in x["dst_data"]:
			if i.split(',')[3] == "true": 
				skewed_cc_list.append((int(i.split(',')[0]) , int(i.split(',')[1]) , int(i.split(',')[2])))
				cc_set.add(True)
			else:
				non_skewed_cc_list.append((int(i.split(',')[0]) , int(i.split(',')[1]) , int(i.split(',')[2])))
				cc_set.add(False)
		if (len(cc_set) == 1) and (next(iter(cc_set)) == True) and ("id_mid" in x["type"]):
			dst_comp = x["src_component"]
		elif (len(cc_set) == 1) and (next(iter(cc_set)) == True) and ("em" in x["type"]):
			dst_comp = x["src_component"]
		elif len(cc_set) == 1 and next(iter(cc_set)) == False and "id_mid" in x["type"]:
			dst_comp = list(sorted(non_skewed_cc_list , key = lambda x: x[1]))[0][0]
		elif len(cc_set) == 1 and next(iter(cc_set)) == False and "em" in x["type"]:
			dst_comp = list(sorted(non_skewed_cc_list , key = lambda x: x[2]))[0][0]
		elif len(cc_set) != 1 and "em" in x["type"]:
			dst_comp = list(sorted(non_skewed_cc_list , key = lambda x: x[2]))[0][0]
		elif len(cc_set) != 1 and "id_mid" in x["type"]:
			dst_comp = list(sorted(non_skewed_cc_list , key = lambda x: x[1]))[0][0]
		return x["src_component"] , dst_comp
	########################################
	## print("relinking starts ")
	cc_data_path = getComponentData(base_path , vertices  , type_ , type_ , long_mapper_path , spark , sc) ## component , offline , online , skewed_or_not  , id
	component_ = vertices
	cc_data = spark.read.parquet(cc_data_path)
	v_set = spark.read.parquet(long_mapper_path).withColumnRenamed("vertex" , "string_id").withColumnRenamed("vertexType" , "type")
	cc_data.join(v_set , on = "long_id").drop("string_id").write.mode("overwrite").parquet(base_path + "data/"+type_+"/ids_with_types_and_cc")
	id_with_types_and_cc = spark.read.parquet(base_path + "data/"+type_+"/ids_with_types_and_cc")
	id_with_types_and_cc.filter(F.col("skewed_or_not") == True).select("component" , "long_id" , F.col("type").alias("type")).write.mode("overwrite").parquet(base_path + "data/"+type_+"/skewed_ids_with_types_and_cc")
	skewed_ids = spark.read.parquet(base_path + "data/"+type_+"/skewed_ids_with_types_and_cc")
	if skewed_ids.count() == 0:
		## print("relinking not required")
		return base_path + "data/"+type_+"/new_cc_after_relinking_" , 0
	else:
		pass
	neighbor_path = getNeighbors(base_path , edges  , type_ )
	print("neigbors_created ")
	neighbors = spark.read.parquet(neighbor_path)
	skewed_ids.join(neighbors , skewed_ids.long_id == neighbors.id).drop("id").write.mode("overwrite").parquet(base_path + "data/"+type_+"/skewed_ids_with_neighbors")
	skewed_ids_with_neighbors = spark.read.parquet(base_path + "data/"+type_+"/skewed_ids_with_neighbors").drop("long_id").withColumnRenamed("component" , "src_component").distinct()
	skewed_ids_with_neighbors.join(cc_data , skewed_ids_with_neighbors.neighbor == cc_data.long_id).drop("long_id").withColumnRenamed("component" , "dst_component").write.mode("overwrite").parquet(base_path + "data/"+type_+"/skewed_ids_with_neighbors_and_their_cc")		
	spark.read.parquet(base_path + "data/"+type_+"/skewed_ids_with_neighbors_and_their_cc").withColumn("dst_data" , F.concat(F.col("dst_component"), F.lit(","), F.col("offline_id_count"), F.lit(",") , F.col("online_id_count"), F.lit(",") , F.col("skewed_or_not"))).select("src_component" , "type" , "dst_data").write.mode("overwrite").parquet(base_path + "data/"+type_+"/skewed_cc_with_dst_cc_data")
	spark.read.parquet(base_path + "data/"+type_+"/skewed_cc_with_dst_cc_data").withColumn("type" , F.when(F.col("type").contains("id_mid") , "id_mid").otherwise("em")).groupby("src_component" , "type").agg(F.collect_list(F.col("dst_data")).alias("dst_data")).write.mode("overwrite").parquet(base_path + "data/"+type_+"/skewed_cc_with_dst_cc_data_groupby")
	skewed_cc_groupby = spark.read.parquet(base_path + "data/"+type_+"/skewed_cc_with_dst_cc_data_groupby")
	skewed_ids_ = skewed_ids.select("component" , F.col("long_id").alias("id"))
	print("skewed vertices at stage 1 created ")
	counter_= 1
	vertices.write.mode("overwrite").parquet(base_path + "data/"+type_+"/new_cc_after_relinking_")
	while skewed_ids.count() >= 2000 and spark.read.parquet(base_path + "data/"+type_+"/new_cc_after_relinking_").groupby("component").count().sort(F.col("count").desc()).take(1)[0][1] <= 10000:
		print("iteration " + str(counter_) + " starts for relinking")
		skewed_cc_groupby.rdd.map(lambda x: RelinkingMapper(x)).toDF(["src_component" , "new_component"]).write.mode("overwrite").parquet(base_path + "data/"+type_+"/new_components_assigned_after_relinking")
		new_components_assigned_after_relinking = spark.read.parquet(base_path + "data/"+type_+"/new_components_assigned_after_relinking")
		new_components_assigned_after_relinking.join(skewed_ids_ , [new_components_assigned_after_relinking.src_component == skewed_ids_.component]).drop("src_component" , "component").withColumnRenamed("new_component" , "component").write.mode("overwrite").parquet(base_path + "data/"+type_+"/new_components_assigned_to_ids")
		component_.select("component" , "id").subtract(skewed_ids_.select("component" , "id")).write.mode("overwrite").parquet(base_path + "data/"+type_+"/non_skewed_components")
		spark.read.parquet(base_path + "data/"+type_+"/non_skewed_components").select("component" , "id").union(spark.read.parquet(base_path + "data/"+type_+"/new_components_assigned_to_ids").select("component" , "id")).write.mode("overwrite").parquet(base_path + "data/"+type_+"/new_cc_after_relinking_")
		component_ = spark.read.parquet(base_path + "data/"+type_+"/new_cc_after_relinking_")	
		print("total count after iteration is " + str(component_.count()))
		cc_data_path = getComponentData(base_path , component_  , type_ , type_ , long_mapper_path , spark , sc)
		cc_data = spark.read.parquet(cc_data_path)			
		cc_data.join(v_set , on = "long_id").drop("string_id").write.mode("overwrite").parquet(base_path + "data/"+type_+"/ids_with_types_and_cc")
		id_with_types_and_cc = spark.read.parquet(base_path + "data/"+type_+"/ids_with_types_and_cc")
		id_with_types_and_cc.filter(F.col("skewed_or_not") == True).select("component" , "long_id" , "type").write.mode("overwrite").parquet(base_path + "data/"+type_+"/skewed_ids_with_types_and_cc")
		skewed_ids = spark.read.parquet(base_path + "data/"+type_+"/skewed_ids_with_types_and_cc")
		if new_components_assigned_after_relinking.filter(F.col("src_component") != F.col("new_component")).count() != 0:
			pass
		else:
			break
		print("skewed id count " + str(skewed_ids.count()))
		spark.read.parquet(base_path + "data/"+type_+"/new_cc_after_relinking_").groupby("component").count().sort(F.col("count").desc()).show()
		skewed_ids.join(neighbors , skewed_ids.long_id == neighbors.id).drop("id").write.mode("overwrite").parquet(base_path + "data/"+type_+"/skewed_ids_with_neighbors")
		skewed_ids_with_neighbors = spark.read.parquet(base_path + "data/"+type_+"/skewed_ids_with_neighbors").drop("long_id").withColumnRenamed("component" , "src_component").distinct()
		skewed_ids_with_neighbors.join(cc_data , skewed_ids_with_neighbors.neighbor == cc_data.long_id).drop("long_id").withColumnRenamed("component" , "dst_component").write.mode("overwrite").parquet(base_path + "data/"+type_+"/skewed_ids_with_neighbors_and_their_cc")
		spark.read.parquet(base_path + "data/"+type_+"/skewed_ids_with_neighbors_and_their_cc").withColumn("dst_data" , F.concat(F.col("dst_component"), F.lit(","), F.col("offline_id_count"), F.lit(",") , F.col("online_id_count"), F.lit(",") , F.col("skewed_or_not"))).select("src_component" , "type" , "dst_data").write.mode("overwrite").parquet(base_path + "data/"+type_+"/skewed_cc_with_dst_cc_data")
		spark.read.parquet(base_path + "data/"+type_+"/skewed_cc_with_dst_cc_data").withColumn("type" , F.when(F.col("type").contains("id_mid") , "id_mid").otherwise("em")).groupby("src_component" , "type").agg(F.collect_list(F.col("dst_data")).alias("dst_data")).write.mode("overwrite").parquet(base_path + "data/"+type_+"/skewed_cc_with_dst_cc_data_groupby")
		skewed_cc_groupby = spark.read.parquet(base_path + "data/"+type_+"/skewed_cc_with_dst_cc_data_groupby")
		skewed_ids_ = skewed_ids.select("component" , F.col("long_id").alias("id"))
		counter_+=1
	return base_path + "data/"+type_+"/new_cc_after_relinking_" , 1
