from helper.packages_ import *
def getNeighbors(base_path , edges  , type_ ):
	neighbor_path = base_path + "data/"+type_+"/neighbor_path"
	edges.select(F.col("src").alias("id") , F.col("dst").alias("neighbor")).union(edges.select(F.col("dst").alias("id") , F.col("src").alias("neighbor"))).distinct().write.mode("overwrite").parquet(neighbor_path)
	return neighbor_path
###################


def relinkingIsolatedID(base_path , component_  , edges ,  type_ , spark , sc):
	single_id_comp_path = base_path + "data/"+type_+"/single_id_cc"
	isolated_vertices_path = base_path + "data/"+type_+"/single_cc_ids"
	isolated_ids_with_neighbors_path =base_path + "data/"+type_+"/isolated_ids_with_neighbors_path"
	isolated_ids_with_new_components_groupby_path = base_path + "data/"+type_+"/isolated_ids_with_new_components_groupby_path"
	isolated_ids_with_new_components_path = base_path + "data/"+type_+"/isolated_ids_with_new_components_path"
	cc_without_isolated_vertices_path = base_path + "data/"+type_+"/cc_without_isolated_vertices_path"
	comp_after_relinking_isolated_ids = base_path + "data/"+type_+"/comp_after_relinking_isolated_ids"
	component_.groupby("component").count().filter(F.col("count") == 1).select("component").write.mode("overwrite").parquet(single_id_comp_path)
	cc_isolated_vertices = spark.read.parquet(single_id_comp_path) ## comp
	cc_isolated_vertices.join(component_ , on = "component").write.mode("overwrite").parquet(isolated_vertices_path)
	single_comp_id = spark.read.parquet(isolated_vertices_path).select("id") ## comp , id 
	neighbor_path = getNeighbors(base_path , edges  , type_)
	neighbors = spark.read.parquet(neighbor_path)
	single_comp_id.join(neighbors , on = "id").write.mode("overwrite").parquet(isolated_ids_with_neighbors_path)
	isolated_ids_with_neighbors = spark.read.parquet(isolated_ids_with_neighbors_path).withColumnRenamed("id" , "isolated_id")
	component_.join(isolated_ids_with_neighbors , component_.id == isolated_ids_with_neighbors.neighbor).drop("id" , "neighbor").write.mode("overwrite").parquet(isolated_ids_with_new_components_path)
	spark.read.parquet(isolated_ids_with_new_components_path).groupby("isolated_id").agg(F.collect_list(F.col("component")).alias("component")).write.mode("overwrite").parquet(isolated_ids_with_new_components_groupby_path)
	spark.read.parquet(isolated_ids_with_new_components_groupby_path).rdd.map(lambda x: (x["isolated_id"] , max(x["component"],key=x["component"].count))).toDF(["id" , "component"]).write.mode("overwrite").parquet(isolated_ids_with_new_components_path)
	component_.subtract(spark.read.parquet(isolated_vertices_path)).write.mode("overwrite").parquet(cc_without_isolated_vertices_path)
	spark.read.parquet(isolated_ids_with_new_components_path).select("component" , "id").union(spark.read.parquet(cc_without_isolated_vertices_path).select("component" , "id")).distinct().write.mode("overwrite").parquet(comp_after_relinking_isolated_ids)
	if spark.read.parquet(comp_after_relinking_isolated_ids).groupby("component").count().filter(F.col("count") == 1).count() == 0:
		print("successful relinkingIsolatedID")
		return comp_after_relinking_isolated_ids
	else:
		print("unsuccessful relinkingIsolatedID")
		return ""