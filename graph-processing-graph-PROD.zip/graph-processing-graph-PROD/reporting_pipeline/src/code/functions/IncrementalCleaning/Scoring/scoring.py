from helper.packages_ import *
def scoringVertexAndEdges(base_path , cleaned_cc_path , all_edges_path , long_mapper_path , type_  , output_vertex_path , output_edge_path , input_vertex_set_path , input_edge_set_path , spark , sc):
	def getHops(x , match_rate=[ 3, 5 ]):
		data = x["edges"]
		count=0
		score_dictionary1 = {} # need to return 
		score_dictionary2 = {} # need to return 
		graph = nx.Graph()
		for i in data:
		    graph.add_edge(list(i.keys())[0] , list(i.values())[0])
		prob = 0
		hops1=0
		hops2=0
		flag = ""
		for node in x["id"]:
			count+=1
			if node in list(graph.nodes()):
				online_id_grabbed_in_1_moove = online_percentage.value * graph.degree(node)
				hops1 = math.ceil(match_rate[0] / online_id_grabbed_in_1_moove)
				hops2 = math.ceil(match_rate[1] / online_id_grabbed_in_1_moove)
				flag = "scored_with_no_anomaly"
				score_dictionary1[node] = hops1
				score_dictionary2[node] = hops2
			else:
				flag = "no_edges_found_for_this_id"
				score_dictionary1[node] = 1
				score_dictionary2[node] = 1
		return x['component'], x['id'], score_dictionary1 , score_dictionary2 
	##################
	def getCliques(x):
		data = x["edges"]
		graph = nx.Graph() 
		for i in data:
			graph.add_edge(list(i.keys())[0] , list(i.values())[0])
		dictionary = nx.node_clique_number(graph)
		return x["component"] , dictionary
	#######################################
	def EdgeAssignerUdf(x):
		sortedVertex1Type = x["vertex1Type"]
		sortedVertex2Type = x["vertex2Type"]
		if (sortedVertex1Type == "id_mid_1" and sortedVertex2Type == "id_mid_1"): return 9
		elif (sortedVertex1Type.startswith("email") and sortedVertex2Type == "id_mid_1"): return 2
		elif (sortedVertex1Type.startswith("cellphone") and sortedVertex2Type == "id_mid_1"): return 4
		elif (sortedVertex1Type == "id_mid_1" and sortedVertex2Type.startswith("id_mid_")): return 6
		elif (sortedVertex1Type.startswith("cellphone") and sortedVertex2Type.startswith("email")): return 1
		elif (sortedVertex1Type.startswith("email") and sortedVertex2Type.startswith("id_mid_")): return 3
		elif (sortedVertex1Type.startswith("cellphone") and sortedVertex2Type.startswith("id_mid_")): return 5
		elif (sortedVertex1Type.startswith("email") and sortedVertex2Type.startswith("email")): return 7
		elif (sortedVertex1Type.startswith("cellphone") and sortedVertex2Type.startswith("cellphone")): return 8
		elif (sortedVertex1Type.startswith("id_mid_") and sortedVertex2Type.startswith("id_mid_")): return 10
		elif (sortedVertex1Type == "id_crm_id" and sortedVertex2Type == ("id_crm_id")): return 11
		elif (sortedVertex1Type == "id_crm_id" and sortedVertex2Type.startswith("email")): return 12
		elif (sortedVertex1Type == "id_crm_id" and sortedVertex2Type.startswith("cellphone")): return 13
		elif (sortedVertex1Type == "id_crm_id" and sortedVertex2Type == "id_mid_1"): return 14
		elif (sortedVertex1Type == "id_crm_id" and sortedVertex2Type.startswith("id_mid_")): return 15
		else: return -1
	#######################################
	EdgeAssignerUdf_ = F.udf(lambda x: EdgeAssignerUdf(x) , IntegerType())
	all_vertex = spark.read.parquet(long_mapper_path).withColumnRenamed("vertex" , "string_id").withColumnRenamed("vertexType" , "type")
	# non_cleaned_cc = spark.read.parquet(base_path + "/country="+country+"/non_cleaned_ids").drop("count")
	graph_edges_mapped_to_long = spark.read.parquet(all_edges_path)
	###################
	cleaned_cc = spark.read.parquet(cleaned_cc_path)
	non_cleaned_cc = spark.read.parquet(base_path + "non_cleaned_ids")
	cleaned_cc.select("component" , "id").union(non_cleaned_cc.select("component" , "id")).distinct().write.mode("overwrite").parquet(base_path + "final_ccs")
	final_ccs = spark.read.parquet(base_path + "final_ccs")
	final_ccs.join(graph_edges_mapped_to_long , final_ccs.id == graph_edges_mapped_to_long.src_long_id).drop("id").withColumnRenamed("component" , "src_component").write.mode("overwrite").parquet(base_path + "data/"+type_+"/cleaned_edges/src_edges_long")
	intermediate = spark.read.parquet(base_path + "data/"+type_+"/cleaned_edges/src_edges_long")
	final_ccs.join(intermediate , final_ccs.id == intermediate.dst_long_id).drop("id").withColumnRenamed("component" , "dst_component").write.mode("overwrite").parquet(base_path + "data/"+type_+"/cleaned_edges/dst_edges_long")
	cleaned_edges_with_cc = spark.read.parquet(base_path + "data/"+type_+"/cleaned_edges/dst_edges_long")
	edge_df = spark.read.parquet(input_edge_set_path)
	cleaned_edges_with_cc.filter(F.col("dst_component") == F.col("src_component")).withColumn("quality" , F.lit(1.0)).drop("dst_component" , "src_long_id" , "dst_long_id").withColumnRenamed("src_component" , "component_id").write.mode("overwrite").parquet(base_path + "data/"+type_+"/cleaned_edges/final_selected_edges") ## vertex1 , vertex1Type , vertex2 , vertex2Type , edge_quality
	spark.read.parquet(base_path + "data/"+type_+"/cleaned_edges/final_selected_edges").withColumn("edge_category" , EdgeAssignerUdf_(F.struct(F.col("vertex1Type") , F.col("vertex2Type")))).write.mode("overwrite").parquet(base_path + "data/"+type_+"/cleaned_edges/final_selected_edges_with_pairing")
	cleaned_edges_with_cc_ = spark.read.parquet(base_path + "data/"+type_+"/cleaned_edges/final_selected_edges_with_pairing")
	cleaned_edges_with_cc_.join(edge_df , on = ["vertex1" , "vertex2" , "vertex1Type" , "vertex2Type"]).write.mode("overwrite").parquet(output_edge_path)
	#################### edge scored
	vertex_df = spark.read.parquet(input_vertex_set_path)
	cleaned_edges_with_cc.filter(F.col("src_component") == F.col("dst_component")).drop("src_component").withColumnRenamed("dst_component" , "component").withColumnRenamed("src_long_id" , "src").withColumnRenamed("dst_long_id" , "dst").withColumnRenamed("vertex1" , "src_string_id").withColumnRenamed("vertex2" , "dst_string_id").withColumnRenamed("vertex1Type" , "src_type").withColumnRenamed("vertex2Type" , "dst_type").write.mode("overwrite").parquet(base_path + "data/"+type_+"/traversible_edges_with_cc")
	edges_removed = cleaned_edges_with_cc.filter(F.col("src_component") != F.col("dst_component")).select("src_long_id" , "dst_long_id").count()
	edges_removed_percentage = (edges_removed*100) / cleaned_edges_with_cc.count()
	edges_removed_percentage_round = float("{0:.5f}".format(edges_removed_percentage))
	spark.createDataFrame([(edges_removed , edges_removed_percentage_round)] , ["edges_removed" , "percentage_of_edges_removed"]).coalesce(1).write.mode("overwrite").json(base_path + "data/"+type_+"/dropout_info")
	spark.read.parquet(base_path + "data/"+type_+"/traversible_edges_with_cc").select("component" , "src" , "dst").groupby("component").agg(F.collect_list(F.create_map(F.col("src") , F.col("dst"))).alias("edges")).write.mode("overwrite").parquet(base_path + "data/"+type_+"/traversible_edges_with_cc_groupby")
	final_ccs.join(all_vertex , [final_ccs.id == all_vertex.long_id]).drop("id").select("component" , "long_id" , "type" , "string_id").write.mode("overwrite").parquet(base_path + "data/"+type_+"/traversible_vertexes_with_types")
	vertex_cc = spark.read.parquet(base_path + "data/"+type_+"/traversible_vertexes_with_types")
	vertex_cc.groupby("component").agg(F.collect_list(F.col("long_id")).alias("id") , F.collect_list(F.col("type")).alias("type")).write.mode("overwrite").parquet(base_path + "data/"+type_+"/traversible_vertexes_with_types_groupby")
	vertex_groupby = spark.read.parquet(base_path + "data/"+type_+"/traversible_vertexes_with_types_groupby")
	edges_groupby = spark.read.parquet(base_path + "data/"+type_+"/traversible_edges_with_cc_groupby")
	vertex_groupby.join(edges_groupby , on = "component").write.mode("overwrite").parquet(base_path + "data/"+type_+"/traversible_vertexes_and_edges_with_cc")
	cc = spark.read.parquet(base_path + "data/"+type_+"/traversible_vertexes_and_edges_with_cc")
	online_count = vertex_cc.filter(vertex_cc.type.contains("id_mid")).count()
	total_count = vertex_cc.count()
	online_percentage_ = online_count/total_count
	online_percentage = sc.broadcast(online_percentage_)
	cc.rdd.map(lambda x: getHops(x)).toDF(["component" , "id" , "hops_mr_3" , "hops_mr_5"]).write.mode("overwrite").parquet(base_path + "data/scoring/hops/scoring_with_hops")
	hops_df_ = spark.read.parquet(base_path + "data/scoring/hops/scoring_with_hops")
	hops_df_.select(F.explode("hops_mr_3").alias("id","hops_mr_3")).write.mode("overwrite").parquet(base_path + "scoring/hops/max_hops/MR3")
	hops_df_.select(F.explode("hops_mr_5").alias("id","hops_mr_5")).write.mode("overwrite").parquet(base_path + "scoring/hops/max_hops/MR5")
	MR3 = spark.read.parquet(base_path + "scoring/hops/max_hops/MR3")
	MR5 = spark.read.parquet(base_path + "scoring/hops/max_hops/MR5")
	join1 = MR5.join(MR3 , on = "id")
	join1.write.mode("overwrite").parquet(base_path + "data/scoring/hops/vertices_with_hops")
	cc.rdd.map(lambda x: getCliques(x)).toDF(["component" , "max_clique_per_id"]).write.mode("overwrite").parquet(base_path + "data/scoring/clique/cliques_with_comp")
	cliques = spark.read.parquet(base_path + "data/scoring/clique/cliques_with_comp")
	cliques.select("component" , F.explode("max_clique_per_id").alias("id","max_len_clique")).write.mode("overwrite").parquet(base_path + "data/scoring/clique/vertices_with_cliques")
	cliques_scored = spark.read.parquet(base_path + "data/scoring/clique/vertices_with_cliques")
	spark.read.parquet(base_path + "data/scoring/hops/vertices_with_hops").withColumn("hops_mr_5" , F.when(F.col("hops_mr_5") >= 5 , 5).otherwise(F.col("hops_mr_5"))).withColumn("hops_mr_3" , F.when(F.col("hops_mr_3") >= 3 , 3).otherwise(F.col("hops_mr_3"))).write.mode("overwrite").parquet(base_path + "data/scoring/hops/vertices_with_hops_")
	hops_scored = spark.read.parquet(base_path + "data/scoring/hops/vertices_with_hops_")
	cliques_scored.join(hops_scored , on = 'id').distinct().withColumnRenamed("max_clique_per_id" , "cliques").write.mode("overwrite").parquet(base_path + "data/scoring/scoring_df")
	scored_df = spark.read.parquet(base_path + "data/scoring/scoring_df")
	isolated_vertices = spark.read.parquet(base_path + "/isolated_ids").withColumn("hops_mr_3" , F.lit(0)).withColumn("hops_mr_5" , F.lit(0)).withColumn("max_len_clique" , F.lit(0))
	scored_df.select('id', 'component', 'max_len_clique', 'hops_mr_5', 'hops_mr_3').union(isolated_vertices.select('id', 'component', 'max_len_clique', 'hops_mr_5', 'hops_mr_3')).write.mode("overwrite").parquet(base_path + "data/scoring/scoring_df_with_solated_vertices")
	scored_df = spark.read.parquet(base_path + "data/scoring/scoring_df_with_solated_vertices")
	all_vertex.join(vertex_df , [all_vertex.string_id == vertex_df.vertex , all_vertex.type == vertex_df.vertexType]).drop("string_id" , "type").write.mode("overwrite").parquet(base_path + "data/scoring/vertex_with_meta_cel")
	vertex_with_meta_cel = spark.read.parquet(base_path + "data/scoring/vertex_with_meta_cel")
	scored_df.join(vertex_with_meta_cel , scored_df.id == vertex_with_meta_cel.long_id).drop("id" , "long_id" , "component_id" , "country_ds_metadata").withColumnRenamed("component" , "component_id").withColumn("quality" , F.lit(1.0)).write.mode("overwrite").parquet(output_vertex_path)



