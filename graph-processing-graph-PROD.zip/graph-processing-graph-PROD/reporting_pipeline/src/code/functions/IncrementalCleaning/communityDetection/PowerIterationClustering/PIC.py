from helper.packages_ import *
def runPIC(base_path , edge_set , cluster_ , iterations_ , type_ , output_path , spark , sc):
	def getNeighborsPic(base_path , edges , cluster_ , iterations_ , type_ ):
		neighbor_path = base_path + "data/"+type_+"/cleaningGraphBigComponentsUsingPIC/PIC_comps/PIC_model="+cluster_+"/iterations="+iterations_+"/neighbor_path"
		edges.select(F.col("src").alias("id") , F.col("dst").alias("neighbor")).union(edges.select(F.col("dst").alias("id") , F.col("src").alias("neighbor"))).distinct().write.mode("overwrite").parquet(neighbor_path)
		return neighbor_path
		####################################################
	def relinkingIsolatedIDForPic(base_path , comp_after_PIC_ , comp_after_PIC_path , neighbor_path , cluster_ , iterations_ , type_ , spark , sc):
		single_id_comp_path = base_path + "data/"+type_+"/cleaningGraphBigComponentsUsingPIC/PIC_comps/PIC_model="+cluster_+"/iterations="+iterations_+"/single_id_comp_path"
		isolated_vertices_path = base_path + "data/"+type_+"/cleaningGraphBigComponentsUsingPIC/PIC_comps/PIC_model="+cluster_+"/iterations="+iterations_+"/isolated_vertices_path"
		isolated_ids_with_neighbors_path = base_path + "data/"+type_+"/cleaningGraphBigComponentsUsingPIC/PIC_comps/PIC_model="+cluster_+"/iterations="+iterations_+"/isolated_ids_with_neighbors_path"
		isolated_ids_with_new_components_groupby_path = base_path + "data/"+type_+"/cleaningGraphBigComponentsUsingPIC/PIC_comps/PIC_model="+cluster_+"/iterations="+iterations_+"/isolated_ids_with_new_components_groupby_path"
		isolated_ids_with_new_components_path = base_path + "data/"+type_+"/cleaningGraphBigComponentsUsingPIC/PIC_comps/PIC_model="+cluster_+"/iterations="+iterations_+"/isolated_ids_with_new_components_path"
		cc_without_isolated_vertices_path = base_path + "data/"+type_+"/cleaningGraphBigComponentsUsingPIC/PIC_comps/PIC_model="+cluster_+"/iterations="+iterations_+"/cc_without_isolated_vertices_path"
		comp_after_PIC_.groupby("component").count().filter(F.col("count") == 1).select("component").write.mode("overwrite").parquet(single_id_comp_path)
		cc_isolated_vertices = spark.read.parquet(single_id_comp_path) ## comp
		cc_isolated_vertices.join(comp_after_PIC_ , on = "component").write.mode("overwrite").parquet(isolated_vertices_path)
		single_comp_id = spark.read.parquet(isolated_vertices_path).select("id") ## comp , id 
		neighbors = spark.read.parquet(neighbor_path)
		single_comp_id.join(neighbors , on = "id").write.mode("overwrite").parquet(isolated_ids_with_neighbors_path)
		isolated_ids_with_neighbors = spark.read.parquet(isolated_ids_with_neighbors_path).withColumnRenamed("id" , "isolated_id")
		comp_after_PIC_.join(isolated_ids_with_neighbors , comp_after_PIC_.id == isolated_ids_with_neighbors.neighbor).drop("id" , "neighbor").write.mode("overwrite").parquet(isolated_ids_with_new_components_path)
		spark.read.parquet(isolated_ids_with_new_components_path).groupby("isolated_id").agg(F.collect_list(F.col("component")).alias("component")).write.mode("overwrite").parquet(isolated_ids_with_new_components_groupby_path)
		spark.read.parquet(isolated_ids_with_new_components_groupby_path).rdd.map(lambda x: (x["isolated_id"] , max(x["component"],key=x["component"].count))).toDF(["id" , "component"]).write.mode("overwrite").parquet(isolated_ids_with_new_components_path)
		comp_after_PIC_.subtract(spark.read.parquet(isolated_vertices_path)).write.mode("overwrite").parquet(cc_without_isolated_vertices_path)
		spark.read.parquet(isolated_ids_with_new_components_path).select("component" , "id").union(spark.read.parquet(cc_without_isolated_vertices_path).select("component" , "id")).distinct().write.mode("overwrite").parquet(comp_after_PIC_path)
		if spark.read.parquet(comp_after_PIC_path).groupby("component").count().filter(F.col("count") == 1).count() == 0:
			print("successful relinking")
			return comp_after_PIC_path
		else:
			print("unsuccessful relinking")
			return ""
		####################################################
	def get_Inter_cluster_edges(base_path , edge_set , cluster_ , iterations_ , type_ , spark , sc):
		inter_cluster_path = base_path + "data/"+type_+"/cleaningGraphBigComponentsUsingPIC/PIC_comps/PIC_model="+cluster_+"/iterations="+iterations_+"/inter_cluster_path"
		inter_cluster_vertices_path = base_path + "data/"+type_+"/cleaningGraphBigComponentsUsingPIC/PIC_comps/PIC_model="+cluster_+"/iterations="+iterations_+"/inter_cluster_vertices_path"
		inter = edge_set.filter(F.col("src_cluster") != F.col("dst_cluster"))
		inter.select("src").union(inter.select("dst")).distinct().withColumnRenamed("src" , "id").write.mode("overwrite").parquet(inter_cluster_vertices_path)
		inter.write.mode("overwrite").parquet(inter_cluster_path)
		if spark.read.parquet(inter_cluster_path).count() > 0:
			print("intra cluster vertices written to "+str(inter_cluster_path)+", running cc in next phase")
			return inter_cluster_path
		else : 
			print("inter cluster vertices not written , check error")
			return ""
		####################################################
	def get_Intra_cluster_edges(base_path , edge_set , cluster_ , iterations_ , type_ , spark , sc):
		intra_cluster_path = base_path + "data/"+type_+"/cleaningGraphBigComponentsUsingPIC/PIC_comps/PIC_model="+cluster_+"/iterations="+iterations_+"/intra_cluster_path"
		intra_cluster_vertices_path = base_path + "data/"+type_+"/cleaningGraphBigComponentsUsingPIC/PIC_comps/PIC_model="+cluster_+"/iterations="+iterations_+"/intra_cluster_vertices_path"
		intra = edge_set.filter(F.col("src_cluster") == F.col("dst_cluster"))
		intra.select("src").union(intra.select("dst")).distinct().withColumnRenamed("src" , "id").write.mode("overwrite").parquet(intra_cluster_vertices_path)
		intra.write.mode("overwrite").parquet(intra_cluster_path)
		if spark.read.parquet(intra_cluster_path).count() > 0:
			print("intra cluster vertices written to "+str(intra_cluster_path)+" , running cc in next phase")
			return intra_cluster_path , spark.read.parquet(intra_cluster_vertices_path)
		else:
			print("intra cluster vertices not written , check error")
			return "" , spark.read.parquet(intra_cluster_vertices_path)
		####################################################
	def graph_cc_intra(base_path , intra_cluster_path , cluster_ , iterations_ , type_ , spark , sc):
		if spark.read.parquet(intra_cluster_path).count() > 0 :
			cc_intra_path = base_path + "data/"+type_+"/cleaningGraphBigComponentsUsingPIC/PIC_comps/PIC_model="+cluster_+"/iterations="+iterations_+"/cc_intra_path"
			edges_set_intra = spark.read.parquet(intra_cluster_path)
			vertex_set_intra = edges_set_intra.select("src").union(edges_set_intra.select("dst")).distinct().withColumnRenamed("src" , "id")
			graph_intra = GraphFrame(vertex_set_intra , edges_set_intra)
			sc.setCheckpointDir(base_path + "data/"+type_+"/cleaningGraphBigComponentsUsingPIC/PIC_comps/PIC_model="+cluster_+"/iterations="+iterations_+"/checkpoint_dir")
			print("PIC intra cluster cc starting for " + str(cluster_) + " cluster and " + str(iterations_) + " iterations")
			graph_intra_cc = graph_intra.connectedComponents(algorithm = "graphframes", checkpointInterval = 2, broadcastThreshold = 100000)
			graph_intra_cc.groupby("component").count().sort(F.col("count").desc()).show()
			graph_intra_cc.write.mode("overwrite").parquet(cc_intra_path)
			if graph_intra_cc.count() > 0:
				print("intra cluster cc created and written to " + cc_intra_path + " path")
				return cc_intra_path
			else : 
				print("intra cluster cc not written , returning empty string")
				return ""
		else:
			print("intra cluster cc not written , returning empty string")
			return ""
		########################################################################################################
	def graph_cc_inter(base_path , inter_cluster_path , intra_cluster_vertices , cluster_ , iterations_ , type_ , spark , sc):
		if spark.read.parquet(inter_cluster_path).count() > 0 :
			cc_inter_path = base_path + "data/"+type_+"/cleaningGraphBigComponentsUsingPIC/PIC_comps/PIC_model="+cluster_+"/iterations="+iterations_+"/cc_inter_path"
			isolated_vertices_path = base_path + "data/"+type_+"/cleaningGraphBigComponentsUsingPIC/PIC_comps/PIC_model="+cluster_+"/iterations="+iterations_+"/isolated_vertices_path"
			inter_cluster_self_vertices_path = base_path + "data/"+type_+"/cleaningGraphBigComponentsUsingPIC/PIC_comps/PIC_model="+cluster_+"/iterations="+iterations_+"/inter_cluster_self_vertices_path"
			edges_set_inter = spark.read.parquet(inter_cluster_path)
			vertex_set_inter = edges_set_inter.select("src").union(edges_set_inter.select("dst")).distinct().withColumnRenamed("src" , "id")
			vertex_set_inter.subtract(intra_cluster_vertices).write.mode("overwrite").parquet(inter_cluster_self_vertices_path)
			inter_cluster_self_vertices = spark.read.parquet(inter_cluster_self_vertices_path)
			inter_cluster_edges_with_self_vertices_intermediate_path = base_path + "data/"+type_+"/cleaningGraphBigComponentsUsingPIC/PIC_comps/PIC_model="+cluster_+"/iterations="+iterations_+"/inter_cluster_edges_with_self_vertices_intermediat_path"
			inter_cluster_edges_with_self_vertices_path = base_path + "data/"+type_+"/cleaningGraphBigComponentsUsingPIC/PIC_comps/PIC_model="+cluster_+"/iterations="+iterations_+"/inter_cluster_edges_with_self_vertices_path"
			inter_cluster_self_vertices.join(edges_set_inter , [inter_cluster_self_vertices.id == edges_set_inter.src]).drop("id").write.mode("overwrite").parquet(inter_cluster_edges_with_self_vertices_intermediate_path)
			intermediate_inter_cluster_edges = spark.read.parquet(inter_cluster_edges_with_self_vertices_intermediate_path)
			inter_cluster_self_vertices.join(intermediate_inter_cluster_edges , [inter_cluster_self_vertices.id == intermediate_inter_cluster_edges.dst]).drop("id").write.mode("overwrite").parquet(inter_cluster_edges_with_self_vertices_path)
			inter_cluster_edges = spark.read.parquet(inter_cluster_edges_with_self_vertices_path)					
			inter_cluster_vertices_final = inter_cluster_edges.select("src").union(inter_cluster_edges.select("dst")).distinct().withColumnRenamed("src" , "id")
			inter_cluster_self_vertices.subtract(inter_cluster_vertices_final).write.mode("overwrite").parquet(isolated_vertices_path)
			isolated_vertices = spark.read.parquet(isolated_vertices_path)
			graph_inter = GraphFrame(inter_cluster_vertices_final , inter_cluster_edges)
			sc.setCheckpointDir(base_path + "data/"+type_+"/cleaningGraphBigComponentsUsingPIC/PIC_comps/PIC_model="+cluster_+"/iterations="+iterations_+"/checkpoint_dir")
			print("PIC inter cluster cc starting for " + str(cluster_) + " cluster and " + str(iterations_) + " iterations")
			graph_inter_cc = graph_inter.connectedComponents(algorithm = "graphframes", checkpointInterval = 2, broadcastThreshold = 100000)
			graph_inter_cc.groupby("component").count().sort(F.col("count").desc()).show()
			graph_inter_cc = graph_inter_cc.select("id" , "component").union(isolated_vertices.withColumn("component" , F.col("id")).select("id" , "component"))
			graph_inter_cc.write.mode("overwrite").parquet(cc_inter_path)
			if graph_inter_cc.count() > 0:
				print("inter cluster cc created and written to " + cc_inter_path + " path")
				return cc_inter_path 
			else : 
				print("inter cluster cc not written , returning empty string")
				return ""
		else:
			print("intra cluster cc not written , returning empty string")
			return ""
		####################################################
	neighbor_path = getNeighborsPic(base_path , edge_set , cluster_ , iterations_ , type_ )
	print("neighbors_created")
	similarities = edge_set.rdd.map(lambda x: tuple((x["src"] , x["dst"] , float(1.0))))
	print("cluster run starting")
	def startPIC(base_path , cluster_ , iterations_  , similarities , spark , sc):
		model1 = PowerIterationClustering.train(similarities , int(cluster_) , int(iterations_))
		sav2 = model1.assignments().toDF(["id" , "cluster"])   
		PIC_result_path = base_path + "data/"+type_+"/cleaningGraphBigComponentsUsingPIC/PIC_comps/PIC_model="+cluster_+"/iterations="+iterations_+"/PIC_result"
		sav2.write.mode("overwrite").parquet(PIC_result_path)
		sav2 = spark.read.parquet(PIC_result_path)
		# sav2.groupby("cluster").count().sort(F.col("count").desc()).show()\
		PIC_src_edges_mapped_to_cluster_path = base_path + "data/"+type_+"/cleaningGraphBigComponentsUsingPIC/PIC_comps/PIC_model="+cluster_+"/iterations="+iterations_+"/PIC_src_edges_mapped_to_cluster_path"
		PIC_dst_edges_mapped_to_cluster_path = base_path + "data/"+type_+"/cleaningGraphBigComponentsUsingPIC/PIC_comps/PIC_model="+cluster_+"/iterations="+iterations_+"/PIC_dst_edges_mapped_to_cluster_path"
		edge_set.join(sav2 , [edge_set.src == sav2.id]).withColumnRenamed("cluster" , "src_cluster").drop("id").write.mode("overwrite").parquet(PIC_src_edges_mapped_to_cluster_path)
		intermediate = spark.read.parquet(PIC_src_edges_mapped_to_cluster_path)
		intermediate.join(sav2 , [intermediate.dst == sav2.id]).withColumnRenamed("cluster" , "dst_cluster").drop("id").write.mode("overwrite").parquet(PIC_dst_edges_mapped_to_cluster_path)
		PIC_dst_edges_mapped_to_cluster = spark.read.parquet(PIC_dst_edges_mapped_to_cluster_path).drop("component")
		return PIC_dst_edges_mapped_to_cluster
		#################################
	PIC_dst_edges_mapped_to_cluster = startPIC(base_path , cluster_ , iterations_ , similarities , spark , sc)
	PIC_inter_and_intra_over_flag = False
	while PIC_inter_and_intra_over_flag == False:
		if PIC_dst_edges_mapped_to_cluster.filter(F.col("src_cluster") == F.col("dst_cluster")).count() != 0 and PIC_dst_edges_mapped_to_cluster.filter(F.col("src_cluster") != F.col("dst_cluster")).count() != 0:
			print("inter and intra cluster run started")
			intra_cluster_path ,intra_cluster_vertices = get_Intra_cluster_edges(base_path , PIC_dst_edges_mapped_to_cluster , cluster_ , iterations_ , type_ , spark , sc)
			inter_cluster_path = get_Inter_cluster_edges(base_path , PIC_dst_edges_mapped_to_cluster , cluster_ , iterations_ , type_ , spark , sc)
			PIC_inter_and_intra_over_flag = True
		else:
			cluster_ = str(int(cluster_) - 2)
			iterations_ = str(int(iterations_) + 10)
			PIC_dst_edges_mapped_to_cluster = startPIC(base_path , cluster_ , iterations_ , similarities , spark , sc)
		## create intra cluster graphframes and cc
	print("inter and intra cluster cc run started")
	cc_intra_path = graph_cc_intra(base_path , intra_cluster_path , cluster_ , iterations_ , type_ , spark , sc)
	if cc_intra_path == "":
		return "" , -1
	cc_inter_path = graph_cc_inter(base_path , inter_cluster_path , intra_cluster_vertices , cluster_ , iterations_ , type_ , spark , sc)
	if cc_inter_path == "":
		return "" , -1
	comp_after_PIC_path = output_path
	spark.read.parquet(cc_intra_path).select("component" , "id").union(spark.read.parquet(cc_inter_path).select("component" , "id")).distinct().write.mode("overwrite").parquet(comp_after_PIC_path)
	comp_after_PIC_ = spark.read.parquet(comp_after_PIC_path)
	if comp_after_PIC_.groupby("component").count().filter(F.col("count") == 1).count() != 0 : 
		comp_after_PIC_path = relinkingIsolatedIDForPic(base_path , comp_after_PIC_ , comp_after_PIC_path , neighbor_path , cluster_ , iterations_ , type_ , spark , sc)
	else:
		pass
	print("Final path : " +  comp_after_PIC_path)
	return comp_after_PIC_path , 1



