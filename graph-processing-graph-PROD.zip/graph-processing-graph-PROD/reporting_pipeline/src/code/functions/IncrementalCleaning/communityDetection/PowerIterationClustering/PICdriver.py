from IncrementalCleaning.communityDetection.PowerIterationClustering.PIC import *
from helper.packages_ import *
def cleaningComponentsUsingPIC(base_path , cc_id_graph_and_ids_for_big_components , edges_id_graph_and_ids_for_big_components , threshold_for_comp_size_set_for_PIC , type_ , spark , sc) : 	
	cc_selected_path = base_path + "data/"+type_+"/cleaningGraphBigComponentsUsingPIC/getting_components_path"
	id_selected_path = base_path + "data/"+type_+"/cleaningGraphBigComponentsUsingPIC/getting_ids_path"
	edges_selected_path = base_path + "data/"+type_+"/cleaningGraphBigComponentsUsingPIC/getting_edges_selected_path"
	cc_id_graph_and_ids_for_big_components.groupby("component").count().filter(F.col("count") > threshold_for_comp_size_set_for_PIC).select("component").write.mode("overwrite").parquet(cc_selected_path)
	cc_selected = spark.read.parquet(cc_selected_path)
	cc_selected.join(cc_id_graph_and_ids_for_big_components , on = "component").write.mode("overwrite").parquet(id_selected_path)
	id_selected = spark.read.parquet(id_selected_path)
	cc_selected.join(edges_id_graph_and_ids_for_big_components , on = "component").write.mode("overwrite").parquet(edges_selected_path)
	edges_selected = spark.read.parquet(edges_selected_path).drop("component")
	## pic run iterations/////////////////////////////// point to discuss
	cluster_ = "18"
	iterations_ = "10" 
	output_path = base_path + "data/"+type_+"/cleaningGraphBigComponentsUsingPIC/PIC_comps/PIC_model="+cluster_+"/iterations="+iterations_+"/comp_after_PIC_path"
	comp_after_PIC_path , value_ = runPIC(base_path , edges_selected , cluster_ , iterations_ , type_ , output_path , spark , sc) ## run pic for first time
	while value_ == -1: 
		print("PIC failed , trying new cluster and iteration value ")
		cluster_ = str(int(int(cluster_) - 2 ))
		iterations_ = str(int(int(iterations_) + 5))
		output_path = base_path + "data/"+type_+"/cleaningGraphBigComponentsUsingPIC/PIC_comps/PIC_model="+cluster_+"/iterations="+iterations_+"/comp_after_PIC_path" 
		comp_after_PIC_path , value_ = runPIC(base_path , edges_selected , cluster_ , iterations_ , type_ , output_path , spark , sc)
	else:
		pass
	## PIC loop
	max_size_cc = spark.read.parquet(comp_after_PIC_path).groupby("component").count().sort(F.col("count").desc()).take(1)[0][1]
	counter_ = 0
	while max_size_cc > threshold_for_comp_size_set_for_PIC:
		print("comp at start of the loop ")
		spark.read.parquet(comp_after_PIC_path).groupby("component").count().sort(F.col("count").desc()).show()
		print("iteration " + str(counter_) + " started")
		cc_more_than_PIC_threshold_path = base_path + "data/"+type_+"/cleaningGraphBigComponentsUsingPIC/cc_more_than_PIC_threshold_path"
		cc_less_than_PIC_threshold_path = base_path + "data/"+type_+"/cleaningGraphBigComponentsUsingPIC/cc_less_than_PIC_threshold_path"
		cc_id_graph_and_ids_for_big_components = spark.read.parquet(comp_after_PIC_path)
		cc_id_graph_and_ids_for_big_components.groupby("component").count().filter(F.col("count") > threshold_for_comp_size_set_for_PIC).select("component").write.mode("overwrite").parquet(cc_more_than_PIC_threshold_path) ## cc to clean at stage i 
		cc_id_graph_and_ids_for_big_components.groupby("component").count().filter(F.col("count") <= threshold_for_comp_size_set_for_PIC).select("component").write.mode("overwrite").parquet(cc_less_than_PIC_threshold_path) ## cc with which we have to merge
		id_selected_path_ = base_path + "data/"+type_+"/cleaningGraphBigComponentsUsingPIC/id_selected_path_"
		id_selected_path_less_than_PIC_threshold = base_path + "data/"+type_+"/cleaningGraphBigComponentsUsingPIC/id_selected_path_less_than_PIC_threshold"
		intermediate_edges_selected_path_ = base_path + "data/"+type_+"/cleaningGraphBigComponentsUsingPIC/intermediate_edges_selected_path_"
		edges_selected_path_ = base_path + "data/"+type_+"/cleaningGraphBigComponentsUsingPIC/edges_selected_path_"
		filtered_edges_selected_path_ = base_path + "data/"+type_+"/cleaningGraphBigComponentsUsingPIC/filtered_edges_selected_path_"
		cc_selected = spark.read.parquet(cc_more_than_PIC_threshold_path)
		cc_selected.join(cc_id_graph_and_ids_for_big_components , on = "component").write.mode("overwrite").parquet(id_selected_path_)
		id_selected = spark.read.parquet(id_selected_path_)
		id_selected.join(edges_selected , id_selected.id == edges_selected.src).drop("id").withColumnRenamed("component" , "src_component").write.mode("overwrite").parquet(intermediate_edges_selected_path_)
		intermediate_edges_selected = spark.read.parquet(intermediate_edges_selected_path_)
		id_selected.join(intermediate_edges_selected , id_selected.id == intermediate_edges_selected.dst).drop("id").withColumnRenamed("component" , "dst_component").write.mode("overwrite").parquet(edges_selected_path_)
		edges_selected = spark.read.parquet(edges_selected_path_)
		edges_selected.filter(F.col("src_component") == F.col("dst_component")).drop("src_component" , "dst_component").write.mode("overwrite").parquet(filtered_edges_selected_path_)
		edges_selected = spark.read.parquet(filtered_edges_selected_path_)
		cc_selected_less_than_PIC_threshold = spark.read.parquet(cc_less_than_PIC_threshold_path)
		cc_selected_less_than_PIC_threshold.join(cc_id_graph_and_ids_for_big_components , on = "component").write.mode("overwrite").parquet(id_selected_path_less_than_PIC_threshold)
		id_selected_less_than_PIC_threshold = spark.read.parquet(id_selected_path_less_than_PIC_threshold)
		output_path = base_path + "data/"+type_+"/cleaningGraphBigComponentsUsingPIC/PIC_comps/PIC_model="+cluster_+"/iterations="+iterations_+"/comp_after_PIC_path_updated"
		comp_after_PIC_path , value_ = runPIC(base_path , edges_selected , cluster_ , iterations_ , type_ , output_path , spark , sc)
		while value_ == -1:
			print("PIC failed , trying new cluster and iteration value")
			cluster_ = str(int(cluster_) - 2 )
			iterations_ = str(int(iterations_) + 5 )
			output_path = base_path + "data/"+type_+"/cleaningGraphBigComponentsUsingPIC/PIC_comps/PIC_model="+cluster_+"/iterations="+iterations_+"/comp_after_PIC_path" 
			comp_after_PIC_path , value_ = runPIC(base_path , edges_selected , cluster_ , iterations_ , type_ , output_path , spark , sc) ## run pic for first time
		comp_after_PIC_new_path = base_path + "data/"+type_+"/cleaningGraphBigComponentsUsingPIC/comp_after_PIC_new_path"
		spark.read.parquet(comp_after_PIC_path).write.mode("overwrite").parquet(comp_after_PIC_new_path)
		comp_after_PIC_new = spark.read.parquet(comp_after_PIC_new_path)
		comp_after_PIC_new.select("component" , "id").union(id_selected_less_than_PIC_threshold.select("component" , "id")).distinct().write.mode("overwrite").parquet(comp_after_PIC_path)
		print("components after PIC iteration " + str(counter_))
		spark.read.parquet(comp_after_PIC_path).groupby("component").count().sort(F.col("count").desc()).show()
		if max_size_cc - spark.read.parquet(comp_after_PIC_path).groupby("component").count().sort(F.col("count").desc()).take(1)[0][1] <= 3000:
			cluster_ = str(int(cluster_) - 3)
			iterations_ = str(int(iterations_) + 10)
			print("cluster is " + cluster_ + " and iterations are " + iterations_)
		else:
			pass
		max_size_cc = spark.read.parquet(comp_after_PIC_path).groupby("component").count().sort(F.col("count").desc()).take(1)[0][1]
		counter_ += 1
	return comp_after_PIC_path
