from helper.packages_ import *


def cleaningGraphBigComponentsUsingCommunityDetection(base_path, cc_id_graph_and_ids_for_big_components, edges_id_graph_and_ids_for_big_components, threhhold_for_comp_size_set_for_community_detection, type_, spark, sc): 
    def prepareDataForCommunityDetection(base_path, edges, type_):
        edges_groupby_path = base_path + "data/" + type_ + "/cleaningGraphBigComponentsUsingCommunityDetection/edges_groupby_path"
        edges.groupby("component").agg(F.collect_list(F.create_map(F.col("src"), F.col("dst"))).alias("edges")).write.mode("overwrite").parquet(edges_groupby_path)
        return edges_groupby_path  
    ####################################
    def findCommunities(base_path, cc_id_graph_and_ids_for_big_components, edges_id_graph_and_ids_for_big_components, threhhold_for_comp_size_set_for_community_detection, type_, spark, sc):
        def InfoMap(x):
            import infomap
            from collections import defaultdict
            d = defaultdict(list)
            community_dict = dict()
            data = x['edges']
            edges_ = [[list(i.keys())[0] , list(i.values())[0]] for i in data]
            merged = list(itertools.chain.from_iterable(edges_))
            vertices = list((set(merged)))
            counter_ = 0
            new_vertices_list = {}
            for i in vertices:
                new_vertices_list[i] = counter_
                counter_ += 1
            converted_edge_list = []
            for i in edges_:
                converted_edge_list.append([new_vertices_list[i[0]] , new_vertices_list[i[1]]])
            im = infomap.Infomap()
            for i in converted_edge_list:
                im.add_link(i[0], i[1])
            im.run()
            inv_map = {v: k for k, v in new_vertices_list.items()}
            for node_id, module_id in im.modules:
                d[module_id].append(inv_map[node_id])
            return x["component"], {min(j): j for i, j in dict(d).items()}	
    ################################
        while cc_id_graph_and_ids_for_big_components.groupby("component").count().filter(F.col("count") >= threhhold_for_comp_size_set_for_community_detection).count() != 0:
            first_max_cc_size = cc_id_graph_and_ids_for_big_components.groupby("component").count().filter(F.col("count") >= threhhold_for_comp_size_set_for_community_detection).sort(F.col("count").desc()).take(1)[0][1]
            print("entering into community detection")
            cc_selected_path = base_path + "data/" + type_ + "/cleaningGraphBigComponentsUsingCommunityDetection/getting_components_path"
            cc_id_graph_and_ids_for_big_components.groupby("component").count().filter(F.col("count") >= threhhold_for_comp_size_set_for_community_detection).select("component").write.mode("overwrite").parquet(cc_selected_path)
            cc_ = spark.read.parquet(cc_selected_path)
            id_selected_path = base_path + "data/" + type_ + "/cleaningGraphBigComponentsUsingCommunityDetection/getting_ids_path"
            cc_.join(cc_id_graph_and_ids_for_big_components, on = "component").write.mode("overwrite").parquet(id_selected_path)
            edges_id_graph_and_ids_for_big_components = edges_id_graph_and_ids_for_big_components.drop("component")
            cc_to_break = spark.read.parquet(id_selected_path)
            print(str(cc_to_break.count()))
            cc_to_break.join(edges_id_graph_and_ids_for_big_components, cc_to_break.id == edges_id_graph_and_ids_for_big_components.src).drop("id").withColumnRenamed("component", "src_component").write.mode("overwrite").parquet(base_path + "data/" + type_ + "/cleaningGraphBigComponentsUsingCommunityDetection/src_mapped_community_edges")
            inter = spark.read.parquet(base_path + "data/" + type_ + "/cleaningGraphBigComponentsUsingCommunityDetection/src_mapped_community_edges")
            cc_to_break.join(inter, cc_to_break.id == inter.dst).drop("id").withColumnRenamed("component", "dst_component").write.mode("overwrite").parquet(base_path + "data/" + type_ + "/cleaningGraphBigComponentsUsingCommunityDetection/dst_mapped_community_edges")
            spark.read.parquet(base_path + "data/" + type_ + "/cleaningGraphBigComponentsUsingCommunityDetection/dst_mapped_community_edges").filter(F.col("src_component") == F.col("dst_component")).drop("dst_component").withColumnRenamed("src_component", "component").write.mode("overwrite").parquet(base_path + "data/" + type_ + "/cleaningGraphBigComponentsUsingCommunityDetection/component_to_break_with_edges_")
            component_to_break_with_edges_ = spark.read.parquet(base_path + "data/" + type_ + "/cleaningGraphBigComponentsUsingCommunityDetection/component_to_break_with_edges_")
            edges_groupby_path = prepareDataForCommunityDetection(base_path, component_to_break_with_edges_, type_)
            comp_data = spark.read.parquet(edges_groupby_path)
            print("infomap is startingg")
            comp_data.rdd.map(lambda x: InfoMap(x)).toDF(["component", "community_dict"]).write.mode("overwrite").parquet(base_path + "data/" + type_ + "/cleaningGraphBigComponentsUsingCommunityDetection/communities_detected")
            spark.read.parquet(base_path + "data/" + type_ + "/cleaningGraphBigComponentsUsingCommunityDetection/communities_detected").select(F.explode("community_dict").alias("component", "id")).select("component", F.explode("id").alias("id")).write.mode("overwrite").parquet(base_path + "data/" + type_ + "/cleaningGraphBigComponentsUsingCommunityDetection/communities_detected_exploded")
            cc_id_graph_and_ids_for_big_components.groupby("component").count().filter(F.col("count") < threhhold_for_comp_size_set_for_community_detection).select("component").write.mode("overwrite").parquet(base_path + "data/" + type_ + "/cleaningGraphBigComponentsUsingCommunityDetection/cc_to_union")
            cc_to_union = spark.read.parquet(base_path + "data/" + type_ + "/cleaningGraphBigComponentsUsingCommunityDetection/cc_to_union")
            cc_to_union.join(cc_id_graph_and_ids_for_big_components, on = "component").write.mode("overwrite").parquet(base_path + "data/" + type_ + "/cleaningGraphBigComponentsUsingCommunityDetection/cc_to_union_with_ids")
            spark.read.parquet(base_path + "data/" + type_ + "/cleaningGraphBigComponentsUsingCommunityDetection/communities_detected_exploded").select("component", "id").union(spark.read.parquet(base_path + "data/" + type_ + "/cleaningGraphBigComponentsUsingCommunityDetection/cc_to_union_with_ids").select("component", "id")).distinct().write.mode("overwrite").parquet(base_path + "data/" + type_ + "/cleaningGraphBigComponentsUsingCommunityDetection/connected_component_updated")
            cc_id_graph_and_ids_for_big_components = spark.read.parquet(base_path + "data/" + type_ + "/cleaningGraphBigComponentsUsingCommunityDetection/connected_component_updated")	
            if cc_id_graph_and_ids_for_big_components.groupby("component").count().filter(F.col("count") >= threhhold_for_comp_size_set_for_community_detection).count() != 0:
                second_max_cc_size = cc_id_graph_and_ids_for_big_components.groupby("component").count().filter(F.col("count") >= threhhold_for_comp_size_set_for_community_detection).sort(F.col("count").desc()).take(1)[0][1]
                if first_max_cc_size == second_max_cc_size:
                    print(str(first_max_cc_size))
                    print(str(second_max_cc_size))
                    break			
        return base_path + "data/" + type_ + "/cleaningGraphBigComponentsUsingCommunityDetection/connected_component_updated"
    ####################################
    breaked_cc_by_communities_path = findCommunities(base_path, cc_id_graph_and_ids_for_big_components, edges_id_graph_and_ids_for_big_components, threhhold_for_comp_size_set_for_community_detection, type_, spark, sc)
    return breaked_cc_by_communities_path
