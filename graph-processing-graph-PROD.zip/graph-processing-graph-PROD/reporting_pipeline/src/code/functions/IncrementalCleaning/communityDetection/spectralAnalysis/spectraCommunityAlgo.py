from helper.packages_ import *

def prepareDataForSpectralCommunities(base_path , edges , type_):
		edges_groupby_path = base_path + "data/"+type_+"/spectral_analysis/edges_groupby_path"
		edges.groupby("component").agg(F.collect_list(F.create_map(F.col("src") , F.col("dst"))).alias("edges")).write.mode("overwrite").parquet(edges_groupby_path)
		return edges_groupby_path



#########################
def spectralAlgo(base_path , vertices , edges , community_threshold , type_ , spark , sc , principal_component = 2):
	def spectralMapperGetModularityMatrix(x):
		G = nx.Graph()
		for i in x:
			G.add_edge(list(i.keys())[0] , list(i.values())[0])
		B = nx.modularity_matrix(G , nodelist = sorted(G.nodes()) ).tolist()
		return B.tolist() 
	#####################
	def eigenValueAndEigenVectorPairsMapper(modularity_matrix , principal_component): 
		EigenValueList , EigenVectorList =  list(map(lambda k: k.real if isinstance(k , complex) else k , numpy.linalg.eig(modularity_matrix)[0].tolist())) , list(map(lambda k: list(map(lambda p: p.real if isinstance(p , complex) else p , k)) , numpy.linalg.eig(modularity_matrix)[1].transpose().tolist()))
		if len(list(filter(lambda x: x>0 , EigenValueList))) in [0,1] :
			return [[-1.0]] 
		else:
			eig_pairs = [(float(EigenValueList[i]), EigenVectorList[:][i]) for i in range(len(EigenValueList))]
			## Sort the (eigenvalue, eigenvector) tuples from high to low
			eig_pairs.sort(key=lambda x: x[0], reverse=True)
			eigen_array = []
			for i in range(principal_component):
				eigen_array.append(numpy.array(eig_pairs[i][1]).reshape(len(EigenValueList),1))
			matrix_w = numpy.hstack(eigen_array)
			return matrix_w.tolist()

	def PassPrincpalCc1(principal_component):
		return F.udf(lambda x: eigenValueAndEigenVectorPairsMapper(x , principal_component) , schema)

	def getQuad(li):     
		neg = []
		for index , value in enumerate(li):
			if value < 0:                     
				neg.append(len(li) - 1 - index)
		sum_ = 0
		for i in neg:
			sum_ += math.pow(2,i)
		return int(sum_)

	def getFinalLinksMapper(x  , principal_component):
		matrix = x["projection_matrix"]
		edges = x["edges"]
		G = nx.Graph()
		for i in edges:
			G.add_edge(list(i.keys())[0] , list(i.values())[0])
		li = []
		eigen_value_count_buckets = int(math.pow(2 , principal_component))
		quad_dict = defaultdict(list,{ k:[] for k in range(eigen_value_count_buckets)})
		for i in list(zip(sorted(G.nodes()) , matrix)):
		    quad_dict[getQuad(i[1])].append(i[0])
		quad_dict = dict(quad_dict)
		select_edges = []
		for i in list(G.edges()):
			for j in range(0,eigen_value_count_buckets):
				if (i[0] in quad_dict[j] and i[1] not in quad_dict[j]) or (i[1] in quad_dict[j] and i[0] not in quad_dict[j]):
					if i in select_edges:
						pass
					else:
						select_edges.append(i)
				else:
					pass
		B= G.copy()
		B.remove_edges_from(select_edges)
		# distinct_anomalous_vertices = list(set((itertools.chain(*select_edges))))
		return list(B.edges())

	def PassPrincpalCc2(principal_component):
		return F.udf(lambda x: getFinalLinksMapper(x , principal_component) , ArrayType(ArrayType(IntegerType())))

	while final_cc.groupby("component").count().filter(F.col("count") > community_threshold).count() > 0:
		vertices.groupby("component").count().filter(F.col("count") > community_threshold).drop("count").write.mode("overwrite").parquet(base_path + "data/"+type_+"/spectral_analysis/cc_to_clean")
		vertices.groupby("component").count().filter(F.col("count") <= community_threshold).drop("count").write.mode("overwrite").parquet(base_path + "data/"+type_+"/spectral_analysis/cleaned_cc")
		cleaned_cc = spark.read.parquet(base_path + "data/"+type_+"/spectral_analysis/cleaned_cc")
		cleaned_cc.join(vertices , on = "component").write.mode("overwrite").parquet(base_path + "data/"+type_+"/spectral_analysis/cleaned_cc_with_ids")
		cc_to_clean = spark.read.parquet(base_path + "data/"+type_+"/spectral_analysis/cc_to_clean")
		cc_to_clean.join(vertices , on = "component").write.mode("overwrite").parquet(base_path + "data/"+type_+"/spectral_analysis/cc_to_clean_with_ids")
		cc_to_clean_with_ids = spark.read.parquet(base_path + "data/"+type_+"/spectral_analysis/cc_to_clean_with_ids")
		edges = edges.drop("component")
		cc_to_clean_with_ids.join(edges , [cc_to_clean_with_ids.id == edges.src] ).withColumnRenamed("component" , "src_component").write.mode("overwrite").parquet(base_path + "data/"+type_+"/spectral_analysis/cc_to_clean_with_src_edges")
		intermediate_edges = spark.read.parquet(base_path + "data/"+type_+"/spectral_analysis/cc_to_clean_with_src_edges")
		cc_to_clean_with_ids.join(intermediate_edges , [cc_to_clean_with_ids.id == edges.dst] ).withColumnRenamed("component" , "dst_component").write.mode("overwrite").parquet(base_path + "data/"+type_+"/spectral_analysis/cc_to_clean_with_dst_edges")
		edges_to_clean = spark.read.parquet(base_path + "data/"+type_+"/spectral_analysis/cc_to_clean_with_dst_edges")
		edges_to_clean.filter(F.col("src_component") == F.col("dst_component")).drop("dst_component").withColumnRenamed("src_component" , "component").write.mode("overwrite").parquet(base_path + "data/"+type_+"/spectral_analysis/edges_to_clean")
		edges_to_clean = spark.read.parquet(base_path + "data/"+type_+"/spectral_analysis/edges_to_clean")
		edges_groupby_path = prepareDataForSpectralCommunities(base_path ,edges_to_clean , type_ )
		edges_with_cc = spark.read.parquet(edges_groupby_path)
		schema = ArrayType(ArrayType(DoubleType()))
		
		spectralMapperGetModularityMatrix_udf = F.udf(lambda x : spectralMapperGetModularityMatrix(x) , schema)
		edges_with_cc.withColumn("modularity_matrix" , spectralMapperGetModularityMatrix_udf(F.col("edges"))).write.mode("overwrite").parquet(base_path + "data/"+type_+"/spectral_analysis/edges_with_modularity_matrix")
		edges_with_modularity_matrix = spark.read.parquet(base_path + "data/"+type_+"/spectral_analysis/edges_with_modularity_matrix")
		edges_with_modularity_matrix.withColumn("projection_matrix" , PassPrincpalCc1(principal_component)(F.col("modularity_matrix"))).write.mode("overwrite").parquet(base_path + "data/"+type_+"/spectral_analysis/edges_with_modularity_matrix")

		edges_with_projection_matrix = spark.read.parquet(base_path + "data/"+type_+"/spectral_analysis/edges_with_modularity_matrix")
		edges_with_projection_matrix.withColumn("final_edges" , PassPrincpalCc2(principal_component)(F.struct((F.col("projection_matrix") , F.col("edges"))))).select("old_component" , "final_edges").write.mode("overwrite").parquet(base_path + "data/"+type_+"/spectral_analysis/final_edges_with_cc")

		final_edges_with_cc = spark.read.parquet(base_path + "data/"+type_+"/spectral_analysis/final_edges_with_cc")
		final_edges = final_edges_with_cc.select(F.explode("edges").alias("edges")).rdd.map(lambda x : (x["edges"][0] , x["edges"][1])).toDF(["src" , "dst"])
		final_vertices = final_edges_with_cc.select("src").union(final_edges_with_cc.select("dst")).withColumnRenamed("src" , "id")
		graph = GraphFrame(final_vertices , final_edges)
		sc.setCheckpointDir(base_path + "data/"+type_+ "/checkpoint_dir_path")
		print("cc starting..")
		cc = graph.connectedComponents(algorithm = "graphframes", checkpointInterval = 2, broadcastThreshold = 10000)
		print("cc writing on cc_path...")
		cc.write.mode("overwrite").parquet(base_path + "data/"+type_+"/spectral_analysis/final_cc_created_after_linkage_removal")
		cc_to_clean.select("id").subtract(spark.read.parquet(base_path + "data/"+type_+"/spectral_analysis/final_cc_created_after_linkage_removal").select("id")).withColumn("component" , F.lit("id")).write.mode("overwrite").parquet(base_path + "data/"+type_+"/spectral_analysis/isolated_ids")
		spark.read.parquet(base_path + "data/"+type_+"/spectral_analysis/isolated_ids").select("component" , "id").union(spark.read.parquet(base_path + "data/"+type_+"/spectral_analysis/cleaned_cc_with_ids").select("component" , "id")).union(spark.read.parquet(base_path + "data/"+type_+"/spectral_analysis/final_cc_created_after_linkage_removal").select("component" , "id")).write.mode("overwrite").parquet(base_path + "data/"+type_+"/spectral_analysis/final_cc")
		final_cc = spark.read.parquet(base_path + "data/"+type_+"/spectral_analysis/final_cc")
	return base_path + "data/"+type_+"/spectral_analysis/final_cc"

