import psycopg2
import datetime
import time
from airflowutils import dpsutils


def getPostgresDbConnection(postgresql_host, postgresql_port, postgresql_user, postgresql_pw, postgresql_database, **kwargs):
    try:
        conn = psycopg2.connect(database=postgresql_database, user = postgresql_user, password = postgresql_pw, host = postgresql_host, port = int(postgresql_port))
        curs = conn.cursor()
    except (Exception, Error) as error:
        print("Error while connecting to PostgreSQL", error)
    return conn, curs

# def updateDsInputPath(version, job_status, table_name, curs):
#     query = f"UPDATE {table_name} SET status = '{job_status}' WHERE (version = '{version}' AND module = 'lq_snapshot')"
#     curs.execute(query)


def updatePreReportingOutputPath(region, version, lqEdgePath, lqVertexPath, postgresql_host, postgresql_port, postgresql_user, postgresql_password, postgresql_database, output_table, **kwargs):
    conn, curs = getPostgresDbConnection(postgresql_host, postgresql_port, postgresql_user, postgresql_password, postgresql_database)
    ts = int(round(time.time()))
    update_ts = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M')
    create_table_query = f"CREATE TABLE IF NOT EXISTS {output_table} (version TEXT, lqEdgePath TEXT, lqVertexPath TEXT, region TEXT, update_ts TEXT , status TEXT , dataframe_type TEXT)"
    curs.execute(create_table_query)
    query = f"INSERT INTO {output_table} (version, lqEdgePath, lqVertexPath, region, update_ts, status , dataframe_type) VALUES ('{version}', '{lqEdgePath}', '{lqVertexPath}', '{region}', '{update_ts}', 'INITIALIZED' , 'lqGraph')"
    curs.execute(query)
    conn.commit()


def updateDsOutputPath(region, version, edgeScoredPath, vertexScoredPath, postgresql_host, postgresql_port, postgresql_user, postgresql_password, postgresql_database, output_table_name_1, output_table_name_2, **kwargs):
    # current time stamp
    conn, curs = getPostgresDbConnection(postgresql_host, postgresql_port, postgresql_user, postgresql_password, postgresql_database)
    ts = int(round(time.time()))
    update_ts = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M')
    curs.execute(f"SELECT id  from {output_table_name_1} order by id desc LIMIT 1")
    result = curs.fetchone()
    biggest_id = 0
    for row in result:
        biggest_id = row + 1
    # table_creation_query = f'create table {output_table_name} (id SERIAL UNIQUE PRIMARY KEY, hdfs_path VARCHAR(255) NOT NULL, region VARCHAR(31) NOT NULL, graph_name VARCHAR(31) NOT NULL, source VARCHAR(31) NOT NULL, status VARCHAR(31) NOT NULL, quality VARCHAR(31) NOT NULL, create_ts timestamp NOT NULL, update_ts timestamp NOT NULL )'
    query = f"INSERT INTO {output_table_name_1} (id, create_ts, graph_name, status, hdfs_path, region, source, update_ts, quality) VALUES ({biggest_id} , '{update_ts}' , 'lqGraph' , 'INITIALIZED' , '{edgeScoredPath}' , '{region}' , 'ds_incremental_cleanup' , '{update_ts}', 'low')"
    # curs.execute(table_creation_query)
    curs.execute(query)

    create_table_query = f"CREATE TABLE IF NOT EXISTS {output_table_name_2} (version TEXT, edge_scored_path TEXT, vertex_scored_path TEXT, region TEXT, update_ts TEXT, status TEXT)"
    curs.execute(create_table_query)
    query = f"INSERT INTO {output_table_name_2} (version, edge_scored_path, vertex_scored_path, region, update_ts, status) VALUES ('{version}', '{edgeScoredPath}', '{vertexScoredPath}', '{region}', '{update_ts}', 'SUCCESS')"
    curs.execute(query)
    conn.commit()


def getPaths(region, postgresql_host, postgresql_port, postgresql_user, postgresql_password, postgresql_database, table_name1, table_name2 **kwargs):
    task_instance = kwargs['ti']
    conn, curs = getPostgresDbConnection(postgresql_host, postgresql_port, postgresql_user, postgresql_password, postgresql_database)
    ## fetch dp
    input_querry = f"SELECT dpscoredpath FROM {table_name2} where region = '{region}' order by update_ts desc limit 1"
    curs.execute(input_querry)
    result = curs.fetchone()
    dp_scored_path = result[0]
    task_instance.xcom_push(key = 'dp_scored_path', value = dp_scored_path)

    input_querry = f"SELECT version , edge_path , vertex_path , update_ts FROM {table_name1} where module = 'lq_snapshot' and graph_type = 'lqGraph' and region = '{region}' order by update_ts desc limit 1"
    curs.execute(input_querry)
    result = curs.fetchone()
    version = ""
    date = ""
    # print(result)
    if result:
        version = result[0]
        edge_path = result[1]
        vertex_path = result[2]
        date = result[3]
        task_instance.xcom_push(key = "edge_path", value = edge_path)
        task_instance.xcom_push(key = "vertex_path", value = vertex_path)

    if isinstance(date, datetime.date):
        date_string = date.__str__()
        date_list = date_string.split(' ')[0].split('-')
        date_string = f"yr={date_list[0]}/mon={date_list[1]}/dt={date_list[2]}"
        task_instance.xcom_push(key = 'date', value = date_string)
    else:
        date_list = date_string.split(' ')[0].split('-')
        date_string = f"yr={date_list[0]}/mon={date_list[1]}/dt={date_list[2]}"
        task_instance.xcom_push(key = 'date', value = date_string)
    task_instance.xcom_push(key = 'version', value = version)



def getConnectDbDetails(configApi, configType, **kwargs):
    task_instance = kwargs['ti']
    dbDetailsDict = dpsutils.getConfigs(configApi, configType)
    for key in dbDetailsDict:
        task_instance.xcom_push(key = key, value = dbDetailsDict[key])