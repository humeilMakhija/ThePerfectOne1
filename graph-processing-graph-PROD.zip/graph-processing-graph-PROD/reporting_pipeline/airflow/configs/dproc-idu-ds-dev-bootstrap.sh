#!/bin/bash
sudo /opt/conda/default/bin/pip install -U numpy;
sudo /opt/conda/default/bin/pip install networkx;
sudo /opt/conda/default/bin/pip install infomap;
