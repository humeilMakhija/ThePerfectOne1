from Helper.packages_ import *
def calculate(non_tube_dpid , DPS_dict):
    total=0
    dpid=non_tube_dpid
    for dp in dpid:
        try:
            total=total+DPS_dict[dp]
        except Exception as e:
            print(e)
    return total/len(dpid)

def scoring(final_data , DPS_dict, input_base_path  , spark , sc):
    edges_set = final_data.groupby("src" , "src_type" , "dst" , "dst_type").agg(F.collect_list("non_tube_dpid").alias("non_tube_dpid"))
    edges_set.write.mode("overwrite").parquet(input_base_path + "/dpid_list")
    edges_set = spark.read.parquet(input_base_path + "/dpid_list")
    edges_set_score = edges_set.rdd.map(lambda x: (x['src'] , x["src_type"] , x['dst'] , x["dst_type"] , calculate(x['non_tube_dpid'],DPS_dict))).toDF(["src_string_id" , "src_type" , "dst_string_id" , "dst_type" , "mDPscore"])
    edges_set_score.write.mode("overwrite").parquet(input_base_path + "/multiDpScore")
    return input_base_path + "/multiDpScore"



