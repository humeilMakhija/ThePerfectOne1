from Helper.packages_ import *
def expand(x):
    SRC=[]
    DST=[]
    Scores=[]
    for data in x['data']:
        SRC.append(data[0])
        DST.append(data[1])
        Scores.append(math.fabs(float(data[2])))
    return x['component'],SRC,DST,Scores


def norm(component , SRC , DST , Scores):
    max_score = np.max(Scores) 
    norm_scores=[float(s/max_score) for s in Scores]
    norm_edge_list=[]
    for i in range(0 , len(norm_scores)):
        norm_edge_list.append([SRC[i] , DST[i] , norm_scores[i]])
    return component , norm_edge_list

def splitter(x):
        src_id = ' '.join(x["norm_scores"][0].split(' ')[:-1])
        src_type = x["norm_scores"][0].split(' ')[-1]
        dst_id = ' '.join(x["norm_scores"][1].split(' ')[:-1])
        dst_type = x["norm_scores"][1].split(' ')[-1]
        return x["component"] , src_id , src_type , dst_id , dst_type , float(x["norm_scores"][2] )

def pathExistsCheck(path , spark , sc):
	fs = sc._jvm.org.apache.hadoop.fs.FileSystem.get(
		sc._jvm.java.net.URI.create("gs://" + path.split("/")[2]),
		sc._jsc.hadoopConfiguration(),
		)
	return fs.isDirectory(sc._jvm.org.apache.hadoop.fs.Path(path))
