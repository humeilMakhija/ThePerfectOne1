from Helper.packages_ import *
def laplacianGraph(edge_list):
    NXgraph = nx.Graph()
    for row in edge_list:
        source = row[0]
        dest = row[1]
        weight_ = float(row[2])
        NXgraph.add_edge(source , dest , weight=weight_)
    laplacianMatrix = laplacian_matrix(NXgraph,weight='weight')
    return NXgraph , laplacianMatrix

def calculateKI(x):
    NXgraph , laplacianMatrix = laplacianGraph(x['edge_list'])
    vertices_list = list(NXgraph.nodes)
    n = len(vertices_list)
    KI = []
    laplacianMatrix_ = csr_matrix(laplacianMatrix)
    ed = NXgraph.edges(data=True)
    for u,v,a in ed:
        weight_= a['weight']
        theta = 0.1
        theta_c = 1 - theta
        source = [[0]*n]
        dest = [[0]*n]
        source_index = vertices_list.index(u)
        dest_index = vertices_list.index(v)
        try:
            source[0][source_index] = 1
            dest[0][dest_index] = 1
        except:
            source_index = laplacianMatrix.shape[0]-(n-source_index)
            dest_index = laplacianMatrix-(n-dest_index)
            source[0][source_index] = 1
            dest[0][dest_index] = 1
        SBV = np.subtract(source,dest)
        SBVt = SBV.transpose()
        SBV = csr_matrix(SBV)
        SBVt = csr_matrix(SBVt)
        dot_ = np.dot(np.dot(laplacianMatrix_,SBVt),SBV)
        numerator = weight_ * np.dot(dot_ , laplacianMatrix_).diagonal().sum()
        denominator = 1-(theta_c * weight_ * dot_).diagonal().sum()
        deltaK = n * theta_c * numerator/denominator
        KI.append([u,v,float(deltaK)])
    return x["component"] , KI
