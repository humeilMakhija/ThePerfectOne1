from Helper.packages_ import *
from Helper.utils import expand
from Helper.utils import norm
from Helper.utils import splitter
from Structural.Calculator import laplacianGraph
from Structural.Calculator import calculateKI
    

def scoring(final_data , input_base_path , spark , sc):
    edges_ = final_data.withColumn("score", when(col("src_type") != col("dst_type"),0.35).otherwise(0.15))
    edges_.rdd.map(lambda x : ([x["src"] +" "+x["src_type"] ,x["dst"] +" "+ x["dst_type"] ,str(x["score"])] , x["component"])).toDF(["edge_data","component"]).distinct().write.mode("overwrite").parquet(input_base_path + "/laplacian_scoring/")
    edges_ = spark.read.parquet(input_base_path + "/laplacian_scoring/")

    edges_.groupby("component").agg(collect_list("edge_data").alias("edge_list")).write.mode("overwrite").parquet(input_base_path + "/edges_groupby_cc/")
    edges_filtered = spark.read.parquet(input_base_path + "/edges_groupby_cc/")
    
    edges_filtered.rdd.map(lambda x: calculateKI(x)).toDF(['component','data']).write.mode("overwrite").parquet(input_base_path + "/component_scores/")
    edges_KI = spark.read.parquet(input_base_path + "/component_scores/")

    edges_KI.rdd.map(lambda x: expand(x)).toDF(["component","SRC","DST","Scores"]).write.mode("overwrite").parquet(input_base_path + "/laplacian_scores/")
    laplacian_score = spark.read.parquet(input_base_path + "/laplacian_scores/")
    
    laplacian_score.rdd.map(lambda x: norm(x['component'],x['SRC'],x['DST'],x['Scores'])).toDF(["component","norm_scores"]).write.mode("overwrite").parquet(input_base_path + "/norm_laplacian_scores/")
    norm_laplacian_score = spark.read.parquet(input_base_path + "/norm_laplacian_scores/")
    df_exploded = norm_laplacian_score.select("component" , F.explode("norm_scores").alias("norm_scores"))
    
    df_exploded.rdd.map(lambda x: splitter(x)).toDF(["component" , "src_string_id" , "src_type" ,  "dst_string_id" , "dst_type" ,  "scores" ]).write.mode("overwrite").parquet(input_base_path + "/flattened_laplacian_score/")
    return input_base_path + "/flattened_laplacian_score/"







