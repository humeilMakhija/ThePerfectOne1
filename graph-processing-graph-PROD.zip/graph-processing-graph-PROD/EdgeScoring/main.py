from Helper.packages_ import *
from Structural.LaplacianCentrality import scoring as structuralScoring
from Metadata.MultiDpScores import scoring as metadataScoring
from Helper.utils import *

if __name__ == "__main__":
    spark = SparkSession.builder.appName("edge scoring").getOrCreate()
    sc = spark.sparkContext
    input_base_path = spark.conf.get("spark.input.basePath") ## gs://gcs-ireland-all-eu-idu-graph-zt/ds_input_processing/yr=2021/mon=05/dt=01/version=1619879963        
    output_scored_path = spark.conf.get("spark.output.edgeScoredPath") ## gs://gcs-ireland-all-eu-idu-graph-zt/ds_output/edgeScored/yr=2021/mon=05/dt=01/version=1619879963
    dpPath = spark.conf.get("spark.input.dpPath") ## this should be changed to sql path later 
    input_base_path = input_base_path + "/reporting_input_processing/edge_scoring/"
    traversible_edge_path = spark.conf.get("spark.input.basePath") + "/reporting_input_processing/data/incremental_cleaning/traversible_edges_with_cc"
    non_tube_edge_set_path = spark.conf.get("spark.input.idGraphEdgeSetPath") 
    # edge_tube_set_path = spark.conf.get("spark.input.basePath") + "/reporting_input_processing/dummy_tube__edge_set_path"
    # field = [StructField("vertex1", StringType(), True) , StructField("vertex2", StringType(), True) , StructField("vertex1Type", StringType(), True) , StructField("vertex2Type", StringType(), True)  , StructField("dpid", IntegerType(), True) , StructField("timestamp", LongType(), True)]
    # schema = StructType(field)
    # edge_tube = spark.createDataFrame(sc.emptyRDD(), schema)
    # edge_tube.write.mode("overwrite").parquet(edge_tube_set_path)

    edge_non_tube = spark.read.parquet(non_tube_edge_set_path)
    dp_scores = spark.read.parquet(dpPath).select('dpid','final_score_Scaled')
    DPS_dict = dp_scores.rdd.collectAsMap()

    traversible_edges = spark.read.parquet(traversible_edge_path)
    modified_traversible_edges = traversible_edges.select('component','src_string_id','dst_string_id','src_type','dst_type').withColumnRenamed("src_string_id","src").withColumnRenamed("dst_string_id","dst")
    # edge_tube = spark.read.parquet(edge_tube_set_path)
    edge_non_tube = spark.read.parquet(non_tube_edge_set_path)
    # edge_tube_modified = edge_tube.select('vertex1','vertex2','dpid','vertex1Type','vertex2Type').withColumnRenamed('vertex1','src').withColumnRenamed('vertex2','dst').withColumnRenamed('vertex1Type','src_type').withColumnRenamed('vertex2Type','dst_type')
    edge_non_tube_modified = edge_non_tube.select('vertex1','vertex2','dpid','vertex1Type','vertex2Type').withColumnRenamed('vertex1','src').withColumnRenamed('vertex2','dst').withColumnRenamed('vertex1Type','src_type').withColumnRenamed('vertex2Type','dst_type')

    # modified_traversible_edges.join(edge_tube_modified,(edge_tube_modified.src==modified_traversible_edges.src)&(edge_tube_modified.dst==modified_traversible_edges.dst)&(edge_tube_modified.src_type==modified_traversible_edges.src_type)&(edge_tube_modified.dst_type==modified_traversible_edges.dst_type),'left').drop(edge_tube_modified.src).drop(edge_tube_modified.dst).drop(edge_tube_modified.src_type).drop(edge_tube_modified.dst_type).withColumnRenamed("dpid","tube_dpid").fillna(0).write.mode("overwrite").parquet(input_base_path + "/dpid_join/intermediate_join")
    # intermediate_join = spark.read.parquet(input_base_path + "/dpid_join/intermediate_join")

    modified_traversible_edges.join(edge_non_tube_modified,(modified_traversible_edges.src==edge_non_tube_modified.src)&(modified_traversible_edges.dst==edge_non_tube_modified.dst)&(modified_traversible_edges.src_type==edge_non_tube_modified.src_type)&(modified_traversible_edges.dst_type==edge_non_tube_modified.dst_type),'left').drop(edge_non_tube_modified.src).drop(edge_non_tube_modified.dst).drop(edge_non_tube_modified.src_type).drop(edge_non_tube_modified.dst_type).withColumnRenamed("dpid","non_tube_dpid").fillna(0).write.mode("overwrite").parquet(input_base_path + "/dpid_join/final_dpid_join")
    final_data = spark.read.parquet(input_base_path + "/dpid_join/final_dpid_join")

    structural_score_path = structuralScoring(final_data , input_base_path , spark , sc)
    structural_score = spark.read.parquet(structural_score_path)

    metadata_score_path = metadataScoring(final_data , DPS_dict , input_base_path , spark , sc)
    metadata_score = spark.read.parquet(metadata_score_path)

    structural_score.join(metadata_score , on = ['src_string_id', 'src_type', 'dst_string_id', 'dst_type']).drop("component").write.mode("overwrite").parquet(input_base_path + "/combined_scores_path1")
    combined_scores1 = spark.read.parquet(input_base_path + "/combined_scores_path1").select("src_string_id" , "src_type" , "dst_string_id" , "dst_type" , "mDPscore" , "scores")
    structural_score.join(metadata_score , [structural_score["src_string_id"] == metadata_score["dst_string_id"] , structural_score["src_type"] == metadata_score["dst_type"] , structural_score["dst_string_id"] == metadata_score["src_string_id"] , structural_score["dst_type"] == metadata_score["src_type"]]).drop(structural_score.component).drop(structural_score.src_string_id).drop(structural_score.src_type).drop(structural_score.dst_string_id).drop(structural_score.dst_type).write.mode("overwrite").parquet(input_base_path + "/combined_scores_path2")
    combined_scores2 = spark.read.parquet(input_base_path + "/combined_scores_path2").select("src_string_id" , "src_type" , "dst_string_id" , "dst_type" , "mDPscore" , "scores")

    combined_scores1.union(combined_scores2).write.mode("overwrite").parquet(input_base_path + "/combined_scores_path")
    combined_scores = spark.read.parquet(input_base_path + "/combined_scores_path")
    combined_scores.rdd.map(lambda x: (x['src_string_id'] , x["src_type"] ,  x['dst_string_id'], x["dst_type"] , (float(x['mDPscore'])*float(x['scores'])))).toDF(['src_string_id', 'src_type', 'dst_string_id', 'dst_type' ,"final_score"]).dropDuplicates().write.mode("overwrite").parquet(input_base_path + "/final_scores_path")
    final_scores = spark.read.parquet(input_base_path + "/final_scores_path")

    modified_traversible_edges = traversible_edges.select('src_string_id','dst_string_id','src_type','dst_type')
    modified_traversible_edges.join(final_scores, on = ['src_string_id','dst_string_id','src_type','dst_type']).dropDuplicates().withColumnRenamed("final_score","quality").write.mode("overwrite").parquet(input_base_path + "/final_data_with_scores_path")

    final = spark.read.parquet(input_base_path + "/final_data_with_scores_path").drop("component" , "graph_type_flag")

    output_scored_df = spark.read.parquet(output_scored_path).drop("quality")
    output_scored_df.join(final , [output_scored_df.vertex1 == final.src_string_id , output_scored_df.vertex2 == final.dst_string_id , output_scored_df.vertex1Type == final.src_type , output_scored_df.vertex2Type == final.dst_type ] ).drop("src_string_id" , "dst_string_id" , "dst_type"  ,"src_type").write.mode("overwrite").parquet(input_base_path + "/final_updated_scores")
    
    spark.read.parquet(input_base_path + "/final_updated_scores").filter(F.col("quality") > 0.0).write.mode("overwrite").parquet(output_scored_path)
    ## end of code







    
