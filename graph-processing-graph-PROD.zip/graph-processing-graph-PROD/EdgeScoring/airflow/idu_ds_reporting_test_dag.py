from airflow import DAG
from airflow.contrib.operators.slack_webhook_operator import SlackWebhookOperator
from airflow.hooks.base_hook import BaseHook
from airflow.operators.python_operator import PythonOperator, BranchPythonOperator 
from airflow.operators.http_operator import SimpleHttpOperator
from airflow.contrib.operators.dataproc_operator import DataprocClusterDeleteOperator
from airflow.operators.bash_operator import BashOperator
from airflowutils import dpsutils
from datetime import datetime
from idu_scripts import idu_ds_reporting_scripts
from airflowutils import computeinstanceutils
def sendSlackAlert(context):
	# slack_msg = """
	#             :red_circle: Task Failed.
	#             *Task*: {task}
	#             *Dag*: {dag}
	#             *Execution Time*: {exec_date}
	#             *Run ID*: {run_id}
	#             *Log Url*: {log_url}
	#             """.format(task = context.get("task_instance").task_id,
	#                        dag = context.get("task_instance").dag_id,
	#                        exec_date = context.get("execution_date"),
	#                        run_id = context.get("run_id"),
	#                        log_url = context.get("task_instance").log_url)
	#
	# sendSlackMessage = SlackWebhookOperator(
	#     task_id = "sendSlackAlert",
	#     message = slack_msg,
	#     http_conn_id = "idu_ds_alerts",
	#     dag = dag
	# )
	#
	# return sendSlackMessage.execute(context = context)
    print("slack alerts")
args = {
	'start_date': datetime(2020, 1, 1),
	'email': ['humeil.makhija@zeotap.com'],
	'email_on_failure': True,
	'provide_context': True,
	'on_failure_callback': sendSlackAlert
}


dag = DAG(
	dag_id='idu_ds_reporting_test_dag',
	default_args=args,
	schedule_interval=None,
)


configSvcConnection = BaseHook.get_connection('configSvc')
configSvcEndpoint = "http://" + configSvcConnection.host + ':' + str(configSvcConnection.port)
uriSeparator = '/'

iduDsConfigServiceNamespace = 'idu_ds_reporting'

dpsConnection = BaseHook.get_connection('dps')
dpsEndpoint = "http://" + dpsConnection.host + ':' + str(dpsConnection.port)

master_machine_type = "n1-highmem-4"
worker_machine_type = "n1-highmem-8"
project_id = "zeotap-dev-datascience"
num_secondary_workers = 75

uri = "gs"
# regionList = ["eu", "in"]
regionList = ["eu"]
workflow_type_ = "Incremental"

propsDict = {
	"eu": {
		"iduIncrementalBucket": "ireland-all-eu-datascience-adhoc-internal-zeotap-com",
		# "iduBucket": "gcs-ireland-all-eu-idu-graph-zt",
		"cluster_region": "europe-west1",
		"zone": "europe-west1-b", ## "europe-west1-c",
		"subnet": "dev-datascience-pvt-eu-ws1-subnet" ## "prod-datascience-pvt-eu-ws1-subnet"
},
	"in": {
		"iduIncrementalBucket": "gcs-datascience-adhoc-in",
		# "iduBucket": "gcs-mumbai-all-in-idu-graph-zt",
		"cluster_region": "asia-south1",
		"zone": "asia-south1-a",
		"subnet": "dev-datascience-pvt-ap-st1-subnet"
	}
}

for region in regionList:
	# fetchDbDetailsfromConfigService = PythonOperator(
	# 	task_id = f"fetchDbDetailsfromConfigService_{region}",
	# 	python_callable = idu_ds_reporting_scripts.getConnectDbDetails,
	# 	op_kwargs = {
	# 		'configApi': uriSeparator.join([configSvcEndpoint, iduDsConfigServiceNamespace, 'db_details', 'properties']),
	# 		'configType': "map",
	# 	},
	# 	provide_context = True, ## check this 
	# 	dag = dag
	# )

	# fetchPathsForReportingTask = PythonOperator(
	# 	task_id=f"fetchPathsForReportingTask_{region}",
	# 	python_callable = idu_ds_reporting_scripts.getPaths,
	# 	op_kwargs = {
	# 		'region': region,
	# 		'postgresql_host' : f'{{{{ti.xcom_pull(task_ids="fetchDbDetailsfromConfigService_{region}" , key="postgresql_host") }}}}',
	# 		'postgresql_port' : f'{{{{ti.xcom_pull(task_ids="fetchDbDetailsfromConfigService_{region}" , key="postgresql_port") }}}}',
	# 		'postgresql_user' : f'{{{{ti.xcom_pull(task_ids="fetchDbDetailsfromConfigService_{region}" , key="postgresql_user") }}}}',
	# 		'postgresql_password' : f'{{{{ti.xcom_pull(task_ids="fetchDbDetailsfromConfigService_{region}" , key="postgresql_pw") }}}}',
	# 		'postgresql_database' : f'{{{{ti.xcom_pull(task_ids="fetchDbDetailsfromConfigService_{region}" , key="postgresql_database") }}}}',
	# 		'table_name' : 'idu_paths_registry' ,##'idu_paths_registry'
	# 	},
	# 	provide_context = True,
	# 	dag = dag
	# )
	# def branchWhetherDsReportingToBeRun(version , **kwargs):
	# 	print(version)
	# 	if version is None or version == "" or version == " " or version == 'None':
	# 		return []
	# 	else:
	# 		return [f"createDataprocCluster_{region}"]

	# branchWhetherDsScoringToBeRunTask = BranchPythonOperator(
	# 	task_id = f'branchWhetherDsReportingToBeRunTask_{region}',
	# 	python_callable = branchWhetherDsReportingToBeRun,
	# 	op_kwargs = {
	# 		'version': f'{{{{ti.xcom_pull(task_ids="fetchPathsForReportingTask_{region}", key="version")}}}}',
	# 	},
	# 	provide_context = True,
	# 	dag=dag
	# )

	# regionPropsDict = propsDict[region]
	# cluster_region = regionPropsDict["cluster_region"]
	# zone = regionPropsDict["zone"]
	# subnet = regionPropsDict["subnet"]
	# cluster_name = f"dproc-idu-ds-incremental-dev-{region}"
	# service_account = f"dproc-datascience-dev-{region}@zeotap-dev-datascience.iam.gserviceaccount.com"

	# getCluster_command = """
	#  gcloud beta dataproc clusters create "{{ params.cluster_name }}" \
	# --service-account "{{ params.service_account }}" \
	# --project "{{ params.project_id }}" \
	# --region "{{ params.region }}" \
	# --subnet "{{ params.subnet }}" \
	# --zone "{{ params.zone }}" \
	# --enable-component-gateway \
	# --bucket gcs-dproc-{{ params.project_id }}-logs-{{ params.region }} \
	# --no-address \
	# --master-machine-type "{{ params.master_machine_type }}" --master-boot-disk-size 500 \
	# --num-workers 2 --num-secondary-workers "{{ params.num_secondary_workers }}" --worker-machine-type "{{ params.worker_machine_type }}" --worker-boot-disk-size 200 --secondary-worker-boot-disk-size 200 --num-worker-local-ssds 2 \
	# --image-version 2.0.0-RC9-debian10 \
	# --scopes 'https://www.googleapis.com/auth/cloud-platform' \
	# --labels team=data-science,owner=humeil-makhija,role=dproc,application=idu-ds,environment=prod,monitoring=no \
	# --tags dproc,{{ params.cluster_name }} \
	# --autoscaling-policy dproc-general-autoscaling-policy \
	# --initialization-actions gs://gcs-dproc-{{ params.project_id }}-initialization_actions/livy_0.5.0.sh,gs://gcs-dproc-{{ params.project_id }}-initialization_actions/dproc-idu-ds-dev-bootstrap.sh \
	# --properties dataproc:secondary-workers.preemptible=false \
	# --quiet \
	# """

	# createDataprocCluster = BashOperator(
	# 	task_id=f'createDataprocCluster_{region}',
	# 	bash_command=getCluster_command,
	# 	params={'cluster_name': cluster_name,
	# 			'service_account': service_account,
	# 			'project_id': project_id,
	# 			'region': cluster_region,
	# 			'subnet': subnet,
	# 			'zone': zone,
	# 			'num_secondary_workers': num_secondary_workers,
	# 			'master_machine_type': master_machine_type,
	# 			'worker_machine_type': worker_machine_type
	# 			},
	# 	xcom_push=True,
	# 	dag=dag
	# )
	cluster_name = f'dproc-datascience-dev-{region}'
	zone = 'europe-west1-d'
	getClusterIp = PythonOperator(
		task_id = f"getClusterIp_{region}",
		python_callable = computeinstanceutils.getInstanceIp,
		op_kwargs = {
			'instance': f'{cluster_name}-m',
			'zone' : zone
		},
		provide_context = True,
		dag = dag
	)
	clusterIp = f'{{{{ ti.xcom_pull(task_ids="getClusterIp_{region}") }}}}'
	livyUrl = f"http://{clusterIp}:8998"

	# versionDateSuffix = f'{{{{ ti.xcom_pull(task_ids="fetchPathsForReportingTask_{region}", key="date") }}}}' + '/version=' + f'{{{{ ti.xcom_pull(task_ids="fetchPathsForReportingTask_{region}", key="version") }}}}'
	# regionBucket = regionPropsDict["iduIncrementalBucket"]

	# PreReportingTask = PythonOperator(
	# 	task_id=f"PreReportingTask_{region}",
	# 	python_callable=dpsutils.launchAndPollDpsJob,
	# 	op_kwargs={
	# 		'runtimePropsDict': {
	# 			'livyUrl': livyUrl,
	# 			'spark.region': region,
	# 			'spark.input.lqSnapshot.verticesPath': f'{{{{ ti.xcom_pull(task_ids="fetchPathsForReportingTask_{region}" , key = "vertex_path") }}}}',
	# 			'spark.input.lqSnapshot.edgesPath': f'{{{{ ti.xcom_pull(task_ids="fetchPathsForReportingTask_{region}" , key = "edge_path") }}}}',
	# 			'spark.input.basePath': f'{uri}://{regionBucket}/humeil/incremental_cleaning/' + versionDateSuffix,
	# 			'spark.input.idGraphEdgePath' : f'{uri}://{regionBucket}/humeil/incremental_cleaning/lqGraph/edge/' + versionDateSuffix,
	# 			'spark.input.idGraphVertexPath' : f'{uri}://{regionBucket}/humeil/incremental_cleaning/lqGraph/vertex/' + versionDateSuffix,
	# 		},
	# 		'configServiceEndpoint': uriSeparator.join([configSvcEndpoint,
	# 													iduDsConfigServiceNamespace,
	# 													'all',
	# 													region,
	# 													'Pre_incremental_cleaning',
	# 													'livy',
	# 													'jobProperties']),
	# 		'jobType': 'livy',
	# 		'jobName': 'Pre_ReportingTask',
	# 		'dpsEndpoint': dpsEndpoint,
	# 		'sourceComponentName': 'Pre_ReportingTask'
	# 	},
	# 	provide_context=True,
	# 	dag=dag
	# )

	# ReportingTask = PythonOperator(
	# 	task_id=f"ReportingTask_{region}",
	# 	python_callable=dpsutils.launchAndPollDpsJob,
	# 	op_kwargs={
	# 		'runtimePropsDict': {
	# 			'livyUrl': livyUrl,
	# 			'spark.region': region,
	# 			'spark.input.basePath': 'gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/humeil/graph/incremental_testing_test1/',
	# 			'spark.input.idGraphEdgePath': 'gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/humeil/graph/incremental_testing_test1/lqGraph/edge',
	# 			'spark.input.idGraphVertexPath': 'gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/humeil/graph/incremental_testing_test1/lqGraph/vertex',
	# 			'spark.output.EdgePath' : 'gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/humeil/graph/incremental_testing_test1/reporting_output/edge',
	# 			'spark.output.vertexPath' : 'gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/humeil/graph/incremental_testing_test1/reporting_output/vertex',
	# 			'spark.processedCountriesPath': 'gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/humeil/graph/incremental_testing_test1/processedCountriesPath',
	# 			'spark.output.thresholdForCc': 2000,
	# 		},
	# 		'configServiceEndpoint': uriSeparator.join([configSvcEndpoint,
	# 													iduDsConfigServiceNamespace,
	# 													'all',
	# 													region,
	# 													'incremental_cleaning',
	# 													'livy',
	# 													'jobProperties']),
	# 		'jobType': 'livy',
	# 		'jobName': 'ReportingTask',
	# 		'dpsEndpoint': dpsEndpoint,
	# 		'sourceComponentName': 'incremental_cleaning'
	# 	},
	# 	provide_context=True,
	# 	dag=dag
	# )
 
	# VertexScoringTask = PythonOperator(
	# 	task_id=f"VertexScoringTask_{region}",
	# 	python_callable=dpsutils.launchAndPollDpsJob,
	# 	op_kwargs={
	# 		'runtimePropsDict': {
	# 		'livyUrl': livyUrl,
	# 		'spark.region': region,
	# 		'spark.input.nontubeEdgeSetPath':  'gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/humeil/graph/incremental_testing_test1/lqGraph/edge',
	# 		'spark.input.nonTubeVertexSetPath' :'gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/humeil/graph/incremental_testing_test1/lqGraph/vertex',
	# 		'spark.input.basePath': 'gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/humeil/graph/incremental_testing_test1/',
	# 		'spark.output.scoredPath': 'gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/humeil/graph/incremental_testing_test1/reporting_output/vertex',
	# 		'spark.processedCountriesPath':'gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/humeil/graph/incremental_testing_test1/processedCountriesPath',
	# 		'spark.input.dpidScoredPath': 'gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/graph/cleanup/country=ALL/Prudhvi/DP_scoring/all_countries_dpid_scores_with_final_scores',
	# 		'spark.input.type' : workflow_type_,
	# 		},
	# 		'configServiceEndpoint': uriSeparator.join([configSvcEndpoint,
	# 													iduDsConfigServiceNamespace,
	# 													'all',
	# 													region,
	# 													'vertex_score',
	# 													'livy',
	# 													'jobProperties']),
	# 		'jobType': 'livy',
	# 		'jobName': 'vertex_score',
	# 		'dpsEndpoint': dpsEndpoint,
	# 		'sourceComponentName': 'vertex_score'
	# 	},
	# 	provide_context=True,
	# 	dag=dag
	# )
	
	edgeScoringTask = PythonOperator(
			task_id=f"edgeScoringTask_{region}",
			python_callable=dpsutils.launchAndPollDpsJob,
			op_kwargs={
				'runtimePropsDict': {
				'livyUrl': livyUrl,
				'spark.region': region,
				'spark.input.idGraphEdgeSetPath': 'gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/humeil/graph/incremental_testing_test1/lqGraph/edge',
				'spark.input.basePath': 'gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/humeil/graph/incremental_testing_test1/',
				'spark.output.edgeScoredPath': 'gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/humeil/graph/incremental_testing_test1/reporting_output/edge',
				'spark.processedCountriesPath':'gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/humeil/graph/incremental_testing_test1/processedCountriesPath',
				'spark.input.dpPath': 'gs://ireland-all-eu-datascience-adhoc-internal-zeotap-com/graph/cleanup/country=ALL/Prudhvi/DP_scoring/all_countries_dpid_scores_with_final_scores',
				'spark.input.type' : workflow_type_,
				},
			'configServiceEndpoint': uriSeparator.join([configSvcEndpoint,
														iduDsConfigServiceNamespace,
														'all',
														region,
														'edge_score',
														'livy',
														'ssc']),
				'jobType': 'livy',
				'jobName': 'edge_score',
				'dpsEndpoint': dpsEndpoint,
				'sourceComponentName': 'edge_score'
			},
			provide_context=True,
			dag=dag
	)
	getClusterIp >> edgeScoringTask

	# 	def check_dropout(base_path , threshold , region , **kwargs):
	# 	task_instance = kwargs['ti']
	# 	bucket_name = base_path.split('/')[0]
	# 	sub_dir_path = "/".join(base_path.split('/')[1:])
	# 	def _item_to_value(iterator, item):
	# 		return item
	# 	def list_directories(bucket_name, prefix):
	# 		if prefix and not prefix.endswith('/'):
	# 			prefix += '/'
	# 			extra_params = {
	# 			"projection": "noAcl",
	# 			"prefix": prefix,
	# 			"delimiter": '/'
	# 		}
	# 		gcs = storage.Client()
	# 		path = "/b/" + bucket_name + "/o"
	# 		iterator = page_iterator.HTTPIterator(
	# 			client=gcs,
	# 			api_request=gcs._connection.api_request,
	# 			path=path,
	# 			items_key='prefixes',
	# 			item_to_value=_item_to_value,
	# 			extra_params=extra_params,
	# 		)
	# 		return [x for x in iterator]
	# 	data = list(map(lambda x : x.split('/')[-2].split('=')[-1] , list_directories(bucket_name , sub_dir_path)))
	# 	# task_instance.xcom_push(key = "country_list" , value = data)
	# 	gcloud_object = GoogleCloudStorageHook(google_cloud_storage_conn_id='google_cloud_default')
	# 	flagged_country_list = []
	# 	for country in data:
	# 		files = gcloud_object.list(bucket_name , prefix=sub_dir_path + '/country='+country+'/data/incremental_cleaning/dropout_info')
	# 		li = []
	# 		for i in files:
	# 			if i.endswith('json'):
	# 				li.append(codecs.decode(gcloud_object.download(bucket_name , i) , encoding='utf-8', errors='ignore'))
	# 			if json.loads(li[0])['percentage_of_edges_removed'] > threshold:
	# 				flagged_country_list.append(country)
	# 	if len(flagged_country_list) > 0:
	# 		task_instance.xcom_push(key = "country_list" , value = flagged_country_list)
	# 		return f'send_email_task_{region}'
	# 	else:
	# 		return f'do_nothing_task_{region}'

	# get_dropout_countries = BranchPythonOperator(
	# 	task_id = f'get_dropout_countries_{region}',
	# 	python_callable = check_dropout,
	# 	op_kwargs = {
	# 		'base_path' : f'{regionBucket}/humeil/ds_reporting_input_processing/' + edgeVersionDateSuffix,
	# 		'threshold' : threshold_for_drop,
	# 		'region' : region,
	# 	},
	# 	provide_context = True,
	# 	dag = dag
 #        )

	# email_task = EmailOperator(
	# 		task_id=f'send_email_task_{region}',
	# 		to='humeil.makhija@zeotap.com',
	# 		subject='drop is below theshold',
	# 		html_content=f""" <h3>idu ds scoring task data drop is greater than {threshold_for_drop} % for countries in {{{{ti.xcom_pull(task_ids="get_dropout_countries_{region}", key='country_list')}}}} </h3> """,
	# 		dag=dag
	# 	)
	# do_nothing_task = DummyOperator(task_id='do_nothing_task', dag=dag)



	# updateInputOutputPathsTask = PythonOperator(
	# 	task_id=f"updateInputOutputPathsTask_{region}",
	# 	python_callable = idu_ds_reporting_scripts.updateDsOutputPath,
	# 	op_kwargs = {
	# 		'region': region,
	# 		'version': f'{{{{ ti.xcom_pull(task_ids="fetchPathsForReportingTask_{region}", key="version") }}}}',
	# 		'edgeScoredPath': f'{uri}://{regionBucket}/humeil/ds_reporting_output/edgeScored/' + versionDateSuffix,
	# 		'vertexScoredPath': f'{uri}://{regionBucket}/humeil/ds_reporting_output/vertexScored/' + versionDateSuffix,
	# 		'postgresql_host' : f'{{{{ti.xcom_pull(task_ids="fetchDbDetailsfromConfigService_{region}" , key="postgresql_host") }}}}',
	# 		'postgresql_port' : f'{{{{ti.xcom_pull(task_ids="fetchDbDetailsfromConfigService_{region}" , key="postgresql_port") }}}}',
	# 		'postgresql_user' : f'{{{{ti.xcom_pull(task_ids="fetchDbDetailsfromConfigService_{region}" , key="postgresql_user") }}}}',
	# 		'postgresql_password' : f'{{{{ti.xcom_pull(task_ids="fetchDbDetailsfromConfigService_{region}" , key="postgresql_pw") }}}}',
	# 		'postgresql_database' : f'{{{{ti.xcom_pull(task_ids="fetchDbDetailsfromConfigService_{region}" , key="postgresql_database") }}}}',
	# 		'output_table_name_1': 'del_paths',
	# 		'output_table_name_2': 'ds_incremental_flow',
	# 		},
			
	# 	provide_context = True,
	# 	dag = dag
	# )

	# deleteDataprocCluster =  DataprocClusterDeleteOperator(
 #        task_id=f"deleteDataprocCluster_{region}",
 #        cluster_name=cluster_name,
 #        project_id=project_id,
 #        region=cluster_region,
 #        dag=dag
 #    )








